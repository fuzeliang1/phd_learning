# - Try to find gomp (openMP)
# Once done, this will define
#
#  gomp_FOUND - system has gomp
#  gomp_INCLUDE_DIRS - the gomp include directories
#  gomp_LIBRARIES - link these to use gomp

include(LibFindMacros)

# Dependencies
# libfind_package( gomp gomp_depend )

# Use pkg-config to get hints about paths
libfind_pkg_check_modules( gomp_PKGCONF gomp )

# Include dir
find_path( gomp_INCLUDE_DIR
	NAMES omp.h
	PATHS
		${gomp_PKGCONF_INCLUDE_DIRS}
		${CMAKE_INCLUDE_PATH}
		c:/mingw/include
		C:/MinGW/lib/gcc/mingw32/4.5.0/include
)

# Finally the library itself
find_library( gomp_LIBRARY
	NAMES gomp
	PATHS
		${gomp_PKGCONF_LIBRARY_DIRS}
		${CMAKE_LIBRARY_PATH}
		c:/mingw/lib
		C:/MinGW/lib/gcc/mingw32/4.5.0
)

# Set the include dir variables and the libraries and let libfind_process do the rest.
# NOTE: Singular variables for this library, plural for libraries this this lib depends on.
set( gomp_PROCESS_INCLUDES gomp_INCLUDE_DIR)
set( gomp_PROCESS_LIBS gomp_LIBRARY)
libfind_process( gomp )

