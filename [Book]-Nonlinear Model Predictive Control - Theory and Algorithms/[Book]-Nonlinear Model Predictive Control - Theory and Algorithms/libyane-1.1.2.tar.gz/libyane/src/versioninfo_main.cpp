/***************************************************************************
 *                                                                         *
 * Interface Library for Minimizer NLPQLP                                  *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
  @author Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>
 */

#include "yane/version.h"
#include <iostream>

using namespace libyane;

int main()
{
	std::cout << "This is " << name() << " v" << version() << " built " << buildTimeStamp() << std::endl;
	return 0;
}
