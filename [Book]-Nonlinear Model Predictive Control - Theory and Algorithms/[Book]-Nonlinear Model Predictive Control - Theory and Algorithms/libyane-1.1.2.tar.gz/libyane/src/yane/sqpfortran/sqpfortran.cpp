/***************************************************************************
 *                                                                         *
 * Interface Library for Minimizer NLPQLP                                  *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>             *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "sqpfortran.h"

#include <yane/utils.h>
#include <yane/minprog.h>

#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cfloat>
#include <iostream>
#include <sstream>

#include "libexport.h"

using namespace std;
using namespace yane::MinProg;

extern "C"
{
	void ql_ ( int * M, int * ME, int * MMAX, int * N, int * NMAX, int * MNN,
			   double * C, double * D, double * A, double * B, double * XL, double * XU,
			   double * X, double * U, double * EPS, int * MODE, int * IOUT, int * IFAIL,
			   int * IPRINT, double * WAR, int * LWAR, int * IWAR, int * LIWAR );
	void nlpqlp_ ( int * L, int * M, int * ME, int * MMAX, int * N, int * NMAX,
				   int * MNN2, double * X, double * F, double * G, double * DF, double * DG,
				   double * U, double * XL, double * XU, double * C, double * D, double * ACC,
				   double * ACCQP, double * STPMIN, int * MAXFUN, int * MAXIT, int * MAX_NM,
				   double * TOL_NM, int * IPRINT, int * MODE, int * IOUT, int * IFAIL,
				   double * WA, int * LWA, int * KWA, int * LKWA, int * ACTIVE, int * LACTIV,
				   int * LQL,
				   void ( *QPSOLVE ) ( int * M, int * ME, int * MMAX, int * N, int * NMAX, int * MNN,
									   double * C, double * D, double * A, double * B, double * XL, double * XU,
									   double * X, double * U, double * EPS, int * MODE, int * IOUT, int * IFAIL,
									   int * IPRINT, double * WAR, int * LWAR, int * IWAR, int * LIWAR ) );
}

LIB_EXPORT yane::SqpFortran::SqpFortran::SqpFortran() :
		yane::MinProg::NLP()
{
	_x = 0;
	_gvalue1 = 0;
	_gvalue2 = 0;
	_g = 0;
	_df = 0;
	_dg = 0;
	_u = 0;
	_c = 0;
	_d = 0;
	_wa = 0;
	_kwa = 0;
	_active = 0;

	setDefaultConfig();
}

LIB_EXPORT yane::SqpFortran::SqpFortran::SqpFortran ( int n, T_FUNC func, T_FUNC rest, int nrest, int nrest_eq, T_FUNC df, T_FUNC dg ) :
		yane::MinProg::NLP()
{
	_x = 0;
	_gvalue1 = 0;
	_gvalue2 = 0;
	_g = 0;
	_df = 0;
	_dg = 0;
	_u = 0;
	_c = 0;
	_d = 0;
	_wa = 0;
	_kwa = 0;
	_active = 0;

	setDefaultConfig();
	try
	{
		init ( n, func, rest, nrest, nrest_eq, df, dg );
	}
	catch ( yane::Utils::MemoryException e )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "memory-allocation failure during initialization" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "undefined failure occured" ), __DEBUGMESS ( "Minimizer could not be initialized due to undefines failure" ), &e );
	}
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::init ( int n, T_FUNC func, T_FUNC rest, int nrest, int nrest_eq, T_FUNC df, T_FUNC dg )
{
	try
	{
		yane::MinProg::NLP::init ( n, func, rest, nrest, nrest_eq, df, dg );
	}
	catch ( yane::Utils::MemoryException e )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "memory-allocation failure during initialization" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "undefined failure occured" ), __DEBUGMESS ( "Minimizer could not be initialized due to undefines failure" ), &e );
	}

	freememory();

	_nmax = _dimension + 1;
	_mmax = max ( _dimension_rest, 1 );
	_mnn2 = _dimension_rest + 2 * _dimension + 2;

	_lwa = 23 * _dimension + 4 * _dimension_rest + 3 * _mmax + 150 + 3 * _nmax * _nmax / 2 + 10 * _nmax + _mmax + _dimension_rest + 1;
	_lkwa = _dimension + 10;
	_lactive = 2 * _dimension_rest + 10;

	try
	{
		_x = new double[_nmax];
		_gvalue1 = new double[_dimension_rest];
		_gvalue2 = new double[_dimension_rest];
		_g = new double[_mmax];
		_df = new double[_nmax];
		_dg = new double[_nmax*_mmax];
		_u = new double[_mnn2];
		_c = new double[_nmax*_nmax];
		_d = new double[_nmax];
		_wa = new double[_lwa];
		_kwa = new int[_lkwa];
		_active = new int[_lactive];
		if ( restr_params != 0 )
		{
			if ( restr_params->active != 0 ) delete[] restr_params->active;
			restr_params->active = _active;
		}
//   if ( restr_params != 0 )
//   {
//    if ( restr_params->active != 0 ) delete[] restr_params->active;
//    restr_params->active = new int[_lactive];
//    _active = restr_params->active;
//   }
//   else
//   {
//    _active = new int[_lactive];
//   }
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "Memory allocation error occured" ) );
	}
}

LIB_EXPORT yane::SqpFortran::SqpFortran::~SqpFortran()
{
	freememory();
}

void yane::SqpFortran::SqpFortran::freememory()
{
	if ( _x != 0 ) delete[] _x;
	if ( _gvalue1 != 0 ) delete[] _gvalue1;
	if ( _gvalue2 != 0 ) delete[] _gvalue2;
	if ( _g  != 0 ) delete[] _g;
	if ( _df != 0 ) delete[] _df;
	if ( _dg != 0 ) delete[] _dg;
	if ( _u != 0 ) delete[] _u;
	if ( _c != 0 ) delete[] _c;
	if ( _d != 0 ) delete[] _d;
	if ( _wa != 0 ) delete[] _wa;
	if ( _kwa != 0 ) delete[] _kwa;
	if ( restr_params != 0 )
	{
		if ( restr_params->active != 0 )
		{
			delete[] restr_params->active;
			restr_params->active = 0;
			_active = 0;
		}
	}

	_x = 0;
	_gvalue1 = 0;
	_gvalue2 = 0;
	_g = 0;
	_df = 0;
	_dg = 0;
	_u = 0;
	_c = 0;
	_d = 0;
	_wa = 0;
	_kwa = 0;
	_active = 0;
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::calcMin ( double * x, double * fx, double * lb, double * ub, double * rpar, int * ipar )
{
	int i = 0;

	func_params->abort = false;
	_clock->reset();

	memcpy ( _x, x, sizeof ( double ) * _dimension );
	_x[_dimension] = 0.0;

	func_params->rpar = rpar;
	func_params->ipar = ipar;

	restr_params->rpar = rpar;
	restr_params->ipar = ipar;

	memset ( _active, 1, sizeof ( int ) *_dimension_rest );

	_ifail = 0;

	try
	{
		evalFunctions();
		evalGradients();

	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating function values caused an error" ), &e );
	}

	do
	{
		if ( _ifail != 0 )
		{
			if ( _ifail == -1 )
			{
				try
				{
					evalFunctions();
				}
				catch ( yane::Utils::Exception e )
				{
					throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating function values caused an error" ), &e );
				}
			}
			else
			{
				try
				{
					evalGradients();
				}
				catch ( yane::Utils::Exception e )
				{
					throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating gradient values caused an error" ), &e );
				}
			}
		}

		nlpqlp_ ( &_l, &_dimension_rest, &_dimension_resteq, &_dimension_rest, &_dimension,
				  &_nmax, &_mnn2, _x, &_f, _g, _df, _dg, _u, lb, ub, _c, _d, &_accuracy, &_accql,
				  &_stepmin, &_maxfun, &_maxit, &_max_nm, &_tol_nm, &_iprint, &_mode,
				  &_iout, &_ifail, _wa, &_lwa, _kwa, &_lkwa, _active, &_lactive, &_lql, ql_ );
	}
	while ( ( _ifail == -1 || _ifail == -2 ) && _clock->elapsedSeconds() < _aborttime  && !func_params->abort );

	for ( int i = 0; i < _dimension; i++ )
	{
		if ( _x[i] < lb[i] )
		{
			_x[i] = lb[i];
		}
		else if ( _x[i] > ub[i] )
		{
			_x[i] = ub[i];
		}
	}


	memcpy ( x, _x, sizeof ( double ) * _dimension );
	if ( ( _ifail == -1 || _ifail == -2 ) && func_params->abort )
	{
		_ifail = 12;
	}
	else if ( ( _ifail == -1 || _ifail == -2 ) && _clock->elapsedSeconds() >= _aborttime )
	{
		_ifail = 11;
	}

	if ( _ifail != 0 )
	{
		switch ( _ifail )
		{
			case 1:
				throw SolverWarning ( __DEBUGMESS ( "Iteration maximum reached" ) );
			case 2:
				throw SolverWarning ( __DEBUGMESS ( "The algorithm computed an uphill search direction." ) );
			case 3:
				throw SolverWarning ( __DEBUGMESS ( "Underflow occurred when determining a new approximation matrix for the Hessian of the Lagrangian." ) );
			case 4:
				throw SolverWarning ( __DEBUGMESS ( "The line search could not be terminated successfully." ) );
			case 7:
				throw SolverWarning ( __DEBUGMESS ( "The search direction is close to zero, but the current iterate is still infeasible." ) );
			case 8:
				throw SolverError ( __DEBUGMESS ( "The starting point violates a lower or upper bound." ) );
			case 10:
				throw SolverError ( __DEBUGMESS ( "Internal inconsistency of the quadratic subproblem, division by zero." ) );
			case 11:
				throw SolverWarning ( __DEBUGMESS ( "User abort due to calculation time." ) );
			case 12:
				throw SolverWarning ( __DEBUGMESS ( "User abort due to reached suboptimality level." ) );
			default:
				stringstream o;
				o << "An internal error occured. IFAIL = ";
				o << _ifail;
				throw MinProgException ( __DEBUGMESS ( o.str() ) );

		}
	}
}

void yane::SqpFortran::SqpFortran::evalFunctions()
{
	try
	{
		_function ( _x, &_f, func_params );
		if ( _dimension_rest > 0 )
		{
			_restrictions ( _x, _g, restr_params );
		}
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating function or restriction values caused an error" ), &e );
	}

//  cout << "rest=" << _dimension_rest << endl;
//  cout << "rest_eq=" << _dimension_resteq << endl;
//  cout << "Value=" << _f << endl << endl;
//  cout << "Restr=" << endl;
//  for (int k=0; k<_dimension_rest; k++)
//  {
//   cout << _g[k] << "  ";
//  }
//  cout << endl << endl;
}

void yane::SqpFortran::SqpFortran::evalGradients ( bool cfg, bool cgg )
{
	if ( cfg )
	{
		if ( _function_diff != 0 )
		{
			try
			{
				_function_diff ( _x, _df, func_params );
			}
			catch ( yane::Utils::Exception e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating function gradient caused an error" ), &e );
			}
		}
		else
		{
			try
			{
				_function ( _x, &_fvalue1, func_params );
			}
			catch ( yane::Utils::Exception e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating function values caused an error" ), &e );
			}
			for ( int i = 0; i < _dimension; i++ )
			{
				_xold = _x[i];
				_x[i] += yane::Utils::OptimalDiff::get();
				try
				{
					_function ( _x, &_fvalue2, func_params );
				}
				catch ( yane::Utils::Exception e )
				{
					throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating function values caused an error" ), &e );
				}
				_df[i] = ( _fvalue2 - _fvalue1 ) / yane::Utils::OptimalDiff::get();
				_x[i] = _xold;
			}
		}
	}
	if ( cgg && _dimension_rest > 0 )
	{
		if ( _restrictions_diff != 0 )
		{
			try
			{
				_restrictions_diff ( _x, _dg, restr_params );
			}
			catch ( yane::Utils::Exception e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating restriction gradient caused an error" ), &e );
			}
		}
		else
		{
			try
			{
				_restrictions ( _x, _gvalue1, restr_params );
			}
			catch ( yane::Utils::Exception e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating restriction values caused an error" ), &e );
			}
			for ( int i = 0; i < _dimension; i++ )
			{
				_xold = _x[i];
				_x[i] += yane::Utils::OptimalDiff::get();
				try
				{
					_restrictions ( _x, _gvalue2, restr_params );
				}
				catch ( yane::Utils::Exception e )
				{
					throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating restriction values caused an error" ), &e );
				}
				for ( int k = 0; k < _dimension_rest; k++ )
				{
					if ( _active[k] )
					{
						_dg[i*_dimension_rest + k] = ( _gvalue2[k] - _gvalue1[k] ) / yane::Utils::OptimalDiff::get();
					}
				}
				_x[i] = _xold;
			}
		}
	}

//  printf("Gradient\n");
//  for (int i=0; i<_dimension; i++)
//  {
//   printf(" %+7.4f",_df[i]);
//  }
//  printf("\n\nRestr-Jacobi\n");
//  for (int i=0; i<_dimension; i++)
//  {
//   for (int k=0; k<_dimension_rest; k++)
//   {
//    printf(" %+7.4f", _dg[i*_dimension_rest+k]);
//   }
//   printf("\n");
//  }
//  printf("\nactive = ");
//  for(int i=0; i<_dimension_rest; i++)
//  {
//   printf(" %3d", _active[i]);
//  }
//  printf("\n\n");

//  cout << "Gradient" << endl;
//  for (int i=0; i<_dimension; i++)
//  {
//   cout << df[i] << "  ";
//  }
//  cout << endl << endl;
	//
//  cout << "Restr-Jacobi" << endl;
//  for (int i=0; i<_dimension; i++)
//  {
//   for (int k=0; k<_dimension_rest; k++)
//   {
//    cout << _dg[i*_dimension_rest + k] << "  ";
//   }
//   cout << endl;
//  }
//  cout << endl << endl;
//  cout << "activ = ";
//  for(int i=0; i<_dimension_rest; i++)
//  {
//   cout << restr_params->active[i] << " ";
//  }
//  cout << endl;
}

LIB_EXPORT yane::MinProg::T_MEMMODEL yane::SqpFortran::SqpFortran::memoryModel() const
{
	return yane::MinProg::BYCOLUMN;
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::setMaxFun ( int num )
{
	_maxfun = num;
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::setMaxIterations ( int num )
{
	if ( num <= 0 )
	{
		throw InitializingException ( __DEBUGMESS ( "Failed to set MaxIterations (in setMaxIterations()), because num <= 0" ) );
	}
	else
	{
		_maxit = num;
	}
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::setNMLineSearchStack ( int size )
{
	_max_nm = size;
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::setLineSearchTol ( double tol )
{
	_tol_nm = tol;
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::setAccuracy ( double acc )
{
	if ( acc <= 0.0 )
	{
		throw InitializingException ( __DEBUGMESS ( "Failed to set tolerance (in setAccuracy()), because acc <= 0.0" ) );
	}
	else
	{
		_accuracy = acc;
		if ( acc < _stepmin )
		{
			_stepmin = acc;
		}
	}
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::setMinimalStepsize ( double step )
{
	if ( step <= 0.0 )
	{
		throw InitializingException ( __DEBUGMESS ( "Failed to set tolerance (in setAccuracy()), because acc <= 0.0" ) );
	}
	if ( step < _accuracy )
	{
		_stepmin = _accuracy;
	}
	else
	{
		_stepmin = step;
	}
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::setQLAccuracy ( double acc )
{
	if ( acc <= 0.0 )
	{
		throw InitializingException ( __DEBUGMESS ( "Failed to set tolerance (in setQLAccuracy()), because acc <= 0.0" ) );
	}
	else
	{
		_accql = acc;
	}
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::setPrintLevel ( int lvl )
{
	_iprint = lvl;
}

void yane::SqpFortran::SqpFortran::setDefaultConfig()
{
	_l = 1;
	_accuracy = 1E-6;
	_accql = DBL_EPSILON * 10000.0;
	_stepmin = _accuracy;
	_maxfun = 20;
	_maxit = 100;
	_max_nm = 0;
	_tol_nm = .1;
	_iprint = 0;
	_iout = 6;
	_mode = 0;
	_lql = 1;
}

LIB_EXPORT yane::MinProg::NLP * yane::SqpFortran::SqpFortran::clone()
{
	SqpFortran * result = new SqpFortran();
	if ( result == 0 )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating new instance" ) );
	}

	result->_accuracy = _accuracy;
	result->_accql = _accql;
	result->_stepmin = _stepmin;
	result->_maxfun = _maxfun;
	result->_maxit = _maxit;
	result->_max_nm = _max_nm;
	result->_tol_nm = _tol_nm;
	result->_iprint = _iprint;

	return result;
}

LIB_EXPORT void yane::SqpFortran::SqpFortran::getRestrictionJacobi ( double * jac )
{
	if ( jac == 0 )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "No memory allocated for double *jac in getRestrictionJacobi()" ) );
	}
	else
	{
		memset ( _active, 1, sizeof ( int ) * _dimension_rest );
		try
		{
			evalGradients ( false, true );
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Unknown calculation error" ), __DEBUGMESS ( "evaluating Gradients caused an error" ), &e );
		}
		memcpy ( jac, _dg, sizeof ( double ) * _dimension * _dimension_rest );
	}
}

// u = Lagrangeparameter der [nichtlin. Restriktionen , unteren Variablenschranken , oberen Variablenschranken]
LIB_EXPORT void yane::SqpFortran::SqpFortran::getLagrangeParameters ( double * lambda )
{
	if ( lambda == 0 )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "No memory allocated for double * lambda in getLagrangeParameters()" ) );
	}
	else
	{
//   for(int i=0; i<dimension_rest; i++)
//    lambda[i] = u[i];
		memcpy ( lambda, _u, sizeof ( double ) * _dimension_rest );
	}
}
