/***************************************************************************
 *                                                                         *
 * Interface Library for Minimizer NLPQLP                                  *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>             *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_SQPFORTRAN_H
#define YANE_SQPFORTRAN_H

#include <yane/minprog/nlp.h>

#include <cfloat>

namespace yane
{

	namespace SqpFortran
	{

		/** \class SqpFortran
		 \brief Wrapper class for the SQP routine NLPQLP
		*/
		class SqpFortran : public yane::MinProg::NLP
		{
			public:

				/**
				 @brief Default-Constructor
				*/
				SqpFortran();

				/**
				 @brief Constructor
				 @param n Dimension of the optimization variable
				 @param func Objective function
				 @param rest Constraints
				 @param nrest Number of constraints (both equality and inequality constraints)
				 @param nrest_eq number of equality constraints \n
				 These have to be listed first within the definition of the constraints
				 @param df Gradient of the objective function
				 @param dg Jacobian matrix of the restriction function
				 @throw yane::Utils::MemoryException Is thrown, if memory allocation has failed
				 @throw yane::Utils::Exception Is thrown, if initialization of the class has failed
				*/
				SqpFortran ( int n, yane::MinProg::T_FUNC func, yane::MinProg::T_FUNC rest = 0, int nrest = 0, int nrest_eq = 0, yane::MinProg::T_FUNC df = 0, yane::MinProg::T_FUNC dg = 0 );

				/**
				 @brief Destructor
				*/
				virtual ~SqpFortran();

				virtual void init ( int n, yane::MinProg::T_FUNC func, yane::MinProg::T_FUNC rest = 0, int nrest = 0, int nrest_eq = 0, yane::MinProg::T_FUNC df = 0, yane::MinProg::T_FUNC dg = 0 );

				virtual void calcMin ( double * x, double * fx, double * lb, double * ub, double * rpar = 0, int * ipar = 0 );

				virtual yane::MinProg::T_MEMMODEL memoryModel() const;

				virtual yane::MinProg::NLP * clone();

				virtual void setMaxIterations ( int num );

				virtual void setAccuracy ( double acc );

				virtual void getRestrictionJacobi ( double * jac );

				virtual void getLagrangeParameters ( double * lambda );

				/**
				@brief Function to set the maximal number of function evaluations
				@param num Maximal number of function evaluations
				 \throw InitializingException Is thrown, if num <= 0.0
				*/
				void setMaxFun ( int num = 20 );

				/**
				 * @brief Function to set the maximal number of nonmonotone linesearch steps
				 * @param size Maximal number of nonmonotone linesearch steps
				 */
				void setNMLineSearchStack ( int size = 0 );

				/**
				 @brief Function to set the tolerance of the linesearch
				 @param tol Absolute tolerance value of the linesearch
				*/
				void setLineSearchTol ( double tol = .1 );

				/**
				 @brief Function to set the accurracy of the QP-Solver
				 @param acc Accuracy of the QP solver
				 @throw InitializingException Is thrown, if acc <= 0.0
				*/
				void setQLAccuracy ( double acc = DBL_EPSILON * 10000.0 );

				/**
				 @brief Function to set the minimal stepsize for a single step of the optimization routine
				 @param step Minimal stepsize of an optimization step
				*/
				void setMinimalStepsize ( double step = 1E-6 );

				/**
				 @brief Function to set the desired output level of the routine
				 @param lvl Outlevel (should lie between 0 and 4)
				*/
				void setPrintLevel ( int lvl = 0 );

			private:
				/**
				 @brief Function to free different variables/values
				*/
				void freememory();

				/**
				 @brief Function to set a default configuration for the SqpFortran object
				*/
				void setDefaultConfig();

				/**
				 @brief Function to evaluate the objective function and the constraints
				 @throw yane::Utils::Exception Is thrown, if the evaluation stopped with an error
				*/
				void evalFunctions();

				/**
				 @brief Function to evaluate the gradient of the objective function and the jacobian ot the constraints
				 @throw yane::Utils::Exception Is thrown, if the evaluation stopped with an error
				*/
				void evalGradients ( bool cf = true , bool cg = true );

			protected:
				double _xold;  /**< @brief Auxilliary variable to save one entry of the optimization variable */
				double _fvalue1; /**< @brief Variable to store the objective function value */
				double _fvalue2; /**< @brief Auxilliary variable to store the objective function value */
				double * _gvalue1; /**< @brief Array to store the constraint values*/
				double * _gvalue2; /**< @brief Auxilliary array to store the constraint values*/

				int _l;			/**< @brief Number of parallel systems, i.e. function calls duringline search at predetermined iterates. \n
				HINT: If less than 10 parallel function evaluations are available, it is recommended to apply the serial version by setting L=1.*/
				int _nmax;		/**< @brief Row dimension of the Hessian. _nmax must be at least two and greater than the number of optimization variables. */
				int _mmax;		/**< @brief Row dimension of the Jacobian matrix. _mmax must be at least one and greater or equal to the number of constraints*/
				int _mnn2;		/**< @brief Auxilliary variable*/
				double * _x;		/**< @brief Array of the optimization variable*/
				double _f;		/**< @brief Value of the cost function*/
				double * _g;		/**< @brief Pointer of the constraints*/
				double * _df;		/**< @brief Pointer of the gradient of the cost function*/
				double * _dg;		/**< @brief Pointer of the Jacobian matrix*/
				double * _u;		/**< @brief _u contains the multipliers with respect to the actual iterate stored in the first column of _x. The first locations contain the multipliers of the nonlinear constraints, the subsequent locations the multipliers of the lower bounds, and the final locations the multipliers of the upper bounds. At an optimal solution, all multipliers with respect to inequality constraints should be nonnegative. */
				double * _c;		/**< @brief Pointer of the last computed approximation of the Hessian*/
				double * _d;		/**< @brief Pointer to the diagonal elements of the LDL of the Quasi-Newton matrix of the constraints*/
				double _accql;		/**< @brief The tolerance is needed for the QP solver to perform several tests, for example whether optimality conditions are satisfied or whether a number is considered as zero or not. If _accqö is less or equal to zero, then the machine precision is computed by NLPQLP and subsequently multiplied by 10000.*/
				double _accuracy;	/**< @brief The user has to specify the desired final accuracy (e.g. 1.0D-7). The termination accuracy should not be smaller than the accuracy by which gradients are computed.*/
				double _stepmin;	/**< @brief Minimum steplength in case of L>1. Recommended is any value in the order of the accuracy by which functions are computed. The value is needed to compute a steplength reduction factor by pow(_stepmin, (1/_l-1)). If _stepmin <= 0, then _stepmin = _acc is used.*/
				int _maxfun;		/**< @brief The integer variable defines an upper bound for the number of function calls during the line search (e.g. 20). _maxfun is only needed in case of _l=1, and must not be greater than 50.*/
				int _maxit;		/**< @brief Maximum number of outer iterations, where one iteration corresponds to one formulation and solution of the quadratic programming subproblem, or, alternatively, one evaluation of gradients (e.g. 100).*/
				int _max_nm;		/**< @brief Stack size for storing merit function values at previous iterations for non-monotone line search (e.g. 10). In case of _max_nm = 0, monotone line search is performed. _max_nm should not be greater than 50.*/
				double _tol_nm;		/**< @brief Relative bound for increase of merit function value, if linesearch is not successful during the very first step. Must be non-negative (e.g. 0.1). */

				int _iprint;		/**< @brief Specification of the desired output level. \n
				- _iprint = 0 :  No output of the program.
				- _iprint = 1 :  Only a final convergence analysis is given.
				- _iprint = 2 :  One line of intermediate results is printed in each iteration.
				- _iprint = 3 :  More detailed information is printed in each iteration step, e.g. variable, constraint and multiplier values.
				- _iprint = 4 :  In addition to '_iprint=3', merit function and steplength values are displayed during the line search.\n
				NOTE: Constraint and multiplier values are not displayed if the number of constraints is larger than 10000*/
				int _mode;		/**< @brief Parameter for warm starts \n
				- _mode = 0: Normal execution (reverse communication!).
				- _mode = 1: The user wants to provide an initial guess for the multipliers in _u and for the Hessian of the Lagrangian function in _c. In case of lql == true, _d is ignored. Otherwise, the lower part of C has to contain the lower triangular factor of an LDL decomposition and _d the diagonal part.*/
				int _iout;		/**< @brief Parameter for the desired output unit*/
				int _ifail;		/**< @brief Parameter which shows the reason for terminating a solution process. Initially _ifail must be set to zero. On return _ifail could contain the following values: \n
				- _ifail =-2 :   Compute gradient values w.r.t. the variables stored in first column of _x, and store them in _df and _dg. Only derivatives for active constraints _active[j] == true need to be computed. Then call NLPQLP again.
				- _ifail =-1 :   Compute objective function and all constraint values subject the variables found in the first l columns of _x, and store them in _f and _g. Then call NLPQLP again.
				- _ifail = 0 :   The optimality conditions are satisfied.
				- _ifail = 1 :   The algorithm has been stopped after _maxit iterations.
				- _ifail = 2 :   The algorithm computed an uphill search direction.
				- _ifail = 3 :   Underflow occurred when determining a new approximation matrix for the Hessian of the Lagrangian.
				- _ifail = 4 :   The line search could not be terminated successfully.
				- _ifail = 5 :   Length of a working array is too short. More detailed error information is obtained with '_irpint>0'.
				- _ifail = 6 :   There are false dimensions, for example M>MMAX, N>=NMAX, or MNN2<>M+N+N+2.
				- _ifail = 7 :   The search direction is close to zero, but the current iterate is still infeasible.
				- _ifail = 8 :   The starting point violates a lower or upper bound.
				- _ifail = 9 :   Wrong input parameter, i.e., _mode, LDL decomposition in _d and _c (in case of _mode == 1), _iprint, _iout
				- _ifail = 10 :  Internal inconsistency of the quadratic subproblem, division by zero.
				- _ifail > 100 : The solution of the quadratic programming subproblem has been terminated with an error message and _ifail is set to _ifql + 100, where _ifql denotes the index of an inconsistent constraint.*/

				double * _wa;  /**< @brief Real working array of length _lwa*/
				int _lwa;   /**< @brief Length of the real working array _lwa*/

				int * _kwa;   /**< @brief Integer working array of length _lkwa*/
				int _lkwa;   /**< @brief Length of the integer working array _kwa*/

				int * _active;  /**< @brief Logical array which shows a user the constraints, which NLPQLP considers to be active at the last computed iterate*/
				int _lactive;  /**< @brief Length of the logical array _active*/

				int _lql;   /**< @brief If _lql is set to true, the quadratic programming subproblem is solved with a full positive definite quasi-Newton matrix. Otherwise, a Cholesky decomposition is performed and updated, so that the subproblem matrix contains only an upper triangular factor.*/

		};
	}
}

#endif
