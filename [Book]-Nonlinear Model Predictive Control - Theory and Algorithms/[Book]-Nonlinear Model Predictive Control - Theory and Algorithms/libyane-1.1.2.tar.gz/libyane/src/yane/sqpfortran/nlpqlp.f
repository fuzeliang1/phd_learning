C
      SUBROUTINE NLPQLP(L,M,ME,MMAX,N,NMAX,MNN2,X,F,G,DF,DG,U,XL,XU,
     /     C,D,ACC,ACCQP,STPMIN,MAXFUN,MAXIT,MAX_NM,TOL_NM,IPRINT,
     /     MODE,IOUT,IFAIL,WA,LWA,KWA,LKWA,ACTIVE,LACTIV,LQL,QPSOLVE)
C
C**********************************************************************
C
C
C         AN IMPLEMENTATION OF A SEQUENTIAL QUADRATIC PROGRAMMING
C          METHOD FOR SOLVING NONLINEAR OPTIMIZATION PROBLEMS BY
C           DISTRIBUTED COMPUTING AND NON-MONOTONE LINE SEARCH
C
C
C   This subroutine solves the general nonlinear programming problem
C
C             minimize    F(X)
C             subject to  G(J,X)   =  0  ,  J=1,...,ME
C                         G(J,X)  >=  0  ,  J=ME+1,...,M
C                         XL  <=  X  <=  XU
C
C   and is an extension of the code NLPQLD. NLPQLP is specifically
C   tuned to run under distributed systems. A new input parameter L is
C   introduced for the number of parallel computers, that is the number of
C   function calls to be executed simultaneously. In case of L=1, NLPQLP
C   is identical to NLPQLD. Otherwise the line search is modified to allow
C   L parallel function calls in advance. Moreover the user has the
C   opportunity to used distributed function calls for evaluating gradients.
C
C   The algorithm is a modification of the method of Wilson, Han, and
C   Powell. In each iteration step, a linearly constrained quadratic
C   programming problem is formulated by approximating the Lagrangian
C   function quadratically and by linearizing the constraints.
C   Subsequently, a one-dimensional line search is performed with
C   respect to an augmented Lagrangian merit function to obtain
C   a new iterate. Also the modified line search algorithm guarantees
C   convergence under the same assumptions as before.
C
C   For the new version, a non-monotone line search is implemented which 
C   allows to increase the merit function in case of instabilities, for 
C   example caused by round-off errors, errors in gradient approximations,
C   etc.
C
C   The subroutine contains the option to predetermine initial
C   guesses for the multipliers or the Hessian of the Lagrangian
C   function and is called by reverse communication.
C
C
C   Usage:
C
C      CALL NLPQLP(L,M,ME,MMAX,N,NMAX,MNN2,X,F,G,DF,DG,U,XL,XU,
C     /     C,D,ACC,ACCQP,STPMIN,MAXFUN,MAXIT,MAX_NM,TOL_NM,IPRINT,
C     /     MODE,IOUT,IFAIL,WA,LWA,KWA,LKWA,ACTIVE,LACTIV,LQL,QPSOLVE)
C
C
C   List of arguments:
C
C   L :       Number of parallel systems, i.e. function calls during
C             line search at predetermined iterates.
C             HINT: If less than 10 parallel function evaluations
C                   are available, it is recommended to apply
C                   the serial version by setting L=1.
C   M :       Number of constraints.
C   ME :      Number of equality constraints.
C   MMAX :    Row dimension of array DG containing Jacobian of constraints.
C             MMAX must be at least one and greater or equal to M.
C   N :       Number of optimization variables.
C   NMAX :    Row dimension of C. NMAX must be at least two and greater
C             than N.
C   MNN2 :    Must be equal to M+N+N+2.
C   X(NMAX,L) : Initially, the first column of X has to contain
C             starting values for the optimal solution. On return, X is
C             replaced by the current iterate. In the driving program
C             the row dimension of X has to be equal to NMAX.
C             X is used internally to store L different arguments for which
C             function values should be computed simultaneously.
C   F(L) :    On return, F(1) contains the final objective function value.
C             F is used also to store L different objective function
C             values to be computed from L iterates stored in X.
C   G(MMAX,L) : On return, the first column of G contains the constraint
C             function values at the final iterate X. In the driving program
C             the row dimension of G has to be equal to MMAX.
C             G is used internally to store L different set of constraint
C             function values to be computed from L iterates stored in X.
C   DF(NMAX) : DF contains intermediate gradients of the objective function.
C             In case of numerical differentiation and a distributed
C             system (L>1), it is recommended to apply parallel evaluations
C             of F to compute DF.
C   DG(MMAX,NMAX) : DG is used to store gradients of the active constraints
C             (ACTIVE(J) true) at a current iterate X.
C             The remaining rows are filled with previously computed
C             gradients. In the driving program the row dimension of DG
C             has to be equal to MMAX.
C   U(MNN2) : U contains the multipliers with respect to the actual iterate
C             stored in the first column of X. The first M locations contain
C             the multipliers of the M nonlinear constraints, the subsequent
C             N locations the multipliers of the lower bounds, and the
C             final N locations the multipliers of the upper bounds.
C             At an optimal solution, all multipliers with respect to
C             inequality constraints should be nonnegative.
C   XL(N),XU(N) : On input, the one-dimensional arrays XL and XU must
C             contain the upper and lower bounds of the variables.
C   C(NMAX,NMAX) : On return, C contains the last computed approximation
C             of the Hessian matrix of the Lagrangian function stored in
C             form of an LDL decomposition if LQL is set to false. In this case,
C             C contains the lower triangular factor of an LDL factorization 
C             of the final quasi-Newton matrix (without diagonal elements, 
C             which are always one). In the driving program, the row dimension 
C             of C has to be equal to NMAX.
C   D(NMAX) : The elements of the diagonal matrix of the LDL decomposition
C             of the quasi-Newton matrix are stored in the one-dimensional
C             array D if LQL is set to false.
C   ACC :     The user has to specify the desired final accuracy
C             (e.g. 1.0D-7). The termination accuracy should not be smaller
C             than the accuracy by which gradients are computed.
C   ACCQP :   The tolerance is needed for the QP solver to perform several 
C             tests, for example whether optimality conditions are satisfied
C             or whether a number is considered as zero or not. If ACCQP is
C             less or equal to zero, then the machine precision is computed 
C             by NLPQLP and subsequently multiplied by 1.0D+4.
C   STPMIN :  Minimum steplength in case of L>1. Recommended is any value in
C             the order of the accuracy by which functions are computed.
C             The value is needed to compute a steplength reduction factor
C             by STPMIN**(1/L-1). If STPMIN<=0, then STPMIN=ACC is used.
C   MAXFUN :  The integer variable defines an upper bound for the number
C             of function calls during the line search (e.g. 20).
C             MAXFUN is only needed in case of L=1, and must not be greater
C             than 50.
C   MAXIT :   Maximum number of outer iterations, where one iteration
C             corresponds to one formulation and solution of the quadratic
C             programming subproblem, or, alternatively, one evaluation of
C             gradients (e.g. 100).
C   MAX_NM :  Stack size for storing merit function values at previous 
C             iterations for non-monotone line search (e.g. 10). In case of
C             MAX_NM=0, monotone line search is performed. MAX_NM should not
C             be greater than 50.
C   TOL_NM :  Relative bound for increase of merit function value, if line
C             search is not successful during the very first step. Must be
C             non-negative (e.g. 0.1).
C   IPRINT :  Specification of the desired output level.
C      IPRINT = 0 :  No output of the program.
C      IPRINT = 1 :  Only a final convergence analysis is given.
C      IPRINT = 2 :  One line of intermediate results is printed in each
C                    iteration.
C      IPRINT = 3 :  More detailed information is printed in each iteration
C                    step, e.g. variable, constraint and multiplier values.
C      IPRINT = 4 :  In addition to 'IPRINT=3', merit function and steplength
C                    values are displayed during the line search.
C                    NOTE: Constraint and multiplier values are not displayed
C                          for M > 10,000.
C   MODE :    Parameter for warm starts.
C      MODE = 0 :    Normal execution (reverse communication!).
C      MODE = 1 :    The user wants to provide an initial guess for the
C                    multipliers in U and for the Hessian of the Lagrangian
C                    function in C. In case of LQL=.TRUE., D is ignored.
C                    Otherwise, the lower part of C has to contain the lower
C                    triangular factor of an LDL decomposition and D the 
C                    diagonal part.
C   IOUT :    Integer indicating the desired output unit number, i.e. all
C             write-statements start with 'WRITE(IOUT,... '.
C   IFAIL :   The parameter shows the reason for terminating a solution
C             process. Initially IFAIL must be set to zero. On return IFAIL
C             could contain the following values:
C      IFAIL =-2 :   Compute gradient values w.r.t. the variables stored in
C                    first column of X, and store them in DF and DG. Only
C                    derivatives for active constraints ACTIVE(J)=.TRUE. need
C                    to be computed. Then call NLPQLP again, see below.
C      IFAIL =-1 :   Compute objective function and all constraint values subject
C                    the variables found in the first L columns of X, and
C                    store them in F and G. Then call NLPQLP again, see below.
C      IFAIL = 0 :   The optimality conditions are satisfied.
C      IFAIL = 1 :   The algorithm has been stopped after MAXIT iterations.
C      IFAIL = 2 :   The algorithm computed an uphill search direction.
C      IFAIL = 3 :   Underflow occurred when determining a new approxi-
C                    mation matrix for the Hessian of the Lagrangian.
C      IFAIL = 4 :   The line search could not be terminated successfully.
C      IFAIL = 5 :   Length of a working array is too short. More
C                    detailed error information is obtained with
C                    'IPRINT>0'.
C      IFAIL = 6 :   There are false dimensions, for example M>MMAX,
C                    N>=NMAX, or MNN2<>M+N+N+2.
C      IFAIL = 7 :   The search direction is close to zero, but the
C                    current iterate is still infeasible.
C      IFAIL = 8 :   The starting point violates a lower or upper bound.
C      IFAIL = 9 :   Wrong input parameter, i.e., MODE, LDL decomposition in D
C                    and C (in case of MODE=1), IPRINT, IOUT
C      IFAIL = 10 :  Internal inconsistency of the quadratic subproblem,
C                    division by zero.
C      IFAIL > 100 : The solution of the quadratic programming
C                    subproblem has been terminated with
C                    an error message and IFAIL is set to IFQL+100,
C                    where IFQL denotes the index of an inconsistent 
C                    constraint.
C   WA(LWA),LWA : WA is a real working array of length LWA. LWA must be
C             at least 23*N+4*M+3*MMAX+150.
C             NOTE:  The standard QP-solver provided by the author (QL) 
C                    needs additional memory for 3*NMAX*NMAX/2+10*NMAX+MMAX+M+1 
C                    real numbers.
C   KWA(LKWA),LKWA : The user has to provide working space for an
C             integer array. LKWA should be at least 10.
C             NOTE:  The standard QP-solver provided by the author (QL) 
C                    needs additional memeory for N integer numbers.
C   ACTIVE(LACTIV),LACTIV : The logical array shows a user the con-
C             straints, which NLPQLP considers to be active at the last
C             computed iterate, i.e. G(J,X) is active, if and only if
C             ACTIVE(J) is true, J=1,...,M. The length LACTIV of the
C             logical array should be at least 2*M+10.
C   LQL :     If LQL is set to true, the quadratic programming subproblem is  
C             solved with a full positive definite quasi-Newton matrix.
C             Otherwise, a Cholesky decomposition is performed and updated, 
C             so that the subproblem matrix contains only an upper triangular 
C             factor.
C   QPSOLVE : External subroutine to solve the quadratic programming subproblem.
C             The calling sequence is
C               CALL QPSOLVE(M,ME,MMAX,N,NMAX,MNN,C,D,A,B,XL,XU,
C              /      X,U,EPS,MODE,IOUT,IFAIL,IPRINT,WAR,LWAR,IWAR,LIWAR)
C             For more details about the choice and dimensions of arguments,
C             please see the corresponding report.
C
C
C   Function and gradient evaluation:
C
C   The user has to provide functions and gradients in the same program, which
C   executes also NLPQLP, according to the following rules:
C
C   1) Choose starting values for the variables to be optimized, and store
C      them in the first column of X.
C
C   2) Compute objective and all constraint function values values,
C      store them in F(1) and the first column of G, respectively.
C
C   3) Compute gradients of objective function and all constraints, and
C      store them in DF and DG, respectively. The J-th row of DG contains
C      the gradient of the J-th constraint, J=1,...,M.
C
C   4) Set IFAIL=0 and execute NLPQLP.
C
C   5) If NLPQLP returns with IFAIL=-1, compute objective function values and
C      constraint values for all variables found in the first L columns of X,
C      store them in F (first L positions) and G (first L columns), and call
C      NLPQLP again. If NLPQLP terminates with IFAIL=0, the internal stopping
C      criteria are satisfied. In case of IFAIL>0, an error occurred.
C
C   6) If NLPQLP terminates with IFAIL=-2, compute gradient values subject to
C      variables stored in first column of X, and store them in DF and DG.
C      Only derivatives for active constraints ACTIVE(J)=.TRUE. need
C      to be computed. Then call NLPQLP again.
C      NOTE: If analytical derivatives are not available, simultaneous function
C            calls can be used for gradient approximations, for example by 
C            forward differences (2*N>L), two-sided differences (4*N>L>=2*N), 
C            or even higher order formulae (L>=4*N).
C
C
C   Function and gradient evaluation:
C
C   The user has to provide functions and gradients in the same program, which
C   executes also NLPQLP, according to the following rules:
C
C   1) Choose starting values for the variables to be optimized, and store
C      them in the first column of X.
C
C   2) Compute objective and all constraint function values values,
C      store them in F(1) and the first column of G, respectively.
C
C   3) Compute gradients of objective function and all constraints, and
C      store them in DF and DG, respectively. The J-th row of DG contains
C      the gradient of the J-th constraint, J=1,...,M.
C
C   4) Set IFAIL=0 and execute NLPQLP.
C
C   5) If NLPQLP returns with IFAIL=-1, compute objective function values and
C      constraint values for all variables found in the first L columns of X,
C      store them in F (first L positions) and G (first L columns), and call
C      NLPQLP again. If NLPQLP terminates with IFAIL=0, the internal stopping
C      criteria are satisfied. In case of IFAIL>0, an error occurred.
C
C   6) If NLPQLP terminates with IFAIL=-2, compute gradient values subject to
C      variables stored in first column of X, and store them in DF and DG.
C      Only derivatives for active constraints ACTIVE(J)=.TRUE. need
C      to be computed. Then call NLPQLP again.
C      NOTE: If analytical derivatives are not available, simultaneous function
C            calls can be used for gradient approximations, for example by 
C            forward differences (2*N>L), two-sided differences (4*N>L>=2*N), 
C            or even higher order formulae (L>=4*N).
C
C
C   Example: Rosenbrock's post office problem
C
C            minimize     -x1*x2*x3
C            subject to    x1 + 2*x2 + 2*x3       >=  0
C                          72 - x1 - 2*x2 - 2*x3  >=  0
C
C      IMPLICIT  NONE
C      INTEGER   NMAX,MMAX,MNN2X,LWA,LKWA,LACTIV
C      PARAMETER (NMAX=4,MMAX=2)
C      PARAMETER (MNN2X = MMAX+NMAX+NMAX+2,
C     /          LWA=1.5*NMAX*NMAX+33*NMAX+9*MMAX+200,
C     /          LKWA=NMAX+10,LACTIV=2*MMAX+10)
C      INTEGER   KWA(LKWA),N,ME,M,L,MNN2,MAXIT,MAXFUN,IPRINT,
C     /          MAX_NM,IOUT,MODE,IFAIL,I
C      DOUBLE PRECISION X(NMAX),F,G(MMAX),DF(NMAX),
C     /          DG(MMAX,NMAX),U(MNN2X),XL(NMAX),XU(NMAX),C(NMAX,NMAX),
C     /          D(NMAX),WA(LWA),ACC,ACCQP,STPMIN,TOL_NM
C      LOGICAL   ACTIVE(LACTIV),LQL
C      EXTERNAL  QL
C
C   Set some constants and initial values
C
C      IOUT   = 6
C      ACC    = 1.0D-11
C      ACCQP  = 1.0D-12
C      STPMIN = 0.0
C      MAXIT  = 100
C      MAXFUN = 10
C      MAX_NM = 0
C      TOL_NM = 0.1D0
C      LQL    = .TRUE.
C      IPRINT = 2
C      N      = 3
C      M      = 2
C      ME     = 0
C      MNN2   = M + N + N + 2
C      MODE   = 0
C      IFAIL  = 0
C      L      = 1
C      DO I=1,N
C         X(I)  = 10.0D0
C         XL(I) = 0.0D0
C         XU(I) = 100.0D0
C      ENDDO
C    1 CONTINUE
C============================================================
C   This block computes all function values.
C
C      F    = -X(1)*X(2)*X(3)
C      G(1) =  X(1) + 2.0D0*X(2) + 2.0D0*X(3)
C      G(2) =  72.0D0 - X(1) - 2.0D0*X(2) - 2.0D0*X(3)
C
C============================================================
C      IF (IFAIL.EQ.-1) GOTO 4
C    2 CONTINUE  
C============================================================
C   This block computes all derivative values.
C
C      DF(1)   = -X(2)*X(3)
C      DF(2)   = -X(1)*X(3)
C      DF(3)   = -X(1)*X(2)
C      DG(1,1) =  1.0D0
C      DG(1,2) =  2.0D0
C      DG(1,3) =  2.0D0
C      DG(2,1) = -1.0D0
C      DG(2,2) = -2.0D0
C      DG(2,3) = -2.0D0
C
C============================================================
C    4 CALL NLPQLP(L,M,ME,MMAX,N,NMAX,MNN2,X,F,G,DF,DG,U,XL,XU,
C     /     C,D,ACC,ACCQP,STPMIN,MAXFUN,MAXIT,MAX_NM,TOL_NM,
C     /     IPRINT,MODE,IOUT,IFAIL,WA,LWA,KWA,LKWA,ACTIVE,LACTIV,
C     /     LQL,QL)
C      IF (IFAIL.EQ.-1) GOTO 1
C      IF (IFAIL.EQ.-2) GOTO 2
C
C      STOP
C      END
C
C
C   Author (C):  K. Schittkowski,
C                Department of Computer Science,
C                University of Bayreuth,
C                D-95440 Bayreuth,
C                Germany
C
C
C   Reference:   K. Schittkowski. NLPQL: A Fortran subroutine solving
C                constrained nonlinear programming problems, Annals of
C                Operations Research, Vol.5 (1985/6), 485-500.
C
C                K. Schittkowski. NLPQLP: A new Fortran implementation 
C                of a sequential quadratic programming algorithm for 
C                parallel computing, Report, Department of Mathematics,
C                University of Bayreuth, 2001
C
C                K. Schittkowski. NLPQLP: A Fortran implementation of a 
C                sequential quadratic programming algorithm with non-
C                monotone line search - user's guide, version 2.2, 
C                Report, Department of Computer Science, University of 
C                Bayreuth, 2006
C
C                K. Schittkowski. QL: A Fortran code for convex quadratic 
C                programming - user's guide, Report, Department of Mathematics,
C                University of Bayreuth, 2005
C
C
C   Version:     1.0  (April, 2001)     - first implementation
C                1.1  (June, 2001)      - new tolerances, additional parameter 
C                                         ACCQP
C                1.2  (June, 2001)      - QP deleted in calling sequence
C                1.3  (May,  2003)      - new error message of QP
C                1.4  (August, 2003)    - QP execution changed (ACCQP attached)
C                1.5  (September, 2004) - QL execution changed (subroutine QL)
C                1.6  (September, 2004) - Length of working array WA 
C                2.0  (October, 2004)   - Non-monotone line search 
C                2.1  (July, 2005)      - Output of last and best solution 
C                                         (in case of MAX_NM>0, IFAIL>0),
C                                         error messages 
C                2.2  (January, 2006)   - organization of working array 
C                                         (QPSOLVE working space separated),
C                                         formatting statements
C                2.21 (March, 2006)     - error check IFAIL=8, initialization 
C                                         best solution
C                2.22 (July, 2006)      - internal flag for non-monotone line 
C                                         search, stopping condition against 
C                                         underflow
C                2.23 (January, 2007)   - EDELI initialized, new warning (d=0)
C                2.24 (June, 2007)      - Output suppressed for M > MOUTMX 
C                                         (10,000), output for IFAIL=8
C
C
C***********************************************************************
C
      IMPLICIT NONE
      INTEGER   L,N,MMAX,NMAX,MNN2,LWA,LKWA,LACTIV
      DIMENSION X(NMAX,L),F(L),G(MMAX,L),DF(NMAX),DG(MMAX,NMAX),
     /          U(MNN2),XL(N),XU(N),C(NMAX,NMAX),D(NMAX),
     /          WA(LWA),KWA(LKWA),ACTIVE(LACTIV)
      INTEGER   M,ME,MAXFUN,MAXIT,MAX_NM,IPRINT,MODE,IOUT,IFAIL,
     /          MOUTMX,KWA
      LOGICAL   ACTIVE,LQL,LMERIT
      DOUBLE PRECISION X,F,G,DF,DG,U,XL,XU,C,D,WA,ACC,ACCQP,STPMIN
      DOUBLE PRECISION DBDFAC,ZEFAC,RPENO,RPENS,RPENU,TOL_NM,
     /          ZEFACU,DELTA,BETA,AMUE,ALM,DSQRT,DABS,EPSMCH,ACCLDL,
     /          ACCQP1,STPMN1
      INTRINSIC DSQRT,DABS
      INTEGER   N1,LACT,M1,M2,MNN,NMNN,I1,I2,I3,I4,I5,I6,IVMU,IDEL,
     /          IDLA,ICLF,IBDEL,IETA,IXOLD,IDLAOL,IV,IW,IVMUOL,IDPHI,
     /          IPEN,MAXFN1,IWAQL,ISTNM,IPMXNM,ITEST,LWAQL,LKWA0,I,
     /          IFBST,IKKTBST,IXBST,IUBST,IGBST,IVBST,IWBST
      EXTERNAL  QPSOLVE,NLPQP2
C
C   CHECK DIMENSIONS
C
      IF (L.LT.1) THEN
         IFAIL = 6
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1011) L 
         RETURN
      ENDIF
      IF ((N.GE.NMAX).OR.(N.LT.1)) THEN
         IFAIL = 6
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1012) N
         RETURN
      ENDIF
      IF ((M.GT.MMAX).OR.(M.LT.0)) THEN
         IFAIL = 6
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1013) M
         RETURN
      ENDIF
      IF ((ME.GT.M).OR.(ME.GT.MMAX).OR.(ME.LT.0)) THEN
         IFAIL = 6
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1014) ME
         RETURN
      ENDIF
      IF (MNN2.LT.M+N+N+2) THEN
         IFAIL = 6
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1015) MNN2
         RETURN
      ENDIF
C
C   CHECK INTEGER PARAMETERS
C
      IF ((IPRINT.LT.0).OR.(IPRINT.GT.4)) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1021) IPRINT
         RETURN
      ENDIF
      IF ((MODE.LT.0).OR.(MODE.GT.1)) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1022) MODE
         RETURN
      ENDIF
       IF ((MAX_NM.LT.0).OR.(MAX_NM.GT.50)) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1023) MAX_NM
         RETURN
      ENDIF
      IF ((MAXFUN.LT.0).OR.(MAXFUN.GT.50)) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1024) MAXFUN
         RETURN
      ENDIF
       IF (MAXIT.LT.0) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1025) MAXIT
         RETURN
      ENDIF
      IF (IOUT.LT.1) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1026) IOUT
         RETURN
      ENDIF
      IF ((IFAIL.LT.-2).OR.(IFAIL.GT.0)) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1027) IFAIL
         RETURN
      ENDIF
C
C   CHECK REAL TOLERANCES
C
      IF (STPMIN.LT.0.0) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1031) STPMIN
         RETURN
      ENDIF
      IF (TOL_NM.LT.0.0) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1032) TOL_NM
         RETURN
      ENDIF
      IF (ACCQP.LT.0.0) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1033) ACCQP
         RETURN
      ENDIF
      IF (ACC.LE.0.0) THEN
         IFAIL = 9
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1034) ACC
         RETURN
      ENDIF
C
C   CHECK ARRAY D 
C      
      IF ((MODE.EQ.1).AND.(.NOT.LQL)) THEN
         DO I = 1,N
            IF (D(I).LE.0.0) THEN    
            IFAIL = 9
            IF (IPRINT.EQ.0) RETURN
               WRITE(IOUT,1041)
               RETURN
            ENDIF
         ENDDO
      ENDIF
C
C   PROVIDE CONSTANT PARAMETERS FOR CALLING NLPQP2
C
      DBDFAC = 2.0D-1
      ZEFAC = 1.0D+0
      LMERIT = .TRUE.
      IF (.NOT.LQL) ZEFAC = DSQRT(ZEFAC)
      RPENO = 1.0D+1
      RPENS = 1.0D-2
      ZEFACU = 1.0D+6
      IF (.NOT.LQL) ZEFACU = DSQRT(ZEFACU)
      RPENU = 1.0D+9
      DELTA = 9.0D-1
      EPSMCH = 1.0D-10
    1 EPSMCH = EPSMCH*1.0D-1
      IF (1.0D0+EPSMCH.GT.1.0D0) GOTO 1
      EPSMCH = EPSMCH*1.0D1
      ACCQP1 = ACCQP
      IF (ACCQP.LE.EPSMCH) ACCQP1 = EPSMCH*1.0D+4
      ACCLDL = EPSMCH*1.0D+2
      STPMN1 = STPMIN
      IF (STPMIN.LE.EPSMCH) STPMN1 = ACC
      IF (L.LE.1) THEN
         MAXFN1 = MAXFUN
         BETA = 1.0D-1
      ELSE
         BETA = STPMN1**(1.0D0/DBLE(L-1))
         MAXFN1 = L
      ENDIF
      AMUE = 1.0D-2
      ALM = 1.0D+0
      MOUTMX = 1000
C
C   PRINT PARAMETERS
C
      IF ((IPRINT.GT.0).AND.(IFAIL.GE.0)) THEN
         WRITE(IOUT,1000)
         WRITE(IOUT,1100) N,M,ME,MODE,ACC,ACCQP1,STPMN1,MAXFN1,MAX_NM,
     /                    MAXIT,IPRINT
         IF (IPRINT.EQ.2) THEN
            WRITE(IOUT,1600)
            IF (M.GT.MOUTMX) THEN
               WRITE(IOUT,1700)
            ELSE
               WRITE(IOUT,1701)
            ENDIF      
         ENDIF
      ENDIF
C
C   INITIAL ADDRESSES IN WA
C
      N1 = N+1
      LACT = 2*M+1
      M1 = LACT+1
      M2 = LACT+2
      MNN = M+N+N
      NMNN = N+MNN
      I1 = 1
      I2 = I1+1
      I3 = I2+1
      I4 = I3+1
      I5 = I4+1
      I6 = I5+1
      IVMU = I6+1
      IDEL = IVMU+MNN
      IDLA = IDEL+N1
      ICLF = IDLA+N
      IBDEL = ICLF+N1
      IETA = IBDEL+N
      IXOLD = IETA+N
      IDLAOL = IXOLD+N
      IV = IDLAOL+N
      IW = IV+N1
      IVMUOL = IW+N1
      IDPHI = IVMUOL+MNN
      IPEN = IDPHI+MNN+N
      ISTNM = IPEN+MNN
      IPMXNM = ISTNM+50
      IFBST = IPMXNM+1
      IKKTBST = IFBST+1
      IXBST = IKKTBST+1
      IUBST = IXBST+N1
      IGBST = IUBST+MNN
      IVBST = IGBST+MMAX
      IWBST = IVBST+N1
      IWAQL = IWBST+N1
      ITEST = IWAQL
      LWAQL = LWA-ITEST
C
C   CHECK WORKING ARRAY LENGTHS
C
      IF (ITEST.GT.LWA) THEN
         IFAIL = 5
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1200) ITEST
         RETURN
      ENDIF
      IF (LKWA.LE.10) THEN
         IFAIL = 5
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1400) LKWA
         RETURN
      ENDIF
      IF (LACTIV.LT.2*M+10) THEN
         IFAIL = 5
         IF (IPRINT.EQ.0) RETURN
         WRITE(IOUT,1500) 2*M+10
         RETURN
      ENDIF
      LKWA0 = LKWA-10
C
C   CHECK INITIAL POINT
C
      IF (IFAIL.EQ.0) THEN
         DO I = 1,N
            IF ((X(I,1).LT.XL(I)-EPSMCH)
     /         .OR.(X(I,1).GT.XU(I)+EPSMCH)) THEN
               IFAIL = 8
               IF (IPRINT.GT.0) WRITE(IOUT,1800) I,XL(I),X(I,1),XU(I)
               RETURN
            ENDIF
            IF (X(I,1).LT.XL(I)) X(I,1)  =  XL(I)
            IF (X(I,1).GT.XU(I)) X(I,1)  =  XU(I)
         ENDDO
      ENDIF
C
C   CALL OF NLPQP2
C
    4 CONTINUE
      CALL NLPQP2(L,M,ME,MMAX,N,NMAX,X,F,G,DF,DG,U,XL,XU,C,D,
     /     ACC,MAXFN1,MAXIT,IPRINT,MODE,IOUT,IFAIL,MOUTMX,
     /     WA(IVMU),WA(IDEL),WA(IDLA),WA(ICLF),WA(IBDEL),WA(IETA),
     /     WA(IXOLD),WA(IDLAOL),WA(IV),WA(IW),WA(IVMUOL),WA(IDPHI),
     /     WA(IPEN),WA(IWAQL),LWAQL,
     /     N1,MNN,MNN2,NMNN,KWA(1),KWA(2),KWA(3),KWA(4),KWA(5),
     /     KWA(6),KWA(7),KWA(11),LKWA0,
     /     WA(I1),WA(I2),WA(I3),WA(I4),WA(I5),WA(I6),
     /     DBDFAC,ZEFAC,RPENO,RPENS,RPENU,ZEFACU,DELTA,BETA,AMUE,ALM,
     /     ACCQP1,ACCLDL,ACTIVE,LACT,ACTIVE(M1),ACTIVE(M2),
     /     LQL,LMERIT,WA(ISTNM),MAX_NM,WA(IPMXNM),KWA(8),KWA(9),
     /     TOL_NM,WA(IFBST),WA(IKKTBST),WA(IXBST),WA(IUBST),WA(IGBST),
     /     WA(IVBST),WA(IWBST),KWA(10),QPSOLVE)
      RETURN
C
C   FORMATTING STATEMENTS
C
 1000 FORMAT(////,4X,
     / '------------------------------------------------------------',
     / '--------',
     / /,5X,'START OF THE SEQUENTIAL QUADRATIC PROGRAMMING ALGORITHM',
     /     /,4X,
     / '------------------------------------------------------------',
     / '--------')
 1011 FORMAT(8X,' *** ERROR 6: Wrong input parameter L:',I8,/)
 1012 FORMAT(8X,' *** ERROR 6: Wrong input parameter N:',I8,/)
 1013 FORMAT(8X,' *** ERROR 6: Wrong input parameter M:',I8,/)
 1014 FORMAT(8X,' *** ERROR 6: Wrong input parameter ME:',I8,/)
 1015 FORMAT(8X,' *** ERROR 6: Wrong input parameter MNN2:',I8,/)
 1021 FORMAT(8X,' *** ERROR 9: Wrong input parameter IPRINT:',I8,/)
 1022 FORMAT(8X,' *** ERROR 9: Wrong input parameter MODE:',I8,/)
 1023 FORMAT(8X,' *** ERROR 9: Wrong input parameter MAX_NM:',I8,/)
 1024 FORMAT(8X,' *** ERROR 9: Wrong input parameter MAXFUN:',I8,/)
 1025 FORMAT(8X,' *** ERROR 9: Wrong input parameter MAXIT:',I8,/)
 1026 FORMAT(8X,' *** ERROR 9: Wrong input parameter IOUT:',I8,/)
 1027 FORMAT(8X,' *** ERROR 9: Wrong input parameter IFAIL:',I8,/)
 1031 FORMAT(8X,' *** ERROR 9: Wrong input parameter STPMIN: ',D13.4,/)
 1032 FORMAT(8X,' *** ERROR 9: Wrong input parameter TOL_NM: ',D13.4,/)
 1033 FORMAT(8X,' *** ERROR 9: Wrong input parameter ACCQP: ',D13.4,/)
 1034 FORMAT(8X,' *** ERROR 9: Wrong input parameter ACC: ',D13.4,/)
 1041 FORMAT(8X,' *** ERROR 9: Wrong input for diagonal of Cholesky ',
     /                                'decomposition, i.e., array D!')
 1100 FORMAT(/,5X,'Parameters:',/,
     /       8X,'N      =',I8,/,
     /       8X,'M      =',I8,/,
     /       8X,'ME     =',I8,/,
     /       8X,'MODE   =',I8,/,
     /       8X,'ACC    =',D13.4,/,
     /       8X,'ACCQP  =',D13.4,/,
     /       8X,'STPMIN =',D13.4,/,
     /       8X,'MAXFUN =',I8,/,
     /       8X,'MAX_NM =',I8,/,
     /       8X,'MAXIT  =',I8,/,
     /       8X,'IPRINT =',I8)
 1200 FORMAT(8X,' *** ERROR 5: Length of WA too short, should be at ',
     /                       'least',I10)
 1400 FORMAT(8X,' *** ERROR 5: Length of KWA too short, should be at ',
     /                       'least 10')
 1500 FORMAT(8X,' *** ERROR 5: Length of ACTIVE too short, should ',
     /                       'be at least',I8)
 1600 FORMAT(/,5X,'Output in the following order:',
     /   /,8X,'IT    - iteration number',
     /   /,8X,'F     - objective function value',
     /   /,8X,'SCV   - sum of constraint violations',
     /   /,8X,'NA    - number of active constraints',
     /   /,8X,'I     - number of line search iterations',
     /   /,8X,'ALPHA - steplength parameter',
     /   /,8X,'DELTA - additional variable to prevent inconsistency',
     /   /,8X,'KKT   - Karush-Kuhn-Tucker optimality criterion')
 1700 FORMAT(//,6X,
     / 'IT         F          SCV        NA   I    ALPHA   DELTA',
     / '    KKT',/,4X,
     / '------------------------------------------------------------',
     / '--------')
 1701 FORMAT(//,6X,
     / 'IT         F          SCV      NA  I    ALPHA     DELTA',
     / '     KKT',/,4X,
     / '------------------------------------------------------------',
     / '--------')
 1800 FORMAT(8X,' *** ERROR 8: Starting value no. ',I5,' violates ',
     /          'bound:',/,
     /       8X,'              ',D13.4,'  <=',D13.4,'  <=',D13.4)
C
      END
C
      SUBROUTINE NLPQP2(L,M,ME,MMAX,N,NMAX,X,F,G,DF,DG,U,XL,XU,DCL,CD,
     /     ACC,MAXFUN,MAXIT,IPRINT,MODE,IOUT,IFAIL,MOUTMX,
     /     VMU,DEL,DLA,DCLF,BDEL,ETA,XOLD,DLAOLD,V,W,VMUOLD,DPHI,RPEN,
     /     WA,LWA,N1,MNN,MNN2,NMNN,NFUNC,NGRAD,ITER,NQL,ILINE,IFLISE,
     /     NOPT,IW,LIW,PHI,DFDEL,DBD,ALPHAM,ALPHAO,PROD,DBDFAC,ZEFAC,
     /     RPENO,RPENS,RPENU,ZEFACU,DELTA,BETA,AMUE,ALM,ACCQP,ACCLDL,
     /     ACTIVE,LACTIV,LLINE,LALSD,LQL,LMERIT,STACK_NM,MAX_NM,
     /     PMAX_NM,ISTACK,ICHK_NM,TOL_NM,F_BST,KKT_BST,X_BST,U_BST,
     /     G_BST,V_BST,W_BST,IT_BST,QPSOLVE)
C
C*********************************************************************
C
C
C   NONLINEAR PROGRAMMING BY SOLVING QUADRATIC OR LEAST SQUARES
C   SUBPROBLEMS.
C
C   THIS IS THE BASIC SUBROUTINE TO SOLVE THE NONLINEAR
C   PROGRAMMING PROBLEM.
C
C
C*********************************************************************
C
      IMPLICIT  NONE
      INTEGER   L,N,MNN2,MNN,NMAX,MMAX,N1,NMNN,LWA,LIW,LACTIV,MAX_NM,
     /          MOUTMX
      DIMENSION X(NMAX,L),U(MNN2),VMU(MNN),DCL(NMAX,NMAX),DEL(N1),
     /          DLA(N),F(L),G(MMAX,L),DF(NMAX),DG(MMAX,NMAX),DCLF(N1),
     /          XOLD(N),DLAOLD(N),CD(NMAX),BDEL(N),ETA(N),
     /          XL(N),XU(N),V(N1),W(N1),VMUOLD(MNN),STACK_NM(50),
     /          DPHI(NMNN),RPEN(MNN),WA(LWA),IW(LIW),
     /          X_BST(N),U_BST(MNN2),G_BST(MMAX),V_BST(N),W_BST(N)
      LOGICAL   ACTIVE(LACTIV),LLINE,LREST,LALSD,LQL,LMERIT,LNMLSA
      DOUBLE PRECISION X,U,VMU,DCL,DEL,DLA,G,DF,DG,DCLF,XOLD,DLAOLD,
     /          CD,BDEL,ETA,XL,XU,V,W,VMUOLD,DPHI,RPEN,ACCLDL,WA,
     /          STACK_NM,TOL_NM,PMAX_NM,F_BST,KKT_BST,X_BST,U_BST,
     /          G_BST,V_BST,W_BST
      DOUBLE PRECISION F,ACC,DBDFAC,ZEFAC,RPENO,RPENS,RPENU,
     /          ZEFACU,DELTA,BETA,AMUE,ALM,ALPHAK
      DOUBLE PRECISION SRES,PHI,SQACC,SDCL11,DCL11,DFDEL,SUM,DBD,
     /          FACT,UAD,PROD,ALPHAM,ALPHAO,EDEL,DBD1,THETA,PHIOLD,
     /          DLAN,THETA1,DBDI,EDELI,SQD,ZERO,ONE,TW,UFLOW,OFLOW,
     /          XNM,DELNM,RPMAX,ACCQP,DSQRT,DABS,DMAX1,DMIN1,DBLE
      INTEGER   M,ME,MAXFUN,MAXIT,IPRINT,IFAIL,MODE,ISTACK,
     /          NFUNC,NGRAD,ITER,NQL,ILINE,IFLISE,NOPT,IW,NACT,
     /          ICHK_NM,IT_BST
      INTEGER   IOUT,MN,ME1,N2,LWAQL,IMERIT,IPR,IFAIL1,
     /          MN1,MNN1,I1,I,J,K,MMAX41,MODEQL
      INTRINSIC DSQRT,DABS,DMAX1,DMIN1,DBLE
      EXTERNAL  QPSOLVE,MERIT1,LINSEA,LDL001
C
C   CONSTANT DATA
C
      ZERO = 0.D+0
      ONE = 1.D+0
      TW = 2.D+0
      UFLOW = ACCQP**6
      IF (UFLOW.EQ.ZERO) UFLOW = ACCQP**5      
      IF (UFLOW.EQ.ZERO) UFLOW = ACCQP**4      
      IF (UFLOW.EQ.ZERO) UFLOW = ACCQP**3      
      IF (UFLOW.EQ.ZERO) UFLOW = ACCQP**2      
      IF (UFLOW.EQ.ZERO) UFLOW = ACCQP      
      OFLOW = ONE/UFLOW
C
C   INITIAL DEFINITIONS
C
      LNMLSA = .FALSE.
      LREST = .FALSE.
      IF (IFAIL.EQ.-2) ICHK_NM = 0
      MN = M+N
      ME1 = ME+1
      N2 = N+N
      MMAX41 = MMAX+41
      LWAQL = LWA-MMAX-50
      IMERIT = 0
      IF (.NOT.LMERIT) IMERIT = 4
      LALSD = .FALSE.
      SQACC = DSQRT(ACC)
      MODEQL = 0
      IF (LQL) MODEQL = 1
      IF (IFAIL.EQ.-1) GOTO 72
      IF (IFAIL.EQ.-2) GOTO 74
      ILINE = 0
      ALPHAO = ZERO
      NFUNC = 1
      NGRAD = 1
      ITER = 0
      NQL = 0
      NOPT = 0
      ISTACK = 0
      PMAX_NM = -OFLOW
      ICHK_NM = 0
      KKT_BST = OFLOW
      IT_BST = 0
      IF (MAX_NM.GT.0) THEN
         DO I = 1,MAX_NM
            STACK_NM(I) = -OFLOW
         ENDDO         
         IT_BST = 0
         F_BST = ZERO
         DO I = 1,N
            X_BST(I) = ZERO
            V_BST(I) = ZERO
            W_BST(I) = ZERO
         ENDDO
         IF (M.GT.0) THEN 
            DO J = 1,M  
               G_BST(J) = ZERO
            ENDDO
         ENDIF
         DO J = 1,MNN
            U_BST(J) = ZERO
         ENDDO   
      ENDIF      
      IF (M.GT.0) THEN
         DO J = 1,M
            ACTIVE(J) = .TRUE.
         ENDDO
      ENDIF
      DCLF(N1) = ZERO
      DF(N1) = ZERO
      DO I = 1,N
         DEL(I) = -DF(I)
         DCL(N1,I) = ZERO
         DCL(I,N1) = ZERO
      ENDDO
      DEL(N1) = ZERO
      DCL(N1,N1) = ZEFAC
      IF (MODE.EQ.0) THEN
         DO I = 1,N
            CD(I) = ONE
            DO J = 1,N
               DCL(I,J) = ZERO
            ENDDO
            DCL(I,I) = ONE
         ENDDO
      ENDIF
      DO J = 1,MNN
         RPEN(J) = RPENS
         VMU(J) = ZERO
         IF (MODE.EQ.1) VMU(J) = U(J)
      ENDDO
      CALL MERIT1(IMERIT+3,L,M,ME,MMAX,N,NMAX,MNN,NMNN,ACC,RPEN,
     /            F,DF,G,DG,VMU,U,X,XL,XU,PHI,DPHI,ACCQP,
     /            ACTIVE,LACTIV,WA,4)
C
C   START MAIN LOOP, PRINT INTERMEDIATE ITERATES
C
  100 CONTINUE
      LLINE = .FALSE.
      IF (IPRINT.GE.3) THEN
         WRITE(IOUT,1000) ITER,F(1),(X(I,1),I=1,N)
         IF (M.GT.0) THEN
            DO J = 1,M
               WA(MMAX41+J) = VMU(J)
               WA(MMAX41+M+J) = G(J,1)
            ENDDO
            IF (M.LE.MOUTMX) THEN
               WRITE(IOUT,1200) (WA(MMAX41+J),J=1,M),(VMU(M+J),J=1,N+N)
               WRITE(IOUT,1120) (WA(MMAX41+M+J),J=1,M)
            ENDIF   
         ELSE
            IF (M.LE.MOUTMX) WRITE(IOUT,1200) (VMU(M+J),J=1,N+N)
         ENDIF
      ENDIF
      ITER = ITER+1
      IF (ITER.GE.MAXIT) THEN
         IFAIL = 1
         IF (IPRINT.GT.0) WRITE(IOUT,1140)
         GOTO 90
      ENDIF
C
C   SEARCH DIRECTION
C
      DO I = 1,N
         DCLF(I) = DF(I)
         V(I) = XL(I) - X(I,1)
         W(I) = XU(I) - X(I,1)
      ENDDO
      IPR = 0
      IF (IPRINT.GT.10.AND.IPRINT.LT.1000) IPR = IPRINT-10
      IFAIL1 = 1
      CALL QPSOLVE(M,ME,MMAX,N,NMAX,MNN,DCL,DCLF,DG,G,V,W,DEL,U,
     /        ACCQP,MODEQL,IOUT,IFAIL1,IPR,WA(MMAX41),LWAQL,
     /        IW,LIW)
      IF (IFAIL1.EQ.5) THEN         
         IFAIL = 5
         IF (IPRINT.GT.0) WRITE(IOUT,1160) 
         RETURN
      ENDIF 
      DEL(N1) = ZERO
      NQL = NQL+1
      IF (IFAIL1.EQ.0) GOTO 126
      IF (ITER.EQ.1) GOTO 154
      IF (DEL(N1).LT.ONE) THEN
         FACT = TW*DABS(DBD*DFDEL)/(DSQRT(DBD)*(ONE-DEL(N1)))
      ELSE
         FACT = TW*DABS(DBD*DFDEL)/DSQRT(DBD)
      ENDIF
      IF (LQL) FACT = FACT*FACT
      DCL11 = DMAX1(ZEFAC,FACT)
      DCL(N1,N1) = DMIN1(ZEFACU,DCL11)
  154 CONTINUE
      DO I = 1,N
         DEL(I) = ZERO
      ENDDO
      DEL(N1) = ONE
      IF (M.GT.0) THEN
         DO J = 1,M
            DG(J,N1) = -G(J,1)
            IF (.NOT.ACTIVE(J)) DG(J,N1) = ZERO
         ENDDO
      ENDIF
      V(N1) = ZERO
      W(N1) = ONE
      IFAIL1 = -1
      CALL QPSOLVE(M,ME,MMAX,N1,NMAX,MNN2,DCL,DCLF,DG,G,V,W,DEL,U,
     /        ACCQP,MODEQL,IOUT,IFAIL1,IPR,WA(MMAX41),LWAQL,
     /        IW,LIW)
      NQL = NQL+1
      MN1 = M+N1+1
      MNN1 = M+N1+N
      LREST = .TRUE.
      IF (IFAIL1.EQ.3) THEN
         IFAIL = 10
         IF (IPRINT.GT.0) WRITE(IOUT,1190) 
         GOTO 90
      ENDIF
      IF (IFAIL1.GT.100) THEN
         IFAIL = IFAIL1
         IF (IPRINT.GT.0) WRITE(IOUT,1150) IFAIL1
         GOTO 90
      ENDIF
      DO I = MN1,MNN1
         U(I-1) = U(I)
      ENDDO
      IF (IPRINT.GE.3) THEN
         SDCL11 = DCL(N1,N1)
         IF (.NOT.LQL) SDCL11 = DSQRT(SDCL11)
         WRITE(IOUT,1250) DEL(N1)
         WRITE(IOUT,1360) SDCL11
      ENDIF
      DCL11 = DCL(N1,N1)
      IF (DEL(N1).LT.DELTA) GOTO 126
      DCL(N1,N1) = DCL11*RPENO
      IF (LQL) DCL(N1,N1) = DCL(N1,N1)*RPENO
      IF (DCL11.LT.ZEFACU) GOTO 154
C
C   AUGMENTED LAGRANGIAN TYPE SEARCH DIRECTION
C
  151 LALSD = .TRUE.
      IF (IPRINT.GE.3) THEN
         WRITE(IOUT,1110)
      ENDIF
      CALL MERIT1(4,L,M,ME,MMAX,N,NMAX,MNN,NMNN,ACC,RPEN,
     /            F,DF,G,DG,VMU,U,X,XL,XU,PHI,DPHI,ACCQP,
     /            ACTIVE,LACTIV,WA,4)
      DO I = 1,N
         WA(40+I) = DPHI(I)
         DCLF(I) = DPHI(I)
      ENDDO
      IFAIL1 = 1
      CALL QPSOLVE(0,0,MMAX,N,NMAX,MNN2,DCL,DCLF,DG,G,V,W,DEL,U,
     /        ACCQP,MODEQL,IOUT,IFAIL1,IPR,WA(MMAX41),LWAQL,
     /        IW,LIW)
      IF (IFAIL1.EQ.3) THEN
         IFAIL = 10
         IF (IPRINT.GT.0) WRITE(IOUT,1190) 
         GOTO 90
      ENDIF
      IF (IFAIL1.GT.100) THEN
         IFAIL = IFAIL1
         IF (IPRINT.GT.0) WRITE(IOUT,1150) IFAIL1
         GOTO 90
      ENDIF
      IF (M.EQ.0) GOTO 129
      DO I = 1,N2
         I1 = I-1
         U(MNN-I1) = U(N2-I1)
      ENDDO
      DO J = 1,M
         U(J) = VMU(J) - DPHI(N+J)
      ENDDO
      GOTO 129
  126 LALSD = .FALSE.
C
C   PROJECTION OF DEL, MAXIMAL STEPLENGTH, AND NORM OF X,DEL
C
  129 ALPHAM = OFLOW
      XNM = ZERO
      DELNM = ZERO
      DO I = 1,N
         IF (W(I).LT.DEL(I)) DEL(I) = W(I)
         IF (V(I).GT.DEL(I)) DEL(I) = V(I)
         UAD = DABS(DEL(I))
         IF (DEL(I).GT.UFLOW) ALPHAM = DMIN1(ALPHAM,W(I)/DEL(I))
         IF (DEL(I).LT.-UFLOW) ALPHAM = DMIN1(ALPHAM,V(I)/DEL(I))
         XNM = DMAX1(DABS(X(I,1)),XNM)
         DELNM = DMAX1(UAD,DELNM)
      ENDDO
      ALPHAM = DMAX1(ONE,ALPHAM)
      ALPHAM = DMIN1(ALPHAM,ALM)
C
C   GRADIENT OF LAGRANGIAN
C
   18 DO I = 1,N
         UAD = DF(I)
         IF (LALSD) UAD = DPHI(I)
         DLA(I) = UAD - U(M+I) - U(MN+I)
      ENDDO
      IF (M.EQ.0.OR.LALSD) GOTO 57
      DO J = 1,M
         IF (U(J).NE.ZERO) THEN
            DO I = 1,N
               DLA(I) = DLA(I) - DG(J,I)*U(J)
            ENDDO
         ENDIF
      ENDDO
   57 CONTINUE
      IF (LLINE) GOTO 19
C
C   STORE SOME DATA
C
      DFDEL = ZERO
      DLAN = ZERO
      DO I = 1,N
         DFDEL = DFDEL + DF(I)*DEL(I)
         DLAOLD(I) = DLA(I)
         DLAN = DMAX1(DLAN,DABS(DLA(I)))
         XOLD(I) = X(I,1)
      ENDDO
      DO J = 1,MNN
         VMUOLD(J) = VMU(J)
      ENDDO
C
C   DETERMINE B*D AND D(T)*B*D
C
      DBD = ZERO
      IF (LQL) THEN
         DO I = 1,N
            SUM = ZERO
            DO J = 1,N
               SUM = SUM + DCL(I,J)*DEL(J)
            ENDDO
            DBD = DBD + SUM*DEL(I)
            BDEL(I) = SUM
         ENDDO
      ELSE
         DO I = 1,N
            SUM = ZERO
            DO J = I,N
               SUM = SUM + DCL(I,J)*DEL(J)
            ENDDO
            ETA(I) = SUM
         ENDDO
         DO I = 1,N
            DBD = DBD + ETA(I)*ETA(I)
            SUM = ZERO
            DO J = 1,I
               SUM = SUM + DCL(J,I)*ETA(J)
            ENDDO
            BDEL(I) = SUM
         ENDDO
      ENDIF
C
C   TEST FOR OPTIMALITY AND FINAL OUTPUT
C
      SRES = ZERO
      SUM = DABS(DFDEL)
      NACT = 0
      IF (M.GT.0) THEN
         DO J = 1,M
            IF (ACTIVE(J)) NACT = NACT + 1
            UAD = DABS(G(J,1))
            IF (J.LE.ME.OR.G(J,1).LT.ZERO) SRES = SRES + UAD
         SUM = SUM + DABS(U(J)*G(J,1))
         ENDDO
      ENDIF
      IF (IPRINT.GE.3) THEN
         WRITE(IOUT,1500) SRES
         WRITE(IOUT,1510) NACT
      ENDIF
      DO I = 1,N
         SUM = SUM + DABS(U(M+I)*V(I)) + DABS(U(MN+I)*W(I))
      ENDDO
C
C   STORE BEST VALUES      
C      
      IF ((SUM.LT.KKT_BST).AND.(MAX_NM.GT.0)) THEN
         KKT_BST = SUM
         IT_BST = ITER
         F_BST = F(1)
         DO I = 1,N
            X_BST(I) = X(I,1)
            V_BST(I) = V(I)
            W_BST(I) = W(I)
         ENDDO
         IF (M.GT.0) THEN 
            DO J = 1,M  
               G_BST(J) = G(J,1)
            ENDDO
         ENDIF
         DO J = 1,MNN
            U_BST(J) = U(J)
         ENDDO   
      ENDIF         
C
C   INTERMEDIATE OUTPUT      
C      
      IF (IPRINT.EQ.2) THEN
         IF (M.GT.MOUTMX) THEN
            WRITE(IOUT,1460) ITER,F(1),SRES,NACT,ILINE,ALPHAO,
     /                       DEL(N1),SUM
         ELSE
            WRITE(IOUT,1461) ITER,F(1),SRES,NACT,ILINE,ALPHAO,
     /                       DEL(N1),SUM
         ENDIF
      ENDIF
      IF (IPRINT.GE.3) THEN
         WRITE(IOUT,1520) SUM
         WRITE(IOUT,1530) DLAN
      ENDIF
      IF (DBD.GE.UFLOW) GOTO 43
      IF (SRES.LT.SQACC) THEN
         IF (IPRINT.GT.0) WRITE(IOUT,1269)
         GOTO 59
      ENDIF   
      IF (DBD.GT.ZERO) GOTO 127
      IF (.NOT.LALSD) GOTO 151
  201 IFAIL = 7
      IF (IPRINT.GT.0) WRITE(IOUT,1440)
      GOTO 90
   43 CONTINUE
      IF (SUM.GE.ACC.OR.SRES.GT.SQACC) GOTO 127
      IF (DLAN.LE.DSQRT(SQACC).OR.DBD.LE.ACC) GOTO 59
      NOPT = NOPT+1
      IF (NOPT.LT.3) GOTO 127
   59 IFAIL = 0
   90 CONTINUE
C
C   SAVE BEST VALUES
C
      IF ((IFAIL.GT.0).AND.(MAX_NM.GT.0)) THEN
         IF (IPRINT.GT.0) THEN
            WRITE(IOUT,1271)
            WRITE(IOUT,1280) F(1)
            WRITE(IOUT,1290) (X(I,1),I=1,N)
            IF (M.LE.MOUTMX) WRITE(IOUT,1300) (U(J),J=1,MNN)
            IF (M.GT.0.AND.M.LE.MOUTMX) 
     /                   WRITE(IOUT,1310) (G(J,1),J=1,M)
            WRITE(IOUT,1320) (V(I),I=1,N)
            WRITE(IOUT,1330) (W(I),I=1,N)
         ENDIF
         F(1) = F_BST
         DO I = 1,N
            X(I,1) = X_BST(I)
            V(I) = V_BST(I)
            W(I) = W_BST(I)
         ENDDO
         IF (M.GT.0) THEN 
            DO J = 1,M  
               G(J,1) = G_BST(J)
            ENDDO
         ENDIF
         DO J = 1,MNN
            U(J) = U_BST(J)
         ENDDO   
      ENDIF   
C
C   WRITE FINAL OUTPUT
C  
      IF (IPRINT.GT.0) THEN
         IF (MAX_NM.GT.0) THEN
            WRITE(IOUT,1270)
            WRITE(IOUT,1275) IT_BST
         ELSE 
            WRITE(IOUT,1271)   
         ENDIF   
         WRITE(IOUT,1280) F(1)
         WRITE(IOUT,1290) (X(I,1),I=1,N)
         IF (M.LE.MOUTMX) WRITE(IOUT,1300) (U(J),J = 1,MNN)
         IF (M.GT.0.AND.M.LE.MOUTMX) WRITE(IOUT,1310) (G(J,1),J=1,M)
         WRITE(IOUT,1320) (V(I),I=1,N)
         WRITE(IOUT,1330) (W(I),I=1,N)
         WRITE(IOUT,1390) NFUNC
         WRITE(IOUT,1340) NGRAD
         WRITE(IOUT,1400) NQL
      ENDIF
      GOTO 9999
  127 CONTINUE
C
C   CORRECT PENALTY PARAMETER
C
      IF (.NOT.LALSD) THEN
         WA(1) = DBD
         WA(2) = DEL(N1)
         WA(3) = RPENU
         WA(4) = DBLE(ITER)
         CALL MERIT1(IMERIT+2,L,M,ME,MMAX,N,NMAX,MNN,NMNN,ACC,RPEN,
     /               F,DF,G,DG,VMU,U,X,XL,XU,PHI,DPHI,ACCQP,
     /               ACTIVE,LACTIV,WA,4)
         GOTO 99
      ENDIF
      SUM = ZERO
      DO I = 1,N
         SUM = SUM + DPHI(I)*DEL(I) + DABS(U(M+I)*V(I))
     /                                  + DABS(U(MN+I)*W(I))
      ENDDO
      IF (SUM.GT.DSQRT(SQACC)) GOTO 99
      DO J = 1,MNN
         RPEN(J) = DMIN1(ZEFACU,RPEN(J)*RPENO)
      ENDDO
      CALL MERIT1(IMERIT+4,L,M,ME,MMAX,N,NMAX,MNN,NMNN,ACC,RPEN,
     /            F,DF,G,DG,VMU,U,X,XL,XU,PHI,DPHI,ACCQP,
     /            ACTIVE,LACTIV,WA,4)
   99 IF (IPRINT.GE.3) THEN
         WRITE(IOUT,1260) DBD
         IF (M.LE.MOUTMX) WRITE(IOUT,1230) (RPEN(J),J=1,MNN)
      ENDIF
C
C   EVALUATION OF MERIT FUNCTION
C
   95 CALL MERIT1(IMERIT+3,L,M,ME,MMAX,N,NMAX,MNN,NMNN,ACC,RPEN,
     /            F,DF,G,DG,VMU,U,X,XL,XU,PHI,DPHI,ACCQP,
     /            ACTIVE,LACTIV,WA,4)
      IF (.NOT.LALSD) CALL MERIT1(IMERIT+4,L,M,ME,MMAX,N,NMAX,MNN,
     /            NMNN,ACC,RPEN,F,DF,G,DG,VMU,U,X,XL,XU,PHI,DPHI,
     /            ACCQP,ACTIVE,LACTIV,WA,4)
      PROD = ZERO
      DO I = 1,N
         PROD = PROD + DPHI(I)*DEL(I)
      ENDDO
      DO J = 1,MNN
         PROD = PROD + DPHI(J+N)*(U(J) - VMU(J))
      ENDDO
      PHIOLD = PHI
      IF (PROD.LT.ZERO) GOTO 28
      RPMAX = ZERO
      DO J = 1,MNN
         RPEN(J) = RPEN(J)*RPENO
         RPMAX = DMAX1(RPMAX,RPEN(J))
      ENDDO
      IF (RPMAX.LT.RPENU) GOTO 95
      IF (LALSD) GOTO 98
C      IF (.NOT.LREST.OR.DBD.LT.ACC) GOTO 151
      IF (.NOT.LREST.OR.DBD.LT.UFLOW) GOTO 151
      DCL11 = DCL(N1,N1)
      IF (DCL11.GE.ZEFACU) GOTO 151
      DCL11 = DCL11*RPENO
      IF (LQL) DCL11 = DCL11*RPENO
      DCL(N1,N1) = DCL11
      GOTO 154
   98 CONTINUE
      IFAIL = 2
      IF (IPRINT.GT.0) WRITE(IOUT,1180) PROD
      GOTO 90
   28 CONTINUE
      IF (IPRINT.GE.3) WRITE(IOUT,1350) PROD
C
C   LINE SEARCH
C
      WA(6) = XNM
      WA(7) = DELNM
      IFLISE = 0
      IF (L.GT.1) THEN
         ALPHAK = ALPHAM
         DO K = 1,L
            DO I = 1,N
               X(I,K) = XOLD(I) + ALPHAK*DEL(I)
            ENDDO
            ALPHAK = ALPHAK*BETA
         ENDDO
      ENDIF
   14 IPR = 0
      IF (IPRINT.GE.1000) IPR = IPRINT-1000
      IF ((IPRINT.EQ.4).AND.(IFLISE.LT.0)) THEN
         WRITE(IOUT,2810) ILINE,ALPHAO,PHI
      ENDIF
   27 CONTINUE
      CALL LINSEA(L-1,ALPHAO,ALPHAM,PHI,PROD,AMUE,BETA,ILINE,
     /            MAXFUN,IFLISE,WA(6),WA(7))
C
C   WRITE MERIT FUNCTION VALUE INTO STACK
C     
      IF (MAX_NM.GT.0) THEN 
         IF ((ILINE.EQ.1).AND.(ICHK_NM.EQ.0)) THEN     
            ISTACK = ISTACK+1
            IF (ISTACK.GT.MAX_NM) THEN
               ISTACK = 1
            ENDIF      
            STACK_NM(ISTACK) = PHI
         ENDIF   
         IF (((ICHK_NM.EQ.0).AND.(IFLISE.EQ.1).AND..NOT.LNMLSA).OR.
     /           ((ICHK_NM.EQ.0).AND.LNMLSA)) THEN
            IFLISE = 0
            ICHK_NM = 1
            IF (ITER.EQ.1) THEN
               IF (STACK_NM(1).GT.ACC) THEN
                  PMAX_NM = STACK_NM(1)*(ONE+TOL_NM)
               ELSE   
                  IF (STACK_NM(1).LT.-ACC) THEN
                     PMAX_NM = STACK_NM(1)*(ONE-TOL_NM)
                  ELSE
                     PMAX_NM = TOL_NM
                  ENDIF
               ENDIF     
            ELSE   
               PMAX_NM = -OFLOW
               DO I = 1,MAX_NM
                  IF (STACK_NM(I).GT.PMAX_NM) PMAX_NM = STACK_NM(I)
               ENDDO   
            ENDIF   
            PHI = PMAX_NM
            GOTO 27
         ENDIF   
      ENDIF          
      IF (IFLISE.EQ.1) GOTO 10
      IF (L.EQ.1) THEN
         DO I = 1,N
            X(I,1) = XOLD(I) + ALPHAO*DEL(I)
         ENDDO
      ELSE
         DO I = 1,N
            X(I,1) = X(I,ILINE)
         ENDDO
      ENDIF
      DO J = 1,MNN
         VMU(J) = VMUOLD(J) + ALPHAO*(U(J) - VMUOLD(J))
      ENDDO
      IF (IFLISE.EQ.0) GOTO 13
      GOTO 197
   10 IFAIL = 4
      IF (IPRINT.GT.0) WRITE(IOUT,1130)
      GOTO 90
   13 LLINE = .TRUE.
      IF (IPRINT.GE.3) THEN
         IF (ILINE.EQ.1) WRITE(IOUT,1090)
         IF (ILINE.GT.1) WRITE(IOUT,1170) ILINE,ALPHAO
      ENDIF
      GOTO 17
  197 CONTINUE
C
C   NEW FUNCTION AND GRADIENT VALUES
C
      IF ((ILINE.EQ.1).OR.(L.EQ.1)) THEN
         NFUNC = NFUNC+1
         IFAIL = -1
         GOTO 9999
      ELSE
         F(1) = F(ILINE)
         IF (M.GT.0) THEN
            DO J = 1,M
               G(J,1) = G(J,ILINE)
            ENDDO
         ENDIF
      ENDIF
   72 CONTINUE
      CALL MERIT1(IMERIT+3,L,M,ME,MMAX,N,NMAX,MNN,NMNN,ACC,RPEN,
     /            F,DF,G,DG,VMU,U,X,XL,XU,PHI,DPHI,ACCQP,
     /            ACTIVE,LACTIV,WA,4)
      IF (.NOT.LLINE) GOTO 14
   17 CONTINUE
      CALL MERIT1(IMERIT+1,L,M,ME,MMAX,N,NMAX,MNN,NMNN,ACC,RPEN,
     /            F,DF,G,DG,VMU,U,X,XL,XU,PHI,DPHI,ACCQP,
     /            ACTIVE,LACTIV,WA,4)
      IFAIL = -2
      GOTO 9999
   74 CONTINUE
      NGRAD = NGRAD+1
      IF (LLINE) GOTO 18
      CALL MERIT1(IMERIT+4,L,M,ME,MMAX,N,NMAX,MNN,NMNN,ACC,RPEN,
     /            F,DF,G,DG,VMU,U,X,XL,XU,PHI,DPHI,ACCQP,
     /            ACTIVE,LACTIV,WA,4)
      PROD = ZERO
      DO I = 1,N
         PROD = PROD + DPHI(I)*DEL(I)
      ENDDO
      DO J = 1,MNN
         PROD = PROD + DPHI(N+J)*(U(J) - VMUOLD(J))
      ENDDO
      GOTO 14
C
C   UPDATE HESSIAN OF LAGRANGIAN
C
   19 EDEL = ZERO
      DBD = DBD*ALPHAO*ALPHAO
      DO I = 1,N
         BDEL(I) = BDEL(I)*ALPHAO
         ETA(I) = DLA(I) - DLAOLD(I)
         EDEL = EDEL + ALPHAO*DEL(I)*ETA(I)
      ENDDO
      DBD1 = DBDFAC*DBD
      IF (EDEL.GE.DBD1) GOTO 31
      THETA = (DBD - DBD1)/(DBD - EDEL)
      THETA1 = ONE - THETA
      DO I = 1,N
         ETA(I) = THETA*ETA(I) + THETA1*BDEL(I)
      ENDDO
      EDEL = DBD1
   31 CONTINUE
      IF (DBD.GT.ZERO) DBDI = DSQRT(ONE/DBD)
      IF (EDEL.GT.ZERO) THEN 
         EDELI = DSQRT(ONE/EDEL)
      ELSE
         EDELI = ZERO
      ENDIF      
C
C   UPDATE FACTORIZATION
C
      DO I = 1,N
         BDEL(I) = DBDI*BDEL(I)
         ETA(I) = EDELI*ETA(I)
      ENDDO
      IF (.NOT.LQL) GOTO 85
      DO I = 1,N
         DO J = I,N
            DCL(I,J) = DCL(I,J) + ETA(I)*ETA(J) - BDEL(I)*BDEL(J)
            DCL(J,I) = DCL(I,J)
         ENDDO
      ENDDO
      GOTO 100
   85 CONTINUE
      CALL LDL001(N,NMAX,DCL,CD,ETA,BDEL,ACCLDL)
C
C   CORRECT DATA FOR QL-SOLUTION
C
    2 DO I = 1,N
         IF (CD(I).LE.UFLOW) THEN
            IFAIL = 3
            IF (IPRINT.GT.0) WRITE(IOUT,1370) 
            GOTO 90
         ENDIF    
         SQD = DSQRT(CD(I))
         I1 = I+1
         IF (I1.LE.N) THEN
            DO J = I1,N
               DCL(I,J) = SQD*DCL(J,I)
            ENDDO
         ENDIF
         DCL(I,I) = SQD
      ENDDO
C
C   PERFORM NEXT ITERATION
C
      GOTO 100
C
C   END OF NLPQP2
C
 9999 RETURN
C
C   FORMAT-STATEMENTS
C
 1000 FORMAT(//5X,'Iteration',I8,//8X,'Function value:  F(X) =',
     /     D16.8,/8X,'Variable:  X =',/,(9X,4D16.8))
 1090 FORMAT(8X,'Line search successful after one step:  ALPHA = 1')
 1170 FORMAT(8X,'Line search successful after',I3,' steps:',
     /     '  ALPHA =',D13.4)
 1200 FORMAT(8X,'Multipliers:  U =',/,(9X,4D16.8))
 1110 FORMAT(8X,' *** WARNING: Augmented Lagrangian search direction')
 1120 FORMAT(8X,'Constraints: G(X) =',/,(9X,4D16.8))
 1130 FORMAT(8X,' *** ERROR 4: Error in line search, e.g., more than',
     /          ' MAXFUN iterations')
 1140 FORMAT(8X,' *** ERROR 1: More than MAXIT iterations')
 1150 FORMAT(8X,' *** ERROR: Internal error in QL, IFAIL(QL) =',I8)
 1160 FORMAT(8X,' *** ERROR 5: Insufficient working space for QPSOLVE.',
     /     /,8X,'              Either LKWA or LWA to small',I8)
 1180 FORMAT(8X,' *** ERROR 2: Search direction not profitable:  ',
     /                       'DPHI*P =',D13.4)
 1190 FORMAT(8X,' *** ERROR 10: Internal inconsistency in QL,',
     /          ' division by zero')
 1260 FORMAT(8X,'Product of search direction with BFGS matrix: ',
     /          '   DBD =',D13.4)
 1230 FORMAT(8X,'Penalty parameter:  R =',/,(9X,4D16.8))
 1250 FORMAT( 8X,'Additional variable to prevent inconsistency:',
     /           '  DELTA =',D13.4)
 1269 FORMAT(8X,' *** WARNING: Zero search direction at feasible',
     /                                            ' point.',/,
     /       8X,'              The final iterate may not be optimal!')
 1270 FORMAT(//,5X,' --- Final Convergence Analysis at Best Iterate ',
     /             '---',/)
 1271 FORMAT(//,5X,' --- Final Convergence Analysis at Last Iterate ',
     /             '---',/)
 1272 FORMAT(//)    
 1275 FORMAT(8X,'Best result at iteration:      ITER  =',I8)
 1280 FORMAT(8X,'Objective function value:      F(X)  =',D16.8)
 1290 FORMAT(8X,'Approximation of solution:     X     =',/,(9X,4D16.8))
 1300 FORMAT(8X,'Approximation of multipliers:  U     =',/,(9X,4D16.8))
 1310 FORMAT(8X,'Constraint values:             G(X)  =',/,(9X,4D16.8))
 1320 FORMAT(8X,'Distance from lower bound:     XL-X  =',/,(9X,4D16.8))
 1330 FORMAT(8X,'Distance from upper bound:     XU-X  =',/,(9X,4D16.8))
 1350 FORMAT(8X,'Product of Lag-gradient with ',
     /        'search direction:   DLP =',D13.4)
 1390 FORMAT(8X,'Number of function calls:      NFUNC =',I8)
 1340 FORMAT(8X,'Number of gradient calls:      NGRAD =',I8)
 1400 FORMAT(8X,'Number of calls of QP solver:  NQL   =',I8,///)
 1360 FORMAT(8X,'Penalty parameter for DELTA:  RHO =',D13.4)
 1370 FORMAT(8X,' *** ERROR 3: Underflow in BFGS update')
 1440 FORMAT(8X,' *** ERROR 7: Underflow in D(T)*B*D ',
     /                     'and infeasible iterate')
 1460 FORMAT(3X,I5,D16.8,D10.2,I8,I3,D10.2,F7.3,D10.2)
 1461 FORMAT(3X,I5,D16.8,D10.2,I5,I3,3D10.2)
 1500 FORMAT(8X,'Sum of constraint violations:',20X,'SCV =',
     /     D13.4)
 1510 FORMAT(8X,'Number of active constraints:',20X,'NAC =',I4)
 1520 FORMAT(8X,'Karush-Kuhn-Tucker optimality condition:',
     /     9X,'KKT =',D13.4)
 1530 FORMAT(8X,'Norm of Lagrangian gradient:',21X,'NLG =',D13.4)
 2810 FORMAT(8X,'Line search',I3,': ALPHA =',D9.2,
     /     ', merit function FCT =',G10.2)
C
      END
C
C
C
      SUBROUTINE LDL001(N,NMAX,CL,D,U,V,EPS)
C
C********************************************************************
C
C
C   UPDATE CHOLESKEY FACTORIZATION
C
C     L*D*L(T) = L*D*L(T) + U*U(T) - V*V(T)
C
C
C********************************************************************
C
      IMPLICIT NONE
      INTEGER N,NMAX
      DIMENSION CL(NMAX,N),D(N),U(N),V(N)
      INTEGER R,J,J1,I,I1,N1
      DOUBLE PRECISION CL,D,U,V,EPS,T,ONE,ZERO,FOUR,PJ,DJ,TNEW,TT,TTI,
     /                 DJNEW,BETA,CLRJ,PDP,SUM,UI
C
C   CONSTANT DATA
C
      ONE = 1.D+0
      ZERO = 0.D+0
      FOUR = 4.D+0
C
C   UPDATE L*D*L(T) + U*U(T)
C
      T = ONE
      DO 1 J = 1,N
      PJ = U(J)
      DJ = D(J)
      TNEW = T + PJ*PJ/DJ
      TT = TNEW/T
      TTI = ONE/TT
      DJNEW = DJ*TT
      BETA = PJ/(DJ*TNEW)
      J1 = J+1
      IF (J1.GT.N) GOTO 5
      IF (DJNEW.LE.FOUR*DJ) GOTO 2
      DO R = J1,N
         CLRJ = CL(R,J)
         CL(R,J) = TTI*CLRJ + BETA*U(R)
         U(R) = U(R) - PJ*CLRJ
      ENDDO
      GOTO 5
    2 DO R = J1,N
         U(R) = U(R) - PJ*CL(R,J)
         CL(R,J) = CL(R,J) + BETA*U(R)
      ENDDO
    5 T = TNEW
      D(J) = DJNEW
    1 CONTINUE
C
C   UPDATE L*D*L(T) - V*V(T)
C
      U(1) = V(1)
      PDP = U(1)*U(1)/D(1)
      DO I = 2,N
         SUM = ZERO
         I1 = I-1
         DO J = 1,I1
            SUM = SUM + CL(I,J)*U(J)
         ENDDO
         UI = V(I) - SUM
         PDP = PDP + UI*UI/D(I)
        U(I) = UI
      ENDDO
C
      T = ONE - PDP
      IF (T.LE.EPS) T = EPS
C
      N1 = N+1
      DO 8 I = 1,N
      J = N1-I
      PJ = U(J)
      DJ = D(J)
      TNEW = T + PJ*PJ/DJ
      TT = T/TNEW
      DJNEW = DJ*TT
      BETA = -PJ/(DJ*T)
      V(J) = PJ
      T = TNEW
      D(J) = DJNEW
      J1 = J+1
      IF (J1.GT.N) GOTO 8
      DO R = J1,N
         CLRJ = CL(R,J)
         CL(R,J) = CLRJ + BETA*V(R)
         V(R) = V(R) + PJ*CLRJ
      ENDDO
    8 CONTINUE
C
C   END OF LDL001
C
      RETURN
      END
C
      SUBROUTINE LINSEA(MODE,ALPHA,ALPHAM,PHI,DPHI,AMUE,BETA,ILINE,
     /                  MAXFUN,IFAIL,WA1,WA2)
C
C*********************************************************************
C
C
C   LINE SEARCH ALGORITHM BASED ON QUADRATIC INTERPOLATION AND ARMIJO-
C   TYPE STOPPING CRITERION.
C
C
C*********************************************************************
C
      IMPLICIT NONE
      DOUBLE PRECISION ALPHA,ALPHAM,PHI,DPHI,AMUE,BETA,HALF,DIFF,
     /                 WA1,WA2,DMAX1
      INTRINSIC DMAX1
      INTEGER MODE,ILINE,MAXFUN,IFAIL
C
C   CONSTANT PARAMETERS
C
      HALF = 5.0D-1
      IF (MODE.GT.0) HALF = 0.0D+0
C
C   START LINE SEARCH
C
      IF (IFAIL.EQ.-1) GOTO 1
      WA1 = PHI
      ILINE = 0
      ALPHA = ALPHAM
      WA2 = ALPHA
    2 ILINE = ILINE+1
      DPHI = DPHI*WA2
      IFAIL = -1
      GOTO 9999
    1 IF (ILINE.LT.MAXFUN) GOTO 3
      IFAIL = 1
      GOTO 9999
    3 DIFF = PHI - WA1
      IF (DIFF.GT.AMUE*DPHI) GOTO 4
      IFAIL = 0
      GOTO 9999
    4 WA2 = DMAX1(BETA,HALF*DPHI/(DPHI - DIFF))
      ALPHA = WA2*ALPHA
      GOTO 2
C
C   END OF LINSEA
C
 9999 RETURN
      END
      SUBROUTINE MERIT1(MODE,L,M,ME,MMAX,N,NMAX,MNN,NMNN,ACC,R,F,
     /                  DF,G,DG,V,U,X,XL,XU,PHI,DPHI,EPS,ACTIVE,LACTIV,
     /                  WA,LWA)
C
C*********************************************************************
C
C
C   FUNCTION AND GRADIENT EVALUATIONS OF THE AUGMENTED LAGRANGIAN
C   MERIT FUNCTION, PENALTY PARAMETERS, AND ACTIVE SET
C
C
C*********************************************************************
C
      IMPLICIT NONE
      INTEGER   MODE,L,M,ME,MMAX,N,NMAX,MNN,NMNN,LWA,LACTIV
      DIMENSION R(MNN),F(L),DF(N),G(MMAX,L),DG(MMAX,N),V(MNN),U(MNN),
     /          X(NMAX,L),
     /          XL(N),XU(N),DPHI(NMNN),ACTIVE(LACTIV),WA(LWA)
      DOUBLE PRECISION ACC,R,F,DF,G,DG,V,U,X,XL,XU,PHI,DPHI,WA
      LOGICAL   ACTIVE
      DOUBLE PRECISION FACT,RNEW,UAD,PHI1,RMJ,RMI,RMNJ,RMNI,VMI,VMNI,
     /          XMXL,XUMX,SUM,ZERO,UFLOW,HA,ONE,EPS,DBLE,DSQRT,DMIN1,
     /          DMAX1,DABS
      INTRINSIC DBLE,DSQRT,DMIN1,DMAX1,DABS
      INTEGER ME1,J,MN,I
C
C   CONSTANT DATA
C
      ZERO = 0.D+0
      UFLOW = EPS*EPS
      HA = 5.D-1
      ONE = 1.D+0
      GOTO (1,2,3,3,5,6,7,8),MODE
C
C   EVALUATION OF ACTIVE SET
C
    1 IF (M.EQ.0.OR.ME.EQ.M) RETURN
      ME1 = ME+1
      DO J = ME1,M
         ACTIVE(J) = .TRUE.
         IF (V(J).EQ.ZERO.AND.G(J,1).GT.ACC) ACTIVE(J) = .FALSE.
      ENDDO
      RETURN
C
C   EVALUATION OF PENALTY PARAMETER
C
    2 FACT = WA(3)
      IF (WA(1).GT.UFLOW) FACT = DBLE(2*M)/(WA(1) + (ONE-WA(2)))
      DO J = 1,MNN
         RNEW = DMIN1(WA(3),FACT*(U(J) - V(J))**2)
         UAD = DMIN1(R(J),WA(4)*DSQRT(R(J)))
         R(J) = DMAX1(RNEW,UAD)
      ENDDO
      RETURN
C
C   PREPARE EVALUATION OF AUGMENTED LAGRANGIAN
C
    3 IF (M.GT.0) THEN
         DO J = 1,M
            ACTIVE(M+J) = .TRUE.
            IF (J.GT.ME.AND.R(J)*G(J,1).GT.V(J)) ACTIVE(M+J) = .FALSE.
         ENDDO
      ENDIF
      IF (MODE.EQ.4) GOTO 4
C
C   EVALUATION OF AUGMENTED LAGRANGIAN VALUE
C
      PHI = F(1)
      IF (M.GT.0) THEN
         DO J = 1,M
            IF (ACTIVE(M+J)) PHI1 = (V(J) - HA*R(J)*G(J,1))*G(J,1)
            IF (.NOT.ACTIVE(M+J)) PHI1 = HA*V(J)*V(J)/R(J)
            PHI = PHI - PHI1
         ENDDO
      ENDIF
      MN = M+N
      DO I = 1,N
        RMJ = R(M+I)
         RMI = ONE/RMJ
         RMNJ = R(MN+I)
        RMNI = ONE/RMNJ
         VMI = V(M+I)
         VMNI = V(MN+I)
         XMXL = X(I,1) - XL(I)
         XUMX = XU(I) - X(I,1)
         IF (XMXL.LE.VMI*RMI) PHI = PHI - (VMI-HA*RMJ*XMXL)*XMXL
         IF (XMXL.GT.VMI*RMI) PHI = PHI - HA*RMI*VMI*VMI
         IF (XUMX.LE.VMNI*RMNI) PHI = PHI - (VMNI-HA*RMNJ*XUMX)*XUMX
         IF (XUMX.GT.VMNI*RMNI) PHI = PHI - HA*RMNI*VMNI*VMNI
      ENDDO
      RETURN
C
C   GRADIENT EVALUATION OF AUGMENTED LAGRANGIAN
C
    4 DO I = 1,N
         DPHI(I) = DF(I)
         SUM = ZERO
         IF (M.GT.0) THEN
            DO J = 1,M
               IF (ACTIVE(M+J)) SUM = SUM + DG(J,I)*(V(J) - R(J)*G(J,1))
            ENDDO
         ENDIF
         DPHI(I) = DPHI(I) - SUM
      ENDDO
      IF (M.GT.0) THEN
         DO J = 1,M
            IF (ACTIVE(M+J)) DPHI(N+J) = -G(J,1)
            IF (.NOT.ACTIVE(M+J)) DPHI(N+J) = -V(J)/R(J)
         ENDDO
      ENDIF
      MN = M+N
      DO I = 1,N
         VMI = V(M+I)
         VMNI = V(MN+I)
         XMXL = X(I,1) - XL(I)
         XUMX = XU(I) - X(I,1)
         RMJ = R(M+I)
         RMI = ONE/RMJ
         RMNJ = R(MN+I)
         RMNI = ONE/RMNJ
         IF (XMXL.LE.VMI*RMI) DPHI(I) = DPHI(I) - VMI + RMJ*XMXL
         IF (XUMX.LE.VMNI*RMNI) DPHI(I) = DPHI(I) + VMNI - RMNJ*XUMX
         IF (XMXL.LE.VMI*RMI) DPHI(MN+I) = -XMXL
         IF (XMXL.GT.VMI*RMI) DPHI(MN+I) = -VMI*RMI
         IF (XUMX.LE.VMNI*RMNI) DPHI(MNN+I) = -XUMX
         IF (XUMX.GT.VMNI*RMNI) DPHI(MNN+I) = -VMNI*RMNI
      ENDDO
      RETURN
C
C   EVALUATION OF L1-PENALTY FUNCTION
C
C   ACTIVE SET
C
    5 IF (M.GT.0) THEN
         DO J = 1,M
            ACTIVE(J) = .TRUE.
         ENDDO
      ENDIF
C
C   PENALTY PARAMETER
C
    6 DO J = 1,MNN
         PHI1 = DABS(U(J))
         R(J) = DMAX1(PHI1,HA*(R(J)+PHI1))
      ENDDO
      RETURN
C
C   MERIT FUNCTION VALUE
C
    7 PHI = F(1)
      IF (M.GT.0) THEN
         DO J = 1,M
            PHI1 = DABS(G(J,1))
            IF (J.GT.ME.AND.G(J,1).GT.ZERO) PHI1 = ZERO
            PHI = PHI + R(J)*PHI1
         ENDDO
      ENDIF
C
C   GRADIENT OF MERIT FUNCTION
C
    8 DO J = N,NMNN
         DPHI(J) = ZERO
      ENDDO
      DO I = 1,N
         DPHI(I) = DF(I)
         IF (M.GT.0) THEN
            PHI1 = ZERO
            DO J = 1,M
               IF (G(J,1).GT.ZERO.AND.J.LE.ME) 
     /                             PHI1 = PHI1 + R(J)*DG(J,I)
               IF (G(J,1).LE.ZERO) PHI1 = PHI1 - R(J)*DG(J,I)
            ENDDO
            DPHI(I) = DPHI(I) + PHI1
         ENDIF
      ENDDO
      RETURN
C
C   END OF MERIT1
C
      END
