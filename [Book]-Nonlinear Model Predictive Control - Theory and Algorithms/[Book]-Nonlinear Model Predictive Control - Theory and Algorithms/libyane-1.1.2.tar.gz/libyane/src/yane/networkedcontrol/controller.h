/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

//TODO Doku
#ifndef YANE_NETWORKEDCONTROL_CONTROLLER_H
#define YANE_NETWORKEDCONTROL_CONTROLLER_H

namespace yane
{

	namespace Model
	{
		class Model;
	}

	namespace MinProg
	{
		class NLP;
	}

	namespace Utils
	{
		class DebugMaster;
		class StatisticsMaster;
		class RTClock;
	}

	namespace MPC
	{
		class ModelShootingData;
		class OdeManager;
	}

	namespace NetworkedControl
	{
		class IOInterface;

		/** @class Controller
		 @brief Class for simulating a distributed plant - sensor - controller - actuator setting
		 */
		class Controller
		{
			public:
				/**
				 Constructor
				 @param model Pointer of the class yane::Model::Model object used for optimization and simulation
				 @param horizon Length of the horizon
				 @param prediction Number of preceding prediction steps
				 @param interface Pointer of the input/output interface of class yane::MPC::IOInterface
				 @param dm Pointer of the debugmanager of class yane::Utils::DebugMaster
				 @param sm Pointer of the statistics manager of class yane::Utils::StatisticsMaster
				 @brief Constructor
				 */
				Controller ( yane::Model::Model * model, int horizon, int prediction, IOInterface * iface,
				        yane::Utils::DebugMaster * debugmaster = 0, yane::Utils::StatisticsMaster * statisticsmaster =
				                0 );

				/**
				 @brief Destructor
				 */
				~Controller ( );

				/**
				 Function to return the used class yane::Model::Model object
				 @return Used class yane::Model::Model object
				 @brief Function to return the used class yane::Model::Model object
				 */
				yane::Model::Model * model ( );

			protected:
				yane::Model::Model * _model; /**< @brief Pointer of the class yane::Model::Model object used for optimization and simulation */
				int _horizon; /**< @brief Length of the control sequence to be computed */
				int _prediction; /**< @brief Length of the prediction between current time and the first time instant the computed control shall be valid */
				IOInterface * _interface; /**< @brief Pointer of the class yane::NetworkedControl::IOInterface object used for communication purposes */
				yane::Utils::DebugMaster * _debugmaster; /**< @brief Pointer of the class yane::Utils::DebugMaster object used for debugging */
				yane::Utils::StatisticsMaster * _statisticsmaster; /**< @brief Pointer of the class yane::Utils::StatisticsMaster object used for producing statistics */
		};

	}

}

#endif
