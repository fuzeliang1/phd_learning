/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_CONTROLLER_REALTIMEMPC_H
#define YANE_NETWORKEDCONTROL_CONTROLLER_REALTIMEMPC_H

#include "controller.h"

namespace yane
{

	namespace Model
	{
		class Model;
	}

	namespace MinProg
	{
		class NLP;
	}

	namespace Utils
	{
		class DebugMaster;
		class StatisticsMaster;
		class RTClock;
	}

	namespace MPC
	{
		class ModelShootingData;
		class OdeManager;
	}

	namespace NetworkedControl
	{
		class ControllerThreadMPC;
		class ControllerThreadOutput;
		class ControllerThreadInput;
		class ControllerThreadActuator;
		class IOInterface;
		class Cycle;

		/** @class RealtimeMPCController
		@brief Class for simulating a distributed plant - sensor - controller - actuator setting
		*/
		class RealtimeMPCController : public Controller
		{
			public:
				/**
				Constructor
				@param model Pointer of the class yane::Model::Model object used for optimization and simulation
				@param shootingdata Pointer of the yane::Model::ModelShootingData object used for optimization
				@param horizon Length of the horizon
				@param prediction Number of preceding prediction steps
				@param minimizer Pointer of the minimization routine of class yane::MinProg::NLP
				@param odemanager Pointer of the differential equation manager of class yane::MPC::OdeManager
				@param clock Pointer of a clock object for log messages
				@param interface Pointer of the input/output interface of class yane::MPC::IOInterface
				@param debugmaster Pointer of the debugmanager of class yane::Utils::DebugMaster
				@param statisticsmaster Pointer of the statistics manager of class yane::Utils::StatisticsMaster
				@brief Constructor
				 */
				RealtimeMPCController(yane::Model::Model * model, yane::MPC::ModelShootingData * shootingdata,
					     int horizon, int prediction,
					     yane::MinProg::NLP * minimizer, yane::MPC::OdeManager * odemanager,
					     yane::Utils::RTClock * clock, IOInterface * iface, yane::Utils::DebugMaster * debugmaster = 0, yane::Utils::StatisticsMaster * statisticsmaster = 0);

				/**
				@brief Destructor
				 */
				~RealtimeMPCController();

				/**
				@brief Function to start the controller
				 */
				virtual void start();

				/**
				@brief Function to stop the controller
				 */
				virtual void stop();

				/**
				 * Returns the internal cycle object used by the Network algorithm. Unlike the cycle()-object this
				 * one is internally created and continuesly adjusted to the timestamps of incoming sensor values.
				 * @return Pointer to the internal cycle object
				 * @brief Function to return the internal cycle object
				 */
				yane::NetworkedControl::Cycle * controllerCycle();

			protected:
				ControllerThreadMPC * _threadmpc;		/**< @brief Pointer of the thread for solving the MPC problem */
				ControllerThreadOutput * _threadoutput;		/**< @brief Pointer of the thread dealing with the output of the controller */
				ControllerThreadInput * _threadinput;		/**< @brief Pointer of the thread dealing with the input of the controller */
				ControllerThreadActuator * _threadactuator;	/**< @brief Pointer of the thread dealing with the actuator */

				yane::Model::Model * _model;			/**< @brief Pointer of the class yane::Model::Model object used for optimization and simulation */
		};

	}

}

#endif
