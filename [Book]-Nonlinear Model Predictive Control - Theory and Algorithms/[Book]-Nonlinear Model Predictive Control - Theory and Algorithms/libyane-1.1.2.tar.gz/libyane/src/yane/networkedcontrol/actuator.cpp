/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "actuator.h"
#include "iointerface.h"
#include "cycle.h"
#include "controlclipboard.h"

#include "../utils.h"
#include "../model.h"

#include <sstream>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::NetworkedControl::Actuator::Actuator ( yane::Model::Model * model, int horizon, T_RESPONSEFUNC func,
        void * ptr, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm )
{
	_horizon = horizon;
	_dimu = model->dimensionControl ( );
	_ptr = ptr;
	_actuatorfunction = func;
	_model = model;

	_cb = new ControlClipboard ( _dimu, horizon );

	if ( dm )
	{
		_debugclient = dm->newClient ( "Actuator" );
	}
	else
	{
		_debugclient = 0;
	}

	if ( sm )
	{
		_stat_collect = true;
		_stat_recvseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator", "received sequences" );
		_stat_outdatedseq
		        = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator", "received outdated sequences" );
		_stat_duplicateseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator",
		        "received duplicate sequences" );
		_stat_appliedseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator", "applied sequences" );
		_stat_bridgedseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator", "validly bridged sequences" );
		_stat_inconsistentseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator", "inconsistent sequences" );
		_stat_missingseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator", "missing sequences" );
		_stat_senterror = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator", "sent errors" );
		_stat_invalidatedseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator", "invalidated sequences" );
		_stat_bufferunderrun = new yane::Utils::StatisticsClientIntCounter ( sm, "Actuator", "buffer underruns" );
	}
	else
	{
		_stat_collect = false;
	}

	_u_seq = - 1;

	_u = new double [ _dimu * _horizon ];
	_defaultu = new double [ _dimu ];
	model->getDefaultControl ( _defaultu );
}

LIB_EXPORT yane::NetworkedControl::Actuator::~Actuator ( )
{
	delete _cb;
	delete _debugclient;
}

LIB_EXPORT void yane::NetworkedControl::Actuator::enterPacket ( void * packet, double * data )
{
	T_OUTPUTPACKET * pack = ( T_OUTPUTPACKET * ) packet;
	double * control = data;

	if ( pack->code == IOInterface::OUTPUTCODE )
	{
		if ( _debugclient )
		{
			stringstream out;
			out << "packet received (seq=" << pack->seq << ", preseq=" << pack->preseq << ")";
			_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
		}

		_cb->lock ( );

		if ( pack->seq < _seq )
		{
			if ( _debugclient )
			{
				_debugclient->sendDebugMessage ( "packet is too old: do not store.", DEBUG_ALGORITHM );
			}
			if ( _stat_collect )
			{
				_stat_outdatedseq->addValue ( 1 );
			}
		}
		else if ( _cb->hasCycle ( pack->seq ) )
		{
			if ( _debugclient )
			{
				_debugclient->sendDebugMessageInt ( "control sequence already exist: do not store.", "existinc seq", 1,
				        & pack->seq, DEBUG_ALGORITHM );
			}
			if ( _stat_collect )
			{
				_stat_duplicateseq->addValue ( 1 );
			}
		}
		else
		{
			if ( _debugclient )
			{
				_debugclient->sendDebugMessageDouble ( "adding control", "control", _horizon * _dimu, control,
				        DEBUG_ALGDETAILS );
			}
			_cb->addData ( pack->seq, pack->preseq, 0.0, control );
			if ( _stat_collect )
			{
				_stat_recvseq->addValue ( 1 );
			}
		}

		_cb->unlock ( );
	}
	else
	{
		if ( _debugclient )
		{
			_debugclient->sendDebugMessage ( "weird packetcode!", DEBUG_BASE );
		}
	}
}

LIB_EXPORT void yane::NetworkedControl::Actuator::getCurrentControl ( double * control )
{
	int seq = _seq;
	int sequencecursor;

	_cb->lock ( );

	if ( _cb->size ( ) == 0 )
	{
		sequencecursor = _horizon;
		if ( _debugclient )
		{
			_debugclient->sendDebugMessage ( "controlclipboard is empty!", DEBUG_ALGORITHM );
		}
	}
	else
	{
		int preseq;
		bool error;
		double calcduration;
		bool gotdata = _cb->getValidatedData ( seq, preseq, error, calcduration, _u );

		if ( gotdata )
		{
			if ( error )
			{
				if ( _debugclient )
				{
					stringstream out;
					out << "got fresh data, but inconsistent seq=" << seq << ", consistent preseq is " << preseq;
					_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
				}

				proceedError ( seq, preseq );
				sequencecursor = seq - preseq;
				if ( _stat_collect )
				{
					_stat_inconsistentseq->addValue ( 1 );
				}
			}
			else
			{
				_u_seq = seq;
				sequencecursor = 0;
				if ( _stat_collect )
				{
					_stat_appliedseq->addValue ( 1 );
				}
			}
		}
		else
		{
			int parentseq;
			int nextpreseq;
			int nextseq;
			bool isconsistent = _cb->getConsistencyInfo ( seq, parentseq, nextseq, nextpreseq );
			if ( ! isconsistent )
			{
				if ( _debugclient )
				{
					stringstream out;
					if ( nextseq == - 1 )
					{
						out << "seq " << seq
						        << " has no fresh data and future cycles do not exist. A packet has possibly been lost.";
					}
					else
					{
						out << "seq " << seq << " has no fresh data. nearby seqs are not consistent (older seq="
						        << parentseq << ", future seq=" << nextseq << ", future preseq=" << nextpreseq << ")";
					}
					_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
				}
				proceedError ( seq, parentseq );
				if ( _stat_collect )
				{
					if ( seq - parentseq <= _horizon )
					{
						_stat_bridgedseq->addValue ( 1 );
					}
					else
					{
						_stat_missingseq->addValue ( 1 );
					}
				}
			}
			else
			{
				if ( _debugclient )
				{
					stringstream out;
					out << "seq " << seq << " has no fresh data, but nearby seqs are consistent (older seq="
					        << parentseq << ", future seq=" << nextseq << ", future preseq=" << nextpreseq << ")";
					_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
				}
				if ( _stat_collect )
				{
					if ( seq - parentseq <= _horizon )
					{
						_stat_bridgedseq->addValue ( 1 );
					}
					else
					{
						_stat_missingseq->addValue ( 1 );
					}
				}
			}
			sequencecursor = seq - parentseq;
		}
	}

	_cb->cleanup ( seq - _horizon, seq );
	_cb->unlock ( );

	stringstream out;
	if ( sequencecursor < _horizon && _u_seq != - 1 )
	{
		memcpy ( control, & _u [ sequencecursor * _dimu ], sizeof(double) * _dimu );

		if ( _debugclient )
		{
			out << "SETTING CONTROL, u_seq=" << _u_seq << " , u_index=" << sequencecursor;
			_debugclient->sendDebugMessageDouble ( out.str ( ), "control", _dimu, control, DEBUG_ALGORITHM );
		}
	}
	else
	{
		memcpy ( control, _defaultu, sizeof(double) * _dimu );
		sequencecursor = _horizon;
		if ( _debugclient )
		{
			out << "empty buffer, SETTING DEFAULTCONTROL";
			_debugclient->sendDebugMessageDouble ( out.str ( ), "control", _dimu, control, DEBUG_ALGORITHM );
		}
		if ( _stat_collect )
		{
			_stat_bufferunderrun->addValue ( 1 );
		}
	}
}

LIB_EXPORT void yane::NetworkedControl::Actuator::proceedError ( int seq, int preseq )
{
	if ( _actuatorfunction )
	{
		if ( _debugclient )
		{
			stringstream out;
			out << "Setting errorflag=true (sigma_err=" << seq << ", cycle_err_pre=" << preseq
			        << "), invalidating cycles > " << preseq;
			_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
		}

		int previous = _cb->size ( );
		_cb->invalidateCycle ( preseq + 1 );

		T_ACTORPACKET response;
		response.code = IOInterface::ACTORERRORCODE;
		response.seq_err = seq;
		response.preseq_err = preseq;
		_actuatorfunction ( & response, _ptr );
		if ( _stat_collect )
		{
			_stat_senterror->addValue ( 1 );
			_stat_invalidatedseq->addValue ( previous - _cb->size ( ) );
		}
	}
	else
	{
		if ( _debugclient )
		{
			_debugclient->sendDebugMessage ( "actuatorresponse is not active.", DEBUG_ALGORITHM );
		}
	}
}

LIB_EXPORT void yane::NetworkedControl::Actuator::setSamplingInstant ( int samplingInstant )
{
	_seq = samplingInstant;
}
