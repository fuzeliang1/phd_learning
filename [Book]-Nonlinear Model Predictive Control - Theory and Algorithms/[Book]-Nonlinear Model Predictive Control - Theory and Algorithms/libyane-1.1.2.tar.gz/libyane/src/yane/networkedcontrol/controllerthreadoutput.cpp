/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "controllerthreadoutput.h"
#include "iointerface.h"
#include "typedefs.h"

#include "../utils.h"
#include "../model.h"
#include "../mpc.h"

#include <cstring>
#include <sstream>

using namespace std;

yane::NetworkedControl::ControllerThreadOutput::ControllerThreadOutput(IOInterface * iface, yane::Model::Model * model, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm)
	: yane::Utils::Thread("Controller: Output", dm)
{
	_data = 0;
	_interface = iface;
	_model = model;
	if (sm != 0)
	{
		_stat_sent = new yane::Utils::StatisticsClientIntCounter(sm, "Controller", "sent sequences");
	} else
	{
		_stat_sent = 0;
	}
}

yane::NetworkedControl::ControllerThreadOutput::~ ControllerThreadOutput()
{
	if (_data) delete _data;
}

void yane::NetworkedControl::ControllerThreadOutput::run()
{
	T_OUTPUTPACKET packet;
	packet.code = IOInterface::OUTPUTCODE;

	while (!_abort)
	{
		if (waitForTrigger(1000, DEBUG_INNERDETAILS))
		{
			lock();
			if (_debugclient)
			{
				stringstream str;
				str << "Sending outputpacket (preseq=" << _preseq << ", seq=" << _seq << ", length=" << _interface->sequenceLength() << ")";
				debugMessageDouble(str.str(), "controlsequence", _interface->sequenceLength(), _data, DEBUG_ALGORITHM);
			}
			packet.preseq = _preseq;
			packet.seq = _seq;
			try
			{
				debugMessage("sending control sequence to interface...", DEBUG_INNERDETAILS);
				_interface->writeOutput(&packet, _data);
				debugMessage("done!", DEBUG_INNERDETAILS);
				if (_stat_sent != 0)
				{
					_stat_sent->addValue(1);
				}
			} catch (yane::Utils::Exception e)
			{
				debugMessageString("interface output method failed!", "e.what()", e.what(), DEBUG_CRITICAL);
			}
			unlock();
		}
		if (!_interface->isConnected())
		{
			debugMessage("Interface is no more in connected state... aborted", DEBUG_CRITICAL);
			_abort = true;
		}
	}
}

bool yane::NetworkedControl::ControllerThreadOutput::setOutputSequence(int preseq, int seq, int horizon, double * data)
{
	if (trylock())
	{
		if (!_data)
		{
			_data = new double[horizon*_model->dimensionControl()];
		} else if (horizon != _horizon)
		{
			delete _data;
			_data = new double[horizon*_model->dimensionControl()];
		}

		_preseq = preseq;
		_seq = seq;
		_horizon = horizon;
		memcpy(_data, data, sizeof(double)*horizon*_model->dimensionControl());

		unlock();

		return true;
	}
	return false;
}
