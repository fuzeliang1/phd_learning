/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_CTRLSERVERTCP_H
#define YANE_NETWORKEDCONTROL_CTRLSERVERTCP_H

#include "commbasetcp.h"

namespace yane
{
	namespace Utils
	{
		class StatisticsMaster;
	}
	namespace Model
	{
		class Model;
	}
	namespace NetworkedControl
	{

		class Cycle;

		/** @class CtrlServerTCP
		not yet documented
		 */
		class CtrlServerTCP : public CommBaseTCP
		{
			public:

				CtrlServerTCP(yane::Model::Model * model, const char * servername, int maxseqlength, double discrtime, T_MESSAGECALLBACK mess_cb, void* ptr, int readbuffersize, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm);

				virtual ~CtrlServerTCP();

				void startListening(int port);
				void stopListening();
				bool waitForConnection(int timeout_sec);

				const char * clientName();
				int sequenceLength();

			protected:
				char * _modelname;
				char * _servername;
				char * _clientname;
				int _maxseqlength;
				int _seqlength;
				double _discrtime;
				yane::Model::Model * _model;
		};
	}
}

#endif
