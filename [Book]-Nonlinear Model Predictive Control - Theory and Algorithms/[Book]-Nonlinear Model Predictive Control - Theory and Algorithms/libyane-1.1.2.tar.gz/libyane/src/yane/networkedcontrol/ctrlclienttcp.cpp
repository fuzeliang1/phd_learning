/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "ctrlclienttcp.h"
#include "typedefs.h"

#include "../version.h"
#include "../utils.h"
#include "../mpc.h"

// TODO WINDOWS includes �berpr�fen (clode() durch closesocket() bereits �berall ersetzt)
#ifdef _WIN32
	#include <winsock.h>
#else
	#include <unistd.h>
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <netdb.h>
	#include <cstring>
	#include <sys/select.h>
	#include <sys/time.h>
	#include <iostream>
	#include <sstream>
#endif

using namespace std;

yane::NetworkedControl::CtrlClientTCP::CtrlClientTCP(const char * clientname, int seqlengthhint, T_MESSAGECALLBACK mess_cb, void* ptr, int readbuffersize, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm)
	:CommBaseTCP(mess_cb, ptr, readbuffersize, "TCP Network Client", dm, sm)
{
	_clientname = new char[128];

	strncpy(_clientname, clientname, 127);

	_clientname[127] = '\0';
	_seqlengthhint = seqlengthhint;
	_discrtime = 0.0;

}

yane::NetworkedControl::CtrlClientTCP::~ CtrlClientTCP()
{
	delete[] _clientname;
}

bool yane::NetworkedControl::CtrlClientTCP::connectToServer(const yane::Utils::Uuid & modelid, const char * addr, int port)
{
	_connectionestablished = false;

	int n;
#ifdef _WIN32
	int length;
#else
	socklen_t length;
#endif
	struct sockaddr_in server;
	struct hostent *hp;

	T_HS_CLIENTMESSAGE clmess;
	T_HS_SERVERMESSAGE servmess;
	T_HS_SERVERRESPONSE servresponse;

	debugMessage("opening socket...", DEBUG_INNERDETAILS);
	_talksocket= socket(AF_INET, SOCK_STREAM, 0);
	if (_talksocket < 0)
	{
		debugMessage("error opening socket", DEBUG_CRITICAL);
		return false;
	}

	debugMessage("resolving hostname...", DEBUG_INNERDETAILS);

	server.sin_family = AF_INET;
	hp = gethostbyname(addr);
	if (hp==0)
	{
		debugMessage("resolving hostname failed... maybe unknown", DEBUG_CRITICAL);
		return false;
	}

	debugMessage("connecting...", DEBUG_INNERDETAILS);

	// TODO WINDOWS bcopy macht doch auch nichts anderes als memcopy, oder?
#ifdef _WIN32
	memcpy(hp->h_addr, &server.sin_addr, hp->h_length);
#else
	bcopy((char *)hp->h_addr, (char *)&server.sin_addr, hp->h_length);
#endif

	server.sin_port = htons(port);

	length=sizeof(struct sockaddr_in);
	if (connect(_talksocket, (struct sockaddr *)&server,length) < 0)
	{
		debugMessage("error while connecting", DEBUG_CRITICAL);
		return false;
	}

	debugMessage("connected to server, waiting for server header...", DEBUG_INNERDETAILS);

	if (!tryRead(_talksocket,(char*)&servmess,sizeof(T_HS_SERVERMESSAGE), n, 30))
	{
		debugMessage("read timeout, or other error", DEBUG_CRITICAL);
#ifdef _WIN32
		closesocket(_talksocket);
#else
		close(_talksocket);
#endif
		return false;
	}

	if (servmess.code != CODE1)
	{
		debugMessage("handshake failed (bad packet #1)", DEBUG_CRITICAL);
#ifdef _WIN32
		closesocket(_talksocket);
#else
		close(_talksocket);
#endif
		return false;
	}

	if (servmess.protocolversion != PROTVER)
	{
		debugMessage("server uses wrong protocol version", DEBUG_CRITICAL);
#ifdef _WIN32
		closesocket(_talksocket);
#else
		close(_talksocket);
#endif
		return false;
	}
	servmess.model[127] = '\0';
	servmess.servername[127] = '\0';

	if (_seqlengthhint > servmess.maxsequencelength)
	{
		_seqlength = servmess.maxsequencelength;
	} else
	{
		_seqlength = _seqlengthhint;
	}
	_discrtime = servmess.discrtime;
	if (yane::Utils::Uuid(servmess.modelid) != modelid)
	{
		debugMessage("Model types of controller and actuator do not match", DEBUG_CRITICAL);
#ifdef _WIN32
		closesocket(_talksocket);
#else
		close(_talksocket);
#endif
		return false;
	}

	if (_debugclient)
	{
		stringstream mess;
		mess << "modelname: " << servmess.model << endl;
		mess << "modelid: " << modelid.toString() << endl;
		mess << "name: " << servmess.servername << endl;
		mess << "protocolversion: " << servmess.protocolversion << endl;
		mess << "softwareversion: " << servmess.ver_maj << "." << servmess.ver_min << "." << servmess.ver_rev << endl;
		mess << "seqlength: " << _seqlength << endl;
		mess << "discrtime: " << _discrtime;

		debugMessageString("got serversided handshake-packet", "serverinfo", mess.str().c_str(), DEBUG_INNERDETAILS);
	}


	clmess.code = servmess.clientcode;
	clmess.protocolversion = PROTVER;
	clmess.sequencelength = _seqlength;
	libyane::versionStringToInt(libyane::version(), clmess.ver_maj, clmess.ver_min, clmess.ver_rev);
	strcpy(clmess.clientname, _clientname);

	debugMessage("sending client header", DEBUG_INNERDETAILS);
	if (!tryWrite(_talksocket,(char*)&clmess, sizeof(T_HS_CLIENTMESSAGE)))
	{
		debugMessage("sending handshake-packet failed", DEBUG_CRITICAL);
#ifdef _WIN32
		closesocket(_talksocket);
#else
		close(_talksocket);
#endif
		return false;
	}

	debugMessage("waiting for server response", DEBUG_INNERDETAILS);
	if (!tryRead(_talksocket,(char*)&servresponse,sizeof(servresponse), n, 30))
	{
		debugMessage("read timeout, or other error", DEBUG_CRITICAL);
#ifdef _WIN32
		closesocket(_talksocket);
#else
		close(_talksocket);
#endif
		return false;
	}

	if (servresponse.code != CODE2)
	{
		debugMessage("handshake failed (bad packet #2)", DEBUG_CRITICAL);
#ifdef _WIN32
		closesocket(_talksocket);
#else
		close(_talksocket);
#endif
		return false;
	}

	if (servresponse.error)
	{
		servresponse.errormessage[127] = '\0';

		debugMessageString("server denies access", "servermessage", servresponse.errormessage, DEBUG_CRITICAL);
#ifdef _WIN32
		closesocket(_talksocket);
#else
		close(_talksocket);
#endif
		return false;
	}

	_connectionestablished = true;
	start();
	debugMessage("connection established", DEBUG_INNERDETAILS);
}



int yane::NetworkedControl::CtrlClientTCP::sequenceLength()
{
	return _seqlength;
}

double yane::NetworkedControl::CtrlClientTCP::discrTime()
{
	return _discrtime;
}

