/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_CONTROLLERTHREADACTUATOR_H
#define YANE_NETWORKEDCONTROL_CONTROLLERTHREADACTUATOR_H

#include "../utils/thread.h"

namespace yane
{

	namespace Utils
	{
		class StatisticsMaster;
		class StatisticsClientIntCounter;
		class RTClock;
	}

	namespace NetworkedControl
	{
		class IOInterface;
		class ControllerThreadMPC;

		/** @class ControllerThreadActuator
		@brief Class for implementing the actuator within a distributed plant - sensor - controller - actuator setting
		*/
		class ControllerThreadActuator : public yane::Utils::Thread
		{
			public:
				/**
				Constructor
				@param interface Pointer of the interface object of class yane::MPC::IOInterface
				@param cycle Pointer of the cycling object of class yane::MPC::Cycle
				@param dm Pointer of the debug manager of class yane::Utils::DebugMaster
				@param sm Pointer of the statistics manager of class yane::Utils::StatisticsMaster
				@brief Constructor
				 */
				ControllerThreadActuator ( IOInterface * iface, yane::Utils::DebugMaster* dm = 0, yane::Utils::StatisticsMaster * sm = 0 );

				/**
				@brief Destructor
				 */
				virtual ~ControllerThreadActuator();

				/**
				Function to define the thread to be used for the actuator
				@param thread Pointer of the thread to be used
				@brief Function to define the thread to be used for the actuator
				 */
				void setMPCThread(ControllerThreadMPC * thread);

			protected:
				/**
				@brief Function to start the actuator thread
				 */
				virtual void run();

				IOInterface * _interface;					/**< @brief Pointer of the interface object of class yane::MPC::IOInterface */
				ControllerThreadMPC * _mpcthread;				/**< @brief Pointer of the corresponding class yane::MPC::ControllerThreadMPC object */
				yane::Utils::StatisticsClientIntCounter * _stat_received;	/**< @brief Pointer of the statistics client counter of class yane::Utils::StatisticsClientIntCounter */

		};

	}

}

#endif
