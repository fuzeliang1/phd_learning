/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "controllerthreadinput.h"
#include "controllerthreadmpc.h"
#include "iointerface.h"
#include "controlclipboard.h"

#include "../minprog.h"
#include "../model.h"
#include "../utils.h"

#include <cmath>
#include <cstring>

yane::NetworkedControl::ControllerThreadInput::ControllerThreadInput(IOInterface * iface, yane::Model::Model * model, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm)
	: yane::Utils::Thread("Controller: Input", dm)
{
	_interface = iface;
	_mpcthread = 0;
	_model = model;
	if (sm != 0)
	{
		_stat_read = new yane::Utils::StatisticsClientIntCounter(sm, "Controller", "received sensorvalues");
	}
	else
	{
		_stat_read = 0;
	}
	
	bool isparam[] = {false, true, false, true};
	_estimator = new yane::Model::StateEstimator( model, 15, isparam);
	_lastaddedcontrolcycle = -1;
	_simulator = new yane::Model::Simulator(_model);
}

yane::NetworkedControl::ControllerThreadInput::~ ControllerThreadInput()
{
}

void yane::NetworkedControl::ControllerThreadInput::run()
{
	T_INPUTPACKET packet;
	double * data = new double[_model->dimensionState()];

	if (!_mpcthread)
	{
		debugMessage("No MPC-Thread specified!", DEBUG_CRITICAL);

		return;
	}

	while(!_abort)
	{
		packet.code = 0;

		try
		{
			debugMessage("reading sensor values from interface...", DEBUG_INNERDETAILS);
			_interface->readInput(&packet, data);
			debugMessage("done!", DEBUG_INNERDETAILS);
		} catch (yane::Utils::Exception e)
		{
			debugMessageString("interface input method failed!", "e.what()", e.what(), DEBUG_CRITICAL);
		}

		if (packet.code == IOInterface::INPUTCODE)
		{
			debugMessage("sending sensor values to mpc thread...", DEBUG_INNERDETAILS);
			_mpcthread->setNewState(packet.time, data);
			debugMessage("done!", DEBUG_INNERDETAILS);
			
			if (_stat_read)
			{
				_stat_read->addValue(1);
			}
		} else
		{
			debugMessageInt("Invalid packet code", "code", 1, &(packet.code), DEBUG_INNERDETAILS);
		}
		if (!_interface->isConnected())
		{
			debugMessage("Interface is no more in connected state... aborted", DEBUG_CRITICAL);
			_abort = true;
		}
	}

	delete data;
}


void yane::NetworkedControl::ControllerThreadInput::setMPCThread(ControllerThreadMPC * thread)
{
	_cb = thread->controlClipboard();
	_mpcthread = thread;
}
