/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */


#ifndef YANE_NETWORKEDCONTROL_MODELHANDLERTCP_H
#define YANE_NETWORKEDCONTROL_MODELHANDLERTCP_H

#include "../utils/thread.h"

namespace yane
{

	namespace Model
	{
		class Model;
	}

	namespace Utils
	{
		class DebugMaster;
		class StatisticsMaster;
	}

	namespace NetworkedControl
	{

		class Cycle;
		class Actuator;
		class CtrlServerTCP;

		/** @class ModelHandlerTCP
		not yet documented
		*/
		class ModelHandlerTCP : public yane::Utils::Thread
		{
			public:
				ModelHandlerTCP(yane::Model::Model * model, Cycle * cycle, int maxseqlength=100, yane::Utils::DebugMaster * dm = 0, yane::Utils::StatisticsMaster * sm = 0, int tcpport=41923, int buffersize=8192);
				virtual ~ModelHandlerTCP();

				void sendSensorValues(double time, double * values);
				void getCurrentControl(double * control);

				bool isConnected();
				void closeConnection();

			protected:

				virtual void controllerConnecting();
				virtual void controllerConnected();
				virtual void controllerDisconnecting();
				virtual void controllerDisconnected();

				virtual void run();

				static void tcp_callback(char* packetdata, int packetlength, void*ptr);
				static void actuator_callback(void * packet, void * ptr);

				int _tcpport;
				int _buffersize;
				int _maxseqlength;

				Actuator * _actuator;
				CtrlServerTCP * _server;
				yane::Model::Model * _model;
				Cycle * _cycle;
				yane::Utils::DebugMaster * _dm;
				yane::Utils::StatisticsMaster * _sm;

				char * _senddata;


		};

	}

}

#endif
