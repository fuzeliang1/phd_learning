/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "iointerfacelocal.h"
#include "modelhandlerlocal.h"

#include "../mpc.h"
#include "../model.h"
#include "../utils.h"

#include <cstring>
#include <cstdlib>

yane::NetworkedControl::IOInterfaceLocal::IOInterfaceLocal ( yane::NetworkedControl::ModelHandlerLocal * modelhandler,
        int sequencelength, double samplingTime ) :
	yane::NetworkedControl::IOInterface::IOInterface ( )
{
	_modelhandler = modelhandler;
	_model = modelhandler->model ( );
	_sequenceLength = sequencelength;
	_samplingTime = samplingTime;

	_x = new double [ modelhandler->model ( )->dimensionState ( ) ];
}

yane::NetworkedControl::IOInterfaceLocal::~IOInterfaceLocal ( )
{
	delete [ ] _x;
}

void yane::NetworkedControl::IOInterfaceLocal::readInput ( T_INPUTPACKET * indata, double * data )
{
	_modelhandler->readState ( _t, _x );
	indata->code = INPUTCODE;
	indata->time = _t;
	memcpy ( data, _x, sizeof(double) * _model->dimensionState ( ) );
}

void yane::NetworkedControl::IOInterfaceLocal::writeOutput ( T_OUTPUTPACKET * outdata, double * data )
{
	_modelhandler->actuator ( )->enterPacket ( outdata, data );
}

void yane::NetworkedControl::IOInterfaceLocal::readActor ( T_ACTORPACKET * response )
{
	if ( _modelhandler->hasActorPacket ( ) && _modelhandler->currentActorPacket ( ).code == ACTORERRORCODE )
	{
		* response = _modelhandler->currentActorPacket ( );
	}
	else
	{
		response->code = 0;
	}
}

int yane::NetworkedControl::IOInterfaceLocal::sequenceLength ( )
{
	return _sequenceLength;
}

double yane::NetworkedControl::IOInterfaceLocal::samplingTime ( )
{
	return _samplingTime;
}

bool yane::NetworkedControl::IOInterfaceLocal::isConnected ( )
{
	return true;
}

yane::NetworkedControl::ModelHandlerLocal * yane::NetworkedControl::IOInterfaceLocal::modelhandler ( )
{
	return _modelhandler;
}

void yane::NetworkedControl::IOInterfaceLocal::setSamplingInstant ( int seq )
{
	_modelhandler->actuator ( )->setSamplingInstant ( seq );
}

void yane::NetworkedControl::IOInterfaceLocal::triggerProcessToImplementControl ( double currentSamplingInstant,
        double nextSamplingInstant )
{
	_modelhandler->implementControl ( currentSamplingInstant, nextSamplingInstant );
}
