/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

//TODO Doku
#ifndef YANE_NETWORKEDCONTROL_IOINTERFACELOCAL_H
#define YANE_NETWORKEDCONTROL_IOINTERFACELOCAL_H

#include "iointerface.h"

namespace yane
{
	namespace NetworkedControl
	{
		class Cycle;
		class ModelHandlerLocal;

		/** @class IOInterfaceLocal
		 * @brief Class for connecting components in a distributed plant - sensor - controller - actuator setting with a simulated network connection
		 */
		class IOInterfaceLocal : public yane::NetworkedControl::IOInterface
		{
			public:
				/**
				 * Constructor
				 * @param modelhandler Pointer of the simulated model handler
				 * @param packetlength Length of the control sequence
				 * @param samplingTime Sampling period
				 * @brief Constructor
				 */
				IOInterfaceLocal ( yane::NetworkedControl::ModelHandlerLocal * modelhandler, int packetlength,
				        double samplingTime );

				/**
				 * Destructor
				 */
				~IOInterfaceLocal ( );

				virtual void writeOutput ( yane::NetworkedControl::T_OUTPUTPACKET * outdata, double * data );
				virtual void readActor ( yane::NetworkedControl::T_ACTORPACKET * response );
				virtual void readInput ( yane::NetworkedControl::T_INPUTPACKET * indata, double * data );

				virtual int sequenceLength ( );
				virtual double samplingTime ( );
				virtual bool isConnected ( );

				yane::NetworkedControl::ModelHandlerLocal * modelhandler ( );

				/**
				 * Function to set the current sampling instant
				 * @param seq Current sampling instant
				 * @brief Function to set the current sampling instant
				 */
				void setSamplingInstant ( int seq );

				/**
				 * Function to trigger the plant to apply the control
				 * @param currentSamplingInstant Time instant to start the implementation of the control
				 * @param nextSamplingInstant Time instant to stop the implementation of the control
				 * @brief Function to trigger the plant to apply the control
				 */
				void triggerProcessToImplementControl ( double currentSamplingInstant, double nextSamplingInstant );

			protected:
				yane::NetworkedControl::ModelHandlerLocal * _modelhandler; /**< @brief Pointer of the simulated model handler */
				int _seq; /**< @brief Current sampling instant */
				double * _x; /**< @brief Pointer of the state vector */
				double _t; /**< @brief Current sampling time */
		};
	}
}
#endif
