/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */


#include "modelhandlertcp.h"
#include "actuator_realtime.h"
#include "iointerface.h"
#include "cycle.h"
#include "ctrlservertcp.h"
#include "typedefs.h"

#include "../model.h"

#include <cstring>
#include <iostream>

#ifdef _WIN32
	#include <windows.h>	// fuer Sleep
#endif

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::NetworkedControl::ModelHandlerTCP::ModelHandlerTCP(yane::Model::Model * model, Cycle * cycle, int maxseqlength, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm, int tcpport, int buffersize)
	: yane::Utils::Thread("Actuator Handler TCP", dm)
{
	_model = model;
	_cycle = cycle;
	_tcpport = tcpport;
	_buffersize = buffersize;
	_dm = dm;
	_sm = sm;
	_maxseqlength = maxseqlength;
	_actuator = 0;
	_server = new CtrlServerTCP(model, "Actuator Handler TCP", maxseqlength, cycle->discrTime(), tcp_callback, this, _buffersize, _dm, sm);

	_senddata = new char[_model->dimensionState()*sizeof(double)*sizeof(T_INPUTPACKET)];
}

LIB_EXPORT yane::NetworkedControl::ModelHandlerTCP::~ ModelHandlerTCP()
{

	stop();
	wait();

	delete _server;
	if (_actuator)
	{
		delete _actuator;
	}

	delete[] _senddata;
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::sendSensorValues(double time, double * values)
{
	T_INPUTPACKET * packet = (T_INPUTPACKET *)_senddata;

	packet->time = time;
	packet->code = IOInterface::INPUTCODE;
	memcpy(&_senddata[sizeof(T_INPUTPACKET)], values, sizeof(double)*_model->dimensionState());

	debugMessageDouble("sending sensorvalues", "sensorvalues", _model->dimensionState(), values, DEBUG_INNERDETAILS);
	_server->sendData(_senddata, _model->dimensionState()*sizeof(double)+sizeof(T_INPUTPACKET));
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::tcp_callback(char * packetdata, int packetlength, void * ptr)
{
	ModelHandlerTCP * base = (ModelHandlerTCP*)ptr;

	base->lock();
	if (base->_actuator)
	{
		base->debugMessage("got package from controller... giving it to actuator", DEBUG_INNERDETAILS);
		base->_actuator->enterPacket(packetdata, (double*)(&packetdata[sizeof(T_OUTPUTPACKET)]));
	}
	base->unlock();
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::actuator_callback(void * packet, void * ptr)
{
	ModelHandlerTCP * base = (ModelHandlerTCP*)ptr;

	if (base->_server && base->_server->isConnected())
	{
		int code = *((int*)packet);
		if (code)
		{
			base->debugMessage("sending actuator feedback", DEBUG_INNERDETAILS);
			base->_server->sendData((const char*)packet, sizeof(T_ACTORPACKET));
		}
	}
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::run()
{
	_server->startListening(_tcpport);
	while (!_abort)
	{
		while (!_server->waitForConnection(1) && !_abort);

		if (_server->isConnected())
		{
			_server->stopListening();

			controllerConnecting();

			lock();

			int seqlength = _server->sequenceLength();
			debugMessageInt("creating actuator object", "length of sequence", 1, &seqlength, DEBUG_INNERDETAILS);
			_actuator = new RealtimeActuator(_model, _cycle, _server->sequenceLength(), actuator_callback, this, _dm, _sm);

			unlock();

			controllerConnected();

			while(_server->isConnected() && !_abort)
			{
#ifdef _WIN32
				Sleep(1000);	// 1000 ms
#else
				sleep(1);	// 1 s
#endif
			}

			controllerDisconnecting();

			lock();
			debugMessage("destroying actuator", DEBUG_INNERDETAILS);
			delete _actuator;
			_actuator = 0;
			unlock();

			controllerDisconnected();

			_server->startListening(_tcpport);
		}

	}
	_server->stopListening();
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::getCurrentControl(double * control)
{
	lock();

	if (_actuator)
	{
		_actuator->getCurrentControl(control);
	} else
	{
		_model->getDefaultControl(control);
	}

	unlock();
}

LIB_EXPORT bool yane::NetworkedControl::ModelHandlerTCP::isConnected()
{
	return _server->isConnected();
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::closeConnection()
{
	_server->closeConnection();
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::controllerConnecting()
{
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::controllerConnected()
{
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::controllerDisconnecting()
{
}

LIB_EXPORT void yane::NetworkedControl::ModelHandlerTCP::controllerDisconnected()
{
}
