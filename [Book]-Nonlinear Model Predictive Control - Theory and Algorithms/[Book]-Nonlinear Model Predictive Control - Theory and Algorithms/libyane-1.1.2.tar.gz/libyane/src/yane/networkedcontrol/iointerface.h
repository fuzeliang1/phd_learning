/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_IOINTERFACE_H
#define YANE_NETWORKEDCONTROL_IOINTERFACE_H

#include "typedefs.h"

#include <stdint.h>

namespace yane
{
	namespace Model
	{
		class Model;
	}
	namespace NetworkedControl
	{

		/** @class IOInterface
		 @brief Class for connecting components in a distributed plant - sensor - controller - actuator setting
		 */
		class IOInterface
		{

			public:
				static const int OUTPUTCODE; /**< @brief Output error code */
				static const int INPUTCODE; /**< @brief Input error code */
				static const int ACTORERRORCODE; /**< @brief Actuator error code */
				static const int ACTORSUCCESSCODE; /**< @brief Actuator success code */

				/**
				 * @brief Constructor
				 */
				IOInterface ( );

				/**
				 * @brief Destructor
				 */
				virtual ~IOInterface ( );

				/**
				 * Function to send output from controller to network connection
				 * @param outdata Output data package
				 * @param data Additional data information
				 * @brief Function to send output from controller to network connection
				 */
				virtual void writeOutput ( T_OUTPUTPACKET * outdata, double * data ) = 0;

				/**
				 * Function to read actuator responds from network connection
				 * @param response Actuator responds packet
				 * @brief Function to read actuator responds from network connection
				 */
				virtual void readActor ( T_ACTORPACKET * response ) = 0;

				/**
				 * Function to read sensor input from network connection
				 * @param indata Sensor input packet
				 * @param data Additional data information
				 * @brief Function to read sensor input from network connection
				 */
				virtual void readInput ( T_INPUTPACKET * indata, double * data ) = 0;

				//TODO outputpacketlength als Sendelaenge im Controller beruecksichtigen

				/**
				 * Function to return the length of the sent control sequence
				 * @brief Function to return the length of the sent control sequence
				 */
				virtual int sequenceLength ( ) = 0;

				/**
				 * Function to return the sampling period
				 * @brief Function to return the sampling period
				 */
				virtual double samplingTime ( ) = 0;

				/**
				 * Function to return whether network connection has been established
				 * @brief Function to return whether network connection has been established
				 */
				virtual bool isConnected ( ) = 0;

				/**
				 * Function to return the used class yane::Model::Model pointer
				 * @brief Function to return the used class yane::Model::Model pointer
				 */
				yane::Model::Model * model ( );

			protected:
				yane::Model::Model * _model; /**< @brief Pointer of the used class yane::Model::Model model */
				int _sequenceLength; /**< @brief Length of the control sequence */
				double _samplingTime; /**< @brief Sampling period */
		};

	}

}

#endif
