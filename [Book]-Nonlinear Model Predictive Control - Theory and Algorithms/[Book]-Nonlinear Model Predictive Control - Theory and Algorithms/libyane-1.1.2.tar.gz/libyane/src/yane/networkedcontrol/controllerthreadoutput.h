/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_CONTROLLERTHREADOUTPUT_H
#define YANE_NETWORKEDCONTROL_CONTROLLERTHREADOUTPUT_H

#include "../utils/thread.h"

namespace yane
{

	namespace Model
	{
		class Model;
	}

	namespace Utils
	{
		class StatisticsMaster;
		class StatisticsClientIntCounter;
	}

	namespace NetworkedControl
	{
		class ControllerThreadMPC;
		class IOInterface;

		/** @class ControllerThreadOutput
		not yet documented
		 */
		class ControllerThreadOutput : public yane::Utils::Thread
		{
			public:
				ControllerThreadOutput ( IOInterface * iface, yane::Model::Model * model, yane::Utils::DebugMaster* dm = 0, yane::Utils::StatisticsMaster * sm = 0 );
				virtual ~ControllerThreadOutput();

				bool setOutputSequence(int preseq, int seq, int horizon, double * data);

			protected:
				virtual void run();

				int _preseq;
				int _seq;
				int _horizon;
				double * _data;

				IOInterface * _interface;
				yane::Utils::StatisticsClientIntCounter * _stat_sent;
				yane::Model::Model * _model;


		};

	}

}

#endif
