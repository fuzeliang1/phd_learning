/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */


#ifndef YANE_NETWORKEDCONTROL_COMMBASETCP_H
#define YANE_NETWORKEDCONTROL_COMMBASETCP_H

#include "../utils/thread.h"

#include <stdint.h>

#define PROTVER 1
#define CODE1 0x29F8A70B
#define CODE2 0xA0926E8F

namespace yane
{
	namespace Utils
	{
		class FIFOBuffer;
		class StatisticsMaster;
		class StatisticsClientIntCounter;
		class StatisticsClientAverage;
		class StatisticsClientPerSecond;
	}

	namespace NetworkedControl
	{
		/** @class CommBaseTCP
		 * Parenting class for TCP server and client objects
		 * @brief Parenting class for TCP server and client objects
		 */
		class CommBaseTCP : protected yane::Utils::Thread
		{
			public:

				/**
				 * Typedef of the callback method to be used for communication
				 * @param packetdata Pointer of the data to be transmitted
				 * @param packetlength Length of the transmitted package
				 * @param ptr Optional custom pointer passed to the callback function for user defined data
				 * @brief Typedef of the callback method to be used for communication
				 */
				typedef void(*T_MESSAGECALLBACK)(char* packetdata, int packetlength, void*ptr);

				/**
				 * Constructor
				 * @param mess_cb Pointer of the callback function used for communication
				 * @param ptr Optional custom pointer passed to the callback function for user defined data
				 * @param readbuffersize Maximal length of data accepted for input
				 * @param name Name of the thread constructed by this object
				 * @param dm Optional pointer to a class yane::Utils::Debugmaster object
				 * @param sm Optional pointer to a class yane::Utils::StatisticsMaster object
				 * @brief Constructor
				 */
				CommBaseTCP(T_MESSAGECALLBACK mess_cb, void* ptr, int readbuffersize, const std::string & name, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm);

				/**
				 * Destructor
				 */
				virtual ~CommBaseTCP();

				/**
				 * @brief Function to close an existing TCP connection
				 */
				void closeConnection();

				/**
				 * @brief Function to return whether a TCP connection is established
				 */
				bool isConnected();

				/**
				 * Function to send data through TCP connection
				 * @param data Data to be sent
				 * @param datasize Length of data to be sent
				 * @brief Function to send data through TCP connection
				 */
				void sendData(const char * data, int datasize);

			protected:

				//TODO Doku
				typedef struct
				{
					int code;
					int protocolversion;
					int ver_maj;
					int ver_min;
					int ver_rev;
					int sequencelength;
					char clientname[128];
				} T_HS_CLIENTMESSAGE;

				typedef struct
				{
					int code;
					int ver_maj;
					int ver_min;
					int ver_rev;
					int clientcode;
					int maxsequencelength;
					int protocolversion;
					int reserved;
					double discrtime;
					unsigned char modelid[16];
					char servername[128];
					char model[128];
				} T_HS_SERVERMESSAGE;

				typedef struct
				{
					int code;
					int error;
					char errormessage[128];
				} T_HS_SERVERRESPONSE;


				bool tryAccept(int sock, int & newsock, int timeout_sec);
				bool tryRead(int sock, char* buffer, int buffersize, int & readbytes, int timeout_sec);
				bool tryWrite(int sock, char* buffer, int buffersize);
				unsigned int nextPackageSize();

				virtual void run();

				int _listensocket;	/**< @brief Socket for incoming messages */
				int _talksocket;	/**< @brief Socket for outgoing messages */
				int _readbuffersize; /**< @brief Maximal length of incoming data package */

				void* _ptr; /**< @brief Custom pointer passed to the callback function for user defined data */
				char * _packetdata; /**< @brief Pointer of the data to be transmitted */
				yane::Utils::FIFOBuffer * _buffer; /**< @brief Pointer of the first-in-first-out buffer */
				T_MESSAGECALLBACK _mess_cb; /**< @brief Callback method to be used for communication */

				bool _connectionestablished; /**< @brief Bool variable indicating whether a TCP connection is established */

				bool _stat_collect; /**< @brief If true, the actuator will collect statistical data*/
				yane::Utils::StatisticsClientIntCounter * _stat_sockerrors; /**< @brief Statistics collector for socket errors*/
				yane::Utils::StatisticsClientIntCounter * _stat_senttotal; /**< @brief Statistics collector for sent bytes*/
				yane::Utils::StatisticsClientPerSecond * _stat_sentpersec; /**< @brief Statistics collector for sent datarate [bytes/sec]*/
				yane::Utils::StatisticsClientIntCounter * _stat_sentpackages; /**< @brief Statistics collector for sent packages*/
				yane::Utils::StatisticsClientIntCounter * _stat_sentlost; /**< @brief Statistics collector for lost bytes (sending)*/
				yane::Utils::StatisticsClientIntCounter * _stat_recvtotal; /**< @brief Statistics collector for received bytes*/
				yane::Utils::StatisticsClientPerSecond * _stat_recvpersec; /**< @brief Statistics collector for received datarate [bytes/sec]*/
				yane::Utils::StatisticsClientIntCounter * _stat_recvpackages; /**< @brief Statistics collector for received packages*/
				yane::Utils::StatisticsClientIntCounter * _stat_recvlost; /**< @brief Statistics collector for lost bytes (receiving)*/
				yane::Utils::StatisticsClientIntCounter * _stat_crc32; /**< @brief Statistics collector for CRC32 errors*/
				yane::Utils::StatisticsClientAverage * _stat_readbuffersize; /**< @brief Statistics collector for receiving buffersize*/
				yane::Utils::StatisticsClientAverage * _stat_sentpackagesize; /**< @brief Statistics collector for size of sent packages [bytes]*/
				yane::Utils::StatisticsClientAverage * _stat_recvpackagesize; /**< @brief Statistics collector for size of received packages [bytes]*/

		};
	}
}

#endif
