/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_CONTROLLERTHREADINPUT_H
#define YANE_NETWORKEDCONTROL_CONTROLLERTHREADINPUT_H

#include "../utils/thread.h"

namespace yane
{

	namespace Model
	{
		class Model;
		class StateEstimator;
		class Simulator;
	}

	namespace Utils
	{
		class StatisticsMaster;
		class StatisticsClientIntCounter;
	}

	namespace NetworkedControl
	{
		class IOInterface;
		class ControllerThreadMPC;
		class ControlClipboard;

		/** @class ControllerThreadInput
		 * @brief Class for simulating the plant and sensor in a distributed plant - sensor - controller - actuator setting
		 */
		class ControllerThreadInput : public yane::Utils::Thread
		{
			public:
				/**
				 * Constructor
				 * @param iface Pointer of the input/output interface of class yane::MPC::IOInterface
				 * @param model Pointer of the class yane::Model::Model object used for optimization
				 * @param dm Pointer of the debugmanager of class yane::Utils::DebugMaster
				 * @param sm Pointer of the statistics manager of class yane::Utils::StatisticsMaster
				 * @brief Constructor
				 */
				ControllerThreadInput ( IOInterface * iface, yane::Model::Model * model, yane::Utils::DebugMaster* dm =
				        0, yane::Utils::StatisticsMaster * sm = 0 );

				/**
				 * @brief Destructor
				 */
				virtual ~ControllerThreadInput ( );

				/**
				 * Function to set the MPC computing thread
				 * @param thread MPC computing thread
				 * @brief Function to set the MPC computing thread
				 */
				void setMPCThread ( ControllerThreadMPC * thread );

			protected:
				/**
				 * @brief Function to start the sensor thread
				 */
				virtual void run ( );

				int _lastaddedcontrolcycle; /**< @brief Sampling instant of the latest added control */

				IOInterface * _interface; /**< @brief Pointer of the network interface of class yane::NetworkedInterface::IOInterface */
				ControllerThreadMPC * _mpcthread; /**< @brief Pointer of the MPC computation thread of class yane::NetworkedControl::ControllerThreadMPC */
				ControlClipboard * _cb; /**< @brief Pointer of the control clipboard of class yane::NetworkedControl::ControlClipboard */
				yane::Model::Model * _model; /**< @brief Pointer of the model of class yane::Model::Model */
				yane::Model::StateEstimator * _estimator; /**< @brief Pointer of the state estimator of class yane::Model::StateEstimator */
				yane::Model::Simulator * _simulator; /**< @brief Pointer of the simulator of class yane::Model::Simulator */

				yane::Utils::StatisticsClientIntCounter * _stat_read; /**< @brief Statistics collector for received sensor values*/

		};

	}

}

#endif
