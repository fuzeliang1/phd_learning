/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_CONTROLCLIPBOARD_H
#define YANE_NETWORKEDCONTROL_CONTROLCLIPBOARD_H

#include "typedefs.h"

#include <map>

namespace yane
{
	namespace Utils
	{
		class Mutex;
	}

	namespace NetworkedControl
	{

		/** @class ControlClipboard
		not yet documented
		 */
		class ControlClipboard
		{
			public:
				ControlClipboard ( int dimension, int horizont );
				~ControlClipboard();

				double * operator[] ( const int cycle );

				void addData ( int cycle, int precycle, double calcduration, double * u );
				void appendData ( int cycle, double calcduration, double * u, int &preseq );
				int cleanup ( int cycle, int currentcycle );

				bool hasCycle ( int cycle ) const;
				bool getValidatedData ( int cycle, int & precycle, bool & error, double & calcduration, double * u ) const;
				bool getConsistencyInfo ( int cycle, int & parentcycle, int & nextcycle, int & nextprecycle ) const;

				void getScheme ( T_SCHEMEENTRY * scheme ) const;

				void invalidateCycle ( int cycle );
				int firstCycle() const;
				int lastCycle() const;

				int horizont() const;
				int size() const;
				void lock();
				void unlock();


			protected:

				typedef std::map<int, T_ENTRY> T_MAPTYPE;
				typedef T_MAPTYPE::iterator T_ITTYPE;

				int _horizont;
				int _dimension;
				T_MAPTYPE * _container;

				yane::Utils::Mutex * _mutex;
		};

	}

}

#endif
