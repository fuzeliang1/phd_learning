/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

//TODO Doku
#ifndef YANE_NETWORKEDCONTROL_TYPEDEFS_H
#define YANE_NETWORKEDCONTROL_TYPEDEFS_H

namespace yane
{

	namespace NetworkedControl
	{

		/**
		 * Type of the callback function pointer which is used to offer potential error packets (of type yane::IOInterface::ACTORPACKET)
		 * @brief Callback function type for potentail error packets
		 */
		typedef void(*T_RESPONSEFUNC) ( void * packet, void * ptr );

		/**
		 * Type of the distance function pointer which is used to determine whether a recomputation of the control sequences is necessary
		 * @brief Distance function pointer used to determine whether a recomputation of the control sequences is necessary
		 */
		typedef double(*T_DISTANCEFUNC) ( int size_x1, int size_x2, double * x1, double * x2 );

		/** @typedef T_DEBUGLEVEL
		 Enumerator for available debug levels of the output
		 - DEBUG_CRITICAL: Only critical debug messages are displayed which force the algorithm to be terminated.
		 - DEBUG_BASE: Additionally, error messages and warnings are displayed.
		 - DEBUG_ALGORITHM: Additionally, steps of the algorithm are displayed.
		 - DEBUG_ALGDETAILS: Additionally, details of the algorithm are displayed.
		 - DEBUG_INNERDETAILS: Additionally, values of variables are displayed.
		 - DEBUG_ALL: All debug messages are displayed.
		 @brief Enumerator for available debug levels of the output
		 */
		typedef enum
		{
			DEBUG_CRITICAL = 0,
			DEBUG_BASE = 1,
			DEBUG_ALGORITHM = 2,
			DEBUG_ALGDETAILS = 3,
			DEBUG_INNERDETAILS = 4,
			DEBUG_ALL = 5
		} T_DEBUGLEVEL;

		/** Structure accompanying an output package
		 * @param code Output code
		 * @param preseq Base time instant used to compute the output package data
		 * @param seq Time instant of the output package data
		 * @brief Structure accompanying an output package
		 */
		typedef struct
		{
				int code;
				int preseq;
				int seq;
		} T_OUTPUTPACKET;

		/** Structure accompanying an input package
		 * @param code Input code
		 * @param reserved
		 * @param time Time instant of the input package data
		 * @brief Structure accompanying an input package
		 */
		typedef struct
		{
				int code;
				char reserved [ 4 ];
				double time;
		} T_INPUTPACKET;

		/** Structure accompanying an actuator package
		 * @param code Actuator code
		 * @param seq_err Time instant of the actuator when error occured
		 * @param preseq_err Time instant which is still prediction consistent within the actuator
		 * @brief Structure accompanying an actuator package
		 */
		typedef struct
		{
				int code;
				int seq_err;
				int preseq_err;
		} T_ACTORPACKET;

		/** @typedef T_SCHEMEINFO
		 * Enumerator for available scheme entry conditions
		 * - DATA Scheme entry contains data
		 * - CONSISTENT Scheme entry contains consistent data
		 * - INCONSISTENT Scheme enty contains inconsistent data
		 * - NODATA Scheme entry contains no data
		 * @brief Enumerator for available scheme data conditions
		 */
		typedef enum
		{
			DATA, CONSISTENT, INCONSISTENT, NODATA
		} T_SCHEMEINFO;

		/**
		 * Structure for available scheme entry data
		 * @param info Type of information stored
		 * @param calcduration Time used for computation
		 * @brief Structure for availalbe scheme entry data
		 */
		typedef struct
		{
				T_SCHEMEINFO info;
				double calcduration;
		} T_SCHEMEENTRY;

		/**
		 * Structure for available scheme data
		 * @param precycle Last prediction consistent time instant
		 * @param calcduration Time used for computation
		 * @param control Control sequence
		 * @brief Structure for available scheme data
		 */
		typedef struct
		{
				int precycle;
				double calcduration;
				double * control;
		} T_ENTRY;

	}

}

#endif
