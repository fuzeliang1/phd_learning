/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */


// TODO WINDOWS sockets funktionieren auch nicht analog, da muss man auch umschreiben.
// close durch closesocket ersetzt. read/write durch _read/_write ersetzt, nochmal durchschaun!

#include "commbasetcp.h"
#include "typedefs.h"

#include "../utils.h"

#ifdef _WIN32
	#include <winsock.h>
#else
	#include <unistd.h>
	#include <sys/stat.h>
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <netdb.h>
	#include <cstring>
	#include <sys/select.h>
	#include <sys/time.h>
#endif
#include <iostream>

using namespace std;

yane::NetworkedControl::CommBaseTCP::CommBaseTCP(T_MESSAGECALLBACK mess_cb, void* ptr, int readbuffersize, const std::string & name, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm)
	: yane::Utils::Thread(name, dm)
{
	_mess_cb = mess_cb;
	_ptr = ptr;
	_readbuffersize = readbuffersize;
	_connectionestablished=false;
	_packetdata = new char[_readbuffersize+2*sizeof(unsigned int)];
	_buffer = new yane::Utils::FIFOBuffer(_readbuffersize+2*sizeof(unsigned int));
	
	if (sm)
	{
		_stat_collect = true;
		_stat_sockerrors = new yane::Utils::StatisticsClientIntCounter(sm, "Network", "socket errors");
		_stat_senttotal = new yane::Utils::StatisticsClientIntCounter(sm, "Network", "sent bytes");
		_stat_sentpersec = new yane::Utils::StatisticsClientPerSecond(sm, "Network", "sent datarate [bytes/sec]", 1);
		_stat_sentpackages = new yane::Utils::StatisticsClientIntCounter(sm, "Network", "sent packages");
		_stat_sentpackagesize = new yane::Utils::StatisticsClientAverage(sm, "Network", "size of sent packages [bytes]", 1, false, true, true);
		_stat_sentlost = new yane::Utils::StatisticsClientIntCounter(sm, "Network", "lost bytes (sending)");
		_stat_recvtotal = new yane::Utils::StatisticsClientIntCounter(sm, "Network", "received bytes");
		_stat_recvpersec = new yane::Utils::StatisticsClientPerSecond(sm, "Network", "received datarate [bytes/sec]", 1);
		_stat_recvpackages = new yane::Utils::StatisticsClientIntCounter(sm, "Network", "received packages");
		_stat_recvpackagesize = new yane::Utils::StatisticsClientAverage(sm, "Network", "size of received packages [bytes]", 1, false, true, true);
		_stat_readbuffersize = new yane::Utils::StatisticsClientAverage(sm, "Network", "receiving buffersize [bytes]", 1, false, true, true);
		_stat_recvlost = new yane::Utils::StatisticsClientIntCounter(sm, "Network", "lost bytes (receiving)");
		_stat_crc32 = new yane::Utils::StatisticsClientIntCounter(sm, "Network", "crc32 errors");
	} else
	{
		_stat_collect = false;
	}

}

yane::NetworkedControl::CommBaseTCP::~ CommBaseTCP()
{
	closeConnection();

	delete[] _packetdata;
	delete _buffer;
}

void yane::NetworkedControl::CommBaseTCP::closeConnection()
{
	stop();
	wait();

	if (_connectionestablished)
	{
#ifdef _WIN32
		closesocket(_talksocket);
#else
		close(_talksocket);
#endif
		_connectionestablished = false;
	}
}

bool yane::NetworkedControl::CommBaseTCP::tryAccept(int sock, int & newsock, int timeout_sec)
{
	//TODO WINDOWS tryAccept anpassen.

#ifdef _WIN32
	int fromlen;
#else
	socklen_t fromlen;
#endif
	fd_set rdfs;
	timeval tv;
	struct sockaddr_in from;
	int ret;

	fromlen = sizeof(struct sockaddr_in);
	FD_ZERO(&rdfs);
	FD_SET(sock, &rdfs);
	tv.tv_sec=timeout_sec;
	tv.tv_usec=0;
	ret = select(sock+1, &rdfs, 0, 0, &tv);

	if (ret == -1)
	{
		if (_stat_collect)
		{
			_stat_sockerrors->addValue(1);
		}
		debugMessageInt("error during socketselect", "errorcode", 1, &ret, DEBUG_CRITICAL);
	}
	else
	{
		if (FD_ISSET(sock, &rdfs))
		{
			newsock = accept(sock, (struct sockaddr *) &from, &fromlen);
			return true;
		}
	}
	return false;
}

bool yane::NetworkedControl::CommBaseTCP::tryRead(int sock, char * buffer, int buffersize, int & readbytes, int timeout_sec)
{
#ifdef _WIN32
	// TODO WINDOWS tryRead anpassen
#else
	fd_set rdfs;
	timeval tv;
	int ret;

	FD_ZERO(&rdfs);
	FD_SET(sock, &rdfs);
	tv.tv_sec=timeout_sec;
	tv.tv_usec=0;
	ret = select(sock+1, &rdfs, 0, 0, &tv);

	if (ret == -1)
	{
		debugMessageInt("error during socketselect", "errorcode", 1, &ret, DEBUG_CRITICAL);
		if (_stat_collect)
		{
			_stat_sockerrors->addValue(1);
		}
	}
	else
	{
		if (FD_ISSET(sock, &rdfs))
		{
			lock();
			debugMessage("got data... reading...", DEBUG_INNERDETAILS);
			readbytes = read(sock,buffer,buffersize);
			unlock();
			if (readbytes < 0) return false;
			if (_stat_collect && readbytes>0)
			{
				_stat_recvtotal->addValue(readbytes);
				_stat_recvpackagesize->addValue((double)readbytes);
				_stat_recvpersec->addValue((double)readbytes);
				_stat_recvpackages->addValue(1);
			}
			return true;
		}
	}
	return false;
#endif
}


bool yane::NetworkedControl::CommBaseTCP::isConnected()
{
	return _connectionestablished;
}

bool yane::NetworkedControl::CommBaseTCP::tryWrite(int sock, char * buffer, int buffersize)
{
	int cursor = 0;
	do
	{
		int size = buffersize-cursor;
#ifdef _WIN32
		// TODO WINDOWS tryWrite anpassen, schaun ob das send hier passt.
		int n = send(sock, &buffer[cursor], size,0);
#else
		int n = write(sock, &buffer[cursor], size);
#endif
		if (n<0)
		{
			if (_stat_collect)
			{
				_stat_sentlost->addValue(buffersize);
			}
			debugMessage("sending data failed", DEBUG_CRITICAL);
			return false;
		}
		
		if (_stat_collect)
		{
			_stat_senttotal->addValue(n);
			_stat_sentpersec->addValue((double)n);
			_stat_sentpackages->addValue(1);
			_stat_sentpackagesize->addValue((double)n);
		}
		cursor += n;	
	} while (cursor < buffersize);
	return true;
}

void yane::NetworkedControl::CommBaseTCP::sendData(const char * data, int datasize)
{
	if (datasize > _readbuffersize)
	{
		debugMessage("size of senddata exceeds buffersize, data dropped!", DEBUG_CRITICAL);
		if (_stat_collect)
		{
			_stat_sentlost->addValue(datasize);
		}
		return;
	}

	if (isConnected())
	{
		lock();
		int crc = yane::Utils::CRC32::compute((void*)data, datasize);

		memcpy(_packetdata, &datasize, sizeof(int));
		memcpy(&_packetdata[sizeof(unsigned int)], data, datasize);
		memcpy(&_packetdata[datasize+sizeof(unsigned int)], &crc, sizeof(unsigned int));

		debugMessage("sending data...", DEBUG_INNERDETAILS);
		tryWrite(_talksocket, _packetdata, datasize+2*sizeof(unsigned int));
		unlock();
	}

}

void yane::NetworkedControl::CommBaseTCP::run()
{
	char  *  buffer = new char[_readbuffersize+2*sizeof(unsigned int)];
	int n;
	int packagesize;

	lock();

	while (!_abort)
	{
		unlock();

		if (tryRead(_talksocket,buffer,_readbuffersize, n, 3))
		{
			if (n==0)
			{
				debugMessage("peer disconnected", DEBUG_INNERDETAILS);
				_connectionestablished=false;
#ifdef _WIN32
				closesocket(_talksocket);
#else
				close(_talksocket);
#endif

				break;
			} else
			{
				debugMessage("received tcp-package", DEBUG_INNERDETAILS);
				try
				{
					_buffer->push(buffer, n);
					if (_stat_collect)
					{
						_stat_readbuffersize->addValue(_buffer->size());
					}
				} catch (yane::Utils::Exception e)
				{
					if (_stat_collect)
					{
						_stat_recvlost->addValue(n);
					}
					debugMessageString("failedadding package to buffer, package dropped!", "e.what()", e.what(), DEBUG_CRITICAL);
				}
			}

			while ((packagesize = nextPackageSize()) > 0)
			{
				try
				{
					_buffer->pop(buffer, packagesize+2*sizeof(unsigned int));

					int packetcrc32 = *(unsigned int*)(&buffer[packagesize+sizeof(unsigned int)]);
					if (packetcrc32 == yane::Utils::CRC32::compute(&buffer[sizeof(unsigned int)], packagesize))
					{
						_mess_cb(&buffer[sizeof(unsigned int)], packagesize, _ptr);
					} else
					{
						if (_stat_collect)
						{
							_stat_crc32->addValue(1);
							_stat_recvlost->addValue(_buffer->size());
							_stat_readbuffersize->addValue(0);
						}
						debugMessage("crc32-check of incoming package failed. dropping all buffered packages.", DEBUG_CRITICAL);
						_buffer->clear();
					}
				} catch (yane::Utils::Exception e)
				{
					if (_stat_collect)
					{
						_stat_recvlost->addValue(_buffer->size());
						_stat_readbuffersize->addValue(0);
					}
					debugMessageString("bufferreading failed, should not happen... buffer cleared", "e.what()", e.what(), DEBUG_CRITICAL);
					_buffer->clear();
				}

			}
		}
		lock();
	}

	unlock();

	delete[] buffer;
}

unsigned int yane::NetworkedControl::CommBaseTCP::nextPackageSize()
{
	unsigned int packagesize;

	if (_buffer->size() < sizeof(unsigned int))
	{
		return 0;
	}

	try
	{
		_buffer->peek(&packagesize, sizeof(unsigned int));
	} catch (yane::Utils::Exception e)
	{
		debugMessageString("bufferpeeking failed, should not happen... buffer cleared", "e.what()", e.what(), DEBUG_CRITICAL);
		if (_stat_collect)
		{
			_stat_recvlost->addValue(_buffer->size());
			_stat_readbuffersize->addValue(0);
		}
		_buffer->clear();
		return 0;
	}

	if (packagesize > _readbuffersize)
	{
		debugMessageInt("fifo buffer contains package with invalid length, dropping all buffered packages... sorry...", "packetsize", 1, (int*)&packagesize, DEBUG_CRITICAL);
		if (_stat_collect)
		{
			_stat_recvlost->addValue(_buffer->size());
			_stat_readbuffersize->addValue(0);
		}
		_buffer->clear();
		return 0;
	}

	if (_buffer->size() >= packagesize+2*sizeof(unsigned int))
	{
		return packagesize;
	}

	return 0;
}
