/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "controller.h"
#include "iointerface.h"

#include "../minprog.h"
#include "../model.h"
#include "../utils.h"

yane::NetworkedControl::Controller::Controller ( yane::Model::Model * model, int horizon, int prediction,
        IOInterface * iface, yane::Utils::DebugMaster * debugmaster,
        yane::Utils::StatisticsMaster * statisticsmaster )
{
	_model = model;

	if ( model->id ( ) != iface->model ( )->id ( ) )
	{
		throw yane::Utils::ValueException (
		        __DEBUGMESS("The given model's type must be equal to the interface assigned model's type") );
	}

	_horizon = horizon;
	_prediction = prediction;
	_interface = iface;
	_debugmaster = debugmaster;
	_statisticsmaster = statisticsmaster;
}

yane::NetworkedControl::Controller::~Controller ( )
{
}

yane::Model::Model * yane::NetworkedControl::Controller::model ( )
{
	return _model;
}
