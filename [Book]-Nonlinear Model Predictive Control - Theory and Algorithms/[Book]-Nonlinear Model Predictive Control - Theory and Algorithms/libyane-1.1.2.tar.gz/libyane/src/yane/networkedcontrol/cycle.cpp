/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "cycle.h"

#include <cmath>

#include "libexport.h"

LIB_EXPORT yane::NetworkedControl::Cycle::Cycle ( double discr_time )
		: yane::Utils::RTClock()
{
	_discr_time =  discr_time;
}

LIB_EXPORT unsigned int yane::NetworkedControl::Cycle::get()
{
	return ( unsigned int ) floor ( elapsedSeconds() / _discr_time );
}

LIB_EXPORT double yane::NetworkedControl::Cycle::cycleStartSeconds()
{
	return floor ( elapsedSeconds() / _discr_time ) * _discr_time;
}

LIB_EXPORT double yane::NetworkedControl::Cycle::cycleEndSeconds()
{
	return ceil ( elapsedSeconds() / _discr_time ) * _discr_time;
}

LIB_EXPORT double yane::NetworkedControl::Cycle::cycleRemainingSeconds()
{
	return cycleEndSeconds() - elapsedSeconds();
}

LIB_EXPORT double yane::NetworkedControl::Cycle::cycleElapsedSeconds()
{
	return elapsedSeconds() - cycleStartSeconds();
}

LIB_EXPORT void yane::NetworkedControl::Cycle::waitUntil ( double time )
{
	do {
		double interval = ( time - elapsedSeconds() ) *1E+6;
		if (interval > 0.0)
		{
			usleep ( ( unsigned int ) interval );
		}
	}
	while ( elapsedSeconds() < time );
}

LIB_EXPORT double yane::NetworkedControl::Cycle::discrTime() const
{
	return _discr_time;
}

LIB_EXPORT yane::NetworkedControl::Cycle::~ Cycle()
{
}
