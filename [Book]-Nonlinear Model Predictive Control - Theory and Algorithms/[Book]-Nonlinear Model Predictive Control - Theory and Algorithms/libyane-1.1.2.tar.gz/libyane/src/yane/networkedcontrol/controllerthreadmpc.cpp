/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "controllerthreadmpc.h"
#include "cycle.h"
#include "controlclipboard.h"
#include "controllerthreadoutput.h"

#include "../minprog.h"
#include "../model.h"
#include "../utils.h"
#include "../mpc.h"

#include <cmath>
#include <cstring>

yane::NetworkedControl::ControllerThreadMPC::ControllerThreadMPC ( IOInterface * iface,
        yane::MPC::OdeManager * odemanager, yane::MinProg::NLP * minimizer, int horizon, int prediction,
        yane::Model::Model * model, yane::MPC::ModelShootingData * shootingdata, yane::Utils::DebugMaster * dm,
        yane::Utils::StatisticsMaster * sm ) :
	yane::Utils::Thread ( "Controller: MPC", dm )
{
	_interface = iface;
	_odemanager = odemanager;
	_minimizer = minimizer;
	_horizon = horizon;
	_prediction = prediction;
	_model = model;
	_shootingdata = shootingdata;

	_cb = new ControlClipboard ( _model->dimensionControl ( ), _horizon );
	_outputthread = 0;
	_samplingTime = 0.0;

	if ( sm != 0 )
	{
		_stat_collect = true;
		_stat_computedseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Controller", "computed sequences" );
		_stat_invalidateseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Controller", "invalidated sequences" );
		_stat_skipseq = new yane::Utils::StatisticsClientIntCounter ( sm, "Controller", "skipped sequences" );
		_stat_calcduration = new yane::Utils::StatisticsClientAverage ( sm, "Controller", "computational time [ms]", 1,
		        true, true, true );
		_stat_discardseq_locked = new yane::Utils::StatisticsClientIntCounter ( sm, "Controller",
		        "discarded sequences (output busy)" );
		_stat_discardseq_timeout = new yane::Utils::StatisticsClientIntCounter ( sm, "Controller",
		        "discarded sequences (timeout)" );
		_stat_inputfuture = new yane::Utils::StatisticsClientIntCounter ( sm, "Controller",
		        "sensor timestamp inconsistency (future)" );
	}
	else
	{
		_stat_collect = false;
	}

	_controllercycle = 0;
	_mpcstartsem = new yane::Utils::Semaphore ( );

	_mpc = new yane::MPC::MPC ( );
	_mpc->reset ( _odemanager, _minimizer, _model, _horizon, 0, _shootingdata );
	_mpc->allocateMemory ( _t, _u );

	_simulator = new yane::Model::Simulator ( _model );

	_x = new double [ _model->dimensionState ( ) ];
	_inputx = new double [ _model->dimensionState ( ) ];
	_inputxtime = - INFINITY;
	_model->getDefaultState ( _inputx );
	_model->getDefaultState ( _x );
}

yane::NetworkedControl::ControllerThreadMPC::~ControllerThreadMPC ( )
{
	delete _mpcstartsem;
	delete _controllercycle;
	delete _cb;
	delete _mpc;
	delete _simulator;
	delete [ ] _x;
	delete [ ] _inputx;
	delete [ ] _t;
	delete [ ] _u;
	delete _stat_computedseq;
	delete _stat_invalidateseq;
	delete _stat_skipseq;
	delete _stat_calcduration;
	delete _stat_discardseq_locked;
	delete _stat_discardseq_timeout;
	delete _stat_inputfuture;
}

void yane::NetworkedControl::ControllerThreadMPC::run ( )
{

	if ( ! _outputthread )
	{
		debugMessage ( "No Output-Thread specified!", DEBUG_CRITICAL );
		return;
	}

	if ( ! _interface->isConnected ( ) )
	{
		debugMessage ( "Interface must be in connected state... controller not started", DEBUG_CRITICAL );
	}

	_samplingTime = _interface->samplingTime ( );
	_controllercycle = new Cycle ( _samplingTime );
	debugMessage ( "Waiting for first sensor value... ", DEBUG_ALGORITHM );
	while ( ! _mpcstartsem->tryAcquire ( 1, 1000 ) )
	{
		if ( _abort ) return;
	}

	int seq_steps;
	int dimx = _model->dimensionState ( );
	int dimu = _model->dimensionControl ( );
	int horizon = _horizon;
	double samplingTime = _samplingTime;

	yane::Utils::RTClock timer;

	_error_received = false;
	_sigma_err = - 1;
	_sigma_cor = - 1;

	try
	{
		lock ( );

		_last_seq = _controllercycle->get ( );
		_inputxchanged = false;

		_mpc->initCalc ( _t, _u );

		while ( ! _abort )
		{
			// Getting current cycle
			_seq = _controllercycle->get ( );

			if ( _debugclient )
			{
				stringstream mess;
				mess << " ================ new cycle " << _seq << ", computing cycle " << _seq + _prediction
				        << " ===================";
				debugMessage ( mess.str ( ), DEBUG_ALGORITHM );
			}

			/*********************
			 * Algorithm Step C0 *
			 *********************/

			if ( _error_received )
			{
				if ( _cb->hasCycle ( _sigma_err ) )
				{
					if ( _debugclient != 0 )
					{
						stringstream mess;
						mess << "errorflag! discarding cycles > " << _sigma_cor;
						debugMessage ( mess.str ( ), DEBUG_ALGORITHM );
					}
					int sizebefore = _cb->size ( );
					_cb->invalidateCycle ( _sigma_cor + 1 );

					if ( _stat_collect )
					{
						_stat_invalidateseq->addValue ( sizebefore - _cb->size ( ) );
					}
					_error_received = false;
					// Indicate, that predicted sensor-value got invalid
					_inputxchanged = true;
				}
				else
				{
					if ( _debugclient != 0 )
					{
						stringstream mess;
						mess << "error received, but clipboard does not have _seq " << _sigma_err
						        << " stored. most likely deleted earlier";
						debugMessage ( mess.str ( ), DEBUG_ALGORITHM );
					}
				}
			}

			/*********************
			 * Algorithm Step C1 *
			 *********************/

			if ( _inputxchanged )
			{
				debugMessage ( "sensor value has to be predicted, so I do...", DEBUG_ALGORITHM );
				predictSensorValues ( _x, _seq + _prediction );
				debugMessage ( "done.", DEBUG_ALGORITHM );
				_inputxchanged = false;
			}

			unlock ( );

			seq_steps = _seq + _prediction - _last_seq;
			if ( seq_steps > horizon )
			{
				debugMessage ( "Alltogether needed longer than horizon length. Something's going wrong...", DEBUG_BASE );
			}

			// It there were no new sensor values since last calculation, we have to predict
			// from the last state manually...
			if ( seq_steps > 0 )
			{
				debugMessage ( "state has to be predicted, so I do...", DEBUG_ALGORITHM );
				predictInternalState ( _x, _last_seq, _seq + _prediction );
				debugMessage ( "done.", DEBUG_ALGORITHM );
			}
			debugMessageDouble ( "initial state", "state", _model->dimensionState ( ), _x, DEBUG_ALGDETAILS );

			/*********************
			 * Algorithm Step C2 *
			 *********************/

			if ( _cb->hasCycle ( _seq + _prediction ) )
			{
				debugMessage ( "cycle already computed, skipping...", DEBUG_ALGORITHM );
				if ( _stat_collect )
				{
					_stat_skipseq->addValue ( 1 );
				}
			}
			else
			{
				// Preparing timesteps and starting values for control calculation
				//TODO shiftHorizon mit beruecksichtigen, um vom ONESTEP-Verfahren profitieren zu koennen.
				_t [ 0 ] = ( _seq + _prediction ) * samplingTime;
				for ( int i = 1; i < horizon + 1; i++ )
				{
					_t [ i ] = _t [ i - 1 ] + samplingTime;
				}
				debugMessageDouble ( "timegrid generated", "timegrid", horizon + 1, _t, DEBUG_ALGDETAILS );

				for ( int i = 0; i < horizon; i++ )
				{
					double * ptr = 0;
					try
					{
						ptr = ( * _cb ) [ i + _seq + _prediction ];
					}
					catch ( yane::Utils::Exception e )
					{
						ptr = 0;
					}

					if ( ptr )
					{
						memcpy ( & _u [ i * dimu ], ptr, sizeof(double) * dimu );
					}
					else
					{
						_model->getDefaultControl ( & _u [ i * dimu ] );
					}
				}
				debugMessageDouble ( "control generated", "control", horizon, _u, DEBUG_ALGDETAILS );

				// calculating control
				timer.reset ( );
				try
				{
					debugMessage ( "executing mpc...", DEBUG_ALGORITHM );
					_mpc->calc ( _x );
				}
				catch ( yane::MinProg::SolverWarning e )
				{
					debugMessageString ( "Solver warning during mpc calculation", "e.what()", e.what ( ),
					        DEBUG_ALGORITHM );
				}
				double neededtime = timer.elapsedSeconds ( );
				if ( _debugclient )
				{
					stringstream mess;
					mess << "New control for cycle " << _seq + _prediction << " calculated. " << neededtime
					        << " sec. needed";
					debugMessage ( mess.str ( ), DEBUG_ALGORITHM );
				}
				if ( _stat_collect )
				{
					_stat_calcduration->addValue ( neededtime * 1000.0 );
					_stat_computedseq->addValue ( 1 );
				}

				/****************************
				 * Algorithm Step C3 and C4 *
				 ****************************/

				if ( neededtime < _prediction * samplingTime )
				{
					int __preseq;
					_cb->appendData ( _seq + _prediction, neededtime, _u, __preseq );

					if ( ! _outputthread->setOutputSequence ( __preseq, _seq + _prediction, horizon, _u ) )
					{
						debugMessage (
						        "outputinferface still locked, should not happen! Discarding calculated sequence.",
						        DEBUG_CRITICAL );
						if ( _stat_collect )
						{
							_stat_discardseq_locked->addValue ( 1 );
						}
					}
					else
					{
						_outputthread->trigger ( );
					}
				}
				else
				{
					if ( _stat_collect )
					{
						_stat_discardseq_timeout->addValue ( 1 );
					}
					debugMessage (
					        "MPC needed too much time: control discarded. Actuator will complain about this, I suppose.",
					        DEBUG_ALGORITHM );
				}
			}

			/*********************
			 * Misc stuff...     *
			 *********************/

			// removing old sequences from clipboard
			debugMessage ( "cleaning clipboard...", DEBUG_INNERDETAILS );
			_cb->cleanup ( min ( ( int ) floor ( _inputxtime / samplingTime + 1E-10 ), _seq - horizon ), _seq );

			debugMessage ( "waiting until cycle has been passed...", DEBUG_ALGORITHM );
			while ( _controllercycle->get ( ) < _seq + 1 )
			{
				double interval = ( double ) ( _seq + 1 ) * samplingTime - _controllercycle->elapsedSeconds ( );
				if ( interval > samplingTime )
				{
					interval = samplingTime;
				}
				if ( interval > 0.0 )
				{
					usleep ( ( unsigned int ) ( interval * 1E+6 ) );
				}
			}

			if ( ! _interface->isConnected ( ) )
			{
				debugMessage ( "Interface is no more in connected state... aborted", DEBUG_CRITICAL );
				_abort = true;
			}

			debugMessage ( "getting lock for mpcthread...", DEBUG_INNERDETAILS );
			lock ( );

		}
		unlock ( );

	}
	catch ( yane::Utils::Exception e )
	{
		debugMessageString ( "EMERGENCY-EXIT", "what()", e.what ( ), DEBUG_CRITICAL );
	}

	delete _controllercycle;
	_controllercycle = 0;
}

void yane::NetworkedControl::ControllerThreadMPC::predictSensorValues ( double * peekedx, int to_seq )
{
	double discr = _samplingTime;

	int startseq = ( int ) floor ( ( _inputxtime + 1E-10 ) / discr );
	int seqlength = to_seq - startseq;

	if ( seqlength > 0 )
	{
		double * timesteps = new double [ seqlength + 1 ];
		timesteps [ 0 ] = _inputxtime;
		timesteps [ 1 ] = ( startseq + 1 ) * discr;
		for ( int i = 2; i < seqlength + 1; i++ )
		{
			timesteps [ i ] = timesteps [ i - 1 ] + discr;
		}

		memcpy ( peekedx, _inputx, sizeof(double) * _model->dimensionState ( ) );

		computePrediction ( peekedx, startseq, to_seq, timesteps );
		delete [ ] timesteps;
	}
	else
	{
		if ( _stat_collect )
		{
			_stat_inputfuture->addValue ( 1 );
		}
		debugMessage ( "Inconsistent sensor Timestamp (future), ignoring sensor data", DEBUG_BASE );
	}
}

void yane::NetworkedControl::ControllerThreadMPC::predictInternalState ( double * state, int from_seq, int to_seq )
{

	int seqlength = to_seq - from_seq;

	if ( seqlength > 0 )
	{
		double discr = _samplingTime;

		double * timesteps = new double [ seqlength + 1 ];
		timesteps [ 0 ] = from_seq * discr;
		;
		for ( int i = 1; i < seqlength + 1; i++ )
		{
			timesteps [ i ] = timesteps [ i - 1 ] + discr;
		}

		computePrediction ( state, from_seq, to_seq, timesteps );
		delete [] timesteps;
	}
	else
	{
		debugMessage ( "Inconsistent prediction interval... nothing done.", DEBUG_BASE );
	}
}

void yane::NetworkedControl::ControllerThreadMPC::computePrediction ( double * state, int from_seq, int to_seq,
        double * timesteps )
{
	int seqlength = to_seq - from_seq;

	int dimu = _model->dimensionControl ( );
	int dimx = _model->dimensionState ( );

	double * control = new double [ seqlength * dimu ];
	for ( int i = 0; i < seqlength; i++ )
	{
		double * ptr = 0;
		try
		{
			ptr = ( * _cb ) [ i + from_seq ];
		}
		catch ( yane::Utils::Exception e )
		{
			ptr = 0;
		}

		if ( ptr )
		{
			memcpy ( & control [ i * dimu ], ptr, sizeof(double) * dimu );
		}
		else
		{
			_model->getDefaultControl ( & control [ i * dimu ] );
		}
	}

	try
	{
		debugMessageDouble ( "before prediction...", "state", dimx, state, DEBUG_INNERDETAILS );
		debugMessageDouble ( "timesteps...", "timesteps", seqlength + 1, timesteps, DEBUG_INNERDETAILS );
		_simulator->predictSequence ( seqlength, timesteps, state, control );
		if ( _debugclient )
		{
			stringstream str;
			str << "prediction from _seq=" << from_seq << " to _seq=" << to_seq << " done.";
			debugMessageDouble ( str.str ( ), "predicted state", dimx, state, DEBUG_ALGDETAILS );
			debugMessageDouble ( "used control", "control", dimu * seqlength, control, DEBUG_INNERDETAILS );
		}
		_last_seq = to_seq;
	}
	catch ( yane::Utils::Exception e )
	{
		debugMessageString ( "Failed predicting state", "e.what()", e.what ( ), DEBUG_BASE );
	}
	delete [] control;
}

void yane::NetworkedControl::ControllerThreadMPC::setNewState ( double t, double * state )
{
	if ( _controllercycle == 0 ) return;
	lock ( );

	if ( _inputxtime > t )
	{
		debugMessage ( "received new state, but timestamp is older then the last one", DEBUG_ALGDETAILS );
	}
	else
	{

		memcpy ( _inputx, state, sizeof(double) * _model->dimensionState ( ) );

		_inputxtime = t;
		_inputxchanged = true;
		_controllercycle->setElapsedSeconds ( t );
		if ( _debugclient )
		{
			stringstream str;
			str << "controller clock has been updated to " << _controllercycle->elapsedSeconds ( ) << " seconds";
			debugMessage ( str.str ( ), DEBUG_ALGORITHM );
		}
	}
	unlock ( );

	if ( ! _mpcstartsem->available ( ) )
	{
		_mpcstartsem->release ( 2 );
	}
}

void yane::NetworkedControl::ControllerThreadMPC::setActuatorErrorVariables ( int lastnonerrorcycle, int currentcycle )
{
	lock ( );

	_error_received = true;
	_sigma_err = currentcycle;
	_sigma_cor = lastnonerrorcycle;

	unlock ( );
}

void yane::NetworkedControl::ControllerThreadMPC::setOutputThread ( ControllerThreadOutput * thread )
{
	_outputthread = thread;
}

yane::NetworkedControl::ControlClipboard * yane::NetworkedControl::ControllerThreadMPC::controlClipboard ( )
{
	return _cb;
}

yane::NetworkedControl::Cycle * yane::NetworkedControl::ControllerThreadMPC::controllerCycle ( )
{
	return _controllercycle;
}

