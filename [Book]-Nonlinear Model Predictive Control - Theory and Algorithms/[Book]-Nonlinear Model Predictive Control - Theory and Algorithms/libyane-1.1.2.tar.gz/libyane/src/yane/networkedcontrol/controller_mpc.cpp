/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "actuator.h"
#include "controlclipboard.h"
#include "controller_mpc.h"
#include "iointerfacelocal.h"
#include "modelhandlerlocal.h"

#include "../minprog.h"
#include "../model.h"
#include "../utils.h"
#include "../mpc.h"
#include "../odesolve.h"

#include <iomanip>
#include <algorithm>

yane::NetworkedControl::MPCController::MPCController ( yane::Model::Model * model_controller,
        yane::MPC::ModelShootingData * shootingdata, int horizon, int prediction, yane::MinProg::NLP * minimizer,
        yane::MPC::OdeManager * odemanager, IOInterfaceLocal * iface, yane::Utils::DebugMaster * debugmaster,
        yane::Utils::StatisticsMaster * statisticsmaster, yane::NetworkedControl::T_DISTANCEFUNC distancefunction,
        double stateDistanceTolerance ) :
	yane::NetworkedControl::Controller ( model_controller, horizon, prediction, iface, debugmaster, statisticsmaster )
{
	_shootingdata = shootingdata;
	_minimizer = minimizer;
	_odemanager = odemanager;
	_interface = iface;
	_distancefunction = distancefunction;
	_stateDistanceTolerance = stateDistanceTolerance;

	if ( debugmaster )
	{
		_debugclient = debugmaster->newClient ( "MPCController" );
	}
	_trajectory = 0;
	if ( distancefunction )
	{
		_trajectory = new double [ ( _horizon + 1 + _prediction ) * _model->dimensionState ( ) ];
	}

	_cb = 0;
	_timer = new yane::Utils::RTClock ( );

	_sensorvalues = new double [ model_controller->dimensionState ( ) ];

	_samplingTime = iface->samplingTime ( );

	_controllerpacket_horizon = horizon;
	_controllerpacket_data = 0;
	_maximalOpenLoopIterations = horizon;

	_stat_sensorinput_sent = 0;
	_stat_mpc_computedseq = 0;
	_stat_mpc_invalidateseq = 0;
	_stat_mpc_alreadycomputed = 0;
	_stat_mpc_skipseq = 0;
	_stat_mpc_calcduration = 0;
	_stat_mpcoutput_sent = 0;
	_stat_actuator_received = 0;

	initializeMPCControllerInput ( );
	initializeMPCController ( );
	initializeMPCControllerOutput ( );
	initializeModelHandler ( );

	bool _saveMPCCallData = false;
	_mpcCallTimes.clear ( );
	_mpcCallStates.clear ( );
}

yane::NetworkedControl::MPCController::~MPCController ( )
{
	if ( _stat_sensorinput_sent )
	{
		delete _stat_sensorinput_sent;
	}
	if ( _stat_mpc_computedseq )
	{
		delete _stat_mpc_computedseq;
	}
	if ( _stat_mpc_invalidateseq )
	{
		delete _stat_mpc_invalidateseq;
	}
	if ( _stat_mpc_alreadycomputed )
	{
		delete _stat_mpc_alreadycomputed;
	}
	if ( _stat_mpc_skipseq )
	{
		delete _stat_mpc_skipseq;
	}
	if ( _stat_mpc_calcduration )
	{
		delete _stat_mpc_calcduration;
	}
	if ( _stat_mpcoutput_sent )
	{
		delete _stat_mpcoutput_sent;
	}
	if ( _stat_actuator_received )
	{
		delete _stat_actuator_received;
	}
	if ( _cb )
	{
		delete _cb;
	}
	if ( _timer )
	{
		delete _timer;
	}
	if ( _simulator_controller )
	{
		delete _simulator_controller;
	}
	if ( _mpc )
	{
		delete _mpc;
	}
	if ( _debugclient )
	{
		delete _debugclient;
	}
	if ( ! _controllerpacket_data )
	{
		delete [ ] _controllerpacket_data;
	}
	if ( _x )
	{
		delete [ ] _x;
	}
	if ( _t )
	{
		delete [ ] _t;
	}
	if ( _u )
	{
		delete [ ] _u;
	}
	if ( _inputx )
	{
		delete [ ] _inputx;
	}
	if ( _sensorvalues )
	{
		delete [ ] _sensorvalues;
	}
	if ( _trajectory )
	{
		delete [ ] _trajectory;
	}
	for ( int i = 0; i < _mpcCallStates.size ( ); i++ )
	{
		_mpcCallStates [ i ].clear ( );
	}
	_mpcCallStates.clear ( );
	_mpcCallTimes.clear ( );
}

void yane::NetworkedControl::MPCController::start ( )
{
	initialize ( );

	try
	{
		for ( int seq = 0; seq < _seqmax; seq++ )
		{
			/*********************
			 *    Controller     *
			 *********************/

			calc ( seq );
			/*********************
			 *      Actuator     *
			 *********************/

			implementControl ( seq );
		}
	}
	catch ( yane::Utils::Exception e )
	{
		if ( _debugmaster )
		{
			_debugclient->sendDebugMessageString ( "EMERGENCY-EXIT", "what()", e.what ( ), DEBUG_CRITICAL );
		}
	}
}

void yane::NetworkedControl::MPCController::initialize ( )
{
	if ( ! _interface->isConnected ( ) )
	{
		if ( _debugmaster )
		{
			_debugclient->sendDebugMessage ( "Interface must be in connected state... controller not started",
			        DEBUG_CRITICAL );
		}
	}

	_error_received = false;
	_sigma_err = - 1;
	_sigma_cor = - 1;
	_last_seq = 0;
	_last_sensor_seq = 0;
	_inputxchanged = false;
	if ( _cb )
	{
		delete _cb;
	}
	_cb = new ControlClipboard ( _model->dimensionControl ( ), _horizon );
}

void yane::NetworkedControl::MPCController::calc ( int seq )
{
	// Create local variables for speedup
	double samplingTime = _samplingTime;
	int horizon = _horizon;
	yane::Utils::DebugMaster * debugmaster = _debugmaster;
	yane::Utils::StatisticsMaster * statisticsmaster = _statisticsmaster;
	yane::Utils::DebugClient * debugclient = _debugclient;
	int dimx = _model->dimensionState ( );
	int dimu = _model->dimensionControl ( );

	try
	{
		/*********************
		 *Controller Actuator*
		 *********************/

		actuatorInputToController ( debugmaster, debugclient, statisticsmaster );

		/*********************
		 * Controller Input  *
		 *********************/

		sensorInputToController ( seq, debugmaster, debugclient, statisticsmaster );

		/*********************
		 * Controller *
		 *********************/
		if ( debugmaster )
		{
			stringstream message;
			message << " ================ new cycle " << seq << ", computing cycle " << seq + _prediction
			        << " ===================";
			debugclient->sendDebugMessage ( message.str ( ), DEBUG_ALGORITHM );
		}

		/*********************
		 * Algorithm Step C0 *
		 *********************/

		if ( _error_received )
		{
			if ( _cb->hasCycle ( _sigma_err ) )
			{
				if ( debugmaster )
				{
					stringstream message;
					message << "errorflag! discarding cycles > " << _sigma_cor;
					debugclient->sendDebugMessage ( message.str ( ), DEBUG_ALGORITHM );
				}
				int sizebefore = _cb->size ( );
				_cb->invalidateCycle ( _sigma_cor + 1 );

				if ( statisticsmaster )
				{
					_stat_mpc_invalidateseq->addValue ( sizebefore - _cb->size ( ) );
				}
				_error_received = false;
				// Indicate, that predicted sensor-value got invalid
				_inputxchanged = true;
			}
			else
			{
				if ( debugmaster )
				{
					stringstream mess;
					mess << "error received, but clipboard does not have seq " << _sigma_err
					        << " stored. most likely deleted earlier or skipped";//TODO checken
					debugclient->sendDebugMessage ( mess.str ( ), DEBUG_ALGORITHM );
				}
			}
		}

		/*********************
		 * Algorithm Step C1 *
		 *********************/

		if ( _inputxchanged )
		{
			if ( debugmaster )
			{
				debugclient->sendDebugMessage ( "sensor value has to be predicted, so I do...", DEBUG_ALGORITHM );
			}
			predictSensorValues ( _x, seq + _prediction );
			if ( debugmaster )
			{
				debugclient->sendDebugMessage ( "done.", DEBUG_ALGORITHM );
			}
			_inputxchanged = false;
		}

		// It there were no new sensor values since last calculation, we have to predict
		// from the last state manually...
		if ( seq + _prediction - _last_seq > _horizon )
		{
			debugclient->sendDebugMessage (
			        "Time between two MPC iterations was larger than horizon length. Something's going wrong...",
			        DEBUG_BASE );
		}
		if ( seq + _prediction - _last_seq > 0 && ! _skipMPC )
		{
			if ( debugmaster )
			{
				debugclient->sendDebugMessage ( "state has to be predicted, so I do...", DEBUG_ALGORITHM );
			}
			predictInternalState ( _x, _last_seq, seq + _prediction );
			if ( debugmaster )
			{
				debugclient->sendDebugMessage ( "done.", DEBUG_ALGORITHM );
			}
		}

		/*********************
		 * Algorithm Step C2 *
		 *********************/

		if ( _cb->hasCycle ( seq + _prediction ) )
		{
			_skipMPC = true;
			if ( debugmaster )
			{
				debugclient->sendDebugMessage (
				        "control for this time instant already computed, skipping mpc computation", DEBUG_ALGORITHM );
			}
			if ( statisticsmaster )
			{
				_stat_mpc_alreadycomputed->addValue ( 1 );
			}
		}

		if ( ! _skipMPC )
		{
			if ( debugmaster )
			{
				debugclient->sendDebugMessage ( "commencing mpc:", DEBUG_ALGORITHM );
				debugclient->sendDebugMessageDouble ( "initial state", "state", _model->dimensionState ( ), _x, DEBUG_ALGDETAILS );
			}
			// calculating control
			_t [ 0 ] = ( seq + _prediction ) * samplingTime;
			for ( int i = 1; i < horizon + 1; i++ )
			{
				_t [ i ] = _t [ i - 1 ] + samplingTime;
			}
			if ( debugmaster )
			{
				debugclient->sendDebugMessageDouble ( "timegrid generated", "timegrid", horizon + 1, _t,
				        DEBUG_ALGDETAILS );
			}

			for ( int i = 0; i < horizon; i++ )
			{
				double * ptr = 0;
				try
				{
					ptr = ( * _cb ) [ i + seq + _prediction ];
				}
				catch ( yane::Utils::Exception e )
				{
					ptr = 0;
				}

				if ( ptr )
				{
					memcpy ( & _u [ i * dimu ], ptr, sizeof(double) * dimu );
				}
				else
				{
					_model->getDefaultControl ( & _u [ i * dimu ] );
				}
			}
			if ( debugmaster )
			{
				debugclient->sendDebugMessageDouble ( "control generated", "control", horizon
				        * _model->dimensionControl ( ), _u, DEBUG_ALGDETAILS );
			}

			_timer->reset ( );
			try
			{
				if ( debugmaster )
				{
					debugclient->sendDebugMessage ( "executing mpc...", DEBUG_ALGORITHM );
				}
				if ( _saveMPCCallData )
				{
					_mpcCallTimes.push_back ( seq * samplingTime );
					_mpcCallStates.resize ( _mpcCallStates.size ( ) + 1 );
					_mpcCallStates [ _mpcCallStates.size ( ) - 1 ].resize ( _model->dimensionState ( ) );
					copy ( _x, _x + _model->dimensionState ( ), _mpcCallStates [ _mpcCallStates.size ( ) - 1 ].begin ( ) );
				}
				_mpc->calc ( _x );
			}
			catch ( yane::MinProg::SolverWarning e )
			{
				if ( debugmaster )
				{
					debugclient->sendDebugMessageString ( "Solver warning during mpc calculation", "e.what()",
					        e.what ( ), DEBUG_ALGORITHM );
				}
			}
			catch ( yane::Utils::Exception e )
			{
				if ( debugmaster )
				{
					debugclient->sendDebugMessageString ( "Critical error during mpc calculation", "e.what()",
					        e.what ( ), DEBUG_CRITICAL );
				}
			}
			if ( _distancefunction )
			{
				try
				{
					_simulator_controller->trajectory ( horizon, _t, _x, _u, & _trajectory [ _prediction
					        * _model->dimensionState ( ) ] );
				}
				catch ( yane::OdeSolve::OdeSolEx e )
				{
					throw yane::OdeSolve::OdeSolEx (
					        __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ),
					        __DEBUGMESS ( "ODE solver could not precede steps" ) );
				}
				catch ( yane::Utils::Exception e )
				{
					throw yane::Utils::Exception (
					        __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ),
					        __DEBUGMESS ( "Calculation was aborted" ), & e );
				}
			}

			double time_needed = _timer->elapsedSeconds ( );
			if ( debugmaster )
			{
				stringstream message;
				message << "New control for cycle " << seq + _prediction << " calculated. " << time_needed
				        << " sec. needed";
				debugclient->sendDebugMessage ( message.str ( ), DEBUG_ALGORITHM );
			}
			if ( statisticsmaster )
			{
				_stat_mpc_calcduration->addValue ( time_needed * 1000.0 );
				_stat_mpc_computedseq->addValue ( 1 );
			}

			/****************************
			 * Algorithm Step C3 and C4 *
			 ****************************/

			_cb->appendData ( seq + _prediction, time_needed, _u, _preseq );
			setControllerOutputPacket ( _preseq, seq + _prediction, horizon, _u );

			/*********************
			 * Controller Output *
			 *********************/

			controllerOutputToActuator ( seq, debugmaster, debugclient, statisticsmaster );
		}

		/*********************
		 * Misc stuff...     *
		 *********************/

		// removing old sequences from clipboard
		if ( debugmaster )
		{
			debugclient->sendDebugMessage ( "cleaning clipboard...", DEBUG_INNERDETAILS );
		}
		_cb->cleanup ( min ( ( int ) floor ( _inputxtime / samplingTime + 1E-10 ), seq - horizon ), seq );
	}
	catch ( yane::Utils::Exception e )
	{
		if ( debugmaster )
		{
			debugclient->sendDebugMessageString ( "EMERGENCY-EXIT", "what()", e.what ( ), DEBUG_CRITICAL );
		}
	}
}

void yane::NetworkedControl::MPCController::implementControl ( int seq )
{
	_interface->setSamplingInstant ( seq );
	_interface->triggerProcessToImplementControl ( seq * _samplingTime, ( seq + 1 ) * _samplingTime );
}

void yane::NetworkedControl::MPCController::predictSensorValues ( double * peekedx, int to_seq )
{
	double samplingTime = _samplingTime;
	int startseq = ( int ) floor ( ( _inputxtime + 1E-10 ) / samplingTime );
	int seqlength = to_seq - startseq;

	memcpy ( peekedx, _inputx, sizeof(double) * _model->dimensionState ( ) );

	if ( seqlength > 0 )
	{
		double * timesteps = new double [ seqlength + 1 ];
		timesteps [ 0 ] = _inputxtime;
		timesteps [ 1 ] = ( startseq + 1 ) * samplingTime;
		for ( int i = 2; i < seqlength + 1; i++ )
		{
			timesteps [ i ] = timesteps [ i - 1 ] + samplingTime;
		}

		computePrediction ( peekedx, startseq, to_seq, timesteps );
		delete [ ] timesteps;
	}
	else if ( seqlength == 0 )
	{
		_last_seq = to_seq;
	}
	else
	{
		if ( _debugmaster )
		{
			_debugclient->sendDebugMessage ( "Future sensor value, something is going wrong.", DEBUG_BASE );
		}
	}
}

void yane::NetworkedControl::MPCController::predictInternalState ( double * state, int from_seq, int to_seq )
{
	int seqlength = to_seq - from_seq;

	if ( seqlength > 0 )
	{
		double samplingTime = _samplingTime;
		double * timesteps = new double [ seqlength + 1 ];
		timesteps [ 0 ] = from_seq * samplingTime;
		for ( int i = 1; i < seqlength + 1; i++ )
		{
			timesteps [ i ] = timesteps [ i - 1 ] + samplingTime;
		}

		computePrediction ( state, from_seq, to_seq, timesteps );
		delete [ ] timesteps;
	}
	else if ( seqlength == 0 )
	{
		_last_seq = to_seq;
	}
	else
	{
		if ( _debugmaster )
		{
			_debugclient->sendDebugMessage ( "Inconsistent prediction interval... nothing done.", DEBUG_BASE );
		}
	}
}

void yane::NetworkedControl::MPCController::computePrediction ( double * state, int from_seq, int to_seq,
        double * timesteps )
{
	// Create local variables for speedup
	yane::Utils::DebugMaster * debugmaster = _debugmaster;
	yane::Utils::DebugClient * debugclient = _debugclient;
	int dimu = _model->dimensionControl ( );
	int dimx = _model->dimensionState ( );

	int seqlength = to_seq - from_seq;

	double * control = new double [ seqlength * dimu ];
	for ( int i = 0; i < seqlength; i++ )
	{
		double * ptr = 0;
		try
		{
			ptr = ( * _cb ) [ i + from_seq ];
		}
		catch ( yane::Utils::Exception e )
		{
			ptr = 0;
		}

		if ( ptr )
		{
			memcpy ( & control [ i * dimu ], ptr, sizeof(double) * dimu );
		}
		else
		{
			if ( debugmaster )
			{
				debugclient->sendDebugMessage ( "No previously computed controls available, using default values",
				        DEBUG_BASE );
			}
			_model->getDefaultControl ( & control [ i * dimu ] );
		}
	}

	try
	{
		if ( debugmaster )
		{
			debugclient->sendDebugMessageDouble ( "before prediction...", "state", dimx, state, DEBUG_INNERDETAILS );
			debugclient->sendDebugMessageDouble ( "timesteps...", "timesteps", seqlength + 1, timesteps,
			        DEBUG_INNERDETAILS );
		}
		try
		{
			if ( _distancefunction )
			{
				_simulator_controller->trajectory ( seqlength, timesteps, state, control, _trajectory );
			}
			_simulator_controller->predictSequence ( seqlength, timesteps, state, control );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx (
			        __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ),
			        __DEBUGMESS ( "ODE solver could not precede steps" ) );
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception (
			        __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ),
			        __DEBUGMESS ( "Calculation was aborted" ), & e );
		}
		if ( debugmaster )
		{
			stringstream str;
			str << "prediction from _seq=" << from_seq << " to _seq=" << to_seq << " done.";
			debugclient->sendDebugMessageDouble ( str.str ( ), "predicted state", dimx, state, DEBUG_ALGDETAILS );
			debugclient->sendDebugMessageDouble ( "used control", "control", dimu * seqlength, control,
			        DEBUG_INNERDETAILS );
		}
		_last_seq = to_seq;
	}
	catch ( yane::Utils::Exception e )
	{
		if ( debugmaster )
		{
			debugclient->sendDebugMessageString ( "Failed predicting state", "e.what()", e.what ( ), DEBUG_BASE );
		}
	}
	delete [ ] control;
}

void yane::NetworkedControl::MPCController::setNewState ( double t, double * state )
{
	if ( _inputxtime > t )
	{
		if ( _debugmaster )
		{
			_debugclient->sendDebugMessage ( "received new state, but timestamp is older then the last one",
			        DEBUG_ALGDETAILS );
		}
	}
	else
	{
		memcpy ( _inputx, state, sizeof(double) * _model->dimensionState ( ) );
		_inputxtime = t;
		_inputxchanged = true;
	}
}

void yane::NetworkedControl::MPCController::setActuatorErrorVariables ( int lastnonerrorcycle, int currentcycle )
{
	_error_received = true;
	_sigma_err = currentcycle;
	_sigma_cor = lastnonerrorcycle;
}

void yane::NetworkedControl::MPCController::setControllerOutputPacket ( int preseq, int seq, int horizon, double * u )
{
	if ( ! _controllerpacket_data )
	{
		_controllerpacket_data = new double [ horizon * _model->dimensionControl ( ) ];
	}
	else if ( horizon != _controllerpacket_horizon )
	{
		delete [ ] _controllerpacket_data;
		_controllerpacket_data = new double [ horizon * _model->dimensionControl ( ) ];
	}
	_controllerpacket.code = IOInterface::OUTPUTCODE;
	_controllerpacket.preseq = preseq;
	_controllerpacket.seq = seq;

	_controllerpacket_horizon = horizon;
	memcpy ( _controllerpacket_data, u, sizeof(double) * horizon * _model->dimensionControl ( ) );
}

void yane::NetworkedControl::MPCController::initializeMPCControllerInput ( )
{
	if ( _statisticsmaster )
	{
		_stat_sensorinput_sent = new yane::Utils::StatisticsClientIntCounter ( _statisticsmaster,
		        "NetworkedController", "sent input sequences" );
	}
}

void yane::NetworkedControl::MPCController::initializeMPCController ( )
{
	if ( _statisticsmaster )
	{
		_stat_mpc_computedseq = new yane::Utils::StatisticsClientIntCounter ( _statisticsmaster, "NetworkedController",
		        "computed control sequences" );
		_stat_mpc_invalidateseq = new yane::Utils::StatisticsClientIntCounter ( _statisticsmaster,
		        "NetworkedController", "invalidated control sequences" );
		_stat_mpc_alreadycomputed = new yane::Utils::StatisticsClientIntCounter ( _statisticsmaster,
		        "NetworkedController", "already computed control sequences" );
		_stat_mpc_skipseq = new yane::Utils::StatisticsClientIntCounter ( _statisticsmaster, "NetworkedController",
		        "skipped control sequences" );
		_stat_mpc_calcduration = new yane::Utils::StatisticsClientAverage ( _statisticsmaster, "NetworkedController",
		        "computational time [ms]", 1, true, true, true );
	}

	try
	{
		_mpc = new yane::MPC::MPC ( );
		_mpc->reset ( _odemanager, _minimizer, _model, _horizon, 0, _shootingdata );
		_mpc->allocateMemory ( _t, _u );
		_mpc->initCalc ( _t, _u );

		yane::Utils::OptimalDiff::calc ( );

		_simulator_controller = new yane::Model::Simulator ( _model );
		_x = new double [ _model->dimensionState ( ) ];
		_inputx = new double [ _model->dimensionState ( ) ];
		_inputxtime = - 1.0;
		_model->getDefaultState ( _x );
		_model->getDefaultState ( _inputx );
	}
	catch ( yane::Utils::Exception e )
	{
		if ( _debugmaster )
		{
			_debugclient->sendDebugMessageString ( "EMERGENCY-EXIT", "what()", e.what ( ), DEBUG_CRITICAL );
		}
	}
}

void yane::NetworkedControl::MPCController::initializeMPCControllerOutput ( )
{
	if ( _statisticsmaster )
	{
		_stat_mpcoutput_sent = new yane::Utils::StatisticsClientIntCounter ( _statisticsmaster, "NetworkedController",
		        "sent control sequences" );
	}
}

void yane::NetworkedControl::MPCController::initializeModelHandler ( )
{
	if ( _statisticsmaster )
	{
		_stat_actuator_received = new yane::Utils::StatisticsClientIntCounter ( _statisticsmaster,
		        "NetworkedController", "received actuator errors" );
	}
}

void yane::NetworkedControl::MPCController::setMaxIter ( int seqmax )
{
	_seqmax = seqmax;
}

void yane::NetworkedControl::MPCController::sensorInputToController ( int seq, yane::Utils::DebugMaster * debugmaster,
        yane::Utils::DebugClient * debugclient, yane::Utils::StatisticsMaster * statisticsmaster )
{
	_sensorpacket.code = 0;
	try
	{
		if ( debugmaster )
		{
			debugclient->sendDebugMessage ( "reading sensor values from interface...", DEBUG_INNERDETAILS );
		}
		_interface->readInput ( & _sensorpacket, _sensorvalues );
		if ( debugmaster )
		{
			debugclient->sendDebugMessage ( "done!", DEBUG_INNERDETAILS );
		}
	}
	catch ( yane::Utils::Exception e )
	{
		if ( debugmaster )
		{
			debugclient->sendDebugMessageString ( "interface input method failed!", "e.what()", e.what ( ),
			        DEBUG_CRITICAL );
		}
	}

	_skipMPC = false;
	if ( _sensorpacket.code == IOInterface::INPUTCODE )
	{
		if ( _distancefunction && seq >= _prediction && seq - _last_sensor_seq < _maximalOpenLoopIterations && seq != 0 )
		{
			if ( _distancefunction ( _model->dimensionState ( ), _model->dimensionState ( ), _sensorvalues,
			        & _trajectory [ ( seq - _last_sensor_seq ) * _model->dimensionState ( ) ] )
			        < _stateDistanceTolerance )
			{
				_skipMPC = true;
				if ( debugmaster )
				{
					debugclient->sendDebugMessage (
					        "predicted state close enough to new sensor value, skipping mpc computation",
					        DEBUG_ALGORITHM );
				}
				if ( statisticsmaster )
				{
					_stat_mpc_skipseq->addValue ( 1 );
				}
			}
		}
		if ( ! _skipMPC )
		{
			if ( debugmaster )
			{
				debugclient->sendDebugMessage ( "sending sensor values to mpc ...", DEBUG_INNERDETAILS );
			}
			setNewState ( _sensorpacket.time, _sensorvalues );
			_last_sensor_seq = seq;
			if ( debugmaster )
			{
				debugclient->sendDebugMessage ( "done!", DEBUG_INNERDETAILS );
			}

			if ( statisticsmaster )
			{
				_stat_sensorinput_sent->addValue ( 1 );
			}
		}
	}
	else
	{
		if ( debugmaster )
		{
			debugclient->sendDebugMessageInt ( "Invalid packet code", "code", 1, & ( _sensorpacket.code ),
			        DEBUG_INNERDETAILS );
		}
	}
}

void yane::NetworkedControl::MPCController::controllerOutputToActuator ( int seq,
        yane::Utils::DebugMaster * debugmaster, yane::Utils::DebugClient * debugclient,
        yane::Utils::StatisticsMaster * statisticsmaster )
{
	if ( debugmaster )
	{
		stringstream str;
		str << "Sending outputpacket (preseq=" << _preseq << ", seq=" << seq << ", length="
		        << _interface->sequenceLength ( ) << ")";
		debugclient->sendDebugMessageDouble ( str.str ( ), "controlsequence", _interface->sequenceLength ( )
		        * _model->dimensionControl ( ), _controllerpacket_data, DEBUG_ALGORITHM );
	}
	try
	{
		if ( debugmaster )
		{
			debugclient->sendDebugMessage ( "sending control sequence to interface...", DEBUG_INNERDETAILS );
		}
		_interface->setSamplingInstant ( seq );
		_interface->writeOutput ( & _controllerpacket, _controllerpacket_data );
		if ( debugmaster )
		{
			debugclient->sendDebugMessage ( "done!", DEBUG_INNERDETAILS );
		}
		if ( statisticsmaster )
		{
			_stat_mpcoutput_sent->addValue ( 1 );
		}
	}
	catch ( yane::Utils::Exception e )
	{
		if ( debugmaster )
		{
			debugclient->sendDebugMessageString ( "interface output method failed!", "e.what()", e.what ( ),
			        DEBUG_CRITICAL );
		}
	}
}

void yane::NetworkedControl::MPCController::actuatorInputToController ( yane::Utils::DebugMaster * debugmaster,
        yane::Utils::DebugClient * debugclient, yane::Utils::StatisticsMaster * statisticsmaster )
{
	try
	{
		_interface->readActor ( & _actuatorpacket );
	}
	catch ( yane::Utils::Exception e )
	{
		if ( debugmaster )
		{
			debugclient->sendDebugMessageString ( "interface actor method failed!", "e.what()", e.what ( ),
			        DEBUG_CRITICAL );
		}
	}

	if ( _actuatorpacket.code == IOInterface::ACTORERRORCODE )
	{
		if ( debugmaster )
		{
			stringstream mess;
			mess << "actuatorpacket: (seq=" << _actuatorpacket.seq_err << ", preseq=" << _actuatorpacket.preseq_err
			        << ")";
			debugclient->sendDebugMessage ( mess.str ( ), DEBUG_ALGORITHM );
		}
		setActuatorErrorVariables ( _actuatorpacket.preseq_err, _actuatorpacket.seq_err );
		if ( statisticsmaster )
		{
			_stat_actuator_received->addValue ( 1 );
		}
	}
	else
	{
		if ( debugmaster )
		{
			stringstream mess;
			mess << "invalid packet: code=0x" << setbase ( 16 ) << setfill ( '0' ) << setw ( 8 )
			        << _actuatorpacket.code << setw ( 1 ) << setbase ( 10 );
			debugclient->sendDebugMessage ( mess.str ( ), DEBUG_INNERDETAILS );
		}
	}
}

void yane::NetworkedControl::MPCController::setMaximalOpenLoopIterations ( int maximalOpenLoopIterations )
{
	_maximalOpenLoopIterations = maximalOpenLoopIterations;
}

int yane::NetworkedControl::MPCController::mpcCallCounter ( )
{
	return _mpcCallStates.size ( );
}

std::vector < std::vector < double > > yane::NetworkedControl::MPCController::mpcCallStates ( )
{
	return _mpcCallStates;
}

std::vector < double > yane::NetworkedControl::MPCController::mpcCallTimes ( )
{
	return _mpcCallTimes;
}

void yane::NetworkedControl::MPCController::setSaveMPCCallData ( bool saveMPCCallData )
{
	_saveMPCCallData = saveMPCCallData;
}
