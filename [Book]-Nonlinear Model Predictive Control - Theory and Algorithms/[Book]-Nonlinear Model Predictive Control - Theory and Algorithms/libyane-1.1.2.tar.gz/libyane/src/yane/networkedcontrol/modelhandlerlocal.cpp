/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "modelhandlerlocal.h"

#include "../model.h"
#include "../utils.h"

#include <cstring>
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

yane::NetworkedControl::ModelHandlerLocal::ModelHandlerLocal ( yane::Model::Model * model, int horizon,
        yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm )
{
	_actuator = new yane::NetworkedControl::Actuator ( model, horizon, actuatorfunc, this, dm, sm );

	_model = model;
	_simulator = new yane::Model::Simulator ( model );

	_x = new double [ model->dimensionState ( ) ];
	model->getDefaultState ( _x );

	_u = new double [ model->dimensionControl ( ) ];
	model->getDefaultControl ( _u );

	_currentSamplingInstant = 0.0;

	_has_actorpacket = false;
}

yane::NetworkedControl::ModelHandlerLocal::~ModelHandlerLocal ( )
{
	delete _simulator;
	delete _actuator;
	delete [ ] _x;
	delete [ ] _u;
}

void yane::NetworkedControl::ModelHandlerLocal::implementControl ( double currentSamplingInstant,
        double nextSamplingInstant )
{
	_actuator->getCurrentControl ( _u );
	_simulator->initialize ( currentSamplingInstant, _x, _u );
	_simulator->run ( nextSamplingInstant );
	_currentSamplingInstant = nextSamplingInstant;
}

void yane::NetworkedControl::ModelHandlerLocal::actuatorfunc ( void * packet, void * ptr )
{
	yane::NetworkedControl::ModelHandlerLocal * base = ( yane::NetworkedControl::ModelHandlerLocal * ) ptr;
	memcpy ( & base->packet, packet, sizeof(yane::NetworkedControl::T_ACTORPACKET) );
	base->_has_actorpacket = true;
}

yane::NetworkedControl::Actuator * yane::NetworkedControl::ModelHandlerLocal::actuator ( )
{
	return _actuator;
}

void yane::NetworkedControl::ModelHandlerLocal::readState ( double & t, double * state )
{
	t = _currentSamplingInstant;
	memcpy ( state, _x, sizeof(double) * _model->dimensionState ( ) );
}

const yane::NetworkedControl::T_ACTORPACKET & yane::NetworkedControl::ModelHandlerLocal::currentActorPacket ( )
{
	_has_actorpacket = false;
	return packet;
}

bool yane::NetworkedControl::ModelHandlerLocal::hasActorPacket ( )
{
	return _has_actorpacket;
}

yane::Model::Model * yane::NetworkedControl::ModelHandlerLocal::model ( )
{
	return _model;
}

void yane::NetworkedControl::ModelHandlerLocal::setInitialValues ( double t, double * x )
{
	_currentSamplingInstant = t;
	memcpy ( _x, x, sizeof(double) * _model->dimensionState ( ) );
}
