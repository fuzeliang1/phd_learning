/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

//TODO Doku
#ifndef YANE_NETWOREDCONTROL_MODELHANDLER_LOCAL_H
#define YANE_NETWOREDCONTROL_MODELHANDLER_LOCAL_H

#include "actuator.h"
#include "typedefs.h"

namespace yane
{
	namespace Model
	{
		class Model;
		class Simulator;
	}
	namespace Utils
	{
		class DebugMaster;
		class StatisticsMaster;
	}

	namespace NetworkedControl
	{
		class Actuator;

		class ModelHandlerLocal
		{
			public:
				ModelHandlerLocal ( yane::Model::Model * model, int horizon, yane::Utils::DebugMaster * dm,
				        yane::Utils::StatisticsMaster * sm );
				~ModelHandlerLocal ( );

				virtual void readState ( double & t, double * state );

				yane::NetworkedControl::Actuator * actuator ( );
				const yane::NetworkedControl::T_ACTORPACKET & currentActorPacket ( );
				virtual bool hasActorPacket ( );
				virtual void implementControl ( double currentSamplingInstant, double nextSamplingInstant );
				yane::Model::Model * model ();

				void setInitialValues ( double t, double * x );

			protected:

				static void actuatorfunc ( void * packet, void * ptr );

				yane::NetworkedControl::Actuator * _actuator;
				yane::Model::Simulator * _simulator;
				yane::Model::Model * _model;
				double * _x;
				double * _u;
				double _currentSamplingInstant;
				bool _has_actorpacket;

				yane::NetworkedControl::T_ACTORPACKET packet;

		};
	}
}

#endif
