/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "controller_realtimempc.h"
#include "controllerthreadmpc.h"
#include "controllerthreadoutput.h"
#include "controllerthreadinput.h"
#include "controllerthreadactuator.h"
#include "iointerface.h"
#include "cycle.h"

#include "../minprog.h"
#include "../model.h"
#include "../utils.h"

yane::NetworkedControl::RealtimeMPCController::RealtimeMPCController ( yane::Model::Model * model,
        yane::MPC::ModelShootingData * shootingdata, int horizon, int prediction, yane::MinProg::NLP * minimizer,
        yane::MPC::OdeManager * odemanager, yane::Utils::RTClock * clock, IOInterface * iface,
        yane::Utils::DebugMaster * debugmaster, yane::Utils::StatisticsMaster * statisticsmaster ) :
	yane::NetworkedControl::Controller ( model, horizon, prediction, iface, debugmaster, statisticsmaster )
{
	_threadmpc = new ControllerThreadMPC ( iface, odemanager, minimizer, horizon, prediction, model, shootingdata, debugmaster,
	        statisticsmaster );
	_threadoutput = new ControllerThreadOutput ( iface, model, debugmaster, statisticsmaster );
	_threadinput = new ControllerThreadInput ( iface, model, debugmaster, statisticsmaster );
	_threadactuator = new ControllerThreadActuator ( iface, debugmaster, statisticsmaster );

	_threadmpc->setOutputThread ( _threadoutput );
	_threadinput->setMPCThread ( _threadmpc );
	_threadactuator->setMPCThread ( _threadmpc );
}

yane::NetworkedControl::RealtimeMPCController::~RealtimeMPCController ( )
{
	this->stop ( );

	delete _threadinput;
	delete _threadactuator;
	delete _threadmpc;
	delete _threadoutput;
}

void yane::NetworkedControl::RealtimeMPCController::start ( )
{
	_threadmpc->start ( );
	_threadinput->start ( );
	_threadactuator->start ( );
	_threadoutput->start ( );
}

void yane::NetworkedControl::RealtimeMPCController::stop ( )
{
	_threadmpc->stop ( );
	_threadinput->stop ( );
	_threadactuator->stop ( );
	_threadoutput->stop ( );

	_threadinput->wait ( );
	_threadmpc->wait ( );
	_threadoutput->wait ( );
	_threadactuator->wait ( );
}

yane::NetworkedControl::Cycle * yane::NetworkedControl::RealtimeMPCController::controllerCycle ( )
{
	return _threadmpc->controllerCycle ( );
}
