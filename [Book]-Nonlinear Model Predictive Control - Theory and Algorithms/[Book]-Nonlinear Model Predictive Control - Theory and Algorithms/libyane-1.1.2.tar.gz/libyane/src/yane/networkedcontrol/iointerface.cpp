/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "iointerface.h"
#include "controller.h"

#include "../utils.h"
#include "../model.h"
#include "../mpc.h"

#include <sstream>
#include <iostream>
#include <unistd.h>

#include "libexport.h"

using namespace std;

LIB_EXPORT const int yane::NetworkedControl::IOInterface::OUTPUTCODE = 0xF02891C2;
LIB_EXPORT const int yane::NetworkedControl::IOInterface::INPUTCODE = 0x9A10092F;
LIB_EXPORT const int yane::NetworkedControl::IOInterface::ACTORERRORCODE = 0x2EE878B8;

LIB_EXPORT yane::NetworkedControl::IOInterface::IOInterface ( )
{
	_model = 0;
}

LIB_EXPORT yane::NetworkedControl::IOInterface::~IOInterface ( )
{
}

LIB_EXPORT yane::Model::Model * yane::NetworkedControl::IOInterface::model ( )
{
	return _model;
}

