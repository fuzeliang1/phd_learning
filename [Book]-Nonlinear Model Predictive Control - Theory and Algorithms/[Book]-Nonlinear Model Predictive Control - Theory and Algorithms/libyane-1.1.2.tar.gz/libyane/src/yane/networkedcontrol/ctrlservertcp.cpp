/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "ctrlservertcp.h"
#include "cycle.h"
#include "typedefs.h"

#include "../version.h"
#include "../mpc.h"
#include "../model.h"
#include "../utils.h"

// TODO WINDOWS includes pr�fen (close() durch closesocket() ersetzt)
#ifdef _WIN32
	#include <winsock.h>
#else
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <netdb.h>
	#include <cstring>
	#include <sys/select.h>
	#include <sys/time.h>
	#include <iostream>
	#include <cstdlib>
	#include <sstream>
#endif
using namespace std;

yane::NetworkedControl::CtrlServerTCP::CtrlServerTCP(yane::Model::Model * model, const char * servername, int maxseqlength, double discrtime, T_MESSAGECALLBACK mess_cb, void * ptr, int readbuffersize, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm)
	: CommBaseTCP(mess_cb, ptr, readbuffersize, "TCP Network Server", dm, sm)
{
	_modelname = new char[128];
	_servername = new char[128];
	_clientname = new char[128];
	_maxseqlength = maxseqlength;
	_discrtime = discrtime;
	_model = model;

	memset(_clientname, 0, 128);

	strncpy(_modelname, model->name(), 127);
	strncpy(_servername, servername, 127);

	_modelname[127] = '\0';
	_servername[127] = '\0';
}

yane::NetworkedControl::CtrlServerTCP::~ CtrlServerTCP()
{
	delete[] _modelname;
	delete[] _servername;
	delete[] _clientname;
}

void yane::NetworkedControl::CtrlServerTCP::startListening(int port)
{
	int length;

	struct sockaddr_in server;

	_listensocket=socket(AF_INET, SOCK_STREAM, 0);
	if (_listensocket < 0)
	{
		debugMessage("error opening listensocket", DEBUG_CRITICAL);
		return;
	}
#ifdef _WIN32
	char on;
#else
	int on=1;
#endif
	if (setsockopt(_listensocket, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
	{
		debugMessage("setsockopt failed", DEBUG_CRITICAL);
		return;
	}


	length = sizeof(server);
	memset(&server, 0 ,length);
	server.sin_family=AF_INET;
	server.sin_addr.s_addr=INADDR_ANY;
	server.sin_port=htons(port);

	if (bind(_listensocket,(struct sockaddr *)&server,length)<0)
	{
		debugMessage("binding socket failed", DEBUG_CRITICAL);
		return;
	}

	listen(_listensocket, 1);
	debugMessage("started listening...", DEBUG_INNERDETAILS);
}

void yane::NetworkedControl::CtrlServerTCP::stopListening()
{
	debugMessage("stopped listening...", DEBUG_INNERDETAILS);
#ifdef _WIN32
	closesocket(_listensocket);
#else
	close(_listensocket);
#endif
}


bool yane::NetworkedControl::CtrlServerTCP::waitForConnection(int timeout_sec)
{
	int n;
	_connectionestablished = false;
	T_HS_CLIENTMESSAGE clmess;
	T_HS_SERVERMESSAGE servmess;
	T_HS_SERVERRESPONSE servresponse;

	srand(time(0));

	if (tryAccept(_listensocket, _talksocket, timeout_sec))
	{
		if (_talksocket >= 0)
		{
			debugMessage("client connected", DEBUG_INNERDETAILS);

			servmess.code = CODE1;
			servmess.maxsequencelength = _maxseqlength;
			servmess.discrtime = _discrtime;
			libyane::versionStringToInt(libyane::version(), servmess.ver_maj, servmess.ver_min, servmess.ver_rev);
			servmess.protocolversion = PROTVER;
			memset(servmess.servername, 0, 128);
			memset(servmess.model, 0, 128);
			strcpy(servmess.servername, _servername);
			strcpy(servmess.model, _modelname);
			servmess.clientcode = rand();
			_model->id().toCharPtr(servmess.modelid);

			debugMessage("sending header", DEBUG_INNERDETAILS);
			if (!tryWrite(_talksocket,(char*)&servmess,sizeof(T_HS_SERVERMESSAGE)))
			{
#ifdef _WIN32
				closesocket(_talksocket);
#else
				close(_talksocket);
#endif
			} else
			{


				debugMessage("waiting for client header", DEBUG_INNERDETAILS);
				if (!tryRead(_talksocket,(char*)&clmess,sizeof(T_HS_CLIENTMESSAGE), n, 30))
				{
					debugMessage("read timeout, or other error", DEBUG_CRITICAL);
#ifdef _WIN32
					closesocket(_talksocket);
#else
					close(_talksocket);
#endif
				} else
				{
					if (clmess.code == servmess.clientcode)
					{
						clmess.clientname[127] = '\0';
						_seqlength = clmess.sequencelength;
						if (_debugclient)
						{
							stringstream mess;
	
							mess << "  name: " << clmess.clientname << endl;
							mess << "  softwareversion: " << clmess.ver_maj << "." << clmess.ver_min << "." << clmess.ver_rev << endl;
							mess << "  protocolversion: " << clmess.protocolversion;
	
							debugMessageString("got clientsided handshake-packet", "clientinfo", mess.str().c_str(), DEBUG_INNERDETAILS);
	
						}
						if (_seqlength > _maxseqlength)
						{
							debugMessage("client requested too big sequencelength, disconnecting", DEBUG_CRITICAL);
	
							servresponse.code = CODE2;
							servresponse.error = true;
							memset(servresponse.errormessage, 0, 128);
							strcpy(servresponse.errormessage, "sequence length too big");
	
							debugMessageString("sending error response", "errormessage", servresponse.errormessage, DEBUG_INNERDETAILS);
							if (!tryWrite(_talksocket,(char*)&servresponse,sizeof(T_HS_SERVERRESPONSE)))
							{
								debugMessage("error sending response", DEBUG_CRITICAL);
							}
#ifdef _WIN32
							closesocket(_talksocket);
#else
							close(_talksocket);
#endif
						}
						else
						{
	
							strcpy(_clientname, clmess.clientname);
	
							servresponse.code = CODE2;
							servresponse.error = false;
							memset(servresponse.errormessage, 0, 128);
	
							debugMessage("sending successful response", DEBUG_INNERDETAILS);
							if (!tryWrite(_talksocket,(char*)&servresponse,sizeof(T_HS_SERVERRESPONSE)))
							{
								debugMessage("error sending response", DEBUG_CRITICAL);
#ifdef _WIN32
								closesocket(_talksocket);
#else
								close(_talksocket);
#endif
							} else
							{
								_connectionestablished = true;
								start();
								debugMessage("connection established", DEBUG_INNERDETAILS);
							}
						}
					}
					else
					{
						debugMessage("handshake failed (bad packet code from client)", DEBUG_CRITICAL);
	
						servresponse.code = CODE2;
						servresponse.error = true;
						memset(servresponse.errormessage, 0, 128);
						strcpy(servresponse.errormessage, "invalid packet code");
	
						debugMessageString("sending error response", "errormessage", servresponse.errormessage, DEBUG_INNERDETAILS);
						if (!tryWrite(_talksocket,(char*)&servresponse,sizeof(T_HS_SERVERRESPONSE)))
						{
							debugMessage("error sending response", DEBUG_CRITICAL);
						}
#ifdef _WIN32
						closesocket(_talksocket);
#else
						close(_talksocket);
#endif
					}
				}
			}
		} else
		{
			debugMessage("accepting socket failed", DEBUG_CRITICAL);
		}
	}

	return _connectionestablished;
}

const char * yane::NetworkedControl::CtrlServerTCP::clientName()
{
	return _clientname;
}

int yane::NetworkedControl::CtrlServerTCP::sequenceLength()
{
	return _seqlength;
}




