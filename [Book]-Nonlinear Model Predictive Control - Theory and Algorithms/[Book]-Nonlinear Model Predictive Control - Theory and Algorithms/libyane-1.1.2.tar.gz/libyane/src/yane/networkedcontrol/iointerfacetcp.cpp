/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "iointerfacetcp.h"
#include "ctrlclienttcp.h"
#include "typedefs.h"

#include "../mpc.h"
#include "../model.h"
#include "../utils.h"

#include <cstring>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::NetworkedControl::IOInterfaceTCP::IOInterfaceTCP(int seqlengthhint, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm, int buffersize)
	: yane::NetworkedControl::IOInterface()
{
	_seqlengthhint = seqlengthhint;
	_sequenceLength = 0;
	_samplingTime = 0.0;
	_client = new CtrlClientTCP("Controller", seqlengthhint, tcp_callback, this, buffersize, dm, sm);

	_actorbuffer = new yane::Utils::FIFOBuffer(buffersize);
	_inputbuffer = new yane::Utils::FIFOBuffer(buffersize);
	_actorsem = new yane::Utils::Semaphore();
	_inputsem = new yane::Utils::Semaphore();
	_outputbuffer = new char[buffersize];

	if (dm)
	{
		_debugclient = dm->newClient("IOInterfaceTCP");
	} else
	{
		_debugclient = 0;
	}
}

LIB_EXPORT yane::NetworkedControl::IOInterfaceTCP::~ IOInterfaceTCP()
{
	if (_client->isConnected())
	{
		_client->closeConnection();
	}

	delete _client;
	delete _actorbuffer;
	delete _inputbuffer;
	delete _outputbuffer;
	delete _actorsem;
	delete _inputsem;
}

LIB_EXPORT void yane::NetworkedControl::IOInterfaceTCP::tcp_callback(char * packetdata, int packetlength, void * ptr)
{
	IOInterfaceTCP * base = (IOInterfaceTCP*)ptr;

	int code = *((int*)packetdata);


	if (code == INPUTCODE)
	{
		base->_inputbuffer->lock();
		try
		{
			base->_inputbuffer->push(packetdata, packetlength);
			base->_inputsem->release(1);
		} catch (yane::Utils::Exception e)
		{
			if (base->_debugclient)
			{
				base->_debugclient->sendDebugMessage("input buffer overflow", DEBUG_CRITICAL);
			}
		}
		base->_inputbuffer->unlock();
	}
	else if (code == ACTORERRORCODE)
	{
		base->_actorbuffer->lock();
		try
		{
			base->_actorbuffer->push(packetdata, packetlength);
			base->_actorsem->release(1);
		} catch (yane::Utils::Exception e)
		{
			if (base->_debugclient)
			{
				base->_debugclient->sendDebugMessage("actor buffer overflow", DEBUG_CRITICAL);
			}
		}
		base->_actorbuffer->unlock();
	} else
	{
		if (base->_debugclient)
		{
			base->_debugclient->sendDebugMessageInt("unknown package code", "code", 1, & code, DEBUG_CRITICAL);
		}
	}
}

LIB_EXPORT void yane::NetworkedControl::IOInterfaceTCP::readActor(T_ACTORPACKET * response)
{
	bool hasdata = false;
	if (_actorsem->tryAcquire(1, 1000))
	{
		_actorbuffer->lock();
		if (_actorbuffer->size() >= sizeof(T_ACTORPACKET))
		{
			try
			{
				_actorbuffer->pop(response, sizeof(T_ACTORPACKET));
				hasdata = true;
			} catch (yane::Utils::Exception e)
			{
				if (_debugclient)
				{
					_debugclient->sendDebugMessage("reading from actor buffer failed... should not happen", DEBUG_CRITICAL);
				}
				_actorbuffer->clear();
			}
	
			_actorbuffer->unlock();
		}
	}
	
	if (!hasdata)
	{
		response->code = 0;
	}
}

LIB_EXPORT void yane::NetworkedControl::IOInterfaceTCP::readInput(T_INPUTPACKET * indata, double * data)
{
	bool hasdata = false;
	if (_inputsem->tryAcquire(1, 1000))
	{
		_inputbuffer->lock();
		if (_inputbuffer->size() >= sizeof(T_INPUTPACKET) + sizeof(double)*_model->dimensionState())
		{
			try
			{
				_inputbuffer->peek(indata, sizeof(T_INPUTPACKET));
				_inputbuffer->peek(data, sizeof(T_INPUTPACKET), sizeof(double)*_model->dimensionState());
				_inputbuffer->discard(sizeof(T_INPUTPACKET) + sizeof(double)*_model->dimensionState());
				hasdata = true;
			} catch (yane::Utils::Exception e)
			{
				if (_debugclient)
				{
					_debugclient->sendDebugMessage("reading from input buffer failed... should not happen", DEBUG_CRITICAL);
				}
				_inputbuffer->clear();
			}
	
			_inputbuffer->unlock();
		}
	}
	
	if (!hasdata)
	{
		indata->code = 0;
	}
}

LIB_EXPORT void yane::NetworkedControl::IOInterfaceTCP::writeOutput(T_OUTPUTPACKET * outdata, double * data)
{
	if (_client->isConnected())
	{
		memcpy(_outputbuffer,  outdata, sizeof(T_OUTPUTPACKET));
		memcpy(&_outputbuffer[sizeof(T_OUTPUTPACKET)], data, sizeof(double)*_model->dimensionControl()*_sequenceLength);

		_client->sendData(_outputbuffer, sizeof(T_OUTPUTPACKET) + sizeof(double)*_model->dimensionControl() *_sequenceLength);
	}
}

LIB_EXPORT int yane::NetworkedControl::IOInterfaceTCP::sequenceLength()
{
	return _sequenceLength;
}

LIB_EXPORT void yane::NetworkedControl::IOInterfaceTCP::connectToModel(yane::Model::Model * model, const char * addr, int port)
{
	if (model == 0)
	{
		throw yane::Utils::ValueException(__DEBUGMESS("Nullpointer not allowed as 'model' parameter"));
	}
	_model = model;
	if (!_client->isConnected())
	{
		_inputbuffer->lock();
		_inputbuffer->clear();
		_inputbuffer->unlock();

		_actorbuffer->lock();
		_actorbuffer->clear();
		_actorbuffer->unlock();

		_client->connectToServer(model->id(), addr, port);

		if (_client->isConnected())
		{
			_sequenceLength = _client->sequenceLength();
			_samplingTime = _client->discrTime();
			_debugclient->sendDebugMessageInt("actuator set length of sending sequence", "sequencelength", 1, & _sequenceLength, DEBUG_ALGORITHM);
			_debugclient->sendDebugMessageDouble("actuator set time discretization", "discrtime", 1, & _samplingTime, DEBUG_ALGORITHM);
		}
	}
}

LIB_EXPORT void yane::NetworkedControl::IOInterfaceTCP::closeConnection()
{
	if (_client->isConnected())
	{
		_client->closeConnection();
	}
}

LIB_EXPORT bool yane::NetworkedControl::IOInterfaceTCP::isConnected()
{
	return _client->isConnected();
}

LIB_EXPORT double yane::NetworkedControl::IOInterfaceTCP::samplingTime()
{
	return _samplingTime;
}
