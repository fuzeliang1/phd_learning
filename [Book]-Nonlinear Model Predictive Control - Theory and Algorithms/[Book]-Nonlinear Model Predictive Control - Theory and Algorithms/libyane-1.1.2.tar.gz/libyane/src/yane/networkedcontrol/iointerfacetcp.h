/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_IOINTERFACETCP_H
#define YANE_NETWORKEDCONTROL_IOINTERFACETCP_H

#include "iointerface.h"

namespace yane
{

	namespace Model
	{
		class Model;
	}

	namespace Utils
	{
		class DebugMaster;
		class DebugClient;
		class FIFOBuffer;
		class Semaphore;
		class StatisticsMaster;
	}

	namespace NetworkedControl
	{

		class CtrlClientTCP;
		class Cycle;

		/** @class IOInterfaceTCP
		 * @brief Class for connecting components in a distributed plant - sensor - controller - actuator setting with a TCP network connection
		 */
		class IOInterfaceTCP : public IOInterface
		{
			public:
				/**
				 * Constructor
				 * @param seqlengthhint Length of the control sequence
				 * @param dm Pointer of the debugmanager of class yane::Utils::DebugMaster
				 * @param sm Pointer of the statistics manager of class yane::Utils::StatisticsMaster
				 * @param buffersize Size of the buffer for storing control values
				 * @brief Constructor
				 */
				IOInterfaceTCP ( int seqlengthhint, yane::Utils::DebugMaster * dm = 0,
				        yane::Utils::StatisticsMaster * sm = 0, int buffersize = 8192 );

				/**
				 * @brief Destructor
				 */
				virtual ~IOInterfaceTCP ( );

				virtual int sequenceLength ( );
				virtual double samplingTime ( );
				virtual void readActor ( T_ACTORPACKET* response );
				virtual void readInput ( T_INPUTPACKET* indata, double* data );
				virtual void writeOutput ( T_OUTPUTPACKET* outdata, double* data );
				virtual bool isConnected ( );

				/**
				 * Function to cause an internal network client to connect to a process
				 * @param model Pointer of the model of class yane::Model::Model which shall be connected
				 * @param addr Address of the process to connect to
				 * @param port Local port to connect the network connection to
				 * @brief Function to connect to a process
				 */
				void connectToModel ( yane::Model::Model * model, const char* addr, int port = 41923 );

				/**
				 * @brief Function to close the connection to a process
				 */
				void closeConnection ( );

			protected:
				/**
				 * Callback function to handle incoming data packets
				 * @param packetdata Identifier and data packet of incoming data
				 * @param packetlength Length of incoming data
				 * @param ptr Base pointer of the class yane::NetworkedControl::IOInterfaceTCP network connection handler
				 * @brief Callback function to handle incoming data packets
				 */
				static void tcp_callback ( char* packetdata, int packetlength, void*ptr );

				yane::Utils::FIFOBuffer * _actorbuffer; /**< @brief Pointer of the actuator data buffer */
				yane::Utils::FIFOBuffer * _inputbuffer; /**< @brief Pointer of the sensor data buffer */
				char * _outputbuffer; /**< @brief Name of the output buffer */
				yane::Utils::Semaphore * _actorsem; /**< @brief Pointer of the actuator semaphore */
				yane::Utils::Semaphore * _inputsem; /**< @brief Pointer of the sensor semaphore */
				yane::Utils::DebugClient * _debugclient; /**< @brief Pointer of the debug client of class yane::Utils::DebugClient */
				CtrlClientTCP * _client; /**< @brief Pointer of the TCP network client */
				int _seqlengthhint; /**< @brief Indicator of the length of the sensor packet to receive */
		};

	}

}

#endif
