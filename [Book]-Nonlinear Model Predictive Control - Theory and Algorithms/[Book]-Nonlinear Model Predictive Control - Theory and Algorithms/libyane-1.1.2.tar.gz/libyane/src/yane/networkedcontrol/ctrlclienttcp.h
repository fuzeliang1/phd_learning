/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_CTRLCLIENTTCP_H
#define YANE_NETWORKEDCONTROL_CTRLCLIENTTCP_H

#include "commbasetcp.h"

namespace yane
{

	namespace Utils
	{
		class StatisticsMaster;
		class Uuid;
	}

	namespace NetworkedControl
	{

		class Cycle;

		/** @class CtrlClientTCP
		not yet documented
		 */
		class CtrlClientTCP : public CommBaseTCP
		{
			public:
				CtrlClientTCP(const char * clientname, int seqlengthhint, T_MESSAGECALLBACK mess_cb, void* ptr, int readbuffersize, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm);
				virtual ~CtrlClientTCP();

				bool connectToServer(const yane::Utils::Uuid & modelid, const char* addr, int port);

				int sequenceLength();
				double discrTime();

			protected:
				char * _clientname;
				int _seqlength;
				int _seqlengthhint;
				double _discrtime;

		};
	}
}

#endif
