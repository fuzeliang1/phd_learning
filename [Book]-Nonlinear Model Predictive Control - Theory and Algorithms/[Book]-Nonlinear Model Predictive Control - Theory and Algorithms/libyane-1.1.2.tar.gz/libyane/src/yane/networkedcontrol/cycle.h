/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_CYCLE_H
#define YANE_NETWORKEDCONTROL_CYCLE_H

#include "../utils/rtclock.h"
#include <unistd.h>

namespace yane
{

	namespace NetworkedControl
	{

		/** @class Cycle
		@brief Class for handling discrete and continuous time sampling instances and times
		 */
		class Cycle : public yane::Utils::RTClock
		{
			public:
				/**
				Constructor \n
				This function sets up and start a clock used for sampling.
				@param discr_time Sampling width
				@brief Constructor
				 */
				Cycle ( double discr_time );

				/**
				@brief Destructor
				 */
				virtual ~Cycle();

				/**
				Function to return the current sampling cycle number
				@return Current cycling number
				@brief Function to return the current sampling cycle number
				 */
				unsigned int get();

				/**
				Function to return the initial time of the current sampling cycle
				@return Initial time of the current sampling cycle in seconds
				@brief Function to return the initial time of the current sampling cycle
				 */
				double cycleStartSeconds();

				/**
				Function to return the terminal time of the current sampling cycle
				@return Terminal time of the current sampling cycle in seconds
				@brief Function to return the terminal time of the current sampling cycle
				 */
				double cycleEndSeconds();

				/**
				Function to return the remaining time within the current sampling cycle
				@return Remaining time within the current sampling cycle in seconds
				@brief Function to return the remaining time within the current sampling cycle
				 */
				double cycleRemainingSeconds();

				/**
				Function to return the elapsed time since start of the current sampling cycle
				@return Elapsed time since start of the current sampling cycle in seconds
				@brief Function to return the elapsed time since start of the current sampling cycle
				 */
				double cycleElapsedSeconds();

				/**
				Function to block the calling thread up to the given target time
				@param time Target time in seconds
				@brief Function to block the calling thread up to the given target time
				 */
				void waitUntil ( double time );

				/**
				Function to return the sampling width
				@return Sampling width in seconds
				@brief Function to return the sampling width
				 */
				double discrTime() const;

			protected:
				double _discr_time;	/**< @brief Sampling width */
		};

	}

}

#endif
