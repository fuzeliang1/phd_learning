/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

//TODO Doku
#ifndef YANE_NETWORKEDCONTROL_ACTUATOR_REALTIME_H
#define YANE_NETWORKEDCONTROL_ACTUATOR_REALTIME_H

#include "typedefs.h"
#include "actuator.h"

#include <string>

namespace yane
{

	namespace Model
	{
		class Model;
	}

	namespace Utils
	{
		class DebugMaster;
		class DebugClient;
		class StatisticsMaster;
		class StatisticsClientIntCounter;
	}

	namespace NetworkedControl
	{

		class Cycle;
		class ControlClipboard;

		/** @class RealtimeActuator
		 * This class can be used to simulate a physical hardware controller. It offers realtime controls computed by a
		 * predictive controller and automatically stores and sorts the transmitted control sequences.
		 *
		 * The user has to pass computed control sequences to an instance of this class. The object automatically chooses
		 * the current control vector and provides error packets dedicated to the predictive controller if necessary. The object
		 * needs an instance of a discrete realtime clock to identify the current cycle.
		 *
		 * @brief Implementation of the actuator sided control sequence manager
		 */
		class RealtimeActuator : public yane::NetworkedControl::Actuator
		{
			public:

				/**
				 * Constructor
				 * @param model Pointer to the class yane:Model::Model object of the controlled system, used to acquire information about dimensions
				 * @param cycle Pointer to an object of a discrete realtime clock.
				 * @param horizon Length of the control sequences sent by the predictive controller
				 * @param func Optional pointer to the error packet callback function. The actuator will not generate error messages, if NULL has been passed.
				 * @param ptr Optional custom pointer passed to the callback function for user defined data
				 * @param dm Optional pointer to a class yane::Utils::Debugmaster object
				 * @param sm Optional pointer to a class yane::Utils::StatisticsMaster object
				 * @brief Constructor
				 */
				RealtimeActuator ( yane::Model::Model * model, Cycle * cycle, int horizon, T_RESPONSEFUNC func = 0,
				        void * ptr = 0, yane::Utils::DebugMaster * dm = 0, yane::Utils::StatisticsMaster * sm = 0 );

				/**
				 * @brief Destructor
				 */
				~RealtimeActuator ( );

				void enterPacket ( void * packet, double * data );

				void getCurrentControl ( double * control );

			protected:
				void proceedError ( int seq, int preseq );

				Cycle * _cycle; /**< @brief stores the pointer the the discrete realtime clock */
		};

	}

}

#endif
