/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "controllerthreadactuator.h"
#include "controllerthreadmpc.h"
#include "iointerface.h"

#include "../utils.h"
#include "../mpc.h"

#include <iomanip>

#ifdef _WIN32
	#include <windows.h>
#endif

using namespace std;

yane::NetworkedControl::ControllerThreadActuator::ControllerThreadActuator(IOInterface * iface, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm)
	: yane::Utils::Thread("Controller: Actuator", dm)
{
	_interface = iface;
	_mpcthread = 0;
	if (sm)
	{
		_stat_received = new yane::Utils::StatisticsClientIntCounter(sm, "Controller", "actuator errors");
	} else
	{
		_stat_received = 0;
	}
}

yane::NetworkedControl::ControllerThreadActuator::~ ControllerThreadActuator()
{
}

void yane::NetworkedControl::ControllerThreadActuator::setMPCThread(ControllerThreadMPC * thread)
{
	_mpcthread = thread;
}

void yane::NetworkedControl::ControllerThreadActuator::run()
{
	T_ACTORPACKET packet;
	if (!_mpcthread)
	{
		debugMessage("No MPC-Thread specified!", DEBUG_CRITICAL);

		return;
	}

	while(!_abort)
	{
		try
		{
			_interface->readActor ( &packet );
		} catch (yane::Utils::Exception e)
		{
			debugMessageString("interface actor method failed!", "e.what()", e.what(), DEBUG_CRITICAL);
#ifdef _WIN32
			//TODO WINDOWS sleep �berpr�fen. sleep(1) = 1ms oder 1s? Sleep(1) = 1ms
			Sleep(1);
#else
			sleep(1);
#endif
		}

		if ( packet.code == IOInterface::ACTORERRORCODE )
		{
			if (_debugclient)
			{
				stringstream mess;
				mess << "actorpacket: (se=" << packet.seq_err << ", preseq=" << packet.preseq_err << ")";
				debugMessage(mess.str(), DEBUG_ALGORITHM);
			}
			_mpcthread->setActuatorErrorVariables(packet.preseq_err, packet.seq_err);
			if (_stat_received)
			{
				_stat_received->addValue(1);
			}
		}
		else
		{
			if ( _debugclient != 0 )
			{
				stringstream mess;
				mess << "invalid packet: code=0x" << setbase ( 16 ) << setfill ( '0' ) << setw ( 8 ) <<  packet.code << setw ( 1 ) << setbase ( 10 );
				debugMessage( mess.str(), DEBUG_INNERDETAILS );
			}
		}
		if (!_interface->isConnected())
		{
			debugMessage("Interface is no more in connected state... aborted", DEBUG_CRITICAL);
			_abort = true;
		}
	}
}
