/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_NETWORKEDCONTROL_CONTROLLERTHREADMPC_H
#define YANE_NETWORKEDCONTROL_CONTROLLERTHREADMPC_H

#include "../utils/thread.h"
#include "../networkedcontrol.h"

namespace yane
{
	namespace Utils
	{
		class Semaphore;
		class StatisticsMaster;
		class StatisticsClientIntCounter;
		class StatisticsClientAverage;
	}

	namespace MinProg
	{
		class NLP;
	}

	namespace Model
	{
		class Model;
		class Simulator;
	}

	namespace MPC
	{

		class OdeManager;
		class ModelShootingData;
		class MPC;
	}

	namespace NetworkedControl
	{
		class ControlClipboard;
		class ControllerThreadOutput;
		class IOInterface;
		class Cycle;

		/** @class ControllerThreadMPC
		 * @brief Class for simulating the controller in a distributed plant - sensor - controller - actuator setting
		 */
		class ControllerThreadMPC : public yane::Utils::Thread
		{
			public:
				/**
				 * Constructor
				 * @param iface Pointer of the input/output interface of class yane::MPC::IOInterface
				 * @param odemanager Pointer of the differential equation manager of class yane::MPC::OdeManager
				 * @param minimizer Pointer of the minimization routine of class yane::MinProg::NLP
				 * @param horizon Length of the horizon
				 * @param prediction Number of preceding prediction steps
				 * @param model Pointer of the class yane::Model::Model object used for optimization
				 * @param shootingdata Pointer of the yane::Model::ModelShootingData object used for optimization
				 * @param dm Pointer of the debugmanager of class yane::Utils::DebugMaster
				 * @param sm Pointer of the statistics manager of class yane::Utils::StatisticsMaster
				 * @brief Constructor
				 */
				ControllerThreadMPC ( IOInterface * iface, yane::MPC::OdeManager * odemanager,
				        yane::MinProg::NLP * minimizer, int horizon, int prediction, yane::Model::Model * model,
				        yane::MPC::ModelShootingData * shootingdata, yane::Utils::DebugMaster* dm,
				        yane::Utils::StatisticsMaster * sm );

				/**
				 * @brief Destructor
				 */
				virtual ~ControllerThreadMPC ( );

				/**
				 * Function to set the internal state vector of the MPC controller
				 * @param t Time instant of the state vector to be set
				 * @param state State vector
				 * @brief Function to set the internal state vector of the MPC controller
				 */
				void setNewState ( double t, double * state );

				/**
				 * Function to set the actuator error variables \f$ \sigma_{\mbox{err}}, \sigma_{\mbox{cor}} \f$ upon receiving an actuator error
				 * @param lastnoerrorcycle Value of \f$ \sigma_{\mbox{cor}} \f$
				 * @param currentcycle Value of \f$ \sigma_{\mbox{err}} \f$
				 * @brief Function to set the actuator error variables \f$ \sigma_{\mbox{err}}, \sigma_{\mbox{cor}} \f$
				 */
				void setActuatorErrorVariables ( int lastnonerrorcycle, int currentcycle );

				/**
				 * Function to set the output thread
				 * @param thread Output thread
				 * @brief Function to set the output thread
				 */
				void setOutputThread ( ControllerThreadOutput * thread );

				/**
				 * @brief Function to return the pointer of the control clipboard object of class yane::NetworkedControl::ControlClipboard
				 */
				ControlClipboard * controlClipboard ( );

				/**
				 * @brief Function to return the pointer of the cycle object of class yane::NetworkedControl::Cycle
				 */
				Cycle * controllerCycle ( );

			protected:
				/**
				 * @brief Function to start the MPC computation thread
				 */
				virtual void run ( );

				/**
				 * Function to compute/predict the state vector measured by sensors to the next sampling instant
				 * @param peededx Computed initial value
				 * @param to_seq Sampling instant the initial value is computed for
				 * @brief Function to compute/predict the state vector to the next sampling instant
				 */
				void predictSensorValues ( double * peekedx, int to_seq );

				/**
				 * Function to compute/predict the state vector to the sampling instant used by the MPC controller
				 * @param peededx Computed initial value
				 * @param from_seq Initial sampling instant
				 * @param to_seq Sampling instant the initial value is computed for
				 * @brief Function to compute/predict the state vector to the sampling instant used by the MPC controller
				 */
				void predictInternalState ( double * state, int from_seq, int to_seq );

				/**
				 * Function to predict the state vector using the internally buffered control sequences
				 * @param state State vector
				 * @param from_seq Initial sampling instant
				 * @param to_seq Terminal sampling instant
				 * @param timesteps Time grid
				 * @brief Function to predict the state vector using the internally buffered control sequences
				 */
				void computePrediction ( double * state, int from_seq, int to_seq, double * timesteps );

				yane::MPC::MPC * _mpc; /**< @brief Pointer of the used controller of class yane::MPC::MPC */
				yane::MPC::OdeManager * _odemanager; /**< @brief Pointer of the used odemanager of class yane::MPC::OdeManager */
				yane::MinProg::NLP * _minimizer; /**< @brief Pointer of the used minimizer of class yane::MinProgl::NLP */
				yane::Model::Model * _model; /**< @brief Pointer of the used model of class yane::Model::Model */
				yane::Model::Simulator * _simulator; /**< @brief Pointer of the used simulator of class yane::Model::Simulator */
				yane::MPC::ModelShootingData * _shootingdata; /**< @brief Pointer of the used shooting data of class yane::MPC::ModelShootingData */
				ControllerThreadOutput * _outputthread; /**< @brief Pointer of the used output thread of class yane::NetworkedControl::ControllerThreadOutput */
				ControlClipboard * _cb; /**< @brief Pointer of the used control clipboard of class yane::NetworkedControl::ControlClipboard */
				IOInterface * _interface; /**< @brief Pointer of the used network interface of class yane::NetworkedControl::IOInterface */
				Cycle * _controllercycle; /**< @brief Pointer of the used cycle object of class yane::NetworkedControl::Cycle */
				yane::Utils::Semaphore * _mpcstartsem; /**< @brief Pointer of the used semaphore of class yane::Utils::Semaphore */

				yane::Utils::StatisticsClientIntCounter * _stat_computedseq; /**< @brief Statistics collector for computed control sequences*/
				yane::Utils::StatisticsClientIntCounter * _stat_invalidateseq; /**< @brief Statistics collector for invalidated control sequences*/
				yane::Utils::StatisticsClientIntCounter * _stat_skipseq; /**< @brief Statistics collector for skipped computations*/
				yane::Utils::StatisticsClientAverage * _stat_calcduration; /**< @brief Statistics collector for average computing time*/
				yane::Utils::StatisticsClientIntCounter * _stat_discardseq_locked; /**< @brief Statistics collector for discarded sequences due to lock*/
				yane::Utils::StatisticsClientIntCounter * _stat_inputfuture; /**< @brief Statistics collector for received future input sequences*/
				yane::Utils::StatisticsClientIntCounter * _stat_discardseq_timeout; /**< @brief Statistics collector for discarded sequences due to timeout*/

				bool _stat_collect; /**< @brief Decision variable whether staticstical data shall be collected */
				bool _inputxchanged; /**< @brief Decision variable whether the internal state vector has been updated */
				bool _error_received; /**< @brief Decision variable whether an error has been received */

				int _horizon; /**< @brief Length of the optimization horizon */
				int _prediction; /**< @brief Length of the ahead prediction */
				int _seq; /**< @brief Current sampling instant used for the MPC calculation */
				int _sigma_err; /**< @brief Value of \f$ \sigma_{\mbox{err}} \f$, the sampling instant of the latest error within the scheme */
				int _sigma_cor; /**< @brief Value of \f$ \sigma_{\mbox{cor}} \f$, the sampling instant of the last correct control sequence */
				int _last_seq; /**< @brief Sampling instant of the latest MPC calculation */

				double _samplingTime; /**< @brief Sampling time */
				double _inputxtime; /**< @brief Time of the last sensor measurement */

				double * _u; /**< @brief Pointer of the control sequence */
				double * _t; /**< @brief Pointer of the time grid */
				double * _x; /**< @brief Pointer of the state vector */
				double * _inputx; /**< @brief Pointer of the internal state vector */

		};

	}

}

#endif
