/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

//TODO Doku
#ifndef YANE_NETWORKEDCONTROL_CONTROLLER_MPC_H
#define YANE_NETWORKEDCONTROL_CONTROLLER_MPC_H

#include "controller.h"

#include <vector>

namespace yane
{

	namespace Model
	{
		class Model;
		class Simulator;
	}

	namespace MinProg
	{
		class NLP;
	}

	namespace Utils
	{
		class DebugMaster;
		class DebugClient;
		class StatisticsMaster;
		class StatisticsClientIntCounter;
		class StatisticsClientAverage;
		class RTClock;
		class Thread;
	}

	namespace MPC
	{
		class ModelShootingData;
		class OdeManager;
		class MPC;
	}

	namespace NetworkedControl
	{
		class Actuator;
		class IOInterfaceLocal;
		class ControlClipboard;
		class ModelHandlerLocal;

		/** @class MPCController
		 * @brief Class for simulating the controller in a distributed plant - sensor - controller - actuator setting with simulated network connection
		 */
		class MPCController : public yane::NetworkedControl::Controller
		{
			public:
				/**
				 * Constructor
				 * @param model_controller Pointer of the class yane::Model::Model object used for optimization
				 * @param shootingdata Pointer of the yane::Model::ModelShootingData object used for optimization
				 * @param horizon Length of the horizon
				 * @param prediction Number of preceding prediction steps
				 * @param minimizer Pointer of the minimization routine of class yane::MinProg::NLP
				 * @param odemanager Pointer of the differential equation manager of class yane::MPC::OdeManager
				 * @param iface Pointer of the input/output interface of class yane::MPC::IOInterface
				 * @param debugmaster Pointer of the debugmanager of class yane::Utils::DebugMaster
				 * @param statisticsmaster Pointer of the statistics manager of class yane::Utils::StatisticsMaster
				 * @brief Constructor
				 */
				MPCController ( yane::Model::Model * model_controller, yane::MPC::ModelShootingData * shootingdata,
				        int horizon, int prediction, yane::MinProg::NLP * minimizer,
				        yane::MPC::OdeManager * odemanager, IOInterfaceLocal * iface,
				        yane::Utils::DebugMaster * debugmaster = 0, yane::Utils::StatisticsMaster * statisticsmaster =
				                0, yane::NetworkedControl::T_DISTANCEFUNC distancefunction = 0,
				        double statedistanceTolerance = 0.0 );

				/**
				 * @brief Destructor
				 */
				~MPCController ( );

				/**
				 * @brief Function to start the controller
				 */
				virtual void start ( );

				/**
				 * @brief Function to initialize the controller
				 */
				void initialize ( );

				/**
				 * Function to execute the computation of a control sequence
				 * @param seq Number of the sampling instant for which the control sequence is computed
				 * @brief Function to execute the computation of a control sequence
				 */
				void calc ( int seq );

				/**
				 * Function to execute the implementation of a computed control sequence on the process connected via the simulated network connection
				 * @param seq Number of the sampling instant for which the control sequence is to be applied
				 * @brief Function to execute the implementation of a computed control sequence on the process connected via the simulated network connection
				 */
				void implementControl ( int seq );

				/**
				 * Function to set the maximal number of MPC iterations to be computed
				 * @param seqmax Maximal number of MPC iterations to be computed
				 * @brief Function to set the maximal number of MPC iterations to be computed
				 */
				void setMaxIter ( int seqmax );

				/**
				 * Function to set the maximal number of allowed open loop iterations
				 * @param maximalOpenLoopIterations Maximal number of allowed open loop iterations
				 * @brief Function to set the maximal number of allowed open loop iterations
				 */
				void setMaximalOpenLoopIterations ( int maximalOpenLoopIterations );

				/**
				 * Function to set the decision variable to save the computed MPC data
				 * @param saveMPCCallData Decision variable to save the computed MPC data
				 * @brief Function to set the decision variable to save the computed MPC data
				 */
				void setSaveMPCCallData ( bool saveMPCCallData );

				/**
				 * Function to return the number of executed MPC calculations. This function requires _saveMPCCallData to be set to true.
				 * @brief Function to return the number of execute MPC calculations
				 */
				int mpcCallCounter ( );

				/**
				 * Function to return the time instances upon which an MPC computation was executed. This function requires _saveMPCCallData to be set to true.
				 * @brief Function to return the time instances upon which an MPC computation was executed
				 */
				std::vector < double > mpcCallTimes ( );

				/**
				 * Function to return the state vectore used as initial values for each MPC computation executed. This function requires _saveMPCCallData to be set to true.
				 * @brief Function to return the state vectore used as initial values for each MPC computation executed
				 */
				std::vector < std::vector < double > > mpcCallStates ( );

			protected:
				/**
				 * @brief Function to initialize the input connected components of the networked MPC controller scheme
				 */
				void initializeMPCControllerInput ( );

				/**
				 * @brief Function to initialize the computing connected components of the networked MPC controller scheme
				 */
				void initializeMPCController ( );

				/**
				 * @brief Function to initialize the output connected components of the networked MPC controller scheme
				 */
				void initializeMPCControllerOutput ( );

				/**
				 * @brief Funtion to initialize the implementation connected components of the networked MPC controller scheme
				 */
				void initializeModelHandler ( );

				/**
				 * Function to handle sensor input data and provide it to be used by the MPC controller
				 * @param seq Current samling instant
				 * @param debugmaster Pointer of the debug master of class yane::Utils::DebugMaster
				 * @param debugclient Pointer of the debug client of class yane::Utils::DebugClient
				 * @param statisticsmaster Pointer of the statistics master of class yane::Utils::StatisticsMaster
				 * @brief Function to handle sensor input data and provide it to be used by the MPC controller
				 */
				void sensorInputToController ( int seq, yane::Utils::DebugMaster * debugmaster,
				        yane::Utils::DebugClient * debugclient, yane::Utils::StatisticsMaster * statisticsmaster );

				/**
				 * Function to handle the output data of the MPC controller and provide it to be used by the actuator
				 * @param seq Current samling instant
				 * @param debugmaster Pointer of the debug master of class yane::Utils::DebugMaster
				 * @param debugclient Pointer of the debug client of class yane::Utils::DebugClient
				 * @param statisticsmaster Pointer of the statistics master of class yane::Utils::StatisticsMaster
				 * @brief Function to handle the output data of the MPC controller and provide it to be used by the actuator
				 */
				void controllerOutputToActuator ( int seq, yane::Utils::DebugMaster * debugmaster,
				        yane::Utils::DebugClient * debugclient, yane::Utils::StatisticsMaster * statisticsmaster );

				/**
				 * Function to handle actuator input data and provide it to be used by the MPC controller
				 * @param seq Current samling instant
				 * @param debugmaster Pointer of the debug master of class yane::Utils::DebugMaster
				 * @param debugclient Pointer of the debug client of class yane::Utils::DebugClient
				 * @param statisticsmaster Pointer of the statistics master of class yane::Utils::StatisticsMaster
				 * @brief Function to handle actuator input data and provide it to be used by the MPC controller
				 */
				void actuatorInputToController ( yane::Utils::DebugMaster * debugmaster,
				        yane::Utils::DebugClient * debugclient, yane::Utils::StatisticsMaster * statisticsmaster );

				/**
				 * Function to compute/predict the state vector measured by sensors to the next sampling instant
				 * @param peededx Computed initial value
				 * @param to_seq Sampling instant the initial value is computed for
				 * @brief Function to compute/predict the state vector to the next sampling instant
				 */
				void predictSensorValues ( double * peekedx, int to_seq );

				/**
				 * Function to compute/predict the state vector to the sampling instant used by the MPC controller
				 * @param peededx Computed initial value
				 * @param to_seq Sampling instant the initial value is computed for
				 * @brief Function to compute/predict the state vector to the sampling instant used by the MPC controller
				 */
				void predictInternalState ( double * state, int from_seq, int to_seq );

				/**
				 * Function to predict the state vector using the internally buffered control sequences
				 * @param state State vector
				 * @param from_seq Initial sampling instant
				 * @param to_seq Terminal sampling instant
				 * @param timesteps Time grid
				 * @brief Function to predict the state vector using the internally buffered control sequences
				 */
				void computePrediction ( double * state, int from_seq, int to_seq, double * timesteps );

				/**
				 * Function to set the internal state vector of the MPC controller
				 * @param t Time instant of the state vector to be set
				 * @param state State vector
				 * @brief Function to set the internal state vector of the MPC controller
				 */
				void setNewState ( double t, double * state );

				/**
				 * Function to set the actuator error variables \f$ \sigma_{\mbox{err}}, \sigma_{\mbox{cor}} \f$ upon receiving an actuator error
				 * @param lastnoerrorcycle Value of \f$ \sigma_{\mbox{cor}} \f$
				 * @param currentcycle Value of \f$ \sigma_{\mbox{err}} \f$
				 * @brief Function to set the actuator error variables \f$ \sigma_{\mbox{err}}, \sigma_{\mbox{cor}} \f$
				 */
				void setActuatorErrorVariables ( int lastnonerrorcycle, int currentcycle );

				/**
				 * Function to set the output packet of the MPC controller
				 * @param preseq Value of \f$ \sigma_{\mbox{pre}} \f$, the sampling instant of the last correct control sequence upon which the sent control sequence was computed
				 * @param seq Value of \f$ \sigma \f$, the initial sampling instant for which the control was computed
				 * @param u Control sequence
				 * @brief Function to set the output packet of the MPC controller
				 */
				void setControllerOutputPacket ( int preseq, int seq, int horizon, double * u );

				yane::MPC::MPC * _mpc; /**< @brief Pointer of the used controller of class yane::MPC::MPC */
				yane::MPC::OdeManager * _odemanager; /**< @brief Pointer of the used odemanager of class yane::MPC::OdeManager */
				yane::MinProg::NLP * _minimizer; /**< @brief Pointer of the used minimizer of class yane::MinProgl::NLP */
				yane::Model::Simulator * _simulator_controller; /**< @brief Pointer of the used simulator of class yane::Model::Simulator */
				yane::NetworkedControl::IOInterfaceLocal * _interface; /**< @brief Pointer of the used network interface of class yane::NetworkedControl::IOInterfaceLocal */
				yane::MPC::ModelShootingData * _shootingdata; /**< @brief Pointer of the used shooting data of class yane::MPC::ModelShootingData */
				yane::NetworkedControl::ControlClipboard * _cb; /**< @brief Pointer of the used control clipboard of class yane::NetworkedControl::ControlClipboard */

				yane::Utils::StatisticsClientIntCounter * _stat_sensorinput_sent; /**< @brief Statistics collector for received sensor input sequences*/
				yane::Utils::StatisticsClientIntCounter * _stat_mpc_computedseq; /**< @brief Statistics collector for computed control sequences*/
				yane::Utils::StatisticsClientIntCounter * _stat_mpc_invalidateseq; /**< @brief Statistics collector for invalidated control sequences*/
				yane::Utils::StatisticsClientIntCounter * _stat_mpc_skipseq; /**< @brief Statistics collector for skipped control sequences*/
				yane::Utils::StatisticsClientIntCounter * _stat_mpc_alreadycomputed; /**< @brief Statistics collector for already computed control sequences*/
				yane::Utils::StatisticsClientAverage * _stat_mpc_calcduration; /**< @brief Statistics collector for average computing time*/
				yane::Utils::StatisticsClientIntCounter * _stat_mpcoutput_sent; /**< @brief Statistics collector for sent control sequences*/
				yane::Utils::StatisticsClientIntCounter * _stat_actuator_received; /**< @brief Statistics collector for received actuator sequences*/
				yane::Utils::DebugClient * _debugclient; /**< @brief Pointer of the debug client of class yane::Utils::DebugClient */
				yane::Utils::RTClock * _timer; /** @brief Pointer of the timer of class yane::Utils::RTClock */
				yane::NetworkedControl::T_INPUTPACKET _sensorpacket; /** @brief Sensor input packet */
				yane::NetworkedControl::T_OUTPUTPACKET _controllerpacket; /** @brief Controller packet */
				yane::NetworkedControl::T_ACTORPACKET _actuatorpacket; /** @brief Acutator packet */
				yane::NetworkedControl::T_DISTANCEFUNC _distancefunction; /** @brief Distance function */

				bool _error_received; /**< @brief Decision variable whether an error has been received */
				bool _has_actorpacket; /**< @brief Decision variable whether an actuator packet has been received */
				bool _inputxchanged; /**< @brief Decision variable whether the internal state vector has been updated */
				bool _skipMPC; /**< @brief Decision variable whether an MPC step is skipped */
				bool _saveMPCCallData; /**< @brief Decision variable to save the computed MPC data */

				int _preseq; /**< @brief Value of \f$ \sigma_{\mbox{pre}} \f$, the sampling instant of the last correct control sequence upon which the sent control sequence was computed */
				int _last_seq; /**< @brief Sampling instant of the latest MPC calculation */
				int _last_sensor_seq; /**< @brief Sampling instant following the time of the latest sensor measurement */
				int _seqmax; /**< @brief Maximal number of MPC iterations to be computed */
				int _sigma_err; /**< @brief Value of \f$ \sigma_{\mbox{err}} \f$, the sampling instant of the latest error within the scheme */
				int _sigma_cor; /**< @brief Value of \f$ \sigma_{\mbox{cor}} \f$, the sampling instant of the last correct control sequence */
				int _controllerpacket_horizon; /**< @brief Length of the control sequence to be sent */
				int _maximalOpenLoopIterations; /**< @brief Maximal number of allowed open loop iterations */

				double _samplingTime; /**< @brief Sampling time */
				double _inputxtime; /**< @brief Time of the last sensor measurement */
				double _stateDistanceTolerance; /**< @brief Maximal tolerance of the state deviation to skip the MPC control computation */

				double * _u; /**< @brief Pointer of the control sequence */
				double * _t; /**< @brief Pointer of the time grid */
				double * _x; /**< @brief Pointer of the state vector */
				double * _sensorvalues; /**< @brief Pointer of the sensor state vector */
				double * _controllerpacket_data; /**< @brief Pointer of the output packet to be sent from the controller to the actuator */
				double * _inputx; /**< @brief Pointer of the internal state vector */
				double * _trajectory; /**< @brief Pointer of the state trajectory */

				std::vector < double > _mpcCallTimes; /**< @brief Array of the sampling times upon which the MPC routine was executed */
				std::vector < std::vector < double > > _mpcCallStates; /**< @brief Array of the initial state connected to the sampling times upon which the MPC routine was executed */
		};
	}
}

#endif
