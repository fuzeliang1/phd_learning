/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "controlclipboard.h"

#include "../utils.h"

#include <cstring>
#include <sstream>
#include <iostream>

using namespace std;

yane::NetworkedControl::ControlClipboard::ControlClipboard ( int dimension_par, int horizont_par )
{
	if ( horizont_par < 1 )
	{
		stringstream out;
		out << "'horizont' parameter must be greater than zero, got ";
		out << horizont_par;
		throw yane::Utils::ValueException ( __DEBUGMESS ( out.str() ) );
	}

	if ( dimension_par < 1 )
	{
		stringstream out;
		out << "'dimension' parameter must be greater than zero, got ";
		out << dimension_par;
		throw yane::Utils::ValueException ( __DEBUGMESS ( out.str() ) );
	}

	_horizont = horizont_par;
	_dimension =  dimension_par;

	_container = new T_MAPTYPE;

	_mutex = new yane::Utils::Mutex();
	
	//TODO Speichersequenzen wieder freigeben!
	//TODO Variabler Horizont
}

yane::NetworkedControl::ControlClipboard::~ ControlClipboard()
{
	for ( T_ITTYPE it = _container->begin(); it != _container->end(); ++it )
	{
		delete it->second.control;
	}
	delete _container;
	delete _mutex;
}

void yane::NetworkedControl::ControlClipboard::addData ( int cycle, int precycle, double calcduration, double * u )
{
	T_ENTRY newentry;
	newentry.control = 0;

	T_ITTYPE it = _container->insert ( _container->end(), make_pair ( cycle, newentry ) );

	it->second.precycle = precycle;
	it->second.calcduration = calcduration;

	if ( it->second.control != 0 ) delete it->second.control;
	it->second.control = new double[_dimension*_horizont];
	memcpy ( it->second.control,  u, sizeof ( double ) *_dimension*_horizont );

}

void yane::NetworkedControl::ControlClipboard::appendData ( int cycle, double calcduration, double * u, int & preseq )
{
	if ( _container->size() == 0 )
	{
		T_ENTRY newentry;
		preseq = newentry.precycle = -1;
		newentry.control = new double[_dimension*_horizont];
		newentry.calcduration = calcduration;
		memcpy ( newentry.control,  u, sizeof ( double ) *_dimension*_horizont );

		_container->insert ( _container->end(), make_pair ( cycle, newentry ) );
	}
	else
	{
		T_ITTYPE it = _container->end();
		--it;
		if ( it->first >= cycle )
		{
			stringstream out;
			out << "appending cycle must be the greatest one! Got ";
			out << cycle << " must be > " << it->first;
			throw yane::Utils::ValueException ( __DEBUGMESS ( out.str() ) );
		}

		T_ENTRY newentry;
		preseq = newentry.precycle = it->first;
		newentry.control = new double[_dimension*_horizont];
		newentry.calcduration = calcduration;
		memcpy ( newentry.control,  u, sizeof ( double ) *_dimension*_horizont );

		_container->insert ( _container->end(), make_pair ( cycle, newentry ) );

	}
}


int yane::NetworkedControl::ControlClipboard::cleanup ( int cycle, int currentcycle )
{
	if ( _container->size() == 0 ) return -1;
	if ( _container->begin()->first >= currentcycle ) return -1;
	if ( cycle > currentcycle ) cycle = currentcycle;

	T_ITTYPE it = _container->lower_bound ( cycle );

	if ( it == _container->begin() ) return -1;
	if ( it == _container->end() ) return -1;

	if ( ++it == _container->end() ) return -1;

	while ( it->first >= currentcycle ) --it;

	_container->erase ( _container->begin(), it );

	return it->first;
}

bool yane::NetworkedControl::ControlClipboard::hasCycle ( int cycle ) const
{
	return _container->find ( cycle ) != _container->end();
}


bool yane::NetworkedControl::ControlClipboard::getValidatedData ( int cycle, int & precycle, bool & error, double & calcduration, double * u ) const
{
	T_ITTYPE it = _container->find ( cycle );

	if ( it == _container->end() )
	{
		precycle = -1;
		error = true;
		calcduration = 0.0;
		return false;
	}

	calcduration = it->second.calcduration;
	int pre = it->second.precycle;

	if ( it == _container->begin() )
	{
		precycle = -1;
		error = false;
	}
	else
	{
		--it;
		precycle = it->first;
		error = ( it->first != pre );
		++it;
	}

	if ( !error ) memcpy ( u, it->second.control, sizeof ( double ) *_horizont*_dimension );

	return true;
}


bool yane::NetworkedControl::ControlClipboard::getConsistencyInfo ( int cycle, int & parentcycle, int & nextcycle, int & nextprecycle ) const
{
	if ( _container->size() == 0 )
	{
		nextcycle = -1;
		nextprecycle = -1;
		parentcycle = -1;
		return false;
	}

	T_ITTYPE it = _container->upper_bound ( cycle );

	if ( it == _container->end() )
	{
		nextcycle = -1;
		nextprecycle = -1;
	}
	else
	{
		nextprecycle = it->second.precycle;
		nextcycle = it->first;
	}

	if ( it == _container->begin() )
	{
		parentcycle = -1;
	}
	else
	{
		--it;
		parentcycle = it->first;
	}

	return ( parentcycle == nextprecycle ) || ( nextcycle == -1 && parentcycle == -1);
}

void yane::NetworkedControl::ControlClipboard::getScheme ( T_SCHEMEENTRY * scheme ) const
{
	T_ITTYPE it = _container->begin();

	if ( it == _container->end() ) return;

	int index = 0;
	int indexshift = it->first;
	int lastcycle = it->first;

	scheme[index].info = DATA;
	scheme[index].calcduration = it->second.calcduration;
	++it;
	++index;

	for ( ;it != _container->end(); ++it )
	{

		while ( index + indexshift < it->first && index + indexshift < lastcycle + _horizont )
		{
			scheme[index].info = ( it->second.precycle == lastcycle ? CONSISTENT : INCONSISTENT );
			scheme[index].calcduration = 0.0;
			index++;
		}

		while ( index + indexshift < it->first )
		{
			scheme[index].info = NODATA;
			scheme[index].calcduration = 0.0;
			index++;
		}

		scheme[index].info = DATA;
		scheme[index].calcduration = it->second.calcduration;

		++index;
		lastcycle = it->first;
	}

	for ( int i = 0; i < _horizont - 1; ++i, ++index )
	{
		scheme[index].info = CONSISTENT;
		scheme[index].calcduration = 0.0;
	}

}

double * yane::NetworkedControl::ControlClipboard::operator [ ] ( const int cycle )
{
	T_ITTYPE it = _container->upper_bound ( cycle );

	if ( it == _container->begin() ) return 0;
	--it;
	if ( it->first + _horizont <= cycle ) return 0;

	return & ( it->second.control[ ( cycle- ( it->first ) ) *_dimension] );

	return 0;
}

void yane::NetworkedControl::ControlClipboard::invalidateCycle ( int cycle )
{
	if ( _container->size() == 0 ) return;
	if ( _container->begin()->first >= cycle )
	{
		_container->clear();
		return;
	}

	T_ITTYPE it = _container->upper_bound ( cycle - 1 );
	if ( it == _container->end() )
	{
		return;
	}
	if ( it == _container->begin() )
	{
		_container->clear();
		return;
	}

	_container->erase ( it, _container->end() );
}


void yane::NetworkedControl::ControlClipboard::lock()
{
	_mutex->lock();
}

void yane::NetworkedControl::ControlClipboard::unlock()
{
	_mutex->unlock();
}

int yane::NetworkedControl::ControlClipboard::lastCycle() const
{
	if ( _container->size() == 0 ) return -1;
	T_ITTYPE it = _container->end();
	return ( --it )->first;
}

int yane::NetworkedControl::ControlClipboard::firstCycle() const
{
	if ( _container->size() == 0 ) return -1;
	return _container->begin()->first;
}

int yane::NetworkedControl::ControlClipboard::horizont() const
{
	return _horizont;
}

int yane::NetworkedControl::ControlClipboard::size() const
{
	return _container->size();
}




