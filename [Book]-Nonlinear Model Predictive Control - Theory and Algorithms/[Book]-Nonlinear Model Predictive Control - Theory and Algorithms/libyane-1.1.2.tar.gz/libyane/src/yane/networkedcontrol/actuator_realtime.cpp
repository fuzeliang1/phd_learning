/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "actuator_realtime.h"
#include "iointerface.h"
#include "cycle.h"
#include "controlclipboard.h"

#include "../utils.h"
#include "../model.h"

#include <string>
#include <sstream>
#include <cstring>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::NetworkedControl::RealtimeActuator::RealtimeActuator ( yane::Model::Model * model, Cycle * cycle,
        int horizon, T_RESPONSEFUNC func, void * ptr, yane::Utils::DebugMaster * dm, yane::Utils::StatisticsMaster * sm ) :
	yane::NetworkedControl::Actuator ( model, horizon, func, ptr, dm, sm )
{
	_cycle = cycle;
}

LIB_EXPORT yane::NetworkedControl::RealtimeActuator::~RealtimeActuator ( )
{
}

LIB_EXPORT void yane::NetworkedControl::RealtimeActuator::enterPacket ( void * packet, double * data )
{
	T_OUTPUTPACKET * pack = ( T_OUTPUTPACKET * ) packet;
	double * control = data;
	setSamplingInstant( _cycle->get() );

	//TODO Threadabsicherung?
	if ( pack->code == IOInterface::OUTPUTCODE )
	{
		if ( _debugclient )
		{
			stringstream out;
			out << "packet received (seq=" << pack->seq << ", preseq=" << pack->preseq << ")";
			_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
		}

		_cb->lock ( );

		if ( pack->seq <= _seq )
		{
			if ( _debugclient )
			{
				_debugclient->sendDebugMessage ( "packet is too old: do not store.", DEBUG_ALGORITHM );
			}
			if ( _stat_collect )
			{
				_stat_outdatedseq->addValue ( 1 );
			}
		}
		else if ( _cb->hasCycle ( pack->seq ) )
		{
			if ( _debugclient )
			{
				_debugclient->sendDebugMessageInt ( "control sequence already exist: do not store.", "existinc seq",
				        1, & pack->seq, DEBUG_ALGORITHM );
			}
			if ( _stat_collect )
			{
				_stat_duplicateseq->addValue ( 1 );
			}
		}
		else
		{
			if ( _debugclient )
			{
				_debugclient->sendDebugMessageDouble ( "adding control", "control", _horizon * _dimu, control,
				        DEBUG_ALGDETAILS );
			}
			_cb->addData ( pack->seq, pack->preseq, 0.0, control );
			if ( _stat_collect )
			{
				_stat_recvseq->addValue ( 1 );
			}
		}

		_cb->unlock ( );
	}
	else
	{
		if ( _debugclient )
		{
			_debugclient->sendDebugMessage ( "weird packetcode!", DEBUG_BASE );
		}
	}
}

LIB_EXPORT void yane::NetworkedControl::RealtimeActuator::getCurrentControl ( double * control )
{
	setSamplingInstant( _cycle->get() );
	int seq = _seq;
	int sequencecursor;

	_cb->lock ( );

	if ( _cb->size ( ) == 0 )
	{
		sequencecursor = _horizon;
		if ( _debugclient )
		{
			_debugclient->sendDebugMessage ( "controlclipboard is empty!", DEBUG_ALGORITHM );
		}
	}
	else
	{
		int preseq;
		bool error;
		double calcduration;
		bool gotdata = _cb->getValidatedData ( seq, preseq, error, calcduration, _u );

		if ( gotdata )
		{
			if ( error )
			{
				if ( _debugclient )
				{
					stringstream out;
					out << "got fresh data, but inconsistent seq=" << seq << ", consistent preseq is " << preseq;
					_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
				}

				proceedError ( seq, preseq );
				sequencecursor = seq - preseq;
				if ( _stat_collect )
				{
					_stat_inconsistentseq->addValue ( 1 );
				}
			}
			else
			{
				_u_seq = seq;
				sequencecursor = 0;
				if ( _stat_collect )
				{
					_stat_appliedseq->addValue ( 1 );
				}
			}
		}
		else
		{
			int parentseq;
			int nextpreseq;
			int nextseq;
			bool isconsistent = _cb->getConsistencyInfo ( seq, parentseq, nextseq, nextpreseq );
			if ( ! isconsistent )
			{
				if ( _debugclient )
				{
					stringstream out;
					if ( nextseq == - 1 )
					{
						out << "seq " << seq
						        << " has no fresh data and future cycles do not exist. A packet has possibly been lost.";
					}
					else
					{
						out << "seq " << seq << " has no fresh data. nearby seqs are not consistent (older seq="
						        << parentseq << ", future seq=" << nextseq << ", future preseq=" << nextpreseq << ")";
					}
					_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
				}
				proceedError ( seq, parentseq );
				if ( _stat_collect )
				{
					if ( seq - parentseq <= _horizon )
					{
						_stat_bridgedseq->addValue ( 1 );
					}
					else
					{
						_stat_missingseq->addValue ( 1 );
					}
				}
			}
			else
			{
				if ( _debugclient )
				{
					stringstream out;
					out << "seq " << seq << " has no fresh data, but nearby seqs are consistent (older seq="
					        << parentseq << ", future seq=" << nextseq << ", future preseq=" << nextpreseq << ")";
					_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
				}
				if ( _stat_collect )
				{
					if ( seq - parentseq <= _horizon )
					{
						_stat_bridgedseq->addValue ( 1 );
					}
					else
					{
						_stat_missingseq->addValue ( 1 );
					}
				}
			}
			sequencecursor = seq - parentseq;
		}
	}

	_cb->cleanup ( seq - _horizon, seq );
	_cb->unlock ( );

	stringstream out;
	if ( sequencecursor < _horizon && _u_seq != - 1 )
	{
		memcpy ( control, & _u [ sequencecursor * _dimu ], sizeof(double) * _dimu );

		if ( _debugclient )
		{
			out << "SETTING CONTROL, u_seq=" << _u_seq << " , u_index=" << sequencecursor;
			_debugclient->sendDebugMessageDouble ( out.str ( ), "control", _dimu, control, DEBUG_ALGORITHM );
		}
	}
	else
	{
		memcpy ( control, _defaultu, sizeof(double) * _dimu );
		sequencecursor = _horizon;
		if ( _debugclient )
		{
			out << "empty buffer, SETTING DEFAULTCONTROL";
			_debugclient->sendDebugMessageDouble ( out.str ( ), "control", _dimu, control, DEBUG_ALGORITHM );
		}
		if ( _stat_collect )
		{
			_stat_bufferunderrun->addValue ( 1 );
		}
	}
}

LIB_EXPORT void yane::NetworkedControl::RealtimeActuator::proceedError ( int seq, int preseq )
{
	if ( _actuatorfunction )
	{
		if ( _debugclient )
		{
			stringstream out;
			out << "Setting errorflag=true (sigma_err=" << seq << ", cycle_err_pre=" << preseq
			        << "), invalidating cycles > " << preseq;
			_debugclient->sendDebugMessage ( out.str ( ), DEBUG_ALGORITHM );
		}

		int previous = _cb->size ( );
		_cb->invalidateCycle ( preseq + 1 );

		T_ACTORPACKET response;
		response.code = IOInterface::ACTORERRORCODE;
		response.seq_err = seq;
		response.preseq_err = preseq;
		_actuatorfunction ( & response, _ptr );
		if ( _stat_collect )
		{
			_stat_senterror->addValue ( 1 );
			_stat_invalidatedseq->addValue ( previous - _cb->size ( ) );
		}
	}
	else
	{
		if ( _debugclient )
		{
			_debugclient->sendDebugMessage ( "actuatorresponse is not active.", DEBUG_ALGORITHM );
		}
	}
}
