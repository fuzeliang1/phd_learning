
/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */


#include "config.h"
#include "libexport.h"
#include <string>
#include <exception>
#include <cstdlib>

using namespace std;

namespace libyane
{
	LIB_EXPORT void versionStringToInt(string versionstr, int & maj, int & min, int & rev)
	{
		if (versionstr.find_first_not_of("1234567890.") != string::npos) throw exception();

		string::size_type idx = versionstr.find_first_of('.');
		if (idx == string::npos)
		{
			maj = atoi(versionstr.c_str());
			min = 0;
			rev = 0;
		} else
		{
			maj = atoi(versionstr.substr(0,idx).c_str());
			versionstr.erase(0, idx+1);

			string::size_type idx2 = versionstr.find_first_of('.');

			if (idx2 == string::npos)
			{
				min = atoi(versionstr.c_str());
				rev = 0;
			} else
			{
				min = atoi(versionstr.substr(0,idx2).c_str());
				versionstr.erase(0, idx2+1);

				rev = atoi(versionstr.c_str());
			}
		}

	}

	LIB_EXPORT void checkVersionCompatibility(const char * chk_ver)
	{
		string versionstr = VERSION;

		int maj;
		int min;
		int rev;

		versionStringToInt(versionstr, maj, min, rev);

		string chk_versionstr(chk_ver);
		int chk_maj;
		int chk_min;
		int chk_rev;

		versionStringToInt(chk_versionstr, chk_maj, chk_min, chk_rev);

		if ( (maj < chk_maj) ||
		     (maj == chk_maj && min < chk_min) ||
		     (maj == chk_maj && min ==  chk_min && rev < chk_rev) ) throw exception();
	}

	LIB_EXPORT string buildTimeStamp()
	{
		return string(__DATE__) + string(" ") + string(__TIME__);
	}

	LIB_EXPORT string version()
	{
		return VERSION;
	}

	LIB_EXPORT string name()
	{
		return PACKAGE;
	}
}
