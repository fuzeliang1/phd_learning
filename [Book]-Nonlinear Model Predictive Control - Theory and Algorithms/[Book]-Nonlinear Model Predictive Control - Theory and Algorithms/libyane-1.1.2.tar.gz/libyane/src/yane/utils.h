/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

/** \namespace yane::Utils
	\brief Namespace of the Utility Library
*/

#ifndef YANE_UTILS_MAIN
#define YANE_UTILS_MAIN

#include "utils/code.h"
#include "utils/crc32.h"
#include "utils/debugclient.h"
#include "utils/debugmaster.h"
#include "utils/debugmasterconsole.h"
#include "utils/debugmasterfile.h"
#include "utils/debugmasterpts.h"
#include "utils/debugmastertextstream.h"
#include "utils/gridio.h"
#include "utils/gridwriter.h"
#include "utils/gridreader.h"
#include "utils/exception.h"
#include "utils/exceptions.h"
#include "utils/fifobuffer.h"
#include "utils/matrixcomputation.h"
#include "utils/mutex.h"
#include "utils/optimaldiff.h"
#include "utils/parallelcomputing.h"
#include "utils/rtclock.h"
#include "utils/savedata.h"
#include "utils/semaphore.h"
#include "utils/thread.h"
#include "utils/uuid.h"
#include "utils/statisticsmaster.h"
#include "utils/statisticsclient.h"
#include "utils/statisticsclientintcounter.h"
#include "utils/statisticsclientaverage.h"
#include "utils/statisticsclientpersecond.h"

#endif
