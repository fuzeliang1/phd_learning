/***************************************************************************
 *                                                                         *
 * Minimization Library                                                    *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

/** \namespace yane::MinProg
	\brief Namespace of the Interface Library for Minimization Routines
*/


#ifndef YANE_MINPROG_MAIN
#define YANE_MINPROG_MAIN

#include "minprog/exceptions.h"
#include "minprog/gaussnewton.h"
#include "minprog/nlp.h"
#include "minprog/typedefs.h"

#endif
