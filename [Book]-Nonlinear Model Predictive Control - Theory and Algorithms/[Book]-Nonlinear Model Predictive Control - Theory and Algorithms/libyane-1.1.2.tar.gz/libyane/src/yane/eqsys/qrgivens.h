/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_QRGIVENS
#define YANE_EQSYS_QRGIVENS

#include "directmethods.h"

namespace yane
{

	namespace EqSys
	{

		/** @class QRgivens
		@brief Class of the QR solver for linear equation systems based on Givens rotations
		 */
		class QRgivens : public DirectMethods
		{
			public:
				/**
				 * @brief Constructor
				 */
				QRgivens ( void );

				/**
				 * @brief Destructor
				 */
				~QRgivens ( void );

				/**
				 * Method to compute the QR decomposition based on Givens rotations
				 * @throw yane::Utils::NotInitializedException is thrown if the linear equation problem is not initialized
				 * @throw yane::Utils::Exception is thrown if matrix is numerically singular
				 * @brief Method to compute the QR decomposition based on Givens rotations
				*/
				void decomposition ( void );

			private:
				bool _singular;			/**< @brief Decision variable if matrix is numerically singular */
		};
	}
}

#endif
