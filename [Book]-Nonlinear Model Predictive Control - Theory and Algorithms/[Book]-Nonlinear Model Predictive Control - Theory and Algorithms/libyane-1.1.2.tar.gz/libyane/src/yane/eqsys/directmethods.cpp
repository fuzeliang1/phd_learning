/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "directmethods.h"

#include "../utils.h"

#include "libexport.h"

LIB_EXPORT yane::EqSys::DirectMethods::DirectMethods()
{
}

LIB_EXPORT yane::EqSys::DirectMethods::~ DirectMethods()
{
}

LIB_EXPORT void yane::EqSys::DirectMethods::backwardSolution ( double * x )
{
	if ( _largescale )
	{
		for ( int i = _dimensionColumns - 1; i >= 0; i-- )
		{
			x[i] = _b[i];
			for ( int j = _dimensionColumns - 1; j > i; j-- )
			{
				x[i] -= _A_largescale[i][j] * x[j];
			}
			x[i] /= _A_largescale[i][i];
		}
	}
	else
	{
		int dimC = _dimensionColumns;
		for ( int i = dimC - 1; i >= 0; i-- )
		{
			x[i] = _b[i];
			for ( int j = _dimensionRows - 1; j > i; j-- )
			{
				x[i] -= _A[i * dimC + j] * x[j];
			}
			x[i] /= _A[i * dimC + i];
		}
	}
}

LIB_EXPORT void yane::EqSys::DirectMethods::solve ( double * x )
{
	if ( !_initialized )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "Problem not initialized" ) );
	}
	try
	{
		decomposition();
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Calculation error" ), __DEBUGMESS ( "Linear equation system cannot be solved" ), &e );
	}
	backwardSolution( x );
}
