/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>             *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 	@author Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>
 */

#ifndef YANE_EQSYS_CHOLESKY_H
#define YANE_EQSYS_CHOLESKY_H

#include "directmethods.h"

namespace yane
{
	namespace EqSys
	{
		extern "C"
		{
			void btchlg_ ( int * n, double * A, double * G, double * b, double * x, double * wa, int * fail );
			void btcsky_ ( int * n, double * A, double * G, int * fail );
			void btcslv_ ( int * n, double * A, double * b, double * x, double * wa );
		}

		/**< @class Cholesky
		@brief Class of the Cholesky method for solving symmetric and positive definit linear equation problems
		 */
		class Cholesky : public DirectMethods
		{
			public:
				/**
				 * @brief Constructor
				 */
				Cholesky ();

				/**
				 * @brief Destructor
				 */
				~Cholesky ();

				/**
				 * Method to solve the linear equation problem
				 * @param x Solution vector of the problem
				 * @throw yane::Utils::NotInitializedException is thrown if the linear equation problem has not been initialized
				 * @brief Method to solve the linear equation problem
				 */
				void solve ( double * x );

				/**
				 * Method to compute the Cholesky decomposition
				 * @throw yane::Utils::NotInitializedException is thrown if the linear equation problem has not been initialized
				 * @brief Method to compute the Cholesky decomposition
				 */
				void decomposition ( void );

				/**
				 * Method to set the symmetry checking decision variable
				 * @param checkmatrix Decision variable if check for symmetry shall be executed
				 * @brief Method to set the symmetry checking decision variable
				 */
				void setCheckmatrix ( bool checkmatrix );

			private:
				/**
				 * @brief Method to allocate the auxilliary arrays
				 */
				void checkWorkingArrays ( void );

				/**
				 * @brief Method to check the system matrix for symmetry
				 * @return True is system matrix is symmetric, false if system matrix is not symmetric
				 */
				bool checkMatrix ( void );

				/**
				 * @brief Method to check the largescale system matrix for symmetry
				 * @return True is system matrix is symmetric, false if system matrix is not symmetric
				 */
				bool checkMatrixLargescale ( void );

				int _fail;		/**< Failure flag of the Cholesky decomposition */
				double * _wa;		/**< Working array */
				double * _G;		/**< Array containing the Cholesky decomposition */
				bool _checkmatrix;	/**< Decision variable if check for symmetry shall be executed */
				double * _Ahelp;	/**< Auxilliary array to use matrix in F77 routines */
		};
	}
}

#endif
