/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "gaussseidel.h"

#include "../utils.h"

#include "libexport.h"

LIB_EXPORT yane::EqSys::GaussSeidel::GaussSeidel ( void ) : IterativeMethods ()
{
}

LIB_EXPORT yane::EqSys::GaussSeidel::~GaussSeidel ( void )
{
}

LIB_EXPORT void yane::EqSys::GaussSeidel::solve ( double * x )
{
	double norm_value, sum;

	if ( !_initialized )
	{
		throw yane::Utils::NotInitializedException( __DEBUGMESS ("Problem not initialized" ) );
	}

	if ( _dimensionRows != _dimensionColumns )
	{
		throw yane::Utils::IndexException( __DEBUGMESS ( "Row and column dimension of the matrix A do not match" ) );
	}

	if ( _largescale )
	{
		for ( int i = 0; i < _dimensionColumns; i++ )
		{
			x[i] = 0.;
			if ( fabs ( _A_largescale[i][i] ) < _epsilon )
			{
				throw yane::Utils::ValueException( __DEBUGMESS ( "Matrix not numerically invertable" ) );
			}
		}

		_iterationCounter = 0;
		do
		{
			for ( int i = 0; i < _dimensionRows; i++ )
			{
				sum = - _A_largescale[i][i] * x[i];

				for ( int j = 0; j < _dimensionColumns; j++ )
				{
					sum += _A_largescale[i][j] * x[j];
				}

				x[i] = ( _b[i] - sum ) / _A_largescale[i][i];
			}

			norm_value = normInfinityError( x );
			if ( norm_value > _bigbound )
			{
				throw yane::Utils::ValueException ( __DEBUGMESS ( "Iteration diverges" ) );
			}
			_iterationCounter++;
		}
		while ( norm_value > _epsilon && _iterationCounter < _maxIter );
	}
	else
	{
		int dimC = _dimensionColumns;
		for ( int i = 0; i < dimC; i++ )
		{
			x[i] = 0.;
			if ( fabs ( _A[i * dimC + i] ) < _epsilon )
			{
				throw yane::Utils::ValueException( __DEBUGMESS ( "Matrix not numerically invertable" ) );
			}
		}

		_iterationCounter = 0;
		do
		{
			for ( int i = 0; i < _dimensionRows; i++ )
			{
				sum = - _A[i * dimC + i] * x[i];

				for ( int j = 0; j < dimC; j++ )
				{
					sum += _A[i * dimC + j] * x[j];
				}

				x[i] = ( _b[i] - sum ) / _A[i * dimC + i];
			}

			norm_value = normInfinityError( x );
			if ( norm_value > _bigbound )
			{
				throw yane::Utils::ValueException ( __DEBUGMESS ( "Iteration diverges" ) );
			}
			_iterationCounter++;
		}
		while ( norm_value > _epsilon && _iterationCounter < _maxIter );
	}

	if ( norm_value > _epsilon && _iterationCounter == _maxIter )
	{
		throw yane::Utils::Exception ( __DEBUGMESS ( "Maximal number of iterations executed without reaching accuracy level" ) );
	}
}
