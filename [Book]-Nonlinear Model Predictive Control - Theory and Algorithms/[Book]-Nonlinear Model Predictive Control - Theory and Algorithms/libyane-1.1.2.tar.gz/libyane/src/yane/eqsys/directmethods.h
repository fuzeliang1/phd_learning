/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_DIRECTMETHODS
#define YANE_EQSYS_DIRECTMETHODS

#include "linearequations.h"

namespace yane
{
	namespace EqSys
	{
		/** @class DirectMethods
		@brief Parenting class for all direct solvers for linear equation problems
		*/
		class DirectMethods : public LinearEquations
		{
			public:
				/**
				 * @brief Constructor
				 */
				DirectMethods ();

				/**
				 * @brief Destructor
				 */
				~DirectMethods ();

				/**
				 * Method to solve an upper triangular linear equation system
				 * @param x Solution vector of the problems
				 * @brief Method to solve an upper triangular linear equation system
				 */
				void backwardSolution ( double * x );

				/**
				 * Method to solve the linear equation problem
				 * @param x Solution vector of the problem
				 * @throw yane::Utils::NotInitializedException is thrown if the linear equation problem has not been initialized
				 * @throw yane::Utils::Exception is thrown if the decomposition matrix could not be computed
				 * @brief Method to solve the linear equation problem
				 */
				void solve ( double * x );

				/**
				 * Method to compute the decomposition matrix
				 * @brief Method to compute the decomposition matrix
				 */
				virtual void decomposition ( void ) = 0;

		};

	}
}

#endif
