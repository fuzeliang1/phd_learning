/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "banachfp.h"

#include "../utils.h"

#include <iostream>
#include <iomanip>

#include "libexport.h"

LIB_EXPORT yane::EqSys::BanachFP::BanachFP ( void ) : NonlinearEquations ()
{
	_itermax = 500;
	_eps = 1.0e-12;
}

LIB_EXPORT yane::EqSys::BanachFP::~BanachFP ( void )
{
	if ( _initialized )
	{
	}
}

LIB_EXPORT void yane::EqSys::BanachFP::initialize ( int dimension, yane::EqSys::T_FUNC function, double * rpar, int * ipar )
{
	_dimension = dimension;
	_function = function;
	_ipar = ipar;
	_rpar = rpar;

	try
	{
		_functionValue = new double [ dimension ];
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "Memory allocation error occured" ) );
	}

	_initialized = true;
}

LIB_EXPORT void yane::EqSys::BanachFP::solve ( double * & x )
{
	if ( !_initialized )
	{
		throw yane::Utils::NotInitializedException( __DEBUGMESS ("Problem not initialized" ) );
	}
	int dim = _dimension;
	bool finished = false;

	for ( int i = 0; i < _itermax; i++ )
	{
		_function ( dim, x, _functionValue, _rpar, _ipar );
		for ( int j = 0; j < dim; j++ )
		{
			x[j] += _functionValue[j];
		}

		_norm_f = 0.;
		for ( int j = 0; j < dim; j++ )
		{
			_norm_f += ( _functionValue[j] ) * ( _functionValue[j] );
		}
		_norm_f = sqrt ( _norm_f );
		if ( _norm_f < _eps )
		{
			finished = true;
			_iterationcounter = i;
			break;
		}
		if ( _norm_f > _bigbound )
		{
			throw yane::Utils::ValueException ( __DEBUGMESS ( "Iteration diverges" ) );
		}
	}
	if ( !finished )
	{
		_iterationcounter = _itermax;
		throw yane::Utils::Exception ( __DEBUGMESS ( "Maximal number of iterations executed without reaching accuracy level" ) );
	}
}

LIB_EXPORT void yane::EqSys::BanachFP::setEps ( double eps )
{
	_eps = eps;
}
