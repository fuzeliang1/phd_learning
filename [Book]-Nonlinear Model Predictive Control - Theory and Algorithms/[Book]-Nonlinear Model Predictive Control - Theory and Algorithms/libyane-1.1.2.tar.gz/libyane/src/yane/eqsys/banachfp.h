/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_BANACHFP
#define YANE_EQSYS_BANACHFP

#include "nonlinearequations.h"

#include <cmath>
#include <iostream>

using namespace std;

namespace yane
{
	namespace EqSys
	{
		/** \class BanachFP
		\brief Class for solving nonlinear equation problems using the Banach fixed point iteration
		 */
		class BanachFP : public NonlinearEquations
		{
			public:
				/**
				@brief Constructor
				 */
				BanachFP ( void );

				/**
				@brief Destructor
				 */
				~BanachFP ( void );

				/**
				Function to initialize the nonlinear equation problem
				@param dimension Dimension of the nonlinear equation problem
				@param function Pointer of the function to be analyzed
				@param rpar Vector of real valued parameters
				@param ipar Vector of integer valued parameters
				@brief Function to initialize the nonlinear equation problem
				*/
				void initialize ( int dimension, yane::EqSys::T_FUNC function, double * rpar, int * ipar );

				/**
				Function to solve the nonlinear equation problem
				@param x Evaluation vector
				@brief Function to solve the nonlinear equation problem
				 */
				void solve ( double * & x );

				/**
				Function to set the accuracy of the nonlinear equation solver
				@param eps Accuracy
				@brief Function to set the accuracy of the nonlinear equation solver
				 */
				void setEps ( double eps );

			private:
				yane::EqSys::T_FUNC _function;						/**< @brief Function to be analyzed */
				double _eps;								/**< @brief Breaking constant */
				double _norm_f;								/**< @brief Norm of the function value */

		};

	}
}

#endif
