/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "qrhouseholder.h"

#include "../utils.h"

#include "libexport.h"

LIB_EXPORT yane::EqSys::QRhouseholder::QRhouseholder ( void ) : DirectMethods ()
{
}

LIB_EXPORT yane::EqSys::QRhouseholder::~QRhouseholder ( void )
{
}

LIB_EXPORT void yane::EqSys::QRhouseholder::decomposition ( void )
{
	double c, d, e, sum;

	if ( !_initialized )
	{
		throw yane::Utils::NotInitializedException( __DEBUGMESS ("Problem not initialized" ) );
	}
	_singular = false;
	int dimR = _dimensionRows;
	int dimC = _dimensionColumns;

	if ( _largescale )
	{
		for ( int j = 0; j < min ( dimC, dimR - 1 ); j++ )
		{
			sum = 0.;
			for ( int i = j; i < dimR; i++ )
			{
				sum += _A_largescale[i][j] * _A_largescale[i][j];
			}
			c = ( _A_largescale[j][j] < 0.0 ? -sqrt ( sum ) : sqrt ( sum ) );
			if ( fabs ( c ) > _epsilon )
			{
				_A_largescale[j][j] += c;
				d = 1. / ( c * _A_largescale[j][j] );

				sum = 0.;
				for ( int i = j; i < dimR; i++ )
				{
					sum += _A_largescale[i][j] * _b[i];
				}
				e = d * sum;
				for ( int i = j; i < dimR; i++ )
				{
					_b[i] -= e * _A_largescale[i][j];
				}
				for ( int k = j + 1; k < dimC; k++ )
				{
					sum = 0.;
					for ( int i = j; i < dimR; i++ )
					{
						sum += _A_largescale[i][j] * _A_largescale[i][k];
					}
					e = d * sum;
					for ( int i = j; i < dimR; i++ )
					{
						_A_largescale[i][k] -= e * _A_largescale[i][j];
					}
				}
				_A_largescale[j][j] = -c;
			}
			else
			{
				_singular = true;
			}
		}
		if ( dimR == dimC && fabs ( _A_largescale[dimC - 1][dimC - 1] ) < _epsilon )
		{
			_singular = true;
		}
	}
	else
	{
		for ( int j = 0; j < min ( dimC, dimR - 1 ); j++ )
		{
			sum = 0.;
			for ( int i = j; i < dimR; i++ )
			{
				sum += _A[i * dimC + j] * _A[i * dimC + j];
			}
			c = ( _A[j * dimC + j] < 0.0 ? -sqrt ( sum ) : sqrt ( sum ) );
			if ( fabs ( c ) > _epsilon )
			{
				_A[j * dimC + j] += c;
				d = 1. / ( c * _A[j * dimC + j] );

				sum = 0.;
				for ( int i = j; i < dimR; i++ )
				{
					sum += _A[i * dimC + j] * _b[i];
				}
				e = d * sum;
				for ( int i = j; i < dimR; i++ )
				{
					_b[i] -= e * _A[i * dimC + j];
				}
				for ( int k = j + 1; k < dimC; k++ )
				{
					sum = 0.;
					for ( int i = j; i < dimR; i++ )
					{
						sum += _A[i * dimC + j] * _A[i * dimC + k];
					}
					e = d * sum;
					for ( int i = j; i < dimR; i++ )
					{
						_A[i * dimC + k] -= e * _A[i * dimC + j];
					}
				}
				_A[j * dimC + j] = -c;
			}
			else
			{
				_singular = true;
			}
		}
		if ( dimR == dimC && fabs ( _A[( dimC - 1 ) * dimC + dimC - 1] ) < _epsilon )
		{
			_singular = true;
		}
	}

	if ( _singular )
	{
		throw yane::Utils::Exception( __DEBUGMESS ( "Matrix appears to be singular" ) );
	}
}
