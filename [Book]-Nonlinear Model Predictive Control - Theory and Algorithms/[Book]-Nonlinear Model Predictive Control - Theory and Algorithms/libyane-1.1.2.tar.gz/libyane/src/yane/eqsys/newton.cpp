/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "newton.h"
#include "linearequations.h"

#include "../utils.h"

#include <iostream>
#include <iomanip>

#include "libexport.h"

LIB_EXPORT yane::EqSys::Newton::Newton ( void ) : NonlinearEquations ()
{
	_itermax = 500;
	_eps = 1.0e-12;
	_diffeps = 1.0e-8;
}

LIB_EXPORT yane::EqSys::Newton::~Newton ( void )
{
	if ( _initialized )
	{
		if ( _largescale )
		{
			for ( int i = 0; i < _dimension; i++ )
			{
				delete[] _jacobianValueLargescale[i];
			}
			delete[] _jacobianValueLargescale;
		}
		else
		{
			delete[] _jacobianValue;
		}
		delete[] _functionValue;
		delete[] _functionValueHelp;
	}
}

LIB_EXPORT void yane::EqSys::Newton::initialize ( int dimension, yane::EqSys::T_FUNC function, yane::EqSys::T_FUNC jacobian, double * rpar, int * ipar, yane::EqSys::LinearEquations * solver, bool analytic_jacobian )
{
	_dimension = dimension;
	_function = function;
	_jacobian = jacobian;
	_analytic_jacobian = analytic_jacobian;
	_ipar = ipar;
	_rpar = rpar;
	_solver = solver;

	try
	{
		_deltax = new double [ dimension ];
		_functionValue = new double [ dimension ];
		_functionValueHelp = new double [ dimension ];
		_jacobianValue = new double [ dimension * dimension ];
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "Memory allocation error occured" ) );
	}

	_largescale = false;
	_initialized = true;
}

LIB_EXPORT void yane::EqSys::Newton::initializeLargescale ( int dimension, yane::EqSys::T_FUNC function, yane::EqSys::T_FUNCMATRIX jacobianlargescale, double * rpar, int * ipar, yane::EqSys::LinearEquations * solver,  bool analytic_jacobian )
{
	_dimension = dimension;
	_function = function;
	_jacobianlargescale = jacobianlargescale;
	_analytic_jacobian = analytic_jacobian;
	_ipar = ipar;
	_rpar = rpar;
	_solver = solver;

	try
	{
		_deltax = new double [ dimension ];
		_functionValue = new double [ dimension ];
		_functionValueHelp = new double [ dimension ];
		_jacobianValueLargescale = new double * [ dimension ];
		for ( int i = 0; i < dimension; i++ )
		{
			_jacobianValueLargescale[i] = new double [ dimension ];
		}
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "Memory allocation error occured" ) );
	}

	_largescale = true;
	_initialized = true;
}

LIB_EXPORT void yane::EqSys::Newton::solve ( double * & x )
{
	if ( !_initialized )
	{
		throw yane::Utils::NotInitializedException( __DEBUGMESS ("Problem not initialized" ) );
	}
	int dim = _dimension;
	bool finished = false;

	_function ( dim, x, _functionValue, _rpar, _ipar );
	if ( _analytic_jacobian )
	{
		if ( _largescale )
		{
			_jacobianlargescale ( dim, x, _jacobianValueLargescale, _rpar, _ipar );
		}
		else
		{
			_jacobian ( dim, x, _jacobianValue, _rpar, _ipar );
		}
	}
	else
	{
		computeJacobian( x );
	}

	for ( int i = 0; i < _itermax; i++ )
	{
		try
		{
			if ( _largescale )
			{
				_solver->initializeLargescale ( _jacobianValueLargescale, dim, dim, _functionValue, dim );
			}
			else
			{
				_solver->initialize ( _jacobianValue, dim, dim, _functionValue, dim );
			}
			_solver->solve ( _deltax );
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Computation was aborted while solving linear equation system" ), &e );
		}
		for ( int j = 0; j < dim; j++ )
		{
			x[j] -= _deltax[j];
		}

		_function ( dim, x, _functionValue, _rpar, _ipar );
		if ( _analytic_jacobian )
		{
			if ( _largescale )
			{
				_jacobianlargescale ( dim, x, _jacobianValueLargescale, _rpar, _ipar );
			}
			else
			{
				_jacobian ( dim, x, _jacobianValue, _rpar, _ipar );
			}
		}
		else
		{
			computeJacobian( x );
		}

		_norm_x = 0.;
		for ( int j = 0; j < dim; j++ )
		{
			_norm_x += ( _deltax[j] ) * ( _deltax[j] );
		}
		_norm_x = sqrt ( _norm_x );

		_norm_f = 0.;
		for ( int j = 0; j < dim; j++ )
		{
			_norm_f += ( _functionValue[j] ) * ( _functionValue[j] );
		}
		_norm_f = sqrt ( _norm_f );

		if ( _norm_x < _eps || _norm_f < _eps )
		{
			finished = true;
			_iterationcounter = i;
			break;
		}
		if ( _norm_f > _bigbound )
		{
			throw yane::Utils::ValueException ( __DEBUGMESS ( "Iteration diverges" ) );
		}
	}

	if ( !finished )
	{
		_iterationcounter = _itermax;
		throw yane::Utils::Exception ( __DEBUGMESS ( "Maximal number of iterations executed without reaching accuracy level" ) );
	}
}

void yane::EqSys::Newton::computeJacobian ( double * & x )
{
	int dim = _dimension;
	for ( int i = 0; i < dim; i++ )
	{
		_function ( dim, x, _functionValue, _rpar, _ipar );
		x[i] += _diffeps;
		_function ( dim, x, _functionValueHelp, _rpar, _ipar );

		for ( int j = 0; j < dim; j++ )
		{
			if ( _largescale )
			{
				_jacobianValueLargescale[j][i] = ( _functionValueHelp[j] - _functionValue[j] ) / _diffeps;
			}
			else
			{
				_jacobianValue[ j * dim + i ] = ( _functionValueHelp[j] - _functionValue[j] ) / _diffeps;
			}
		}
		x[i] -= _diffeps;
	}
}

LIB_EXPORT void yane::EqSys::Newton::setDiffeps ( double diffeps )
{
	_diffeps = diffeps;
}

LIB_EXPORT void yane::EqSys::Newton::setEps ( double eps )
{
	_eps = eps;
}
