/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "nonlinearequations.h"

#include <iostream>
#include <iomanip>

#include "libexport.h"

using namespace std;

LIB_EXPORT const double yane::EqSys::NonlinearEquations::_bigbound = 1e20;

LIB_EXPORT yane::EqSys::NonlinearEquations::NonlinearEquations()
{
	_initialized = false;
}

LIB_EXPORT yane::EqSys::NonlinearEquations::~ NonlinearEquations()
{
}

LIB_EXPORT void yane::EqSys::NonlinearEquations::setIpar ( int * ipar )
{
	_ipar = ipar;
}

LIB_EXPORT void yane::EqSys::NonlinearEquations::setRpar ( double * rpar )
{
	_rpar = rpar;
}

LIB_EXPORT void yane::EqSys::NonlinearEquations::setItermax ( int itermax )
{
	_itermax = itermax;
}

LIB_EXPORT int yane::EqSys::NonlinearEquations::iterationCounter ( void )
{
	return _iterationcounter;
}
