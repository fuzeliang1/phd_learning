/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "qrgivens.h"

#include "../utils.h"

#include "libexport.h"

LIB_EXPORT yane::EqSys::QRgivens::QRgivens ( void ) : DirectMethods ()
{
}

LIB_EXPORT yane::EqSys::QRgivens::~QRgivens ( void )
{
}

LIB_EXPORT void yane::EqSys::QRgivens::decomposition ( void )
{
	double sum, cos_phi, sin_phi, temp;

	if ( !_initialized )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "Problem not initialized" ) );
	}

	_singular = false;
	int dimC = _dimensionColumns;
	int dimR = _dimensionRows;

	if ( _largescale )
	{
		for ( int i = 0; i < min ( dimC, dimR - 1 ); i++ )
		{
			for ( int j = i + 1; j < dimR; j++ )
			{
				if ( fabs ( _A_largescale[j][i] ) > _epsilon )
				{
					sum = sqrt ( _A_largescale[i][i] * _A_largescale[i][i] + _A_largescale[j][i] * _A_largescale[j][i] );
					cos_phi = _A_largescale[i][i] / sum;
					sin_phi = - _A_largescale[j][i] / sum;
					for ( int k = i; k < dimC; k++ )
					{
						temp = sin_phi * _A_largescale[i][k] + cos_phi * _A_largescale[j][k];
						_A_largescale[i][k] = cos_phi * _A_largescale[i][k] - sin_phi * _A_largescale[j][k];
						_A_largescale[j][k] = temp;
					}
					temp = sin_phi * _b[i] + cos_phi * _b[j];
					_b[i] = cos_phi * _b[i] - sin_phi * _b[j];
					_b[j] = temp;
				}
			}
			if ( fabs ( _A_largescale[i][i] ) < _epsilon )
			{
				_singular = true;
			}
		}
		if ( dimR == dimC && fabs ( _A_largescale[dimC - 1][dimC - 1] ) < _epsilon )
		{
			_singular = true;
		}
	}
	else
	{
		for ( int i = 0; i < min ( dimC, dimR - 1 ); i++ )
		{
			for ( int j = i + 1; j < dimR; j++ )
			{
				if ( fabs ( _A[j * dimC + i] ) > _epsilon )
				{
					sum = sqrt ( _A[i* dimC + i] * _A[i * dimC + i] + _A[j * dimC + i] * _A[j * dimC + i] );
					cos_phi = _A[i * dimC + i] / sum;
					sin_phi = - _A[j * dimC + i] / sum;
					for ( int k = i; k < dimC; k++ )
					{
						temp = sin_phi * _A[i * dimC + k] + cos_phi * _A[j * dimC + k];
						_A[i * dimC + k] = cos_phi * _A[i * dimC + k] - sin_phi * _A[j * dimC + k];
						_A[j * dimC + k] = temp;
					}
					temp = sin_phi * _b[i] + cos_phi * _b[j];
					_b[i] = cos_phi * _b[i] - sin_phi * _b[j];
					_b[j] = temp;
				}
			}
			if ( fabs ( _A[i * dimC + i] ) < _epsilon )
			{
				_singular = true;
			}
		}
		if ( dimR == dimC && fabs ( _A[( dimC - 1 ) * dimC + dimC - 1] ) < _epsilon )
		{
			_singular = true;
		}
	}

	if ( _singular )
	{
		throw yane::Utils::Exception( __DEBUGMESS ( "Matrix appears to be singular" ) );
	}
}
