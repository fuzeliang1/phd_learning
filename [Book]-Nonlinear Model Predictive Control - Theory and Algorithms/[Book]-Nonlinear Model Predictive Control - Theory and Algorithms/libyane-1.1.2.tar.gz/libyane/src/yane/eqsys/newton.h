/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_NEWTON
#define YANE_EQSYS_NEWTON

#include "nonlinearequations.h"

#include <cmath>
#include <iostream>

namespace yane
{
	namespace EqSys
	{
		class LinearEquations;

		/** \class Newton
		\brief Class for solving nonlinear equation problems using Newton's method
		 */
		class Newton : public NonlinearEquations
		{
			public:
				/**
				@brief Constructor
				 */
				Newton ( void );

				/**
				@brief Destructor
				 */
				~Newton ( void );

				/**
				Function to initialize the nonlinear equation problem
				@param dimension Dimension of the nonlinear equation problem
				@param function Pointer of the function to be analyzed
				@param jacobian Pointer of the Jacobian of the function to be analyzed
				@param analytic_jacobian decision variable if Jacobian is supplied.
				@param rpar Vector of real valued parameters
				@param ipar Vector of integer valued parameters
				@param solver Pointer of linear equation problem solver
				@brief Function to initialize the nonlinear equation problem
				 */
				void initialize ( int dimension, yane::EqSys::T_FUNC function, yane::EqSys::T_FUNC jacobian , double * rpar, int * ipar, yane::EqSys::LinearEquations * solver, bool analytic_jacobian = false );

				/**
				Function to initialize the nonlinear equation problem for largescale problems
				@param dimension Dimension of the nonlinear equation problem
				@param function Pointer of the function to be analyzed
				@param jacobianlargescale Pointer of the Jacobian of the function to be analyzed
				@param analytic_jacobian decision variable if Jacobian is supplied.
				@param rpar Vector of real valued parameters
				@param ipar Vector of integer valued parameters
				@param solver Pointer of linear equation problem solver
				@brief Function to initialize the nonlinear equation problem for largescale problems
				 */
				void initializeLargescale ( int dimension, yane::EqSys::T_FUNC function, yane::EqSys::T_FUNCMATRIX jacobianlargescale, double * rpar, int * ipar, yane::EqSys::LinearEquations * solver, bool analytic_jacobian = false );

				/**
				Function to solve the nonlinear equation problem
				@param x Evaluation vector
				@brief Function to solve the nonlinear equation problem
				 */
				void solve ( double * & x );

				/**
				Function to set the accuracy of the nonlinear equation solver
				@param eps Accuracy
				@brief Function to set the accuracy of the nonlinear equation solver
				 */
				void setEps ( double eps );

				/**
				 * Function to set the disturbance for evaluating the Jacobian of the function to be analyzed numerically
				@param diffeps Disturbance for numerical differentiation
				@brief Function to set the disturbance for evaluating the Jacobian of the function to be analyzed numerically
				 */
				void setDiffeps ( double diffeps );

			private:
				/**
				Function to evaluate the Jacobian
				@param x Evaluation vector
				@brief Function to evaluate the Jacobian
				 */
				void computeJacobian ( double * & x );

				yane::EqSys::T_FUNC _function;						/**< @brief Function to be analyzed */
				yane::EqSys::T_FUNC _jacobian;						/**< @brief Jacobian of the function to be analyzed */
				yane::EqSys::T_FUNCMATRIX _jacobianlargescale;				/**< @brief Jacobian of the function to be analyzed for largescale linear equation solvers */
				yane::EqSys::LinearEquations * _solver;					/**< @brief Solver for the linear equation system */
				double _eps;								/**< @brief Breaking constant */
				double _diffeps;							/**< @brief Differentiation disturbance for numerical approximation of the derivative */
				double _norm_x;								/**< @brief Norm of the step length \f$ \Delta x \f$ */
				double _norm_f;								/**< @brief Norm of the function value */
				double * _deltax;							/**< @brief Array of the step length \f$ \Delta x \f$ */
				double * _functionValueHelp;						/**< @brief Auxilliary array to store the function value */
				double * _jacobianValue;						/**< @brief Array of the Jacobian */
				double ** _jacobianValueLargescale;					/**< @brief Array of the Jacobian for largescale linear equation solvers */
				bool _largescale;							/**< @brief Decision variable for use of largescale linear equation solvers */
				bool _analytic_jacobian;						/**< @brief Decision variable if analytical Jacobian is supplied by user */

		};

	}
}

#endif
