/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_ITERATIVEMETHODS
#define YANE_EQSYS_ITERATIVEMETHODS

#include "linearequations.h"

#include <cstring>
#include <omp.h>

namespace yane
{
	namespace EqSys
	{
		/** @class IterativeMethods
		@brief Parenting class for all iterative solvers for linear equation problems
		 */
		class IterativeMethods : public LinearEquations
		{
			public:
				/**
				 * @brief Constructor
				 */
				IterativeMethods ( void );

				/**
				 * @brief Destructor
				 */
				~IterativeMethods ( void );

				/**
				 * Method to set the maximal number of iterations
				 * @param maxIter Maximal number of iterations
				 * @brief Method to set the maximal number of iterations
				 */
				void setMaxIter ( int maxIter );

				/**
				 * Method to obtain the number of iterations used by the solution method
				 * @param iterationCounter
				 */
				int iterationCounter ( void );

				/**
				 * Abstract method to solve the linear equation problem
				 * @param x Solution vector of the problem
				 * @brief Abstract method to solve the linear equation problem
				 */
				virtual void solve ( double * x ) = 0;

			protected:
				/**
				 * Method to compute the infinity norm error of the current iterate
				 * @param x Vector of the current iterate
				 * @return Infinity norm error of the current iterate
				 * @brief Method to compute the infinity norm error of the current iterate
				 */
				double normInfinityError ( double * x );

				int _iterationCounter;				/**< @brief Iteration counter */
				int _maxIter;					/**< @brief Maximal number of iterations */
				static const double _bigbound;		/**< @brief Bound to stop diverging iterations */
		};
	}
}

#endif
