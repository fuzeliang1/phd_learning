/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "jacobi.h"

#include "../utils.h"

#include "libexport.h"

LIB_EXPORT yane::EqSys::Jacobi::Jacobi ( void ) : IterativeMethods ()
{
}

LIB_EXPORT yane::EqSys::Jacobi::~Jacobi ( void )
{
}

LIB_EXPORT void yane::EqSys::Jacobi::solve ( double * x )
{
	int i, j;
	double norm_value, sum;
	double * x2;
	int dimR = _dimensionRows;
	int dimC = _dimensionColumns;
	omp_lock_t lock;

	if ( !_initialized )
	{
		throw yane::Utils::NotInitializedException( __DEBUGMESS ("Problem not initialized" ) );
	}

	if ( dimR != dimC )
	{
		throw yane::Utils::IndexException( __DEBUGMESS ( "Row and column dimension of the matrix A do not match" ) );
	}

	try
	{
		x2 = new double[dimC];
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "Memory allocation error occured" ) );
	}

	if ( _largescale )
	{
		for ( i = 0; i < dimC; i++ )
		{
			x[i] = 0.;
			if ( fabs ( _A_largescale[i][i] ) < _epsilon )
			{
				throw yane::Utils::ValueException( __DEBUGMESS ( "Matrix not numerically invertable" ) );
			}
		}

		_iterationCounter = 0;
		do
		{
			omp_init_lock ( & lock );
#pragma omp parallel default ( shared ) private( i, j, sum )
			{
#pragma omp for
				for ( i = 0; i < dimR; i++ )
				{
					sum = - _A_largescale[i][i] * x[i];
					for ( j = 0; j < dimC; j++ )
					{
						sum = sum + _A_largescale[i][j] * x[j];
					}
					omp_set_lock ( & lock );
					x2[i] = ( _b[i] - sum ) / _A_largescale[i][i];
					omp_unset_lock ( & lock );
				}
			}
			omp_destroy_lock ( & lock );
			memcpy(x, x2, sizeof ( double ) * dimC );
			norm_value = normInfinityError( x );
			if ( norm_value > _bigbound )
			{
				delete[] x2;
				throw yane::Utils::ValueException ( __DEBUGMESS ( "Iteration diverges" ) );
			}
			_iterationCounter++;
		}
		while ( norm_value > _epsilon && _iterationCounter < _maxIter );
	}
	else
	{
		for ( i = 0; i < dimC; i++ )
		{
			x[i] = 0.;
			if ( fabs ( _A[i * dimC + i] ) < _epsilon )
			{
				throw yane::Utils::ValueException( __DEBUGMESS ( "Matrix not numerically invertable" ) );
			}
		}

		_iterationCounter = 0;
		do
		{
			omp_init_lock ( & lock );
#pragma omp parallel default ( shared ) private( i, j, sum )
			{
#pragma omp for
				for ( i = 0; i < dimR; i++ )
				{
					sum = - _A[i * dimC + i] * x[i];
					for ( j = 0; j < dimC; j++ )
					{
						sum = sum + _A[i * dimC + j] * x[j];
					}
					omp_set_lock ( & lock );
					x2[i] = ( _b[i] - sum ) / _A[i * dimC + i];
					omp_unset_lock ( & lock );
				}
			}
			omp_destroy_lock ( & lock );
			memcpy(x, x2, sizeof ( double ) * dimC );
			norm_value = normInfinityError( x );
			if ( norm_value > _bigbound )
			{
				delete[] x2;
				throw yane::Utils::ValueException ( __DEBUGMESS ( "Iteration diverges" ) );
			}
			_iterationCounter++;
		}
		while ( norm_value > _epsilon && _iterationCounter < _maxIter );
	}

	if ( norm_value > _epsilon && _iterationCounter == _maxIter )
	{
		throw yane::Utils::Exception ( __DEBUGMESS ( "Maximal number of iterations executed without reaching accuracy level" ) );
	}
	delete[] x2;
}
