/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "iterativemethods.h"

#include "libexport.h"

LIB_EXPORT const double yane::EqSys::IterativeMethods::_bigbound = 1e20;

LIB_EXPORT yane::EqSys::IterativeMethods::IterativeMethods ( void ) : LinearEquations ()
{
	_maxIter = 100;
}

LIB_EXPORT yane::EqSys::IterativeMethods::~IterativeMethods ( void )
{
}

LIB_EXPORT void yane::EqSys::IterativeMethods::setMaxIter ( int maxIter )
{
	_maxIter = maxIter;
}

LIB_EXPORT int yane::EqSys::IterativeMethods::iterationCounter ( void )
{
	return _iterationCounter;
}

LIB_EXPORT double yane::EqSys::IterativeMethods::normInfinityError ( double * x )
{
	int i, j;
	double max = 0.0, sum;
	omp_lock_t lock;

	if ( _largescale )
	{
		omp_init_lock ( & lock );
#pragma omp parallel default ( shared ) private ( i, j, sum )
		{
#pragma omp for
			for ( i = 0; i < _dimensionRows; i++ )
			{
				sum = - _b[i];
				for ( j = 0; j < _dimensionColumns; j++ )
				{
					sum += _A_largescale[i][j] * x[j];
				}
				omp_set_lock ( & lock );
				if ( fabs ( sum ) > max )
				{
					max = fabs ( sum );
				}
				omp_unset_lock ( & lock );
			}
		}
		omp_destroy_lock ( & lock );
	}
	else
	{
		int dimC = _dimensionColumns;
		omp_init_lock ( & lock );
#pragma omp parallel default ( shared ) private ( i, j, sum )
		{
#pragma omp for
			for ( i = 0; i < _dimensionRows; i++ )
			{
				sum = - _b[i];
				for ( j = 0; j < dimC; j++ )
				{
					sum += _A[i * dimC + j] * x[j];
				}
				omp_set_lock ( & lock );
				if ( fabs ( sum ) > max )
				{
					max = fabs ( sum );
				}
				omp_unset_lock ( & lock );
			}
		}
		omp_destroy_lock ( & lock );
	}
	return ( max );
}
