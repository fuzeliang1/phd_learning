/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_GAUSS
#define YANE_EQSYS_GAUSS

#include "directmethods.h"

namespace yane
{
	namespace EqSys
	{
		/**< @class Gauss
		@brief Class of the Gauss Method for linear equation systems
		 */
		class Gauss : public DirectMethods
		{
			public:
				/**
				 * @brief Constructor
				 */
				Gauss ();

				/**
				 * @brief Destructor
				 */
				~Gauss ();

				/**
				 * Method to compute the Gauss decomposition
				 * @throw yane::Utils::NotInitializedException is thrown if the linear equation problem is not initialized
				 * @throw yane::Utils::IndexException is thrown if the matrix is not quadratic
				 * @throw yane::Utils::Exception is thrown if matrix is numerically singular
				 * @brief Method to compute the Gauss decomposition
				 */
				void decomposition ( void );

				/**
				 * Method to exchange rows within the matrix
				 * @param i Row index i
				 * @param j Row index j
				 * @brief Method to exchange rows within the matrix
				 */
				void exchangeRows ( int i, int j );

		};
	}
}

#endif
