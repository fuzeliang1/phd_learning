/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>             *
 *                                                                         *
 ***************************************************************************/

/**
	 @file
	 @author Juergen Pannek <juergen.pannek@googlemail.com>
	 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	 @author Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>
 */

#include "cholesky.h"

#include "../utils.h"

#include <cfloat>
#include <cstring>

#include "libexport.h"

LIB_EXPORT yane::EqSys::Cholesky::Cholesky () : DirectMethods()
{
	_checkmatrix = false;
}

LIB_EXPORT yane::EqSys::Cholesky::~ Cholesky()
{
	if ( _wa != 0 ) delete[] _wa;
	if ( _G != 0 ) delete[] _G;

	_wa = 0;
	_G = 0;
}

LIB_EXPORT void yane::EqSys::Cholesky::solve ( double * x )
{
	if ( _initialized )
	{
		if ( _dimensionRows == _dimensionColumns )
		{
			if ( _checkmatrix )
			{
				if ( checkMatrixLargescale() )
				{
					try
					{
						checkWorkingArrays();
					}
					catch ( yane::Utils::MemoryException e )
					{
						throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Allocation error" ), __DEBUGMESS ( "Working arrays could not be allocated" ), &e );
					}
				}
				else
				{
					throw yane::Utils::Exception ( __DEBUGMESS ( "Matrix not symmetric" ) );
				}
			}
			else
			{
				try
				{
					checkWorkingArrays();
				}
				catch ( yane::Utils::MemoryException e )
				{
					throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Allocation error" ), __DEBUGMESS ( "Working arrays could not be allocated" ), &e );
				}
			}
		}
		else
		{
			throw yane::Utils::IndexException ( __DEBUGMESS ( "Row and column dimension of the matrix A do not match" ) );
		}

		if ( _largescale )
		{
			try
			{
				_Ahelp = new double[_dimensionColumns * _dimensionColumns];
			}
			catch ( std::bad_alloc )
			{
				throw yane::Utils::MemoryException ( __DEBUGMESS ( "Memory allocation error occured" ) );
			}
			for ( int i = 0; i < _dimensionRows; i++ )
			{
				memcpy ( &_Ahelp[i * _dimensionRows], &_A_largescale[i][0], sizeof ( double ) * _dimensionRows );
			}

			btchlg_ ( &_dimensionRows, _Ahelp, _G, _b, x, _wa, &_fail );
		}
		else
		{
			btchlg_ ( &_dimensionRows, _A, _G, _b, x, _wa, &_fail );
		}
	}
	else
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "Problem is not initialized " ) );
	}
}

LIB_EXPORT void yane::EqSys::Cholesky::decomposition ( void )
{
	if ( _initialized )
	{
		if ( _dimensionRows == _dimensionColumns )
		{
			if ( _checkmatrix )
			{
				if ( checkMatrixLargescale() )
				{
					try
					{
						checkWorkingArrays();
					}
					catch ( yane::Utils::MemoryException e )
					{
						throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Allocation error" ), __DEBUGMESS ( "Working arrays could not be allocated" ), &e );
					}
				}
				else
				{
					throw yane::Utils::Exception ( __DEBUGMESS ( "Matrix not symmetric" ) );
				}
			}
			else
			{
				try
				{
					checkWorkingArrays();
				}
				catch ( yane::Utils::MemoryException e )
				{
					throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Allocation error" ), __DEBUGMESS ( "Working arrays could not be allocated" ), &e );
				}
			}
		}
		else
		{
			throw yane::Utils::IndexException ( __DEBUGMESS ( "Row and column dimension of the matrix A do not match" ) );
		}
		if ( _largescale )
		{
			try
			{
				_Ahelp = new double[_dimensionColumns * _dimensionColumns];
			}
			catch ( std::bad_alloc )
			{
				throw yane::Utils::MemoryException ( __DEBUGMESS ( "Memory allocation error occured" ) );
			}
			for ( int i = 0; i < _dimensionRows; i++ )
			{
				memcpy ( &_Ahelp[i * _dimensionRows], &_A_largescale[i][0], sizeof ( double ) * _dimensionRows );
			}

			btcsky_ ( &_dimensionRows, _Ahelp, _G, &_fail );
		}
		else
		{
			btcsky_ ( &_dimensionRows, _A, _G, &_fail );
		}
	}
	else
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "Problem is not initialized " ) );
	}
}

void yane::EqSys::Cholesky::checkWorkingArrays ( void )
{
	int dimC = _dimensionColumns;
	if ( _wa != 0 ) delete[] _wa;
	if ( _G != 0 ) delete[] _G;
	try
	{
		_wa = new double[dimC];
		_G = new double[dimC * dimC];
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "Memory allocation error occured" ) );
	}
}

bool yane::EqSys::Cholesky::checkMatrixLargescale ( void )
{
	int dimC = _dimensionColumns;
	for ( int i = 0; i < dimC; i++ )
	{
		for ( int j = i; j < dimC; j++ )
		{
			if ( _A_largescale[i][j] != _A_largescale[j][i] )
			{
				return false;
			}
		}
	}
	return true;
}

bool yane::EqSys::Cholesky::checkMatrix ( void )
{
	int dimC = _dimensionColumns;
	for ( int i = 0; i < dimC; i++ )
	{
		for ( int j = i; j < dimC; j++ )
		{
			if ( _A[i * dimC + j] != _A[j * dimC + i] )
			{
				return false;
			}
		}
	}
	return true;
}

LIB_EXPORT void yane::EqSys::Cholesky::setCheckmatrix ( bool checkmatrix )
{
	_checkmatrix = checkmatrix;
}
