/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_LINEAREQUATIONS
#define YANE_EQSYS_LINEAREQUATIONS

#include <cmath>
#include <iostream>

namespace yane
{
	namespace EqSys
	{
		/** @class LinearEquations
		@brief Class for solving linear equation problems
		*/
		class LinearEquations
		{
			public:
				/**
				 * @brief Constructor
				 */
				LinearEquations ();

				/**
				 * @brief Destructor
				 */
				~LinearEquations ();

				/**
				 * Method to initialize the linear equation problem
				 * @param A System matrix
				 * @param dimensionRows Row dimension of the system matrix
				 * @param dimensionColumns Column dimension of the system matrix
				 * @param b Data vector of the problem
				 * @param dimensionB Dimension of the data vector
				 * @throw ValueException is thrown if row dimension of the matrix and dimension of the data vector are not identical
				 * @brief Method to initialize the linear equation problem
				 */
				void initialize ( double * A, int dimensionRows, int dimensionColumns, double * b, int dimensionB );

				/**
				 * Method to initialize the linear equation problem
				 * @param A System matrix
				 * @param dimensionRows Row dimension of the system matrix
				 * @param dimensionColumns Column dimension of the system matrix
				 * @param b Data vector of the problem
				 * @param dimensionB Dimension of the data vector
				 * @throw ValueException is thrown if row dimension of the matrix and dimension of the data vector are not identical
				 * @brief Method to initialize the linear equation problem
				 */
				void initializeLargescale ( double ** A, int dimensionRows, int dimensionColumns, double * b, int dimensionB );

				/**
				 * Method to solve the linear equation problem
				 * @param x Solution vector of the problem
				 * @brief Method to solve the linear equation problem
				 */
				virtual void solve ( double * x ) = 0;

				/**
				 * Method to obtain the row dimension of the system matrix
				 * @return Row dimension of the system matrix
				 * @brief Method to obtain the row dimension of the system matrix
				 */
				int dimensionRows ();

				/**
				 * Method to obtain the column dimension of the system matrix
				 * @return Column dimension of the system matrix
				 * @brief Method to obtain the column dimension of the system matrix
				 */
				int dimensionColumns ();

			protected:
				double * _A;			/**< @brief System matrix stored by line in a large vector */
				double ** _A_largescale;	/**< @brief System matrix with double pointers for large scale matrices */
				int _dimensionRows;		/**< @brief Row dimension of the system matrix */
				int _dimensionColumns;		/**< @brief Column dimension of the system matrix */
				double * _b;			/**< @brief Data vector of the problem */
				int _dimensionB;		/**< @brief Dimension of data vector */
				bool _initialized;		/**< @brief Decision variable on initialization status of the linear equation problem */
				bool _largescale; 		/**< @brief Decision variable whether large scale solution methods shall be used */

				static const double _epsilon;	/**< @brief Constant to check for numerical singularity of the system matrix */

		};

	}
}

#endif
