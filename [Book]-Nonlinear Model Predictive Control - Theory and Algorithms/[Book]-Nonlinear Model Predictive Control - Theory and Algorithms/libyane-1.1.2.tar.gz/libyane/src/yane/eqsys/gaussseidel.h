/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_GAUSSEIDEL
#define YANE_EQSYS_GAUSSEIDEL

#include "iterativemethods.h"

namespace yane
{
	namespace EqSys
	{
		/** @class GaussSeidel
		@brief Class of the Jacobi Iteration Method for linear equation systems
		 */
		class GaussSeidel : public IterativeMethods
		{
			public:
				/**
				 * @brief Constructor
				 */
				GaussSeidel ( void );

				/**
				 * @brief Destructor
				 */
				~GaussSeidel ( void );

				/**
				 * Method to solve the linear equation problem
				 * @param x Solution vector of the problem
				 * @throw yane::Utils::NotInitializedException is thrown if the linear equation problem has not been initialized
				 * @throw yane::Utils::IndexException is thrown if the matrix is not quadratic
				 * @throw yane::Utils::ValueException is thrown if the matrix is numerically not invertable of iteration diverges
				 * @throw yane::Utils::Exception is thrown if problem neither converges nor diverges within the maximal number of iterations
				 * @brief Method to solve the linear equation problem
				 */
				void solve ( double * x );
		};
	}
}

#endif
