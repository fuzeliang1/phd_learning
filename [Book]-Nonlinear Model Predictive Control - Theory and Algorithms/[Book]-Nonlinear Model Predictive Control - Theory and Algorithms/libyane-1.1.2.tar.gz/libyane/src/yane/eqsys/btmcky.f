      SUBROUTINE BTCHLG(N,A,G,B,X,WA,FAIL)

      IMPLICIT NONE
      INTEGER N,FAIL
      DOUBLE PRECISION A,B,X,G,WA
      DIMENSION A(N,N),B(N),X(N),G(N,N),WA(N)

      CALL BTCSKY(N,A,G,FAIL)
      IF (FAIL.NE.0) RETURN

      CALL BTCSLV(N,G,B,X,WA)

      END


      SUBROUTINE BTCSKY(N,A,G,FAIL)

      IMPLICIT NONE
      INTEGER N,I,J,K,FAIL
      DOUBLE PRECISION A,G,D
      DIMENSION A(N,N),G(N,N)

      DO 1 I=1,N

         DO 2 J=1,I-1
            D=A(I,J)
            DO 3 K=1,J-1
               D=D-G(I,K)*G(J,K)
3           CONTINUE
            G(I,J)=D/G(J,J)
2        CONTINUE

         D=A(I,I)
         DO 4 K=1,I-1
            D=D-(G(I,K)**2.0D0)
4        CONTINUE
         IF (D.LE.0.0D0) THEN
            FAIL=1
            RETURN
         ENDIF
         G(I,I)=DSQRT(D)

1     CONTINUE
      FAIL=0

      END


      SUBROUTINE BTCSLV(N,A,B,X,WA)

      IMPLICIT NONE
      INTEGER N,I,J
      DOUBLE PRECISION A,B,X,WA
      DIMENSION A(N,N),X(N),WA(N),B(N)

      DO 1 I=1,N
         WA(I)=B(I)
         DO 2 J=1,I-1
            WA(I)=WA(I)-A(I,J)*WA(J)
2        CONTINUE
         WA(I)=WA(I)/A(I,I)
1     CONTINUE

      DO 3 I=N,1,-1
         X(I)=WA(I)
         DO 4 J=I+1,N
            X(I)=X(I)-A(J,I)*X(J)
4        CONTINUE
         X(I)=X(I)/A(I,I)
3     CONTINUE

      END