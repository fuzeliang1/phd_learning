/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_QRHOUSEHOLDER
#define YANE_EQSYS_QRHOUSEHOLDER

#include "directmethods.h"

namespace yane
{
	namespace EqSys
	{
		/** @class QRhouseholder
		@brief Class of the QR solver for linear equation systems based on Householder transformations
		*/
		class QRhouseholder : public DirectMethods
		{
			public:
				/**
				 * @brief Constructor
				 */
				QRhouseholder ( void );

				/**
				 * @brief Destructor
				 */
				~QRhouseholder ( void );

				/**
				 * Method to compute the QR decomposition based on Householder transformations
				 * @throw yane::Utils::NotInitializedException is thrown if the linear equation problem is not initialized
				 * @throw yane::Utils::Exception is thrown if matrix is numerically singular
				 * @brief Method to compute the QR decomposition based on Householder transformations
				 */
				void decomposition ( void );

			private:
				bool _singular;			/**< @brief Decision variable if matrix is numerically singular */
		};
	}
}

#endif
