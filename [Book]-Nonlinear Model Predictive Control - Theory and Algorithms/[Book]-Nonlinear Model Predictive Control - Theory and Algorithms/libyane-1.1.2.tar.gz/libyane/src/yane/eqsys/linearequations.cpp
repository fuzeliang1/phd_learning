/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "linearequations.h"

#include "../utils.h"

#include <iostream>
#include <iomanip>

#include "libexport.h"

using namespace std;

LIB_EXPORT const double yane::EqSys::LinearEquations::_epsilon = 1e-12;

LIB_EXPORT yane::EqSys::LinearEquations::LinearEquations()
{
	_initialized = false;
	_largescale = false;
}

LIB_EXPORT yane::EqSys::LinearEquations::~ LinearEquations()
{
}

LIB_EXPORT void yane::EqSys::LinearEquations::initialize ( double * A, int dimensionRows, int dimensionColumns, double * b, int dimensionB )
{
	if ( dimensionRows != dimensionB )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "Row dimension of A must be equal to dimension of b" ) );
	}

	_A = A;
	_dimensionRows = dimensionRows;
	_dimensionColumns = dimensionColumns;
	_b = b;
	_dimensionB = dimensionB;

	_largescale = false;
	_initialized = true;
}

LIB_EXPORT void yane::EqSys::LinearEquations::initializeLargescale ( double ** A, int dimensionRows, int dimensionColumns, double * b, int dimensionB )
{
	if ( dimensionRows != dimensionB )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "Row dimension of A must be equal to dimension of b" ) );
	}

	_A_largescale = A;
	_dimensionRows = dimensionRows;
	_dimensionColumns = dimensionColumns;
	_b = b;
	_dimensionB = dimensionB;

	_largescale = true;
	_initialized = true;
}

LIB_EXPORT int yane::EqSys::LinearEquations::dimensionRows()
{
	return _dimensionRows;
}

LIB_EXPORT int yane::EqSys::LinearEquations::dimensionColumns()
{
	return _dimensionColumns;
}
