/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_EQSYS_NONLINEAREQUATIONS
#define YANE_EQSYS_NONLINEAREQUATIONS

#include <cmath>
#include <iostream>

namespace yane
{
	namespace EqSys
	{
		/** \typedef T_FUNC
		\brief Pointer of the function to be analyzed
		\param dimension Dimension of the vector
		\param x Vector containing the evaluation point
		\param fx Vector containing the function values
		\param rpar Vector of double parameters
		\param ipar Vector of integer paramters
		 */
		typedef void ( * T_FUNC ) ( int dimension, double * x, double * fx, double * rpar, int * ipar );

		/** \typedef T_FUNCMATRIX
		\brief Pointer of the Jacobian of the function to be analyzed
		\param dimension Dimension of the vector
		\param x Vector containing the evaluation point
		\param jacobianlargescale Vector containing the Jacobian
		\param rpar Vector of double parameters
		\param ipar Vector of integer paramters
		 */
		typedef void ( * T_FUNCMATRIX ) ( int dimension, double * x, double ** jacobianlargescale, double * rpar, int * ipar );


		/** @class NonlinearEquations
		@brief Class for solving nonlinear equation problems
		*/
		class NonlinearEquations
		{
			public:
				/**
				 * @brief Constructor
				 */
				NonlinearEquations ();

				/**
				 * @brief Destructor
				 */
				~NonlinearEquations ();

				virtual void solve ( double * & x ) = 0;

				/**
				Function to set the vector of integer parameters
				@param ipar Vector of integer parameters
				@brief Function to set the vector of integer parameters
				 */
				void setIpar ( int * ipar );

				/**
				Function to set the vector of real valued parameters
				@param rpar Vector of real valued parameters
				@brief Function to set the vector of real valued parameters
				 */
				void setRpar ( double * rpar );

				/**
				Function to set the maximal number of iterations
				@param itermax Maximal number of iterations
				@brief Function to set the maximal number of iterations
				 */
				void setItermax ( int itermax );

				/**
				@brief Function to get the number of iterations
				 */
				int iterationCounter ( void );

			protected:
				bool _initialized;		/**< @brief Decision variable on initialization status of the linear equation problem */
				int _dimension;			/**< @brief Dimension of the solution vector */
				int _iterationcounter;		/**< @brief Iteration counter */
				int _itermax;			/**< @brief Maximum allowable number of iterations */
				int * _ipar;			/**< @brief Array of integer paramters */
				double * _rpar;			/**< @brief Array of double parameters */
				double * _functionValue;	/**< @brief Array to store the function value */
				static const double _bigbound;	/**< @brief Bound to stop diverging iterations */

		};

	}
}

#endif
