/***************************************************************************
 *                                                                         *
 * Library for Equation Systems Solver                                     *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "gauss.h"

#include "../utils.h"

#include "libexport.h"

LIB_EXPORT yane::EqSys::Gauss::Gauss()
{
}

LIB_EXPORT yane::EqSys::Gauss::~ Gauss()
{
}

LIB_EXPORT void yane::EqSys::Gauss::decomposition( void )
{
	if ( !_initialized )
	{
		throw yane::Utils::NotInitializedException( __DEBUGMESS ("Problem not initialized" ) );
	}

	if ( _dimensionRows != _dimensionColumns )
	{
		throw yane::Utils::IndexException( __DEBUGMESS ( "Row and column dimension of the matrix A do not match" ) );
	}

	if ( _largescale )
	{
		for ( int j = 0; j < _dimensionColumns; j++ )
		{
			for ( int i = _dimensionRows - 1; i > j; i-- )
			{
				if ( fabs ( _A_largescale[i][j] ) > _epsilon )
				{
					if ( fabs ( _A_largescale[j][j] ) < _epsilon )
					{
						exchangeRows ( j, i );
					}
					else
					{
						_A_largescale[i][j] /= _A_largescale[j][j];
						_b[i] -= _A_largescale[i][j] * _b[j];
						for ( int k = j + 1; k < _dimensionRows; k++ )
						{
							_A_largescale[i][k] -= _A_largescale[i][j] * _A_largescale[j][k];
						}
					}
				}

				if ( fabs ( _A_largescale[j][j] ) < _epsilon )
				{
					throw yane::Utils::Exception( __DEBUGMESS ( "Matrix appears to be singular" ) );
				}
			}
		}
	}
	else
	{
		int dimC = _dimensionColumns;
		for ( int j = 0; j < dimC; j++ )
		{
			for ( int i = _dimensionRows - 1; i > j; i-- )
			{
				if ( fabs ( _A[i * dimC + j] ) > _epsilon )
				{
					if ( fabs ( _A[j * dimC + j] ) < _epsilon )
					{
						exchangeRows ( j, i );
					}
					else
					{
						_A[i * dimC + j] /= _A[j * dimC + j];
						_b[i] -= _A[i * dimC + j] * _b[j];
						for ( int k = j + 1; k < _dimensionRows; k++ )
						{
							_A[i * dimC + k] -= _A[i * dimC + j] * _A[j * dimC + k];
						}
					}
				}

				if ( fabs ( _A[j * dimC + j] ) < _epsilon )
				{
					throw yane::Utils::Exception( __DEBUGMESS ( "Matrix appears to be singular" ) );
				}
			}
		}
	}
}

LIB_EXPORT void yane::EqSys::Gauss::exchangeRows( int i, int j )
{
	double help;

	help = _b[j];
	_b[j] = _b[i];
	_b[i] = help;

	if ( _largescale )
	{
		for ( int k = 0; k < _dimensionColumns; k ++ )
		{
			help = _A_largescale[i][k];
			_A_largescale[i][k] = _A_largescale[j][k];
			_A_largescale[j][k] = help;
		}
	}
	else
	{
		int dimC = _dimensionColumns;
		for ( int k = 0; k < dimC; k ++ )
		{
			help = _A[i * dimC + k];
			_A[i * dimC + k] = _A[j * dimC + k];
			_A[j * dimC + k] = help;
		}
	}
}

