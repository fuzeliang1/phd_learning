/***************************************************************************
 *                                                                         *
 * Model Library                                                           *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

/** \namespace yane::Model
	\brief Namespace of the Model Library
 */

#ifndef YANE_MODEL_MAIN
#define YANE_MODEL_MAIN

#include "model/model.h"
#include "model/simulator.h"
#include "model/stateestimator.h"
#include "model/exceptions.h"

#endif
