/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

/** @namespace yane
	\brief Main namespace
 */

/** @namespace yane::MPC
	\brief Namespace of the Model Predictive Controller
 */

#ifndef _YANE_MPC_HEADERS
#define _YANE_MPC_HEADERS

#include "mpc/typedefs.h"
#include "mpc/exceptions.h"

#include "mpc/modelshootingdata.h"

#include "mpc/odemanager.h"
#include "mpc/simpleodemanager.h"
#include "mpc/cacheodemanager.h"
#include "mpc/multithreadcacheodemanager.h"
#include "mpc/syncodemanager.h"

#include "mpc/mpc.h"
#include "mpc/suboptimalitympc.h"
#include "mpc/adaptivempc.h"
#include "mpc/m21mpc.h"
#include "mpc/networkedmpcconfig.h"
#include "mpc/strategyexchangempc.h"
#include "mpc/strategyexchangempcparallel.h"
#include "mpc/dualdecompositionmpc.h"
#include "mpc/dualdecompositionmpcparallel.h"

#endif
