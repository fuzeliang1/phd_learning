/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_ODESOLVE_DOPRI_H
#define YANE_ODESOLVE_DOPRI_H

#include "odesolvefirst.h"

namespace yane
{
	namespace OdeSolve
	{

		/** \class DoPri
		 \brief Class of Dormand-Prince solvers for differential equation systems
		*/
		class DoPri : public OdeSolveFirst
		{
			public:

				virtual int functionEvalCount();
				virtual int computedSteps();
				virtual int acceptedSteps();
				virtual int rejectedSteps();


				virtual ~DoPri();

			protected:

				/**
				 * @brief Constructor
				 */
				DoPri ( );

				virtual void abstractCalc ( double t, double * rpar, int* ipar );

				virtual void assertConfig();

				virtual void assertValidDGL ( OdeFunction * dgl );

				/**
				 @brief Prototype for calling the Dormand-Prince differential equation solver
				 \param n Dimension of the state
				 \param FCN Pointer of the differential equation
				 \param x Initial time
				 \param y Initial value of the state
				 \param xend Terminal time
				 \param rtol Relative tolerance
				 \param atol Absolute tolerance
				 \param itol Decision variable
				 - \f$ itol = 0 \f$ Scalar error tolerances
				 - \f$ itol \geq 0 \f$ Vector error tolerances
				 \param solout Output function for continuous time output
				 \param iout Output parameter
				 - \f$ iout \geq 1 \f$ Output of the state vector for every accepted step
				 - \f$ iout = 0 \f$ No output, dummy function required
				 \param work reservierter Arbeitsspeicher fÃ¼r double-Werte
				 \param work Working array for double variables
				 \param lwork Size of working array for double variables
				 \param iwork Working array for integer variables
				 \param liwork Size of working array for integer variables
				 \param rpar Array for double parameters
				 \param ipar Array for integer parameters
				 \param did Error flag:
				 - \f$ _did = 1 \f$ Successful termination
				 - \f$ _did = 2 \f$ Successful termination with output via yane::OdeSolve::OdeSolve::_solout
				 - \f$ _did = -1 \f$ Input data is inconsistent
				 - \f$ _did = -2 \f$ Maximal number of steps reached
				 - \f$ _did = -3 \f$ Step size became too small
				 - \f$ _did = -4 \f$ Problem seems to be too stiff
				 */
				void ( * _dopri_func ) ( int * n, yane::OdeSolve::T_ODEFUNC FCN, double * x, double * y, double * xend, double * rtol, double * atol, int * itol, yane::OdeSolve::T_SOLOUTFUNC solout, int * iout, double * work, int* lwork, int * iwork, int * liwork, double * rpar, int * ipar, int * did );

		};

	}

}

#endif
