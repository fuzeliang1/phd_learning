/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "odeconfig.h"
#include "odesolex.h"

#include "../utils.h"

#include <string>
#include <sstream>
#include <iomanip>
#include <iostream>

#include "libexport.h"

using namespace std;
using namespace yane::Utils;

// #define ODECONFIGID "6047ec95-2810-4ef2-a7bb-ab6433d492b7"

LIB_EXPORT yane::OdeSolve::OdeConfig::OdeConfig()
{
	_setting_uuid = new yane::Utils::Uuid();
// config_type_id.insert ( std::string ( ODECONFIGID ) );

	setTolerance();
	setToleranceVector();
	setMaxSteps();
	setStepsizeSelectionParameters();
	setMaxStepsize();
	setInitialStepsize();
	setSafetyFactor();
}

LIB_EXPORT yane::OdeSolve::OdeConfig::~OdeConfig()
{
	delete _setting_uuid;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::setTolerance ( double rtol, double atol )
{
	if ( rtol <= 0.0 || atol <= 0.0 )
	{
		stringstream out;
		out << "positive values for rtol and atol expected, got ";
		out << setprecision ( 5 ) << scientific << "rtol=" << setprecision ( 5 ) << scientific << rtol << " and atol=" << atol;
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}
	_rtol = rtol;
	_atol = atol;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::setToleranceVector ( double * rtol, double * atol )
{
//  if ( rtol == 0 || atol == 0 )
//  {
//   stringstream out;
//   out << "yane::OdeSolve::OdeConfig::setToleranceVector(): uninitialized tolerance vectors supplied";
//   throw wrongSolverInputException ( out.str() );
//  }
	_rtol_vec = rtol;
	_atol_vec = atol;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::setMaxSteps ( int steps )
{
	if ( steps < 0 )
	{
		stringstream out;
		out << "steps must be greater then or equal to zero, got ";
		out << "steps=" << steps;
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}

	_max_steps = steps;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::setStepsizeSelectionParameters ( double fac1, double fac2 )
{
	if ( fac2 < fac1 || fac1 <= 0.0 )
	{
		stringstream out;
		out << "fac1 and fac2 must be greater then zero and fac1 <= fac2, got ";
		out << "fac1=" << setprecision ( 5 ) << scientific << fac1 << " and fac2=" << setprecision ( 5 ) << scientific << fac2;
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}
	_ss_fac1 = fac1;
	_ss_fac2 = fac2;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::setMaxStepsize ( double stepsize )
{
	if ( stepsize < 0.0 )
	{
		stringstream out;
		out << "stepsize must be greater then or equal to zero, got ";
		out << "stepsize=" << setprecision ( 5 ) << scientific << stepsize;
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}

	_max_stepsize = stepsize;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::setInitialStepsize ( double hinit )
{

	if ( hinit < 0.0 )
	{
		stringstream out;
		out << "hinit must be greater then or equal to zero, got ";
		out << "hinit=" << setprecision ( 5 ) << scientific << hinit;
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}

	_initial_stepsize = hinit;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::setSafetyFactor ( double safetyfactor )
{
	if ( safetyfactor <= 0.0 )
	{
		stringstream out;
		out << "safetyfactor must be greater then zero, got ";
		out << "safetyfactor=" << setprecision ( 5 ) << scientific << safetyfactor;
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}

	_safety_factor = safetyfactor;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::getTolerance ( double & rtol, double & atol )
{
	rtol = _rtol;
	atol = _atol;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::getToleranceVector ( double *& rtol, double *& atol )
{
	rtol = _rtol_vec;
	atol = _atol_vec;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::getMaxSteps ( int & steps )
{
	steps = _max_steps;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::getStepsizeSelectionParameters ( double & fac1, double & fac2 )
{
	fac1 = _ss_fac1;
	fac2 = _ss_fac2;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::getMaxStepsize ( double & stepsize )
{
	stepsize = _max_stepsize;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::getInitialStepsize ( double & hinit )
{
	hinit = _initial_stepsize;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::getSafetyFactor ( double & safetyfactor )
{
	safetyfactor = _safety_factor;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::invalidateOldConfig()
{
	_setting_uuid->reset();
}

LIB_EXPORT yane::Utils::Uuid * yane::OdeSolve::OdeConfig::configID()
{
	return _setting_uuid;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::assertValidConfigObject ( OdeConfig * config )
{
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::copyToNoInvalidation ( OdeConfig * target )
{
	target->_rtol = _rtol;
	target->_atol = _atol;
	target->_rtol_vec = _rtol_vec;
	target->_atol_vec = _atol_vec;
	target->_max_steps = _max_steps;
	target->_ss_fac1 = _ss_fac1;
	target->_ss_fac2 = _ss_fac2;
	target->_max_stepsize = _max_stepsize;
	target->_initial_stepsize = _initial_stepsize;
	target->_safety_factor = _safety_factor;
}

LIB_EXPORT void yane::OdeSolve::OdeConfig::copyTo ( OdeConfig * target )
{
	copyToNoInvalidation ( target );

	target->invalidateOldConfig();
}

LIB_EXPORT yane::OdeSolve::OdeConfig * yane::OdeSolve::OdeConfig::clone()
{
	OdeConfig * result = new OdeConfig();

	copyTo ( result );

	return result;
}
