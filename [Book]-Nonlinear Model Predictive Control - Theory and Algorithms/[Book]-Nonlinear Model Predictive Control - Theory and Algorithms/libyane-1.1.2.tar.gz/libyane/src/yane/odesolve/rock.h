/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */


#ifndef YANE_ODESOLVE_ROCK_H
#define YANE_ODESOLVE_ROCK_H

#include "odesolvefirst.h"

namespace yane
{
	namespace OdeSolve
	{

		class OdeConfig;

		/** \class ROCK
		 \brief Class of ROCK solvers for merely stiff differential equations (e.g. parabolic PDEs which are discretized using finite differences)
		*/
		class ROCK : public OdeSolveFirst
		{
			public:

				virtual int functionEvalCount();
				virtual int computedSteps();
				virtual int acceptedSteps();
				virtual int rejectedSteps();


				virtual ~ROCK();

			protected:

				ROCK ( );

				virtual void abstractCalc ( double t, double * rpar, int* ipar );

				virtual void assertConfig();
				virtual void assertValidDGL ( OdeFunction * dgl );

				/**
				 * @brief Prototype for calling the ROCK differential equation solver
				 * \param n Dimension of the state
				 * \param x Initial time
				 * \param xend Terminal time
				 * \param hinit Initial time step size
				 * \param y Initial value of the state
				 * \param FCN Pointer of the differential equation
				 * \param atol Absolute tolerance
				 * \param rtol Relative tolerance
				 * \param RHO Pointer for computation of the spectral radius
				 * \param solout Output function for continuous time output
				 * \param iout Output parameter
				 * - \f$ iout \geq 1 \f$ Output of the state vector for every accepted step
				 * - \f$ iout = 0 \f$ No output, dummy function required
				 * \param work Working array for double variables
				 * \param iwork Working array for integer variables
				 * \param rpar Array for double parameters
				 * \param ipar Array for integer parameters
				 * \param did Error flag:
				 *  - \f$ did = 1 \f$ Successful termination
				 *  - \f$ did = 2 \f$ Successful termination of one step, call function again
				 *  - \f$ did = -1 \f$ Input is inconsistent
				 *  - \f$ did = -2 \f$ Step size becomes too small
				 *  - \f$ did = -3 \f$ Internal method for approximating the spectral radius did not converge
				 */
				void ( *_rock_func ) ( int * n, double * x, double * xend, double * hinit, double * y,
									   yane::OdeSolve::T_ODEFUNC FCN, double * atol, double * rtol, yane::OdeSolve::T_RHOFUNC RHO, yane::OdeSolve::T_SOLOUTFUNC SOLOUT, int * iout, double * work, int * iwork, double * rpar, int * ipar, int * did );

				double _hinit;

		};

	}

}

#endif
