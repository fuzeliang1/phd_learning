/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "dopri.h"
#include "dopriconfig.h"
#include "odesolex.h"
#include "odefunction.h"

#include "../utils.h"

#include <cfloat>
#include <iostream>

#include "libexport.h"

using namespace yane::Utils;
using namespace std;

LIB_EXPORT yane::OdeSolve::DoPri::DoPri ( ) : OdeSolveFirst ( )
{
}

LIB_EXPORT void yane::OdeSolve::DoPri::abstractCalc ( double t, double * rpar, int* ipar )
{
	_dopri_func ( &_dimension, _paramdata.odefunc, & ( _t ), _y, &t, (_itol == 0 ? &_rtol : _rtol_vec), (_itol == 0 ? &_atol : _rtol_vec), &_itol, _paramdata.soloutfunc, &_paramdata.has_solout, _work, &_lwork, _iwork, &_liwork, rpar, ipar, &_did );

	if ( _did!=0 )
	{
		switch ( _did )
		{
			case -1: throw WrongSolverInputException(__DEBUGMESS("invalid solver initialization"));
			case -2: throw TooManyStepsException(__DEBUGMESS("solver needed too many steps"));
			case -3: throw TooSmallStepSizeException(__DEBUGMESS("the stepsize went too small"));
			case -4: throw StiffException(__DEBUGMESS("problem seems to bee stiff (dopri cannot solve stiff ODEs)"));
		}
	}
}

LIB_EXPORT void yane::OdeSolve::DoPri::assertConfig()
{
	DoPriConfig::assertValidConfigObject(_config);

	OdeSolve::assertConfig();

	((DoPriConfig*)_config)->getMaxSteps(_iwork[0]);
	((DoPriConfig*)_config)->getStiffnessTest(_iwork[3]);
	((DoPriConfig*)_config)->getSafetyFactor(_work[1]);
	((DoPriConfig*)_config)->getStepsizeSelectionParameters(_work[2], _work[3]);
	((DoPriConfig*)_config)->getMaxStepsize(_work[5]);
	((DoPriConfig*)_config)->getInitialStepsize(_work[6]);
	((DoPriConfig*)_config)->getBeta(_work[4]);

	_work[0] = DBL_EPSILON;
	_iwork[1] = 1;
	_iwork[2] = -1;
	_iwork[4] = 0;
}

LIB_EXPORT int yane::OdeSolve::DoPri::functionEvalCount()
{
	return _iwork[16];
}

LIB_EXPORT int yane::OdeSolve::DoPri::computedSteps()
{
	return _iwork[17];
}

LIB_EXPORT int yane::OdeSolve::DoPri::acceptedSteps()
{
	return _iwork[18];
}

LIB_EXPORT int yane::OdeSolve::DoPri::rejectedSteps()
{
	return _iwork[19];
}

LIB_EXPORT yane::OdeSolve::DoPri::~DoPri()
{
}

LIB_EXPORT void yane::OdeSolve::DoPri::assertValidDGL(OdeFunction * dgl)
{
	T_ODEPARAMS tempparams;
	dgl->getParams(&tempparams);

	if (tempparams.has_mas != 0) throw IncompatibleDGLException(__DEBUGMESS("Mass-Matrix is not supported by DoPri-solvers"));
}


