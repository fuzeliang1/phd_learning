/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_ODESOLVE_DOPRI5_H
#define YANE_ODESOLVE_DOPRI5_H

#include "dopri.h"

namespace yane
{
	namespace OdeSolve
	{

		/** \class DoPri5
			\brief Class of the Dormand-Prince5(4) solver for differential equation systems
		*/
		class DoPri5 : public DoPri
		{

			public:
				/**
				 * @brief Constructor
				 */
				DoPri5 ( );

				virtual OdeSolveFirst * clone();

				virtual ~DoPri5();


			protected:
				virtual void assertMemory();

		};

	}

}

#endif
