/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "odesolve.h"

#include "odesolex.h"
#include "odefunction.h"
#include "odeconfig.h"

#include "../utils.h"

#include <cstdlib>
#include <cstring>
#include <sstream>
#include <iostream>

#include "libexport.h"

using namespace  std;
using namespace yane::Utils;

LIB_EXPORT yane::OdeSolve::OdeSolve::OdeSolve ( )
{
	_work = 0;
	_iwork = 0;
	_config_id = new Uuid;
	_config_id->setNull();

	_initial_value_set = false;

	_func = 0;
	_config = 0;
}

LIB_EXPORT yane::OdeSolve::OdeSolve::~OdeSolve()
{
	if ( _work != 0 ) delete[] _work;
	if ( _iwork != 0 ) delete[] _iwork;
	delete _config_id;
}

LIB_EXPORT void yane::OdeSolve::OdeSolve::reset ( OdeFunction * func, OdeConfig * config )
{
	if ( func == 0 )
	{
		throw WrongSolverInputException ( __DEBUGMESS ( "giving a NULL-Pointer as OdeFunction-Object to the reset()-Method is not supported" ) );
	}
	if ( config == 0 )
	{
		throw WrongSolverInputException ( __DEBUGMESS ( "giving a NULL-Pointer as OdeConfig-Object to the reset()-Method is not supported" ) );
	}
	assertValidDGL ( func );

	_func = func;
	_func->getParams ( &_paramdata );
	_dimension = _paramdata.dimension;

	_config = config;
	_config_id->setNull();

	try
	{
		assertMemory();
	}
	catch ( MemoryException e )
	{
		throw MemoryException ( __DEBUGMESS ( "The differential equation solver was unable to allocate the required memory" ), &e );
	}
	catch ( OdeSolEx e )
	{
		throw OdeSolEx ( __EXCEPTIONMESS ( OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "memory could not be asserted" ), &e );
	}

	try
	{
		refreshConfig();
	}
	catch ( IncompatibleConfigException e )
	{
		throw IncompatibleConfigException ( __DEBUGMESS ( "invalid configuration object" ), &e );
	}
	catch ( OdeSolEx e )
	{
		throw OdeSolEx ( __EXCEPTIONMESS ( OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Configuration of the differential equation solver could not be refreshed" ), &e );
	}
}

LIB_EXPORT void yane::OdeSolve::OdeSolve::assertConfig()
{
	_config->getTolerance ( _rtol, _atol );
	_config->getToleranceVector ( _rtol_vec, _atol_vec );

	_itol = ( _rtol_vec != 0 && _atol_vec != 0 );

}

LIB_EXPORT void yane::OdeSolve::OdeSolve::refreshConfig()
{
	if ( _config == 0 )
	{
		throw NotInitializedException ( __DEBUGMESS ( "Object must be initialized before calling refreshConfig()" ) );
	}

	Uuid * tmpuuid = _config->configID();
	if ( *tmpuuid != *_config_id ) assertConfig();
	*_config_id = *_config->configID();
}

LIB_EXPORT void yane::OdeSolve::OdeSolve::assertValidDGL ( OdeFunction * dgl )
{
}

LIB_EXPORT void yane::OdeSolve::OdeSolve::resize ( int dimension )
{
	if ( _func == 0 || _config == 0 )
	{
		throw NotInitializedException ( __DEBUGMESS ( "Object must be initialized before calling refreshConfig()" ) );
	}
	if ( dimension <= 0 )
	{
		stringstream out;
		out << "dimension must be greater then zero, got ";
		out << "dimension=" << dimension;
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}
	if ( dimension > _paramdata.dimension )
	{
		stringstream out;
		out << "dimension exceeds maximum size set by reset()-method, got ";
		out << "dimension=" << dimension << " but must be smaller then or equal to " << _paramdata.dimension;
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}

	_dimension = dimension;

	assertConfig();
	_config_id = _config->configID();
}

LIB_EXPORT void yane::OdeSolve::OdeSolve::calc ( double t, double * rpar, int * ipar )
{
	if ( _func == 0 || _config == 0 )
	{
		throw NotInitializedException ( __DEBUGMESS ( "Object must be initialized before calling calc()" ) );
	}
	if ( !_initial_value_set )
	{
		throw NoInitialValueException ( __DEBUGMESS ( "initial value has not been set before by calling the calc()-method." ) );
	}

	try
	{
		abstractCalc ( t, rpar, ipar );
	}
	catch ( OdeSolEx e )
	{
		throw OdeSolEx ( __EXCEPTIONMESS ( OdeSolEx::TYPE, "Calculation error" ), __DEBUGMESS ( "An error occured during calculating" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Calculation error" ), __DEBUGMESS ( "An error occured during calculating" ), &e );
	}

	_t = t;
}

