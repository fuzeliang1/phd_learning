/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_RECURSESEQUENCE_H
#define YANE_ODESOLVE_RECURSESEQUENCE_H

#include "odesolvefirst.h"

namespace yane
{
	namespace OdeSolve
	{

		/**
		 * In constrast to the differential equation system solver, the purpose of this class is to provide a solver for difference equation systems which exhibits an identical frondend. For this reason, the implemented solver computes a sequence of state vectors instead of a approximated solution of a differential equation system. \n
		 Once the function yane::OdeSolve::OdeSolve::calc has been called, this solver evaluates the right hand side defined in the yane::OdeSolve::OdeFunction object. The results are given by a double array of length 2 for the time grid, consisting of the initial time and the terminal time, and the initial value for the state is overwritten.
		 * @brief Class to solve difference equation systems
		*/
		class RecurseSequence : public OdeSolveFirst
		{
			public:
				/**
				 * @brief Constructor
				 */
				RecurseSequence ( );

				virtual ~RecurseSequence();

				virtual OdeSolveFirst * clone();

				virtual int acceptedSteps();

				virtual int computedSteps();

				virtual int functionEvalCount();

				virtual int rejectedSteps();


			protected:

				virtual void abstractCalc ( double t, double * rpar=0, int* ipar=0 );

				virtual void assertMemory();
				virtual void assertValidDGL(OdeFunction * dgl);

				bool _hascalced;			/**< @brief Decision variable if computation has been executed */
				double * _tfield;			/**< @brief Time grid */
				double * _tempy;			/**< @brief Auxilliary variable to compute the solution of the difference equation */
		};

	}

}


#endif
