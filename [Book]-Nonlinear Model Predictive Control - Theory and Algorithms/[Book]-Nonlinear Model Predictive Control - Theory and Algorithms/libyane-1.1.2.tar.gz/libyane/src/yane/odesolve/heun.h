/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Arthur Fleig <arthur.fleig@stmail.uni-bayreuth.de>                    *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Wolfgang Riedl <wolfgang.riedl@stmail.uni-bayreuth.de>                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	 @file
	 @author Arthur Fleig <arthur.fleig@stmail.uni-bayreuth.de>
	 @author Juergen Pannek <juergen.pannek@googlemail.com>
	 @author Wolfgang Riedl <wolfgang.riedl@stmail.uni-bayreuth.de>
	 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_HEUN_H
#define YANE_ODESOLVE_HEUN_H

#include "../odesolve.h"

namespace yane
{
	namespace OdeSolve
	{

		/**
		 * @brief Class of Heun solver for differential equation systems
		 */
		class Heun : public OdeSolveFirst
		{
			public:
				/**
				* @brief Constructor
				* @param h Step size of the Heun method
				 */
				Heun ( double h );

				virtual ~Heun();

				virtual OdeSolveFirst * clone();

				virtual int acceptedSteps();

				virtual int computedSteps();

				virtual int functionEvalCount();

				virtual int rejectedSteps();

				/**
				 * @brief Function to set the step size of the Heun method
				 * @param h Step size of the Heun method
				 */
				virtual void setStepsize ( double h );

				/**
				@brief Function to obtain the stepsize
				 */
				virtual double stepsize ( void );


			protected:

				virtual void abstractCalc ( double t, double * rpar = 0, int* ipar = 0 );

				virtual void assertMemory();
				virtual void assertValidDGL ( OdeFunction * dgl );

				double * _tempy, * _tempy2, * _y2;  /**< @brief Auxilliary variables to save the state vector */
				int _steps;   /**< @brief Step counter */
				double _h;   /**< @brief Step size */
		};

	}

}

#endif
