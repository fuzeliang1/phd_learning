/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "rock2.h"
#include "odesolex.h"

#include "../utils.h"

#include <cstdlib>
#include <cstring>
#include <cfloat>

#include "libexport.h"

using namespace yane::Utils;

#define __FORTRANNAME(x) x##_
extern "C"
{
	void __FORTRANNAME ( rock2 ) ( int * _n, double * _x, double * _xend, double * _hinit, double * _y,
								 yane::OdeSolve::T_ODEFUNC FCN, double * _atol, double * _rtol, yane::OdeSolve::T_RHOFUNC RHO, yane::OdeSolve::T_SOLOUTFUNC SOLOUT, int * iout, double * _work, int * _iwork, double * _rpar, int * _ipar, int * _did );
}


LIB_EXPORT yane::OdeSolve::ROCK2::ROCK2 ( ) : ROCK ( )
{

	_rock_func = __FORTRANNAME ( rock2 );
}

LIB_EXPORT void yane::OdeSolve::ROCK2::assertMemory()
{
	_lwork = 4 * ( unsigned int ) _dimension;
	if ( _paramdata.has_rho == 0 ) _lwork += ( unsigned int ) _dimension;
	_liwork = 12;

	if ( _work != 0 ) delete _work;
	if ( _iwork != 0 ) delete _iwork;

	try
	{
		_work = new double[_lwork];
		_iwork = new int[_liwork];
	}
	catch ( std::bad_alloc )
	{
		throw MemoryException ( __DEBUGMESS ( "failed to allocate working-arrays" ) );
	}

}

LIB_EXPORT yane::OdeSolve::OdeSolveFirst * yane::OdeSolve::ROCK2::clone()
{
	return new ROCK2();
}

LIB_EXPORT yane::OdeSolve::ROCK2::~ ROCK2()
{
}
