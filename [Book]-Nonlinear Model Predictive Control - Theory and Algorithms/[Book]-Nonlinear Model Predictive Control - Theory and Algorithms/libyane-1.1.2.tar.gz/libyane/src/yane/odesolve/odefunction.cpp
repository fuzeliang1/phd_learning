/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "odefunction.h"

#include <cstring>

#include "libexport.h"

LIB_EXPORT yane::OdeSolve::OdeFunction::OdeFunction ( T_ODEFUNC ode, int dim )
{
	_paramdata.dimension = dim;
	_paramdata.odefunc = ode;

	_paramdata.jacobifunc = 0;
	_paramdata.massfunc = 0;
	_paramdata.dftfunc = 0;

	_paramdata.has_jac = 0;
	_paramdata.has_mas = 0;
	_paramdata.has_dft = 0;

	_paramdata.ljac = dim;
	_paramdata.ujac = dim;
	_paramdata.lmas = dim;
	_paramdata.umas = dim;

	_paramdata.autonome = 0;

	_paramdata.rhofunc = 0;
	_paramdata.has_rho = 0;
	_paramdata.rho_is_constant = 0;
	
	_paramdata.soloutfunc = 0;
	_paramdata.has_solout = 0;
}

LIB_EXPORT yane::OdeSolve::OdeFunction::~ OdeFunction()
{
}

LIB_EXPORT void yane::OdeSolve::OdeFunction::setJacobiMatrix ( T_JACFUNC func, int ljac, int ujac )
{
	_paramdata.jacobifunc = func;
	_paramdata.ljac = ( ljac == -1 ? _paramdata.dimension : ljac );
	_paramdata.ujac = ( ujac == -1 ? _paramdata.dimension : ujac );
	_paramdata.has_jac = ( func != 0 ? 1 : 0 );
}

LIB_EXPORT void yane::OdeSolve::OdeFunction::setMassMatrix ( T_MASSFUNC func, int lmas, int umas )
{
	_paramdata.massfunc = func;
	_paramdata.lmas = ( lmas == -1 ? _paramdata.dimension : lmas );
	_paramdata.umas = ( umas == -1 ? _paramdata.dimension : umas );
	_paramdata.has_mas = ( func != 0 ? 1 : 0 );
}

LIB_EXPORT void yane::OdeSolve::OdeFunction::setAutonomeMode ( bool autonome, T_DFTFUNC func )
{
	_paramdata.dftfunc = func;
	_paramdata.has_dft = ( func != 0 ? 1 : 0 );
	_paramdata.autonome = ( autonome == true ? 0 : 1 );
}

LIB_EXPORT void yane::OdeSolve::OdeFunction::getParams ( T_ODEPARAMS * params )
{
	memcpy ( params, &_paramdata, sizeof ( T_ODEPARAMS ) );
}

LIB_EXPORT void yane::OdeSolve::OdeFunction::setRho ( bool is_constant, T_RHOFUNC func )
{
	_paramdata.rhofunc = func;
	_paramdata.has_rho = ( func != 0 ? 1 : 0 );
	_paramdata.rho_is_constant = ( is_constant == true ? 1 : 0 );
}

LIB_EXPORT void yane::OdeSolve::OdeFunction::setSolutionOutput(T_SOLOUTFUNC func)
{
	_paramdata.soloutfunc = func;
	_paramdata.has_solout = ( func != 0 ? 1 : 0 );
}
