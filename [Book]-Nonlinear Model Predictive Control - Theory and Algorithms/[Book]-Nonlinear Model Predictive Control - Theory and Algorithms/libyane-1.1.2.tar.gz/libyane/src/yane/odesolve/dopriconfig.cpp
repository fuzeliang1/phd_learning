/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "dopriconfig.h"
#include "odesolex.h"

#include "../utils.h"

#include <string>
#include <sstream>
#include <iomanip>
#include <iostream>

#include "libexport.h"

using namespace yane::Utils;
using namespace std;

//#define DOPRICONFIGID "fa694a15-0e28-4e46-a4f5-3e14444f82f3"

LIB_EXPORT yane::OdeSolve::DoPriConfig::DoPriConfig() :
		yane::OdeSolve::OdeConfig()
{
//	config_type_id.insert(std::string(DOPRICONFIGID));

	setStiffnessTest();
	setBeta();
}

LIB_EXPORT yane::OdeSolve::DoPriConfig::~ DoPriConfig()
{
}

LIB_EXPORT void yane::OdeSolve::DoPriConfig::setStiffnessTest(int teststeps)
{
	_stiff_teststeps = teststeps;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::DoPriConfig::setBeta(double beta)
{
	if ( beta < 0.0 || beta > 0.1 ) {
		std::stringstream out;
		out << "got invalid beta=" << std::setprecision(6) << std::scientific<< beta << ", valid values are 0.0 <= beta <= 0.1";
		throw WrongSolverInputException(__DEBUGMESS(out.str()));
	}
	_beta = beta;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::DoPriConfig::getStiffnessTest(int & teststeps)
{
	teststeps = _stiff_teststeps;
}

LIB_EXPORT void yane::OdeSolve::DoPriConfig::getBeta(double & beta)
{
	beta = _beta;
}

LIB_EXPORT void yane::OdeSolve::DoPriConfig::assertValidConfigObject(OdeConfig * config)
{
	DoPriConfig * dopriconf = dynamic_cast<DoPriConfig*>(config);

	if (!dopriconf ) throw IncompatibleConfigException(__DEBUGMESS("Configtype 'DoPriConfig' or derived type expected, but got something else"));
}

LIB_EXPORT void yane::OdeSolve::DoPriConfig::copyToNoInvalidation(OdeConfig * target)
{
	assertValidConfigObject(target);

	OdeConfig::copyToNoInvalidation(target);

	DoPriConfig * dopritarget = (DoPriConfig*)target;

	dopritarget->_stiff_teststeps = _stiff_teststeps;
	dopritarget->_beta = _beta;
}

LIB_EXPORT yane::OdeSolve::OdeConfig * yane::OdeSolve::DoPriConfig::clone()
{
	DoPriConfig * result = new DoPriConfig();

	copyTo(result);

	return result;
}




