/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "radauconfig.h"
#include "odesolex.h"

#include "../utils.h"

#include <string>
#include <sstream>

#include "libexport.h"

using namespace yane::Utils;
using namespace std;

//#define RADAUCONFIGID "03fbf0f4-dbcd-43dc-bdfc-ef5ad003af0b"

LIB_EXPORT yane::OdeSolve::RadauConfig::RadauConfig() :
		yane::OdeSolve::OdeConfig()
{
//	config_type_id.insert(std::string(RADAUCONFIGID));

	setHessenbergTransformation();
	setMaxNewtonSteps();
	setJacobiRecomputation();
	setStepsizeStrategy();
	setStepsizeFixingParameters();
}

LIB_EXPORT yane::OdeSolve::RadauConfig::~ RadauConfig()
{
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::assertValidConfigObject(OdeConfig * config)
{
	RadauConfig * conf = dynamic_cast<RadauConfig*>(config);

	if (!conf )	throw IncompatibleConfigException(__DEBUGMESS("Configtype 'RadauConfig' or derived type expected, but got something else"));
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::setHessenbergTransformation(int enable)
{
	_enable_hessenberg = enable;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::getHessenbergTransformation(int & enable)
{
	enable = _enable_hessenberg;
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::setMaxNewtonSteps(int steps)
{
	if (steps < 1)
	{
		stringstream out;
		out << "maximum Newton-steps in Radau-solver must be greater then zero, got ";
		out << "steps=" << steps;
		throw WrongSolverInputException(__DEBUGMESS(out.str()));
	}
	_newton_steps = steps;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::getMaxNewtonSteps(int & steps)
{
	steps = _newton_steps;
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::setJacobiRecomputation(double step)
{
	_jac_step = step;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::getJacobiRecomputation(double & step)
{
	step = _jac_step;
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::setStepsizeStrategy(T_STEPSIZESTRATEGY strategy)
{
	if (strategy != Gustaffson && strategy != Classic)
	{
		stringstream out;
		out << "Unknown stepsize-strategy '" << (int)strategy << "'. ";
		out << "Supported strategies are Gustaffson '" << (int)Gustaffson << "' and Classic '" << (int)Classic << "'.";
		throw WrongSolverInputException(__DEBUGMESS(out.str()));
	}

	_strat = strategy;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::getStepsizeStrategy(T_STEPSIZESTRATEGY & strategy)
{
	strategy = _strat;
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::setStepsizeFixingParameters(double fac1, double fac2)
{
	if (fac2 < fac1)
	{
		stringstream out;
		out << "fac2 (=" << fac2 << ") must be greater then or equal to fac1 (=" << fac1 << ")";
		throw WrongSolverInputException(__DEBUGMESS(out.str()));
	}
	_sf_fac1 = fac1;
	_sf_fac2 = fac2;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::getStepsizeFixingParameters(double & fac1, double & fac2)
{
	fac1 = _sf_fac1;
	fac2 = _sf_fac2;
}

LIB_EXPORT void yane::OdeSolve::RadauConfig::copyToNoInvalidation(OdeConfig * target)
{
	assertValidConfigObject(target);

	OdeConfig::copyToNoInvalidation(target);

	RadauConfig * radautarget = (RadauConfig*)target;

	radautarget->_enable_hessenberg = _enable_hessenberg;
	radautarget->_newton_steps = _newton_steps;
	radautarget->_jac_step = _jac_step;
	radautarget->_strat = _strat;
	radautarget->_sf_fac1 = _sf_fac1;
	radautarget->_sf_fac2 = _sf_fac2;

}

LIB_EXPORT yane::OdeSolve::OdeConfig * yane::OdeSolve::RadauConfig::clone()
{
	RadauConfig * result = new RadauConfig();

	copyTo(result);

	return result;
}



