/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_TYPEDEFS_H
#define YANE_ODESOLVE_TYPEDEFS_H

namespace yane
{
	namespace OdeSolve
	{
		/** @enum T_STEPSIZESTRATEGY
		@Brief Enumerator for the choice of the step size control method \n
		- Gustaffson method which gives safer results for simple problems
		- Classic method which is usually faster
		*/
		typedef enum
		{
			Gustaffson = 1,
			Classic = 2
		} T_STEPSIZESTRATEGY;

		typedef void ( * T_ODEFUNC ) ( int * n, double * t, double * y, double * dy, double * rpar, int * ipar );
		/**< @brief Typedef defining the right hand side of the differential equation system */

		typedef void ( * T_JACFUNC ) ( int * n, double * t, double * y, double * dfy, int * ldfy, double * rpar, int* ipar );
		/**< @brief Typedef defining the jacobian of the differential equation system */

		typedef void ( * T_MASSFUNC ) ( int * n, double * mas, int * lmas, double * rpar, int * ipar );
		/**< @brief Typedef defining the mass matrix of the differential equation system */

		typedef void ( * T_DFTFUNC ) ( int * n, double * t, double * y, double * ft, double * rpar, int * ipar );
		/**< @brief Typedef defining the time derivative of the right hand side of the differential equation system */

		typedef double ( * T_RHOFUNC ) ( int * n, double * t, double * y, double * rpar, int * ipar );
		/**< @brief Typedef defining the function for the spectral radius of the differential equation system */

		typedef void ( * T_SOLOUTFUNC ) ( int * nr, double * t_old, double * t, double * y, int * n, double * cont, int * icont, int * nrd, double * rpar, int* ipar, int* ireturn );
		/**< @brief Typedef defining the function for the continuous time output of the solution of the differential equation system */


		/**< @struct T_ODEPARAMS
		@brief Parameter of the differential equation system
		 */
		typedef struct
		{
			int dimension;		/**< @brief Dimension of the state */

			T_ODEFUNC odefunc;	/**< @brief Differential equation system */
			T_JACFUNC jacobifunc;	/**< @brief Jacobian of the differential equation system */
			T_MASSFUNC massfunc;	/**< @brief Mass matrix of the differential equation system*/
			T_DFTFUNC dftfunc;	/**< @brief Time derivative of the differential equation system */
			T_RHOFUNC rhofunc;	/**< @brief Function to compute the spectral radius of the differential equation system */
			T_SOLOUTFUNC soloutfunc;	/**< @brief Solution output function */

			int ljac;		/**< @brief Number of subdiagonals of the Jacobian */
			int ujac;		/**< @brief Number of superdiagonals of the Jacobian */
			int has_jac;		/**< @brief Evaluation of the Jacobian \n
						- 0: numerically
						- 1: analytically */

			int lmas;		/**< @brief Number of subdiagonals of the mass matrix */
			int umas;		/**< @brief Number of superdiagonals of the mass matrix */
			int has_mas;		/**< @brief Decision variable \n
			 			- 0: No mass matrix, use identity
						- 1: Mass matrix is supplied */

			int autonome;		/**< @brief Type of the differential equation system \n
			 			- 0: autonomous
						- 1: nonautonomous */
			int has_dft;		/**< @brief Computation of the time derivative of the differential equation system \n
			 			- 0: numerically
						- 1: analytically */
			int has_rho;		/**< @brief Computation of the spectral radius of the differential equation system \n
						- 0: ROCK computes spectral radius by itself
						- 1: External function is supplied */
			int rho_is_constant;	/**< @brief Property of the spectral radius \n
						- 0: Radius is time variable
						- 1: Radius is constant */

			int has_solout;		/**< @brief Sets whether the solout function is called. \n
						- 0: Function is not called.
						- 1: Function is called. */
		} T_ODEPARAMS;
	}
}

#endif
