/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_RODASCONFIG_H
#define YANE_ODESOLVE_RODASCONFIG_H

#include "odeconfig.h"

namespace yane
{

	namespace OdeSolve
	{
		/**
		 * This class includes all configuration methods for the Rodas solver. \n
		 * Atter construction of an object of this class it is initialized with default values which usually give good results. Still, the parameters of the class should be adapted to the considered yane::Model::Model object.
		 * @brief Class to configure all Radau solvers
		 */
	
		class RodasConfig  : public OdeConfig
		{
			public:
				RodasConfig();

				~RodasConfig();
				
				/**
				 * This function sets the choice of the coefficients
				 * IF IWORK(2).EQ.1  METHOD (SEE BOOK, PAGE 452)	
				 * IF IWORK(2).EQ.2  SAME METHOD WITH DIFFERENT PARAMETERS
				 * IF IWORK(2).EQ.3  METHOD WITH COEFF. OF GERD STEINEBACH
				 * THE DEFAULT VALUE (FOR IWORK(2)=0) IS IWORK(2)=1.
				 * @param choice choice of the coefficients
				 * @brief Function to set the choice of the coefficients
				 */
				void setCoefficientChoice(int choice = 0);
				
				/**
				 * This function can be used to obtain the choice of the coefficients
				 * @sa setCoefficientChoice
				 * @param choice choice of the coefficients
				 * @brief Function to obtain the choice of the coefficients
				 */
				void getCoefficientChoice(int & choice);
				
				/**
				 * This function sets the strategy of step size computation
				 * @sa STEPSIZESTRATEGY
				 * @sa getStepsizeStrategy
				 * @param strategy Strategy of step size computation
				 * @throw WrongSolverInputException Is thrown if an invalid strategy is to be used
				 * @brief Function to set the strategy of step size computation
				 */
				void setStepsizeStrategy ( T_STEPSIZESTRATEGY strategy = Gustaffson );

				/**
				 * This function can be used to obtain the strategy of step size computation
				 * @sa STEPSIZESTRATEGY
				 * @sa setStepsizeStrategy
				 * @param strategy Strategy of step size computation
				 * @brief Function to obtain the strategy of step size computation
				 */
				void getStepsizeStrategy ( T_STEPSIZESTRATEGY & strategy );
				
								/**
				 * This function overloads the standard method. It checks whether the supplied yane::OdeSolve::OdeConfig object possesses the ID of a yane::OdeSolve::RodasConfig class and is therefore valid.
				 * @param config Configuration object to be checked
				 * @brief Function to check whether a supplied configuration object is of type yane::OdeSolve::RodasConfig
				 */
				static void assertValidConfigObject ( OdeConfig * config );
				
				virtual OdeConfig * clone();
				
			protected:

				virtual void copyToNoInvalidation ( OdeConfig * target );
			
				T_STEPSIZESTRATEGY _strat;	/**< @brief Strategy of the step size control algorithm */
				int _coeff_choice; /**< @brief Choice of the coefficients */

		};

	}

}

#endif
