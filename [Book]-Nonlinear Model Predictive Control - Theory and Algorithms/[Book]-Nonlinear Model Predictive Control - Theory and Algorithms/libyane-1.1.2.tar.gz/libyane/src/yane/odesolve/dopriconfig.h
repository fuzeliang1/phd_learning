/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_ODESOLVE_DOPRICONFIG_H
#define YANE_ODESOLVE_DOPRICONFIG_H

#include "odeconfig.h"

namespace yane
{

	namespace OdeSolve
	{

		/**
		 * This class includes all configuration methods for all DoPri solvers. \n
		 * Atter construction of an object of this class it is initialized with default values which usually give good results. Still, the parameters of the class should be adapted to the considered yane::Model::Model object.
		 * @brief Class to configure all DoPri solvers
		 */
		class DoPriConfig : public OdeConfig
		{
			public:
				/**
				 * @brief Constructor
				 */
				DoPriConfig();

				/**
				 * @brief Destructor
				 */
				virtual ~DoPriConfig();

				/**
				 * This function sets the number of steps which shall be used to test whether the problem is stiff. Note that supplying a value lower than zero deactivates this test for stiffness.
				 * @param teststeps Number of steps for stiffness test
				 * @sa getStiffnessTest
				 * @brief Function to set the number of steps which shall be used to test for stiffness of the system
				 */
				void setStiffnessTest ( int teststeps = 1000 );

				/**
				 * This function can be used to obtain the number of steps which shall be used to test whether the problem is stiff.
				 * @param teststeps Number of steps for stiffness test
				 * @sa getStiffnessTest
				 * @brief Function to obtain the number of steps which shall be used to test for stiffness of the system
				 */
				void getStiffnessTest ( int & teststeps );


				/**
				 * This function sets the value for stabilizing the step size computation. These values are required to satisfy @f$ 0 \leq beta \leq 0.1 @f$. Note that larger values leave the step size computation to be more stable.
				 * @param beta Value of the stabilizing value used within the step size computation
				 * @throw WrongSolverInputException Is thrown if an invalid value is supplied
				 * @sa getBeta
				 */
				void setBeta ( double beta = 4E-2 );

				/**
				 * This function can be used to obtain the value for stabilizing the step size computation.
				 * @param beta Value of the stabilizing value used within the step size computation
				 * @sa setBeta
				 */
				void getBeta ( double & beta );

				/**
				 * This function overloads the standard method. It checks whether the supplied yane::OdeSolve::OdeConfig object possesses the ID of a yane::OdeSolve::DoPriConfig class and is therefore valid.
				 * @param config Configuration object to be checked
				 * @brief Function to check whether a supplied configuration object is of type yane::OdeSolve::DoPriConfig
				 */
				static void assertValidConfigObject ( OdeConfig * config );

				virtual OdeConfig * clone();

			protected:

				virtual void copyToNoInvalidation ( OdeConfig * target );

				int _stiff_teststeps;	/**< @brief Number of steps for stiffness test */
				double _beta;		/**< @brief Value of the stabilizing value used within the step size computation */
		};

	}

}

#endif
