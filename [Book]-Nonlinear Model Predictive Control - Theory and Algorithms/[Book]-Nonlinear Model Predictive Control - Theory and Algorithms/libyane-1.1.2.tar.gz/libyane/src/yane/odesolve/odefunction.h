/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_ODESOLVE_ODEFUNCTION_H
#define YANE_ODESOLVE_ODEFUNCTION_H

#include "typedefs.h"

namespace yane
{
	namespace OdeSolve
	{
		/**
		 * This class assembles all data of the differential equation system and makes it accessable for the differential equation solver. Depending on the type of solver to be used, different data is required and stored.
		 *
		 * An object of this class is fully configurated after calling the constructor and may be used within any of the solvers. In some cases, however, one should provide an analytically computed Jacobian to speed up the computation.
		 * @brief Class for transferring data from the user to the yane::OdeSolve::OdeSolve object
		 */
		class OdeFunction
		{
			public:

				/**
				 * Upon construction, this object is initialized without Jacobian and mass matrix. Hence, if a method requires the use of the Jacobian or the mass matrix, this will be done numerically and it is assumed that these matrices are full. Moreover, by default the differential equation system is considered to be autonomous and no derivative of the differential equation system with respect to time is defined
				 * @param ode Pointer of the differential equation system
				 * @param dim Dimension of the state variable
				 * @brief Constructor
				 */
				OdeFunction ( T_ODEFUNC ode, int dim );


				/**
				 * @brief Destructor
				 */
				virtual ~OdeFunction();

				/**
				 * @brief Function to provide the Jacobian of the differential equation system
				 * @param func Pointer of the Jacobian. If func = 0 then the Jacobian is computed numerically
				 * @param ljac Number of subdiagonals of the Jacobian (band structure). If ljac = -1 the Jacobian is assumed to be full
				 * @param ujac Number of superdiagonals of the Jacobian (band structure). If ujac = -1 the Jacobian is assumed to be full
				 */
				void setJacobiMatrix ( T_JACFUNC func, int ljac = -1, int ujac = -1 );


				/**
				 * @brief Function to provide the mass matrix of the differential equation system
				 * @param func Pointer of the mass matrix. If func = 0 then the identity matrix is used
				 * @param lmas Number of subdiagonals of the mass matrix (band structure). If lmas = -1 the Jacobian is assumed to be full
				 * @param umas Number of superdiagonals of the mass matrix (band structure). If umas = -1 the Jacobian is assumed to be full
				 */
				void setMassMatrix ( T_MASSFUNC func, int lmas = -1, int umas = -1 );

				/**
				 * @brief Function to set the spectral radius of the differential equation system
				 * @param func Pointer of the function to compute the spectral radius
				 * @param is_constant Decision variable if the spectral radius is constant in time
				 */
				void setRho ( bool is_constant, T_RHOFUNC func = 0);
				
				/**
				 * @brief Function to set the solution output function.
				 * @param func Pointer of the solution output function which is called after each accepted step.
				 */
				void setSolutionOutput ( T_SOLOUTFUNC func);

				/**
				 * @brief Function to define if the differential equation system is autonomous (default)
				 * @param autonome Decision variable if the differential equation system is autonomous
				 * @param func Pointer of the time derivative of the differential equation system
				 */
				
				void setAutonomeMode ( bool autonome, T_DFTFUNC func = 0 );


				/**
				 * @brief Function to set the parameters of the differential equation system
				 * @param params Pointer to an external structure
				 */
				void getParams ( T_ODEPARAMS * params );
			private:

				T_ODEPARAMS _paramdata; /**< @brief Structure to save the parameters of the differential equation system */
		};

	}

}

#endif
