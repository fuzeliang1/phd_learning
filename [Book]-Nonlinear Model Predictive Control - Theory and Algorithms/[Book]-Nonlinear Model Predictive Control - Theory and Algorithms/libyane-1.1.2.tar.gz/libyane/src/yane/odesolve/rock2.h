/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_ROCK2_H
#define YANE_ODESOLVE_ROCK2_H

#include "rock.h"

namespace yane
{
	namespace OdeSolve
	{


		/** \class ROCK2
		\brief Class of ROCK solver of order 2 for merely stiff differential equations
		*/
		class ROCK2 : public ROCK
		{

			public:
				/**
				 * @brief Constructor
				 */
				ROCK2 ( );

				virtual OdeSolveFirst * clone();
				virtual ~ROCK2();


			protected:
				virtual void assertMemory();

		};

	}

}

#endif
