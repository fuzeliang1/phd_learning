/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_RADAU5913_H
#define YANE_ODESOLVE_RADAU5913_H

#include "radau.h"

namespace yane
{
	namespace OdeSolve
	{

		/** \class Radau5913
		\brief Class of Radau5913 solver for differential equation systems
		*/
		class Radau5913 : public Radau
		{
			public:
				/**
				 * @brief Constructor
				 */
				Radau5913 ( );

				virtual ~Radau5913();

				virtual OdeSolveFirst * clone();

			protected:
				virtual void assertMemory();
				virtual void assertConfig();


		};

	}

}

#endif
