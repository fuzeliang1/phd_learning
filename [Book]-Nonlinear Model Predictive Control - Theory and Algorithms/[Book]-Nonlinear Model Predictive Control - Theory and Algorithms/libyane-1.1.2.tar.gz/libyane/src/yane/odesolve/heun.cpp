/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Arthur Fleig <arthur.fleig@stmail.uni-bayreuth.de>                    *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Wolfgang Riedl <wolfgang.riedl@stmail.uni-bayreuth.de>                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	 @file
	 @author Arthur Fleig <arthur.fleig@stmail.uni-bayreuth.de>
	 @author Juergen Pannek <juergen.pannek@googlemail.com>
	 @author Wolfgang Riedl <wolfgang.riedl@stmail.uni-bayreuth.de>
	 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "heun.h"

#include "../utils.h"

#include <cstring>

#include "libexport.h"

using namespace yane::Utils;

LIB_EXPORT yane::OdeSolve::Heun::Heun ( double h )
{
	_h = h;
	_tempy = 0;
	_tempy2 = 0;
	_y2 = 0;
	_steps = 0;
}

LIB_EXPORT yane::OdeSolve::Heun::~ Heun()
{
	if ( _tempy != 0 ) delete[] _tempy;
	if ( _tempy2 != 0 ) delete[] _tempy2;
	if ( _y2 != 0 ) delete[] _y2;
	_tempy = 0;
	_tempy2 = 0;
	_y2 = 0;
}

LIB_EXPORT void yane::OdeSolve::Heun::assertMemory()
{
	if ( _tempy != 0 ) delete[] _tempy;
	if ( _tempy2 != 0 ) delete[] _tempy2;
	if ( _y2 != 0 ) delete[] _y2;

	try
	{
		_tempy = new double[_paramdata.dimension];
		_tempy2 = new double[_paramdata.dimension];
		_y2 = new double[_paramdata.dimension];
	}
	catch ( std::bad_alloc )
	{
		throw MemoryException ( __DEBUGMESS ( "failed to allocate working-array" ) );
	}
}

LIB_EXPORT void yane::OdeSolve::Heun::assertValidDGL ( OdeFunction * dgl )
{
	T_ODEPARAMS tempparams;
	dgl->getParams ( &tempparams );

	if ( tempparams.has_mas != 0 ) throw IncompatibleDGLException ( __DEBUGMESS ( "Mass-Matrix is not supported by Euler-Solver" ) );

}

LIB_EXPORT void yane::OdeSolve::Heun::abstractCalc ( double t, double * rpar, int * ipar )
{
	double time = _t;
	double time2;
	double to = t;
	double posneg = ( to - time >= 0.0 ? 1.0 : -1.0 );
	bool quit = false;
	double stepsize = posneg * _h;
	int maxsteps;

	( ( OdeConfig* ) _config )->getMaxSteps ( maxsteps );

	_steps = 0;

	while ( !quit )
	{
		time2 = time + stepsize;

		if ( ( time2 + 1.01f*stepsize - to ) * posneg > 0.0f )
		{
			stepsize = ( stepsize + to - time ) * 0.5;
			quit = true;
		}

		_paramdata.odefunc ( & ( _paramdata.dimension ), &time, _y, _tempy, rpar, ipar );

		for ( int i = 0; i < _paramdata.dimension; i++ )
		{
			_y2[i] = _y[i] + stepsize * _tempy[i];
		}

		_paramdata.odefunc ( & ( _paramdata.dimension ), &time2, _y2, _tempy2, rpar, ipar );

		for ( int i = 0; i < _paramdata.dimension; i++ )
		{
			_y[i] += 0.5 * stepsize * ( _tempy[i] + _tempy2[i] );
		}

		_steps++;
		time += stepsize;
		if ( _steps > maxsteps )
		{
			throw TooManyStepsException ( __DEBUGMESS ( "solver needet too many steps" ) );
		}
	}
	_t = to;
}

LIB_EXPORT yane::OdeSolve::OdeSolveFirst * yane::OdeSolve::Heun::clone()
{
	return new Euler ( _h );
}

LIB_EXPORT int yane::OdeSolve::Heun::acceptedSteps()
{
	return _steps;
}

LIB_EXPORT int yane::OdeSolve::Heun::computedSteps()
{
	return _steps;
}

LIB_EXPORT int yane::OdeSolve::Heun::functionEvalCount()
{
	return _steps;
}

LIB_EXPORT int yane::OdeSolve::Heun::rejectedSteps()
{
	return 0;
}

LIB_EXPORT void yane::OdeSolve::Heun::setStepsize ( double h )
{
	_h = h;
}

LIB_EXPORT double yane::OdeSolve::Heun::stepsize ( void )
{
	return _h;
}
