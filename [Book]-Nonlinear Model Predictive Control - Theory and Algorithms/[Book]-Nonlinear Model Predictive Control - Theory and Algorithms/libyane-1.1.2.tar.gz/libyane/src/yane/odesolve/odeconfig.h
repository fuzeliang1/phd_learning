/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_ODESOLVE_ODECONFIG_H
#define YANE_ODESOLVE_ODECONFIG_H

#include "typedefs.h"

namespace yane
{

	namespace Utils
	{
		class Uuid;
	}

	namespace OdeSolve
	{
		/**
		 * This class can be used to access all the configuration possibilities of the differential equation solvers. On construction of an object of this class the configuration data is set to default values which are reasonable for standard usage. These values, however, should be adapted to the model to achieve efficiency and performance.
		 * @brief Class of configuration possibilities for the differential equation solvers
		 */
		class OdeConfig
		{
			public:

				/**
				 * This function is the constructor of the class yane::OdeSolve::OdeConfig and initializes every constructed object of this type with default values for all configuration variables.
				 * @brief Constructor setting all data to default values
				 */
				OdeConfig();

				/**
				 * @brief Destructor
				 */
				virtual ~OdeConfig();


				/**
				 * This function sets scalar error tolerances for the adaptive step size control algorithms.
				 * @param rtol Relative tolerance
				 * @param atol Absolute tolerance
				 * @sa getTolerance
				 * @throw WrongSolverInputException Is thrown if unapplicable data values are supplied
				 * @brief Function to set scalar error tolerances for the adaptive step size control algorithms
				 */
				void setTolerance ( double rtol = 1E-6, double atol = 1E-6 );

				/**
				 * This function can be used to obtain the currently used error tolerances
				 * @param rtol Relative tolerance
				 * @param atol Absolute tolerance
				 * @sa setTolerance
				 * @brief Function to obtain the error tolerances
				 */
				void getTolerance ( double & rtol, double & atol );

				/**
				 * This function sets vectors of error tolerances for the adaptive step size control algorithms. Here, the dimension of the vectors of error tolerances are required to be identical to the dimension of the state variable. \n
				 * If a null pointer is supplied to this routine, then the usage of error tolerance vectors is switched to scalar error tolerances base on the internally stored values.
				 * @param rtol Pointer of the relative error tolerances
				 * @param atol Pointer of the absolute error tolerances
				 * @throw WrongSolverInputException Is thrown if unapplicable data values are supplied
				 * @sa getToleranceVector
				 * @brief Function to set the vectors of error tolerances for the adaptive step size control algorithms
				 */
				void setToleranceVector ( double * rtol = 0, double * atol = 0 );

				/**
				 * This function can be used to obtain the vectors of currently used error tolerances
				 * @param rtol Pointer of the relative error tolerance vector
				 * @param atol Pointer of the absolute error tolerance vector
				 * @sa setToleranceVector
				 * @brief Function to obtain the vectors of currently used error tolerances
				 */
				void getToleranceVector ( double * &rtol, double * &atol );

				/**
				 * This function sets the maximal number of allowed integration steps of the differential equation solver. If a computation requires more iteration steps then the method yane::OdeSolve::OdeSolve::calc is terminated with exception yane::OdeSolve::TooManyStepsException.
				 * @param steps Maximal number of computation steps of the differential equation solver
				 * @throw WrongSolverInputException Is thrown if unapplicable data values are supplied
				 * @sa getMaxSteps
				 * @brief Function to set the maximal numer of allowed
				 */
				void setMaxSteps ( int steps = 10000000 );

				/**
				 * This function can be used to obtain the current maximal number of steps allowed for the step size control methods.
				 * @param steps Maximal number of computation steps of the differential equation solver
				 * @sa setMaxSteps
				 * @brief Function to obtain the current maximal number of steps allowed for the step size control methods
				 */
				void getMaxSteps ( int & steps );

				/**
				 * This function sets the bounds for the allowed change in the step size. Within the algorithms the condition
				 \f[ \mbox{fac}_1 \leq \frac{h_{new}}{h_{old}} \leq \mbox{fac}_2 \f]
				 is checked and the new step size is set accordingly.
				 * @param fac1 Lower bound
				 * @param fac2 Upper bound
				 * @throw WrongSolverInputException Is thrown if unapplicable data values are supplied
				 * @sa getStepsizeSelectionParameters
				 * @brief Function to set the bounds for the allowed change in the step size
				\f[ \mbox{fac}_1 \leq \frac{h_{new}}{h_{old}} \leq \mbox{fac}_2 \f]
				 */
				void setStepsizeSelectionParameters ( double fac1 = 0.2, double fac2 = 10.0 );

				/**
				 * This function can be used to obtain the bounds for the allowed change in the step size.
				 * @param fac1 Lower bound
				 * @param fac2 Upper bound
				 * @sa setStepsizeSelectionParameters
				 * @brief Function to obtain the bounds for the allowed change in the step size
				 */
				void getStepsizeSelectionParameters ( double & fac1, double & fac2 );


				/**
				 * This function sets the maximal step size length. If zero is supplied to this method, then the maximal step size is set to the length of the integration interval.
				 * @param stepsize Maximal step size length
				 * @throw WrongSolverInputException Is thrown if unapplicable data values are supplied
				 * @sa getMaxStepsize
				 * @brief Function to set the maximal step size length
				 */
				void setMaxStepsize ( double stepsize = 0.0 );

				/**
				 * This function can be used to obtain the maximal set size length.
				 * @param stepsize Maximal step size length
				 * @sa setMaxStepsize
				 * @brief Function to obtain the maximal step size length
				 */
				void getMaxStepsize ( double & stepsize );

				/**
				 * This function sets the initial step size which is used upon start of the used solution method for differential equations. If the value is set to zero then a guess for the initial step size is computed numerically.
				 * @param hinit Initial step size
				 * @throw WrongSolverInputException Is thrown if unapplicable data values are supplied
				 * @sa getInitialStepsize
				 * @brief Function to set the initial step size
				 */
				void setInitialStepsize ( double hinit = 0.0 );

				/**
				 * This function can be used to obtain the initial step size of the used solution method for differential equations.
				 * @param hinit Initial step size
				 * @sa setInitialStepsize
				 * @brief Function to obtain the initial step size of the used solution method for differential equations
				 */
				void getInitialStepsize ( double & hinit );


				/**
				 * This function sets the safety factor used within the step size control method.
				 * @param safetyfactor Safety factor
				 * @sa getSafetyFactor
				 * @throw WrongSolverInputException Is thrown if unapplicable data values are supplied
				 * @brief Function to set the safety factor used within the step size control method
				 */
				void setSafetyFactor ( double safetyfactor = 0.9 );


				/**
				 * This function can be used to obtain the safety factor used within the step size control method.
				 * @param safetyfactor Safety factor
				 * @sa setSafetyFactor
				 * @brief Function to obtain the safety factor used within the step size control method
				 */
				void getSafetyFactor ( double & safetyfactor );

				/**
				 * This function can be used to obtain the ID of the current configuration. If one data values has been changed, then the ID is modified. Using this ID the solver can automatically recognize that it has to update itself using the new values.
				 * @return ID of the current configuration
				 * @brief Function to obtain the ID of the current configuration
				 */
				yane::Utils::Uuid * configID();

				/**
				 * This function is a static method which allows a solver to guarantee that the pointer of a yane::OdeSolve::OdeConfig object reveals a valid configuration object. \n
				 * Each solver, for which a yane::OdeSolve::OdeConfig object has been implemented, must make sure that such a configuration object has been supplied to it. To this end this method must be overloaded in the derived yane::OdeSolve::OdeConfig class and this method must check whether the keyelement of the supplied configuration object is an element of the set of keys of this class.
				 * @param config Configuration object to be checked
				 * @brief Static function to check validity of the supplied configuration object
				*/
				static void assertValidConfigObject ( OdeConfig * config );

				/**
				 * This function can be used to copy current data of the object to a (different) supplied configuration object. It automatically resets the ID of the supplied object.
				 * @param target Configuration object which shall be configured
				 * @brief Function to copy default data to a supplied configuration object
				 */
				void copyTo ( OdeConfig * target );

				/**
				 * This function can be used to clone the current yane::OdeSolve::OdeConfig object.
				 * @return Cloned yane::OdeSolve::OdeConfig object
				 * @brief Function to clone the current yane::OdeSolve::OdeConfig object
				 */
				virtual OdeConfig * clone();

			protected:

				/**
				 * This function changes the ID of the configuration object. Hence, all solvers which use this configuration object will notice that they need to be reconfigured using the new configuration data. Each derived class must call this method if any of its set-methods is called.
				 * @brief Function to change the ID of the configuration object
				 */
				void invalidateOldConfig();

				/**
				 * This function copies all internal configuration data to the supplied configuration object.
				 * @param target Configuration object to hold data of calling yane::OdeSolve::OdeConfig object
				 * @brief Function to copy all internal configuration data to the supplied configuration object
				 */
				virtual void copyToNoInvalidation ( OdeConfig * target );

				double _rtol;			/**< @brief Relative tolerance */
				double _atol;			/**< @brief Absolute Tolerance */
				double* _rtol_vec;		/**< @brief Vector of relative Tolerances */
				double* _atol_vec;		/**< @brief Vector of absolute Tolerances */
				int _max_steps;			/**< @brief Maximal number of steps of the iterative method */
				double _ss_fac1;		/**< @brief Lower bound for the change of the step size */
				double _ss_fac2;		/**< @brief Upper bound for the change of the step size */
				double _max_stepsize;		/**< @brief Maximal step size */
				double _initial_stepsize;	/**< @brief Initial step size */
				double _safety_factor;		/**< @brief Safty factor */

//    std::set<std::string> config_type_id; /**< Schluesselmenge, speichert die ID's der unterstuetzten Konfigurationstypen zur Identifizierung */
				yane::Utils::Uuid * _setting_uuid; /**< @brief ID of the yane::OdeSolve::OdeConfig object */
		};

	}

}

#endif
