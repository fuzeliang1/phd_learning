/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "recursesequence.h"
#include "odesolex.h"
#include "odefunction.h"

#include "../utils.h"

#include <cstring>

#include "libexport.h"

using namespace yane::Utils;

LIB_EXPORT yane::OdeSolve::RecurseSequence::RecurseSequence()
{
	_hascalced=false;
	_tfield = 0;
	_tempy = 0;

}

LIB_EXPORT yane::OdeSolve::RecurseSequence::~ RecurseSequence()
{
	if (_tfield != 0) delete _tfield;
	if (_tempy != 0) delete _tempy;
}

LIB_EXPORT void yane::OdeSolve::RecurseSequence::assertMemory()
{
	if (_tfield != 0) delete _tfield;
	if (_tempy != 0) delete _tempy;

	try
	{
		_tfield = new double[2];
		_tempy = new double[_paramdata.dimension];
	}
	catch (std::bad_alloc)
	{
		throw MemoryException(__DEBUGMESS("failed to allocate working-arrays"));
	}

}

LIB_EXPORT void yane::OdeSolve::RecurseSequence::assertValidDGL(OdeFunction * dgl)
{
	T_ODEPARAMS tempparams;
	dgl->getParams(&tempparams);

	if (tempparams.has_mas != 0) throw IncompatibleDGLException(__DEBUGMESS("Mass-Matrix is not supported by RecurseSequence-Solver"));

}

LIB_EXPORT void yane::OdeSolve::RecurseSequence::abstractCalc(double t, double * rpar, int * ipar)
{
	_tfield[0] = _t;
	_tfield[1] = t;

	_paramdata.odefunc(&_dimension, _tfield, _y, _tempy, rpar, ipar);
	memcpy(_y, _tempy, sizeof(double)*_paramdata.dimension);
	_hascalced = true;
}

LIB_EXPORT yane::OdeSolve::OdeSolveFirst * yane::OdeSolve::RecurseSequence::clone()
{
	return new RecurseSequence();
}

LIB_EXPORT int yane::OdeSolve::RecurseSequence::acceptedSteps()
{
	return (_hascalced == true ? 1 : 0);
}

LIB_EXPORT int yane::OdeSolve::RecurseSequence::computedSteps()
{
	return (_hascalced == true ? 1 : 0);
}

LIB_EXPORT int yane::OdeSolve::RecurseSequence::functionEvalCount()
{
	return (_hascalced == true ? 1 : 0);
}

LIB_EXPORT int yane::OdeSolve::RecurseSequence::rejectedSteps()
{
	return (_hascalced == true ? 1 : 0);
}
