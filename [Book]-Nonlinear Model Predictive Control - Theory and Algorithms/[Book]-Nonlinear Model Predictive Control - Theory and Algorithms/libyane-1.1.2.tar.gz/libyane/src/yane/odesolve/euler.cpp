/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "euler.h"
#include "odesolex.h"
#include "odeconfig.h"
#include "odefunction.h"

#include "../utils.h"

#include <cstring>

#include "libexport.h"

using namespace yane::Utils;

LIB_EXPORT yane::OdeSolve::Euler::Euler ( double h )
{
	_h = h;
	_tempy = 0;
	_steps = 0;
}

LIB_EXPORT yane::OdeSolve::Euler::~ Euler()
{
	if ( _tempy != 0 ) delete _tempy;
}

LIB_EXPORT void yane::OdeSolve::Euler::assertMemory()
{
	if ( _tempy != 0 ) delete _tempy;

	try
	{
		_tempy = new double[_paramdata.dimension];
	}
	catch ( std::bad_alloc )
	{
		throw MemoryException ( __DEBUGMESS ( "failed to allocate working-array" ) );
	}
}

LIB_EXPORT void yane::OdeSolve::Euler::assertValidDGL ( OdeFunction * dgl )
{
	T_ODEPARAMS tempparams;
	dgl->getParams ( &tempparams );

	if ( tempparams.has_mas != 0 ) throw IncompatibleDGLException ( __DEBUGMESS ( "Mass-Matrix is not supported by Euler-Solver" ) );

}

LIB_EXPORT void yane::OdeSolve::Euler::abstractCalc ( double t, double * rpar, int * ipar )
{
	double time = _t;
	double to = t;
	double posneg = ( to - time >= 0.0 ? 1.0 : -1.0 );
	bool quit = false;
	double stepsize = posneg * _h;
	int maxsteps;

	( ( OdeConfig* ) _config )->getMaxSteps ( maxsteps );

	_steps = 0;

	while ( !quit )
	{
		if ( ( time + 1.01f*stepsize - to ) * posneg > 0.0f )
		{
			stepsize = to - time;
			quit = true;
		}

		_paramdata.odefunc ( & ( _paramdata.dimension ), &time, _y, _tempy, rpar, ipar );
		for ( int i = 0; i < _paramdata.dimension; i++ )
		{
			_y[i] += stepsize * _tempy[i];
		}

		_steps++;
		time += stepsize;
		if ( _steps > maxsteps )
		{
			throw TooManyStepsException ( __DEBUGMESS ( "solver needet too many steps" ) );
		}
	}
	_t = to;
}

LIB_EXPORT yane::OdeSolve::OdeSolveFirst * yane::OdeSolve::Euler::clone()
{
	return new Euler ( _h );
}

LIB_EXPORT int yane::OdeSolve::Euler::acceptedSteps()
{
	return _steps;
}

LIB_EXPORT int yane::OdeSolve::Euler::computedSteps()
{
	return _steps;
}

LIB_EXPORT int yane::OdeSolve::Euler::functionEvalCount()
{
	return _steps;
}

LIB_EXPORT int yane::OdeSolve::Euler::rejectedSteps()
{
	return 0;
}

LIB_EXPORT void yane::OdeSolve::Euler::setStepsize ( double h )
{
	_h = h;
}

LIB_EXPORT double yane::OdeSolve::Euler::stepsize ( void )
{
	return _h;
}

