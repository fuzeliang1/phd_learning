/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "dopri5.h"
#include "odesolex.h"

#include "../utils.h"

#include <cstdlib>
#include <cstring>
#include <cfloat>

#include "libexport.h"

using namespace yane::Utils;

#define __FORTRANNAME(x) x##_
extern "C"
{
	void __FORTRANNAME ( dopri5 ) ( int * n, yane::OdeSolve::T_ODEFUNC FCN, double * x, double * y, double * xend, double * rtol, double * atol, int * itol, yane::OdeSolve::T_SOLOUTFUNC solout, int * iout, double * work, int* lwork, int * iwork, int * liwork, double * rpar, int * ipar, int * did );
}


LIB_EXPORT yane::OdeSolve::DoPri5::DoPri5 ( ) : DoPri ( )
{

	_dopri_func = __FORTRANNAME ( dopri5 );
}

LIB_EXPORT void yane::OdeSolve::DoPri5::assertMemory()
{
	_lwork = 8 * _paramdata.dimension + 21;
	_liwork = 21;

	if ((_lwork<<3) <0 || (_liwork<<2) <0)
	{
		throw MemoryException(__DEBUGMESS("working-arrays length overflow - the problem is too big"));
	}

	if (_work != 0) delete _work;
	if (_iwork != 0) delete _iwork;

	try
	{
		_work = new double[_lwork];
		_iwork = new int[_liwork];
	}
	catch (std::bad_alloc)
	{
		throw MemoryException(__DEBUGMESS("failed to allocate working-arrays"));
	}
}

LIB_EXPORT yane::OdeSolve::OdeSolveFirst * yane::OdeSolve::DoPri5::clone()
{
	return new DoPri5();
}

LIB_EXPORT yane::OdeSolve::DoPri5::~ DoPri5()
{
}
