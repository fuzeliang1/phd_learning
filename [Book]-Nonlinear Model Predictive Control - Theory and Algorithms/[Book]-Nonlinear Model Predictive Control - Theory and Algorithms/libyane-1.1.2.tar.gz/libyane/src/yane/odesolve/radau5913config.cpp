/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "radauconfig.h"
#include "odesolex.h"
#include "radau5913config.h"

#include "../utils.h"

#include <string>
#include <sstream>

#include "libexport.h"

using namespace yane::Utils;
using namespace std;

//#define RADAU5913CONFIGID "c6375c65-cb4c-40ba-9408-bd3f6e45be79"

LIB_EXPORT yane::OdeSolve::Radau5913Config::Radau5913Config() :
		yane::OdeSolve::RadauConfig()
{
// config_type_id.insert(std::string(RADAU5913CONFIGID));

	setOrderSelectionParameters();
	setStages();
}

LIB_EXPORT yane::OdeSolve::Radau5913Config::~ Radau5913Config()
{
}

LIB_EXPORT void yane::OdeSolve::Radau5913Config::assertValidConfigObject ( OdeConfig * config )
{
	Radau5913Config * conf = dynamic_cast<Radau5913Config*> ( config );

	if ( !conf ) throw IncompatibleConfigException ( __DEBUGMESS ( "Configtype 'Radau5913Config' or derived type expected, but got something else" ) );
}

LIB_EXPORT void yane::OdeSolve::Radau5913Config::setOrderSelectionParameters ( double inc_factor, double dec_factor, double hfac1, double hfac2 )
{
	if ( hfac1 > hfac2 )
	{
		stringstream out;
		out << "hfac2 (=" << hfac2 << ") must be greater then or equal to hfac1 (=" << hfac1 << ")";
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}
	_os_inc = inc_factor;
	_os_dec = dec_factor;
	_os_fac1 = hfac1;
	_os_fac2 = hfac2;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::Radau5913Config::getOrderSelectionParameters ( double & inc_factor, double & dec_factor, double & hfac1, double & hfac2 )
{
	inc_factor = _os_inc;
	dec_factor = _os_dec;
	hfac1 = _os_fac1;
	hfac2 = _os_fac2;
}

LIB_EXPORT void yane::OdeSolve::Radau5913Config::setStages ( int minstage, int maxstage, int firststage )
{
	if ( !isValidStage ( minstage ) || !isValidStage ( maxstage ) || !isValidStage ( firststage ) )
	{
		stringstream out;
		out << "Invalid stagenumber entered. Valid Numbers are 1, 3,  5 and 7." << endl;
		out << "                (got: minstage=" << minstage << ", maxstage=" << maxstage << ", firststage=" << firststage << ")";
		throw WrongSolverInputException ( __DEBUGMESS ( out.str() ) );
	}

	_s_min = minstage;
	_s_max = maxstage;
	_s_first = firststage;

	invalidateOldConfig();
}

LIB_EXPORT bool yane::OdeSolve::Radau5913Config::isValidStage ( int stage )
{
	return ( stage == 1 || stage == 3 || stage == 5 || stage == 7 );
}

LIB_EXPORT void yane::OdeSolve::Radau5913Config::getStages ( int & minstage, int & maxstage, int & firststage )
{
	minstage = _s_min;
	maxstage = _s_max;
	firststage = _s_first;
}

LIB_EXPORT void yane::OdeSolve::Radau5913Config::copyToNoInvalidation ( OdeConfig * target )
{
	assertValidConfigObject ( target );

	RadauConfig::copyToNoInvalidation ( target );

	Radau5913Config * radautarget = ( Radau5913Config* ) target;

	radautarget->_os_inc = _os_inc;
	radautarget->_os_dec = _os_dec;
	radautarget->_os_fac1 = _os_fac1;
	radautarget->_os_fac2 = _os_fac2;
	radautarget->_s_min = _s_min;
	radautarget->_s_max = _s_max;
	radautarget->_s_first = _s_first;
}

LIB_EXPORT yane::OdeSolve::OdeConfig * yane::OdeSolve::Radau5913Config::clone()
{
	Radau5913Config * result = new Radau5913Config();

	copyTo ( result );

	return result;
}



