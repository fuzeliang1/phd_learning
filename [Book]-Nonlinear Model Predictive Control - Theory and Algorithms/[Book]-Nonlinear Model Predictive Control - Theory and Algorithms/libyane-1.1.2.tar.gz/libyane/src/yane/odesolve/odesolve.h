/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */
 
#ifndef YANE_ODESOLVE_ODESOLVE_H
#define YANE_ODESOLVE_ODESOLVE_H

#include "typedefs.h"

namespace yane
{
	namespace Utils
	{
		class Uuid;
	}

	namespace OdeSolve
	{
		class OdeConfig;
		class OdeFunction;
		class OdeSolEx;

		/**
		 * @brief Class of solvers for ordinary differential equations
		 */
		class OdeSolve
		{
			public:
				/**
				 @brief Destructor
				*/
				virtual ~OdeSolve();

				/**
				 * This function initializes the object and provides the dynamic of the system as well as the configuration. The size of the problem is set according to the data contained in the OdeFunction object.
				 * @param func Pointer of the dynamic of the system
				 * @param config Pointer of the configuration object
				 * @throw yane::Utils::MemoryException Is thrown if the memory allocation failed
				 * @throw WrongSolverInputException Is thrown if a null pointer is provided to the routine
				 * @throw OdeSolEx Is thrown if an error occured during the allocation or configuration of the differential equation solver
				 * @throw IncompatibleConfigException Is thrown if an error occured during the configuration of the differential equation solver
				 * @sa OdeFunction
				 * @sa resize
				 * @brief Function to initialize the object
				 */
				void reset ( OdeFunction * func, OdeConfig * config );

				/**
				 * This function can be used to efficiently change the size of the dynamic of the system. The size of the dynamic must ont be larger than the dimension of the problem set within the yane::OdeSolve::OdeFunction object. Note that the object must be initialized with a call of yane::OdeSolve::OdeSolve::reset and that calling this method results in an update of the configuration of the object.
				 * @sa OdeFunction
				 * @sa reset
				 * @param dimension New size of the dynamic of the problem
				 * @throw WrongSolverInputException Is thrown if the new size or the system is too large or less or equal to zero
				 * @throw yane::Utils::NotInitializedException Is thrown if the solver has not been initialized
				 * @brief Function to change the size of the dynamic of the system
				 */
				void resize ( int dimension );

				/**
				 * This function refreshed the configuration of the object. This may be necessary if the user cannot be sure that data within the yane::OdeSolve::OdeConfig object have been changed since the last call of yane::OdeSolve::OdeSolve::reset. Hence, this data should be handed over to the solver. \n
				 The function checks if the configuration has been changed and refreshes it using the internal function yane::OdeSolve::OdeSolve::assertConfig.
				 * @throw yane::Utils::NotInitializedException Is thrown if the solver has not been initialized
				 * @brief Function to refresh the configuration of the object
				 */
				void refreshConfig();


				/**
				 * This function solves the differential or difference equation problem up to a supplied time instant. Internally, the function calls the function yane::OdeSolve::OdeSolve::abstractCalc which is given by the solver supplied to this object.
				 * @param t Terminal time for solving the differential or difference equation problem
				 * @param rpar Array of double parameters
				 * @param ipar Array of integer parameters
				 * @throw noInitialValueException Is thrown if no initial value has been supplied
				 * @throw yane::Utils::NotInitializedException Is thrown if the solver has not been initialized
				 * @brief Function to compute the solution of the dynamic
				 */
				void calc ( double t, double * rpar = 0, int* ipar = 0 );

				/**
				 * @brief Function to obtain the number of function evaluations
				 * @return Number of function evaluations
				 */
				virtual int functionEvalCount() = 0;

				/**
				 * @brief Function to obtain the number of computed steps of the solver
				 * @return Number of computed steps
				 */
				virtual int computedSteps() = 0;

				/**
				 * @brief Function to obtain the number of accepted steps of the solver
				 * @return Number fo accepted steps
				 */
				virtual int acceptedSteps() = 0;

				/**
				 * @brief Function to obtain the number of rejected steps of the solver
				 * @return Number of rejected steps
				 */
				virtual int rejectedSteps() = 0;

			protected:
				/**
				 * @brief Constructor
				 * @sa reset
				 */
				OdeSolve ( );

				/**
				 * @brief Function to abstract the allocation of memory which are required by object classes derived from this class
				 */
				virtual void assertMemory() = 0;

				/**
				 * @brief Function to check the configuration of the object
				 */
				virtual void assertConfig();

				/**
				 * @brief Function to check whether the current differential equation or difference equation can be solved by the yane::OdeSolve::OdeSolve object
				 * @throw IncompatibleDGLException Is thrown if the current differential equation or difference equation cannot be solved by the yane::OdeSolve::OdeSolve object
				 */
				virtual void assertValidDGL ( OdeFunction * dgl );

				/**
				 * @brief Function to abstract the computation of the solution of the differential equation or difference equation
				 * @param t Terminal time for solving the differential or difference equation problem
				 * @param rpar Array of double parameters
				 * @param ipar Array of integer parameters
				 * @throw NoInitialValueException Is thrown if no initial value has been supplied
				 * @throw WrongSolverInputException Is thrown if parameters are incorrect
				 * @throw TooManyStepsException Is thrown if the maximal allowed number of steps is reached
				 * @throw TooSmallStepSizeException Is thrown if the current step size becomes too small
				 * @throw StiffException Is thrown if the system appears to be too stiff for the solver
				 * @throw yane::Utils::NotInitializedException Is thrown if the solver has not been initialized
				 */
				virtual void abstractCalc ( double t, double * rpar, int* ipar ) = 0;

				int _dimension;   			/**< @brief Dimension of the state variable of the system */

				OdeFunction * _func;  			/**< @brief Pointer of the differential or difference equation */
				OdeConfig * _config;  			/**< @brief Pointer of the configuration object */

				bool _initial_value_set;  		/**< @brief Decision variable to check if an initial value has been assigned */
				yane::Utils::Uuid * _config_id; 	/**< @brief Pointer for configuration identifier */

				double _t;  				/**< @brief Current time instance */
				double * _y;  				/**< @brief Current state vector */

				T_ODEPARAMS _paramdata; 		/**< @brief Structure of differential equation or difference equation data */
				int _did;  				/**< @brief Error flag:
        								- \f$ did = 1 \f$ Successful termination
									- \f$ did = 2 \f$ Successful termination with output via yane::OdeSolve::OdeSolve::_solout
									- \f$ did = -1 \f$ Input data is inconsistent
									- \f$ did = -2 \f$ Maximal number of steps reached
									- \f$ did = -3 \f$ Step size became too small
									- \f$ did = -4 \f$ Problem seems to be too stiff */
				double _rtol;				/**< @brief Relative error tolerance */
				double _atol;				/**< @brief Absolute error tolerance */
				double * _rtol_vec;			/**< @brief Vector of relative error tolerances */
				double * _atol_vec;			/**< @brief Vector of absolute error tolerances */
				int _itol;				/**< @brief Decision variable
									- \f$ itol = 0 \f$ Scalar error tolerances
									- \f$ itol \geq 0 \f$ Vector error tolerances */

				double *_work;				/**< @brief Array for double variables */
				int _lwork;				/**< @brief Size of array for double variables */
				int * _iwork;				/**< @brief Array for integer variables */
				int _liwork;				/**< @brief Size of array for integer variables */

		};

	}
}

#endif
