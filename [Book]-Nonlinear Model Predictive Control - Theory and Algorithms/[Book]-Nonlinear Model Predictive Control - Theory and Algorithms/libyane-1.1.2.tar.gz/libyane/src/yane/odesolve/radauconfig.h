/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_RADAUCONFIG_H
#define YANE_ODESOLVE_RADAUCONFIG_H

#include "odeconfig.h"

namespace yane
{

	namespace OdeSolve
	{
		/**
		 * This class includes all configuration methods for all Radau solvers. \n
		 * Atter construction of an object of this class it is initialized with default values which usually give good results. Still, the parameters of the class should be adapted to the considered yane::Model::Model object.
		 * @brief Class to configure all Radau solvers
		 */
		class RadauConfig : public OdeConfig
		{
			public:
				/**
				 * @brief Constructor
				 */
				RadauConfig();

				/**
				 * @brief Destructor
				 */
				virtual ~RadauConfig();

				/**
				 * This function sets the decision variable on whether the Jacobian shall be transformed into Hessenberg form. This can be advantageous for large systems.
				 * @param enable Decision variable if Jacobian shall be transformed into Hessenberg form \n
						- 1: Transformation
						- 0: No transformation (default)
				 * @sa getHessenbergTransformation
				 * @brief Function to set the decision variable on transforming the Jacobina into Hessenberg form
				 */
				void setHessenbergTransformation ( int enable = 0 );

				/**
				 * This function can be used to obtain the decision variable on whether the Jacobian shall be transformed into Hessenberg form. This can be advantageous for large systems.
				 * @param enable Decision variable if Jacobian shall be transformed into Hessenberg form \n
				- 1: Transformation
				- 0: No transformation (default)
				 * @sa getHessenbergTransformation
				 * @brief Function to obtain the decision variable on transforming the Jacobina into Hessenberg form
				 * @sa setHessenbergTransformation
				 */
				void getHessenbergTransformation ( int & enable );

				/**
				 * This function sets the maximal number of newton steps per step of the differential equation solver
				 * @param steps Maximal number of newton steps
				 * @throw WrongSolverInputException Is thrown if an invalid number of steps is provided
				 * @sa getMaxNewtonSteps
				 * @brief Function to set the maximal number of newton steps
				 */
				void setMaxNewtonSteps ( int steps = 7 );

				/**
				 * This function can be used to obtain the maximal number of newton steps per step of the differential equation solver
				 * @param steps Maximal number of newton steps
				 * @sa setMaxNewtonSteps
				 * @brief Function to obtain the maximal number of newton steps
				 */
				void getMaxNewtonSteps ( int & steps );


				/**
				 * This function defines how often the Jacobian is recomputed. For large systems where the Jacobian is computationally expensive, 0.1 has shown to be reasonable. Negative values will cause a recomputation in every step of the step size control method.
				 * @param step Step size of the recomputation of the Jacobian
				 * @sa getJacobiRecomputation
				 * @brief Function to define how often the Jacobian is recomputed
				 */
				void setJacobiRecomputation ( double step = 0.001 );

				/**
				 * This function can be used to obtain the value of how often the Jacobian is recomputed. For large systems where the Jacobian is computationally expensive, 0.1 has shown to be reasonable. Negative values will cause a recomputation in every step of the step size control method.
				 * @param step Step size of the recomputation of the Jacobian
				 * @sa setJacobiRecomputation
				 * @brief Function to obtain the value of how often the Jacobian is recomputed
				 */
				void getJacobiRecomputation ( double & step );

				/**
				 * This function sets the strategy of step size computation
				 * @sa STEPSIZESTRATEGY
				 * @sa getStepsizeStrategy
				 * @param strategy Strategy of step size computation
				 * @throw WrongSolverInputException Is thrown if an invalid strategy is to be used
				 * @brief Function to set the strategy of step size computation
				 */
				void setStepsizeStrategy ( T_STEPSIZESTRATEGY strategy = Gustaffson );

				/**
				 * This function can be used to obtain the strategy of step size computation
				 * @sa STEPSIZESTRATEGY
				 * @sa setStepsizeStrategy
				 * @param strategy Strategy of step size computation
				 * @brief Function to obtain the strategy of step size computation
				 */
				void getStepsizeStrategy ( T_STEPSIZESTRATEGY & strategy );

				/**
				 * This function sets the factors for accepting an integration step which is given by the condition
				 * \f[ \mbox{fac}_1 /leq /frac{h_{new}}{h_{old}} \le \mbox{fac}_2 \f]
				 * For large systems the parameters 0.99 and 2.0 appear to be reasonable.
				 * @param fac1 Lower bound for the acceptance of an integration step
				 * @param fac2 Upper bound for the acceptance of an integration step
				 * @sa getStepsizeFixingParameters
				 * @throw WrongSolverInputException Is thrown if \f$ fac2 < fac1 \f$
				 * @brief Function to set the bounds on accepting an integration step
				 */
				void setStepsizeFixingParameters ( double fac1 = 1.0, double fac2 = 1.2 );

				/**
				 * This function can be used to obtain the factors for accepting an integration step which is given by the condition
				 * \f[ \mbox{fac}_1 /leq /frac{h_{new}}{h_{old}} \le \mbox{fac}_2 \f]
				 * @param fac1 Lower bound for the acceptance of an integration step
				 * @param fac2 Upper bound for the acceptance of an integration step
				 * @sa setStepsizeFixingParameters
				 * @brief Function to set the bounds on accepting an integration step
				 */
				void getStepsizeFixingParameters ( double & fac1, double & fac2 );


				/**
				 * This function overloads the standard method. It checks whether the supplied yane::OdeSolve::OdeConfig object possesses the ID of a yane::OdeSolve::RadauConfig class and is therefore valid.
				 * @param config Configuration object to be checked
				 * @brief Function to check whether a supplied configuration object is of type yane::OdeSolve::RadauConfig
				 */
				static void assertValidConfigObject ( OdeConfig * config );

				virtual OdeConfig * clone();

			protected:

				virtual void copyToNoInvalidation ( OdeConfig * target );

				int _enable_hessenberg;  	/**< @brief Decision variable if Jacobian shall be transformed into Hessenberg form \n
								- 1: Transformation
								- 0: No transformation (default) */
				int _newton_steps;		/**< @brief Maximal number of Newton steps */
				double _jac_step;		/**< @brief Step size after which a new Jacobian is to be computed */
				T_STEPSIZESTRATEGY _strat;	/**< @brief Strategy of the step size control algorithm */
				double _sf_fac1;		/**< @brief Lower bound for step size acceptance */
				double _sf_fac2;		/**< @brief Upper bound for step size acceptance */

		};
	}

}

#endif
