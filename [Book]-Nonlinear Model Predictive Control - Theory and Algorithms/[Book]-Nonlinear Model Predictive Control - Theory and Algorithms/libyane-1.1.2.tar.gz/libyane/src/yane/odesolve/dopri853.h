/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_ODESOLVE_DOPRI853_H
#define YANE_ODESOLVE_DOPRI853_H

#include "dopri.h"

namespace yane
{
	namespace OdeSolve
	{

		/** \class DoPri853
			\brief Class of the Dormand-Prince8(5)3 solver for differential equation systems
		*/
		class DoPri853 : public DoPri
		{

			public:
				/**
				* @brief Constructor
				*/
				DoPri853 ( );

				virtual ~DoPri853();

				virtual OdeSolveFirst * clone();

			protected:

				virtual void assertMemory();
		};

	}

}

#endif
