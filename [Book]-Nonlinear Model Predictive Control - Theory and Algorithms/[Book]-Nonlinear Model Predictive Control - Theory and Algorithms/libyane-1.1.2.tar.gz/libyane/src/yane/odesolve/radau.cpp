/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "radau.h"
#include "radauconfig.h"
#include "odesolex.h"

#include "../utils.h"

#include <cfloat>
#include <iostream>

#include "libexport.h"

using namespace yane::Utils;
using namespace std;

LIB_EXPORT yane::OdeSolve::Radau::Radau ( ) : yane::OdeSolve::OdeSolveFirst ( )
{
	_first_calc_done = false;
}

LIB_EXPORT void yane::OdeSolve::Radau::abstractCalc ( double t, double * rpar, int* ipar )
{

	if ( _first_calc_done && ( _iwork[15] > _iwork[16] + _iwork[17] ) )
	{
		// Schlechte Konvergenz, Aktiviere Newton-Startwerte
		_iwork[3] = 1;
	}
	else
	{
		// Konvergenz ist gut, deaktiviere Newton-Startwerte
		_iwork[3] = 0;
	}

	_radau_func ( &_dimension, _paramdata.odefunc, & ( _t ), _y, &t, &_hinit,
				  ( _itol == 0 ? &_rtol : _rtol_vec ), ( _itol == 0 ? &_atol : _rtol_vec ), &_itol,
				  _paramdata.jacobifunc, & ( _paramdata.has_jac ), & ( _paramdata.ljac ), & ( _paramdata.ujac ),
				  _paramdata.massfunc, & ( _paramdata.has_mas ), & ( _paramdata.lmas ), & ( _paramdata.umas ),
				  _paramdata.soloutfunc, &_paramdata.has_solout,
				  _work, &_lwork, _iwork, &_liwork, rpar, ipar, &_did );

	if ( _did != 0 )
	{
		switch ( _did )
		{
			case - 1:
				throw WrongSolverInputException ( __DEBUGMESS ( "Invalid solver configuration" ) );
			case - 2:
				throw TooManyStepsException ( __DEBUGMESS ( "Solver needed too many steps" ) );
			case - 3:
				throw TooSmallStepSizeException ( __DEBUGMESS ( "The stepsize became too small" ) );
			case - 4:
				throw SingularyMatrixException ( __DEBUGMESS ( "Singular Jacobian" ) );
		}
	}

	_first_calc_done = true;
}

LIB_EXPORT int yane::OdeSolve::Radau::functionEvalCount()
{
	return _iwork[13];
}

LIB_EXPORT int yane::OdeSolve::Radau::computedSteps()
{
	return _iwork[15];
}

LIB_EXPORT int yane::OdeSolve::Radau::acceptedSteps()
{
	return _iwork[16];
}

LIB_EXPORT int yane::OdeSolve::Radau::rejectedSteps()
{
	return _iwork[17];
}

LIB_EXPORT yane::OdeSolve::Radau::~ Radau()
{
}

LIB_EXPORT void yane::OdeSolve::Radau::assertConfig()
{
	RadauConfig::assertValidConfigObject ( _config );

	OdeSolve::assertConfig();

	( ( RadauConfig* ) _config )->getMaxSteps ( _iwork[1] );
	( ( RadauConfig* ) _config )->getSafetyFactor ( _work[1] );
	( ( RadauConfig* ) _config )->getStepsizeSelectionParameters ( _work[7], _work[8] );
	( ( RadauConfig* ) _config )->getMaxStepsize ( _work[6] );
	( ( RadauConfig* ) _config )->getInitialStepsize ( _hinit );

	( ( RadauConfig* ) _config )->getHessenbergTransformation ( _iwork[0] );
	( ( RadauConfig* ) _config )->getMaxNewtonSteps ( _iwork[2] );
	( ( RadauConfig* ) _config )->getJacobiRecomputation ( _work[2] );
	T_STEPSIZESTRATEGY strat;
	( ( RadauConfig* ) _config )->getStepsizeStrategy ( strat );
	_iwork[7] = strat;
	( ( RadauConfig* ) _config )->getStepsizeFixingParameters ( _work[4], _work[5] );

	_work[0] = DBL_EPSILON;
	_work[3] = 0.0;

	_iwork[3] = 0;
	_iwork[4] = _dimension;
	_iwork[5] = 0;
	_iwork[6] = 0;
	_iwork[8] = 0;
	_iwork[9] = 0;

}

LIB_EXPORT void yane::OdeSolve::Radau::assertValidDGL ( OdeFunction * dgl )
{
}
