/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Hoellbacher <thomas.hoellbacher@stud.uni-bayreuth.de           *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Hoellbacher <thomas.hoellbacher@stud.uni-bayreuth.de>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_ODEEXCEPTION_H
#define YANE_ODESOLVE_ODEEXCEPTION_H

#include "../utils.h"

#include <string>

namespace yane
{

	namespace OdeSolve
	{
		/**
		 * @brief Exceptions of the differential and difference equation solver
		 */
		class OdeSolEx : public yane::Utils::Exception
		{
			public:
				OdeSolEx ( std::string mess = "unknown exception", std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};

		/**
		 * @brief Exception due to incompatible configuration object
		 * */
		class IncompatibleConfigException : public OdeSolEx
		{
			public:
				IncompatibleConfigException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};

		/**
		 * @brief Exception due to incompatible differential or difference equation
		 */
		class IncompatibleDGLException : public OdeSolEx
		{
			public:
				IncompatibleDGLException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};

		/**
		 * @brief Exception due to wrong input to the solver
		 */
		class WrongSolverInputException : public OdeSolEx
		{
			public:
				WrongSolverInputException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};


		/**
		 * @brief Exception due to too many steps of the solver
		 */
		class TooManyStepsException : public OdeSolEx
		{
			public:
				TooManyStepsException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};


		/**
		 * @brief Exception due to too small step size
		 */
		class TooSmallStepSizeException : public OdeSolEx
		{
			public:
				TooSmallStepSizeException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};


		/**
		 * @brief Exception due to uninitialized calls
		 */
		class NoInitialValueException : public OdeSolEx
		{
			public:
				NoInitialValueException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};


		/**
		 * @brief Exception due to a singularity in the matrix
		 */
		class SingularyMatrixException : public OdeSolEx
		{
			public:
				SingularyMatrixException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};


		/**
		 * @brief Exception due to stiffness of the problem
		 */
		class StiffException : public OdeSolEx
		{
			public:
				StiffException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};


		/**
		 * @brief Exception due to unsuccessful termination of the solver
		 */
		class UnsuccessfulException : public OdeSolEx
		{
			public:
				UnsuccessfulException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string TYPE;
		};


	}

}

#endif
