/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "odesolvefirst.h"
#include "odesolex.h"

#include "../utils.h"

#include "libexport.h"

using namespace yane::Utils;

LIB_EXPORT yane::OdeSolve::OdeSolveFirst::OdeSolveFirst()
		: yane::OdeSolve::OdeSolve()
{
}

LIB_EXPORT void yane::OdeSolve::OdeSolveFirst::init ( double t0, double * y0 )
{
	if ( _func == 0 ) throw NotInitializedException ( __DEBUGMESS ( "tryed to call init()-method, but solver has not been initialized by reset()-method" ) );

	_t = t0;
	_y = y0;

	_initial_value_set = true;
}

LIB_EXPORT yane::OdeSolve::OdeSolveFirst::~ OdeSolveFirst()
{
}

