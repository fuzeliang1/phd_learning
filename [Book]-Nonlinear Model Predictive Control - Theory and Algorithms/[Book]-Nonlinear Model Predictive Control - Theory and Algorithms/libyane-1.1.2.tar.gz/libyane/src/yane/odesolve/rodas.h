/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_RODAS_H
#define YANE_ODESOLVE_RODAS_H

#include "odesolvefirst.h"

namespace yane
{

	namespace OdeSolve
	{
		/** \class Rodas
		 \brief Class of Rodas solvers for differential equation systems
		*/
		class Rodas  : public OdeSolveFirst
		{
			public:
				Rodas();
				virtual ~Rodas();

				virtual OdeSolveFirst * clone();

				virtual int acceptedSteps();
				virtual int computedSteps();
				virtual int functionEvalCount();
				virtual int rejectedSteps();


			protected:
				virtual void abstractCalc ( double t, double * rpar=0, int* ipar=0 );

				virtual void assertMemory();
				
				virtual void assertConfig();
				virtual void assertValidDGL ( OdeFunction * dgl );
				
				double _hinit;   /**< Initial step size */
				
								/**
				 @brief Prototype for calling the Rodas differential equation solver
				 \param n Dimension of the state
				 \param FCN Pointer of the differential equation
				 \param ifcn Decision variable
				  - \f$ ifcn = 0 \f$ independant of x (autonomous)
				  - \f$ ifcn = 1 \f$ may depend on x (non-autonomous)
				 \param x Initial time
				 \param y Initial value of the state
				 \param xend Terminal time
				 \param hinit Initial time step
				 \param rtol Relative tolerance
				 \param atol Absolute tolerance
				 \param itol Decision variable
				  - \f$ itol = 0 \f$ Scalar error tolerances
				  - \f$ itol \geq 0 \f$ Vector error tolerances
				 \param jac Pointer of the Jacobian
				 \param ijac Decision variable
				    - \f$ ijac = 0 \f$ Jacobian is computed numerically
				    - \f$ ijac = 1 \f$ Jacobian is evaluated using a user supplied function
				 \param mljac Decision variable if Jacobian possesses special structure
				    - \f$ mljac = ndgl \f$ Full Jacobian, use Gauss
				    - \f$ 0 \leq mljac \leq ndgl \f$ Jacobian with lower bandwidth mljac
				 \param mujac Upper bandwidth of jacobian matrix.
				 \param DFX Pointer to the function which computes the partial derivates.
				 \param idfx Decision variable
				    - \f$ idfx = 0 \f$ is computed numerically
				    - \f$ idfx = 1 \f$ DFX is given by a user supplied function
				 \param mas Pointer of the mass matrix
				 \param imas Decision variable
				    - \f$ imas = 0 \f$ Mass matrix is identity
				    - \f$ imas = 1 \f$ Mass matrix is given by a user supplied function
				 \param mlmas Decision variable if mass matrix possesses special structure
				    - \f$ mlmas = ndgl \f$ Full mass matrix, use Gauss
				    - \f$ 0 \leq mlmas \leq ndgl \f$ Mass matrix has bandwidth mlmas
				\param mumas Decision variable if mass matrix possesses special structure
				    - \f$ mlmas = ndgl \f$ Full mass matrix, use Gauss
				    - \f$ 0 \leq mumas \leq ndgl \f$ Mass matrix has bandwidth mumas
				 \param solout Output function for continuous time output
				 \param iout Output parameter
				  - \f$ iout \geq 1 \f$ Output of the state vector for every accepted step
				  - \f$ iout = 0 \f$ No output, dummy function required
				 \param work Working array for double variables
				 \param lwork Size of working array for double variables
				 \param iwork Working array for integer variables
				 \param liwork Size of working array for integer variables
				 \param rpar Array for double parameters
				 \param ipar Array for integer parameters
				 \param did Error flag:
				 - \f$ _did = 1 \f$ Successful termination
				 - \f$ _did = 2 \f$ Successful termination with output via yane::OdeSolve::OdeSolve::_solout
				 - \f$ _did = -1 \f$ Input data is inconsistent
				 - \f$ _did = -2 \f$ Maximal number of steps reached
				 - \f$ _did = -3 \f$ Step size became too small
				 - \f$ _did = -4 \f$ Matrix is repeatedly singular
				*/
				
				void ( * _rodas_func )  ( int * n, yane::OdeSolve::T_ODEFUNC FCN, int * ifcn, double * x, double * y, double * xend, double * hinit, double * rtol, double * atol, int * itol, yane::OdeSolve::T_JACFUNC JAC, int * ijac, int * mljac, int * mujac, yane::OdeSolve::T_DFTFUNC DFX, int * idfx, yane::OdeSolve::T_MASSFUNC MAS, int * imas, int * mlmas, int * mumas, yane::OdeSolve::T_SOLOUTFUNC solout, int * iout, double * work, int* lwork, int * iwork, int * liwork, double * rpar, int * ipar, int * did );

		};

	}

}

#endif
