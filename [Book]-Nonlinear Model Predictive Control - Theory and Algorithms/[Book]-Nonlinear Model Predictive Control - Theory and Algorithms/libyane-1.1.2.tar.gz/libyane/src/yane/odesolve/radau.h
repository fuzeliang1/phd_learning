/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_RADAU_H
#define YANE_ODESOLVE_RADAU_H

#include "odesolvefirst.h"

namespace yane
{
	namespace OdeSolve
	{
		class RadauConfig;


		/** \class Radau
		 \brief Class of Radau solvers for differential equation systems
		*/
		class Radau : public OdeSolveFirst
		{
			public:


				virtual int functionEvalCount();
				virtual int computedSteps();
				virtual int acceptedSteps();
				virtual int rejectedSteps();

				virtual ~Radau();

			protected:

				virtual void abstractCalc ( double t, double * rpar = 0, int* ipar = 0 );

				/**
				 * @brief Constructor
				 */
				Radau ( );

				virtual void assertConfig();
				virtual void assertValidDGL ( OdeFunction * dgl );

				double _hinit;   /**< Initial step size */
				bool _first_calc_done; /**< Auxilliary variable to save if one step has been executed yet */

				/**
				 @brief Prototype for calling the ROCK differential equation solver
				 \param n Dimension of the state
				 \param FCN Pointer of the differential equation
				 \param x Initial time
				 \param y Initial value of the state
				 \param xend Terminal time
				 \param hinit Initial time step
				 \param rtol Relative tolerance
				 \param atol Absolute tolerance
				 \param itol Decision variable
				  - \f$ itol = 0 \f$ Scalar error tolerances
				  - \f$ itol \geq 0 \f$ Vector error tolerances
				 \param jac Pointer of the Jacobian
				 \param ijac Decision variable
				    - \f$ ijac = 0 \f$ Jacobian is computed numerically
				    - \f$ ijac = 1 \f$ Jacobian is evaluated using a user supplied function
				 \param mljac Decision variable if Jacobian possesses special structure
				    - \f$ mljac = ndgl \f$ Full Jacobian, use Gauss
				    - \f$ 0 \leq mljac \leq ndgl \f$ Jacobian with bandwidth mljac
				 \param mas Pointer of the mass matrix
				 \param imas Decision variable
				    - \f$ imas = 0 \f$ Mass matrix is identity
				    - \f$ imas = 1 \f$ Mass matrix is given by a user supplied function
				 \param mlmas Decision variable if mass matrix possesses special structure
				    - \f$ mlmas = ndgl \f$ Full mass matrix, use Gauss
				    - \f$ 0 \leq mlmas \leq ndgl \f$ Mass matrix has bandwidth mlmas
				\param mumas Decision variable if mass matrix possesses special structure
				    - \f$ mlmas = ndgl \f$ Full mass matrix, use Gauss
				    - \f$ 0 \leq mumas \leq ndgl \f$ Mass matrix has bandwidth mumas
				 \param solout Output function for continuous time output
				 \param iout Output parameter
				  - \f$ iout \geq 1 \f$ Output of the state vector for every accepted step
				  - \f$ iout = 0 \f$ No output, dummy function required
				 \param work Working array for double variables
				 \param lwork Size of working array for double variables
				 \param iwork Working array for integer variables
				 \param liwork Size of working array for integer variables
				 \param rpar Array for double parameters
				 \param ipar Array for integer parameters
				 \param did Error flag:
				 - \f$ _did = 1 \f$ Successful termination
				 - \f$ _did = 2 \f$ Successful termination with output via yane::OdeSolve::OdeSolve::_solout
				 - \f$ _did = -1 \f$ Input data is inconsistent
				 - \f$ _did = -2 \f$ Maximal number of steps reached
				 - \f$ _did = -3 \f$ Step size became too small
				 - \f$ _did = -4 \f$ Problem seems to be too stiff
				*/
				void ( *_radau_func ) ( int * n, T_ODEFUNC FCN, double * x, double * y, double * xend,
										double *hinit, double * rtol, double * atol, int * itol,
										T_JACFUNC jac , int * ijac, int * mljac, int * mujac,
										T_MASSFUNC mass , int * imas, int * mlmas, int * mumas,
										T_SOLOUTFUNC solout, int * iout,
										double * work, int* lwork, int * iwork, int * liwork, double * rpar, int * ipar, int * did );

		};

	}

}

#endif
