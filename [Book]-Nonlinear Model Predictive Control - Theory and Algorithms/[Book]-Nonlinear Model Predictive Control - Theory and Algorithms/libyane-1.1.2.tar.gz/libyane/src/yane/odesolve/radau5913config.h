/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_RADAU5913CONFIG_H
#define YANE_ODESOLVE_RADAU5913CONFIG_H

#include "radauconfig.h"

namespace yane
{

	namespace OdeSolve
	{
		/**
		 * This class includes all configuration methods for the Radau5913 solver. \n
		 * Atter construction of an object of this class it is initialized with default values which usually give good results. Still, the parameters of the class should be adapted to the considered yane::Model::Model object.
		 * @brief Class to configure the Radau5913 solver
		 */
		class Radau5913Config : public RadauConfig
		{
			public:
				/**
				 * @brief Constructor
				 */
				Radau5913Config();

				/**
				 * @brief Destructor
				 */
				virtual ~Radau5913Config();


				/**
				 * This function sets the parameters for the definition of the order of consistency to be used for the integration method
				 * @param inc_factor The order is increase if the contraction is smaller than this factor
				 * @param dec_factor The order is decrease if the contraction is larger than this factor
				 * @param hfac1 The order is only decreased if \f$ hfac1 \leq \frac{h_{new}}{h_{old}} \leq hfac2 \f$ holds
				 * @param hfac2 see hfac1
				 * @throw WrongSolverInputException Is thrown if \f$ hfac1 > hfac2 \f$
				 * @sa getOrderSelectionParameters
				 * @brief Function to set the parameters for the defintion of the order of consistency to be used for the integration method
				 */
				void setOrderSelectionParameters ( double inc_factor = 0.002, double dec_factor = 0.8, double hfac1 = 0.8, double hfac2 = 1.2 );

				/**
				 * This function can be used to obtain the parameters for the definition of the order of consistency to be used for the integration method
				 * @param inc_factor The order is increase if the contraction is smaller than this factor
				 * @param dec_factor The order is decrease if the contraction is larger than this factor
				 * @param hfac1 The order is only decreased if \f$ hfac1 \leq \frac{h_{new}}{h_{old}} \leq hfac2 \f$ holds
				 * @param hfac2 see hfac1
				 * @sa setOrderSelectionParameters
				 * @brief Function to obtain the parameters for the defintion of the order of consistency to be used for the integration method
				 */
				void getOrderSelectionParameters ( double & inc_factor, double & dec_factor, double & hfac1, double & hfac2 );

				/**
				 * This function sets the bounds for the stages (valid stage values are 1, 3, 5 und 7). \n
				 * The order of consistency is fixed by the choice of the stage which is done computed by the method. The order of the method is then given by
				 * \f[ 2 \cdot \mbox{Stage} - 1 \f]
				 * @param minstage Lower bound for the stages
				 * @param maxstage Upper bound for the stages
				 * @param firststage Stages for the first step
				 * @throw WrongSolverInputException Is thrown if no valid values are supplied
				 * @sa getStages
				 * @brief Function to set the bounds for the stages
				 */
				void setStages ( int minstage = 3, int maxstage = 7, int firststage = 3 );

				/**
				 * This function can be used to obtain the bounds for the stages (valid stage values are 1, 3, 5 und 7).
				 * @param minstage Lower bound for the stages
				 * @param maxstage Upper bound for the stages
				 * @param firststage Stages for the first step
				 * @sa setStages
				 * @brief Function to obtain the bounds for the stages
				 */
				void getStages ( int & minstage, int & maxstage, int & firststage );

				/**
				 * This function overloads the standard method. It checks whether the supplied yane::OdeSolve::OdeConfig object possesses the ID of a yane::OdeSolve::Radau5913Config class and is therefore valid.
				 * @param config Configuration object to be checked
				 * @brief Function to check whether a supplied configuration object is of type yane::OdeSolve::RadauConfig
				 */
				static void assertValidConfigObject ( OdeConfig * config );

				virtual OdeConfig * clone();


			protected:

				virtual void copyToNoInvalidation ( OdeConfig * target );

				/**
				 * This function checks whether the stage number is valid
				 * @param stage Stage number
				 * @return true if valid, else false
				 * @brief Function to check whether the stage number is valid
				 * @sa setStages
				 */
				static bool isValidStage ( int stage );

				double _os_inc;		/**< @brief The order is increase if the contraction is smaller than this factor */
				double _os_dec;		/**< @brief The order is decrease if the contraction is larger than this factor */
				double _os_fac1;	/**< @brief The order is only decreased if \f$ hfac1 \leq \frac{h_{new}}{h_{old}} \leq hfac2 \f$ holds */
				double _os_fac2;	/**< @brief The order is only decreased if \f$ hfac1 \leq \frac{h_{new}}{h_{old}} \leq hfac2 \f$ holds */
				int _s_min;		/**< @brief Lower bound for the stages */
				int _s_max;		/**< @brief Upper bound for the stages */
				int _s_first;		/**< @brief Stages for the initial step */

		};
	}

}

#endif
