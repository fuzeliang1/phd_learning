/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "radau5913.h"
#include "radau5913config.h"
#include "odesolex.h"

#include "../utils.h"

#include <cstdlib>
#include <cstring>
#include <cfloat>

#include "libexport.h"

using namespace yane::Utils;

#define __FORTRANNAME(x) x##_
extern "C"
{
	void __FORTRANNAME ( radau ) ( int * n, yane::OdeSolve::T_ODEFUNC FCN, double * x, double * y, double * xend, double *hinit, double * rtol, double * atol, int * itol, yane::OdeSolve::T_JACFUNC jac , int * ijac, int * mljac, int * mujac, yane::OdeSolve::T_MASSFUNC mas , int * imas, int * mlmas, int * mumas, yane::OdeSolve::T_SOLOUTFUNC solout, int * iout, double * work, int* lwork, int * iwork, int * liwork, double * rpar, int * ipar, int * did );
}

LIB_EXPORT yane::OdeSolve::Radau5913::Radau5913 ( ) :
		yane::OdeSolve::Radau ( )
{

	_radau_func = __FORTRANNAME ( radau );
}

LIB_EXPORT void yane::OdeSolve::Radau5913::assertMemory()
{
	unsigned int sizejac, sizemas, sizee;

	if ( _paramdata.ljac == _paramdata.dimension )
	{
		sizejac = ( unsigned int ) _paramdata.dimension;
		sizee = ( unsigned int ) _paramdata.dimension;
	}
	else
	{
		sizejac = ( unsigned int ) _paramdata.ljac + ( unsigned int ) _paramdata.ujac + 1U;
		sizee = 2U * ( unsigned int ) _paramdata.ljac + ( unsigned int ) _paramdata.ujac + 1U;
	}

	if ( _paramdata.has_mas == 0 )
	{
		sizemas = 0;
	}
	else
	{
		if ( _paramdata.lmas == _paramdata.dimension )
		{
			sizemas = ( unsigned int ) _paramdata.dimension;
		}
		else
		{
			sizemas = ( unsigned int ) _paramdata.lmas + ( unsigned int ) _paramdata.umas + 1U;
		}
	}

	_lwork = ( unsigned int ) _paramdata.dimension * ( sizejac + sizemas + 7U * sizee + 3U * 7U + 3U ) + 20U;
	_liwork = ( 2U + ( 7U - 1U ) / 2U ) * ( unsigned int ) _paramdata.dimension + 20U;

	if ( ( _lwork << 3 ) < 0 || ( _liwork << 2 ) < 0 )
	{
		throw MemoryException ( __DEBUGMESS ( "working-arrays length overflow - the problem is too big" ) );
	}

	if ( _work != 0 )  delete _work;
	if ( _iwork != 0 ) delete _iwork;

	try
	{
		_work = new double[_lwork];
		_iwork = new int[_liwork];
	}
	catch ( std::bad_alloc )
	{
		throw MemoryException ( __DEBUGMESS ( "failed to allocate working-arrays" ) );
	}


}

LIB_EXPORT void yane::OdeSolve::Radau5913::assertConfig()
{
	Radau5913Config::assertValidConfigObject ( _config );

	Radau::assertConfig();

	( ( Radau5913Config* ) _config )->getOrderSelectionParameters ( _work[9], _work[10], _work[12], _work[11] );
	( ( Radau5913Config* ) _config )->getStages ( _iwork[10],  _iwork[11],  _iwork[12] );

}

LIB_EXPORT yane::OdeSolve::OdeSolveFirst * yane::OdeSolve::Radau5913::clone()
{
	return new Radau5913();
}

LIB_EXPORT yane::OdeSolve::Radau5913::~ Radau5913()
{
}
