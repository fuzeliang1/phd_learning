/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_RK4_H
#define YANE_ODESOLVE_RK4_H

#include "../odesolve.h"

namespace yane
{
	namespace OdeSolve
	{

		/**
		 * @brief Class of Runge Kutta 4 solver for differential equation systems
		 */
		class RK4 : public OdeSolveFirst
		{
			public:
				/**
				* @brief Constructor
				* @param h Step size of the Heun method
				 */
				RK4 ( double h );

				virtual ~RK4();

				virtual OdeSolveFirst * clone();

				virtual int acceptedSteps();

				virtual int computedSteps();

				virtual int functionEvalCount();

				virtual int rejectedSteps();

				/**
				 * @brief Function to set the step size of the Runge Kutta 4 method
				 * @param h Step size of the Heun method
				 */
				virtual void setStepsize ( double h );

				/**
				@brief Function to obtain the stepsize
				 */
				virtual double stepsize ( void );


			protected:

				virtual void abstractCalc ( double t, double * rpar = 0, int* ipar = 0 );

				virtual void assertMemory();
				virtual void assertValidDGL ( OdeFunction * dgl );

				double * _tempy, * _tempy2, * _y2;  /**< @brief Auxilliary variables to save the state vector */
				int _steps;   /**< @brief Step counter */
				double _h;   /**< @brief Step size */
		};

	}

}

#endif
