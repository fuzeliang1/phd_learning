/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */
 
#include "rodasconfig.h"
#include "odesolex.h"

#include "../utils.h"

#include <string>
#include <sstream>

#include "libexport.h"

using namespace yane::Utils;
using namespace std;

LIB_EXPORT yane::OdeSolve::RodasConfig::RodasConfig()
{
	setCoefficientChoice();
	setStepsizeStrategy();
}

LIB_EXPORT yane::OdeSolve::RodasConfig::~ RodasConfig()
{
}

LIB_EXPORT void yane::OdeSolve::RodasConfig::setStepsizeStrategy(T_STEPSIZESTRATEGY strategy)
{
	if (strategy != Gustaffson && strategy != Classic)
	{
		stringstream out;
		out << "Unknown stepsize-strategy '" << (int)strategy << "'. ";
		out << "Supported strategies are Gustaffson '" << (int)Gustaffson << "' and Classic '" << (int)Classic << "'.";
		throw WrongSolverInputException(__DEBUGMESS(out.str()));
	}

	_strat = strategy;

	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::RodasConfig::getStepsizeStrategy(T_STEPSIZESTRATEGY & strategy)
{
	strategy = _strat;
}

LIB_EXPORT void yane::OdeSolve::RodasConfig::setCoefficientChoice(int choice)
{
	_coeff_choice = choice;
	invalidateOldConfig();
}

LIB_EXPORT void yane::OdeSolve::RodasConfig::getCoefficientChoice(int & choice)
{
	choice = _coeff_choice;
}

LIB_EXPORT void yane::OdeSolve::RodasConfig::assertValidConfigObject(OdeConfig * config)
{
	RodasConfig * conf = dynamic_cast<RodasConfig*>(config);

	if (!conf )	throw IncompatibleConfigException(__DEBUGMESS("Configtype 'RadauConfig' or derived type expected, but got something else"));
}

LIB_EXPORT yane::OdeSolve::OdeConfig * yane::OdeSolve::RodasConfig::clone()
{
	RodasConfig * result = new RodasConfig();

	copyTo(result);

	return result;
}

LIB_EXPORT void yane::OdeSolve::RodasConfig::copyToNoInvalidation(OdeConfig * target)
{
	assertValidConfigObject(target);

	OdeConfig::copyToNoInvalidation(target);

	RodasConfig * rodastarget = (RodasConfig*)target;

	rodastarget->_strat = _strat;
	rodastarget->_coeff_choice = _coeff_choice;

}
