/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_ODESOLVE_EULER_H
#define YANE_ODESOLVE_EULER_H

#include "odesolvefirst.h"

namespace yane
{
	namespace OdeSolve
	{

		/**
		 * @brief Class of Radau solver for differential equation systems
		*/
		class Euler : public OdeSolveFirst
		{
			public:
				/**
				 * @brief Constructor
				 * @param h Step size of the Euler method
				 */
				Euler ( double h );

				virtual ~Euler();

				virtual OdeSolveFirst * clone();

				virtual int acceptedSteps();

				virtual int computedSteps();

				virtual int functionEvalCount();

				virtual int rejectedSteps();

				/**
				 * @brief Function to set the step size of the Euler method
				 * @param h Step size of the Euler method
				 */
				virtual void setStepsize ( double h );

				/**
				 * Funktion zum Auslesen der Schrittweite
				 */
				virtual double stepsize ( void );


			protected:

				virtual void abstractCalc ( double t, double * rpar = 0, int* ipar = 0 );

				virtual void assertMemory();
				virtual void assertValidDGL ( OdeFunction * dgl );

				double * _tempy;  /**< @brief Auxilliary variable to save the state vector */
				int _steps;   /**< @brief Step counter */
				double _h;   /**< @brief Step size */
		};

	}

}

#endif
