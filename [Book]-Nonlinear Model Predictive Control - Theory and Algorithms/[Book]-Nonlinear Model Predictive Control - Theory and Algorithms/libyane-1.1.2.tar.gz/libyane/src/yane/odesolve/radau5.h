/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_RADAU5_H
#define YANE_ODESOLVE_RADAU5_H

#include "radau.h"

namespace yane
{
	namespace OdeSolve
	{

		/** \class Radau5
		\brief Class of Radau5 solver for differential equation systems
		*/
		class Radau5 : public Radau
		{
			public:

				/**
				 * @brief Constructor
				 */
				Radau5 ( );

				virtual ~Radau5();

				virtual OdeSolveFirst * clone();

			protected:
				virtual void assertMemory();
		};

	}

}

#endif
