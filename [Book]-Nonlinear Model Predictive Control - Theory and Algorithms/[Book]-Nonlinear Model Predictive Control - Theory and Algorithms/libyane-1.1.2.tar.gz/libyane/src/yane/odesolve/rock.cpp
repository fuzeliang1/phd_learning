/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "rock.h"
#include "odeconfig.h"
#include "odesolex.h"
#include "odefunction.h"

#include "../utils.h"

#include <cfloat>
#include <iostream>

#include "libexport.h"

using namespace std;
using namespace yane::Utils;


LIB_EXPORT yane::OdeSolve::ROCK::ROCK ( ) : OdeSolveFirst ( )
{
	_hinit = 0.1;
}

LIB_EXPORT void yane::OdeSolve::ROCK::abstractCalc ( double t, double * rpar, int* ipar )
{
	if (_hinit > t-_t)
	{
		_hinit = t-_t;
	}
	
	_rock_func ( &_dimension, &_t , &t, &_hinit, _y, _paramdata.odefunc,
				 ( _itol == 0 ? &_atol : _atol_vec ), ( _itol == 0 ? &_rtol : _rtol_vec ),
				 _paramdata.rhofunc, _paramdata.soloutfunc, &_paramdata.has_solout, _work, _iwork, rpar, ipar, &_did );

	if ( _did != 0 )
	{
		switch ( _did )
		{
			case - 1:
				throw WrongSolverInputException ( __DEBUGMESS ( "invalid solver initialization" ) );
			case - 2:
				throw TooSmallStepSizeException ( __DEBUGMESS ( "the stepsize went too small" ) );
			case - 3:
				throw UnsuccessfulException ( __DEBUGMESS ( "internal method to estimate spectral radius did not converge" ) );
		}
	}
}

LIB_EXPORT void yane::OdeSolve::ROCK::assertConfig()
{
	OdeConfig::assertValidConfigObject ( _config );
	OdeSolve::assertConfig();

	_config->getInitialStepsize ( _hinit );
	if ( _hinit < 1E-4 ) _hinit = 0.1;

	_iwork[0] = _paramdata.has_rho;
	_iwork[1] = _paramdata.rho_is_constant;
	_iwork[2] = 0;
	_iwork[3] = _itol;
}

LIB_EXPORT int yane::OdeSolve::ROCK::functionEvalCount()
{
	return _iwork[4];
}

LIB_EXPORT int yane::OdeSolve::ROCK::computedSteps()
{
	return _iwork[5];
}

LIB_EXPORT int yane::OdeSolve::ROCK::acceptedSteps()
{
	return _iwork[6];
}

LIB_EXPORT int yane::OdeSolve::ROCK::rejectedSteps()
{
	return _iwork[7];
}

LIB_EXPORT yane::OdeSolve::ROCK::~ROCK()
{
}

LIB_EXPORT void yane::OdeSolve::ROCK::assertValidDGL ( OdeFunction * dgl )
{
	T_ODEPARAMS tempparams;
	dgl->getParams ( &tempparams );

	if ( tempparams.has_mas != 0 ) throw IncompatibleDGLException ( __DEBUGMESS ( "Mass-Matrix is not supported by ROCK-solvers" ) );
}


