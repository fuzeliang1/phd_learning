/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_ODESOLVE_ODESOLVEFIRST_H
#define YANE_ODESOLVE_ODESOLVEFIRST_H

#include "odesolve.h"

namespace yane
{

	namespace OdeSolve
	{

		/**
		 * @brief Class of differential or difference equation systems
		 */
		class OdeSolveFirst : public OdeSolve
		{
			public:
				virtual ~OdeSolveFirst();

				/**
				 * This abstract function clone the object derived from the yane::OdeSolve::OdeSolve. Note that the new instance is constructed but not initialized. Hence, the function yane::OdeSolve::OdeSolve::reset and yane::OdeSolve::OdeSolve::init must be called prior to using this object. In a similar manner, the user must delete this object himself. It is not delete if the object which has been cloned is deleted.
				 * @return Clone of the object
				 * @brief Function to construct a clone of the object derived from the class yane::OdeSolve::OdeSolve
				 */
				virtual OdeSolveFirst * clone() = 0;

				/**
				 * @brief Function to set the initial values for the differential or difference equation system solver
				 * @param t0 Initial time
				 * @param y0 Initial state vector. On exit, this variable contrains the solution at the terminal time instance.
				 * @throw yane::Utils::NotInitializedException Is thrown if the solver has not been initialized
				 */
				void init ( double t0, double * y0 );

			protected:

				/**
				 * @brief Constructor
				 */
				OdeSolveFirst();


		};

	}

}

#endif
