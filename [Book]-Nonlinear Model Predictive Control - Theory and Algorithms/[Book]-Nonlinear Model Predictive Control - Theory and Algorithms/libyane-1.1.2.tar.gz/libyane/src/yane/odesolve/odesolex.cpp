/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "odesolex.h"

#include "../utils.h"

#include <iostream>

#include "libexport.h"

using namespace yane::Utils;

LIB_EXPORT const std::string yane::OdeSolve::OdeSolEx::TYPE = std::string ( "yane::OdeSolve::OdeSolEx" );

LIB_EXPORT yane::OdeSolve::OdeSolEx::OdeSolEx ( std::string mess, std::string debug, Exception * ex )
		: Exception ( mess, debug, ex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::OdeSolve::WrongSolverInputException::TYPE = std::string ( "yane::OdeSolve::wrongSolverInputException" );

LIB_EXPORT yane::OdeSolve::WrongSolverInputException::WrongSolverInputException ( std::string debug, Exception * ex )
		: OdeSolEx ( __EXCEPTIONMESS ( TYPE, "invalid solver-configuration" ), debug, ex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::OdeSolve::TooManyStepsException::TYPE = std::string ( "yane::OdeSolve::tooManyStepsException" );

LIB_EXPORT yane::OdeSolve::TooManyStepsException::TooManyStepsException ( std::string debug, Exception * ex )
		: OdeSolEx ( __EXCEPTIONMESS ( TYPE, "solver needs too many steps" ), debug, ex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::OdeSolve::TooSmallStepSizeException::TYPE = std::string ( "yane::OdeSolve::tooSmallStepSizeException" );

LIB_EXPORT yane::OdeSolve::TooSmallStepSizeException::TooSmallStepSizeException ( std::string debug, Exception * ex )
		: OdeSolEx ( __EXCEPTIONMESS ( TYPE, "stepsize became too small" ), debug, ex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::OdeSolve::NoInitialValueException::TYPE = std::string ( "yane::OdeSolve::noInitialValueException" );

LIB_EXPORT yane::OdeSolve::NoInitialValueException::NoInitialValueException ( std::string debug, Exception * ex )
		: OdeSolEx ( __EXCEPTIONMESS ( TYPE, "solverobject has no initial value" ), debug, ex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::OdeSolve::SingularyMatrixException::TYPE = std::string ( "yane::OdeSolve::singularyMatrixException" );

LIB_EXPORT yane::OdeSolve::SingularyMatrixException::SingularyMatrixException ( std::string debug, Exception * ex )
		: OdeSolEx ( __EXCEPTIONMESS ( TYPE, "solver got a singulary matrix" ), debug, ex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::OdeSolve::StiffException::TYPE = std::string ( "yane::OdeSolve::stiffException" );

LIB_EXPORT yane::OdeSolve::StiffException::StiffException ( std::string debug, Exception * ex )
		: OdeSolEx ( __EXCEPTIONMESS ( TYPE, "the problem is stiff and the current solver cannot handle it" ), debug, ex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::OdeSolve::UnsuccessfulException::TYPE = std::string ( "yane::OdeSolve::unsuccessfulException" );

LIB_EXPORT yane::OdeSolve::UnsuccessfulException::UnsuccessfulException ( std::string debug, Exception * ex )
		: OdeSolEx ( __EXCEPTIONMESS ( TYPE, "solver has not been successful" ), debug, ex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::OdeSolve::IncompatibleConfigException::TYPE = std::string ( "yane::OdeSolve::incompatibleConfigException" );

LIB_EXPORT yane::OdeSolve::IncompatibleConfigException::IncompatibleConfigException ( std::string debug, Exception * ex )
		: OdeSolEx ( __EXCEPTIONMESS ( TYPE, "incompatible configuration-object" ), debug, ex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::OdeSolve::IncompatibleDGLException::TYPE = std::string ( "yane::OdeSolve::incompatibleDGLException" );

LIB_EXPORT yane::OdeSolve::IncompatibleDGLException::IncompatibleDGLException ( std::string debug, Exception * ex )
		: OdeSolEx ( __EXCEPTIONMESS ( TYPE, "ODE-system is not supported by this solver" ), debug, ex )
{
	addType ( TYPE );
}


