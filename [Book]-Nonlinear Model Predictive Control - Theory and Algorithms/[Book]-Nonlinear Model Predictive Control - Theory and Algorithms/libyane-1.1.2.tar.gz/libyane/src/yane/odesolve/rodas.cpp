/***************************************************************************
 *                                                                         *
 * Library of the Differential Equation Solver                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */
 
#include "rodas.h"
#include "rodasconfig.h"
#include "odesolex.h"

#include "../utils.h"

#include <cfloat>
#include <iostream>

#include "libexport.h"

using namespace yane::Utils;
using namespace std;

#define __FORTRANNAME(x) x##_
extern "C"
{
	void __FORTRANNAME ( rodas ) ( int * n, yane::OdeSolve::T_ODEFUNC FCN, int * ifcn, double * x, double * y, double * xend, double * hinit, double * rtol, double * atol, int * itol, yane::OdeSolve::T_JACFUNC JAC, int * ijac, int * mljac, int * mujac, yane::OdeSolve::T_DFTFUNC DFX, int * idfx, yane::OdeSolve::T_MASSFUNC MAS, int * imas, int * mlmas, int * mumas, yane::OdeSolve::T_SOLOUTFUNC solout, int * iout, double * work, int* lwork, int * iwork, int * liwork, double * rpar, int * ipar, int * did );
}

LIB_EXPORT yane::OdeSolve::Rodas::Rodas()
{
	_rodas_func = __FORTRANNAME ( rodas );
}

LIB_EXPORT yane::OdeSolve::Rodas::~ Rodas()
{
}

LIB_EXPORT yane::OdeSolve::OdeSolveFirst * yane::OdeSolve::Rodas::clone()
{
	return new Rodas();
}

LIB_EXPORT int yane::OdeSolve::Rodas::acceptedSteps()
{
	return _iwork[16];
}

LIB_EXPORT int yane::OdeSolve::Rodas::computedSteps()
{
	return _iwork[15];
}

LIB_EXPORT int yane::OdeSolve::Rodas::functionEvalCount()
{
	return _iwork[13];
}

LIB_EXPORT int yane::OdeSolve::Rodas::rejectedSteps()
{
	return _iwork[17];
}

LIB_EXPORT void yane::OdeSolve::Rodas::abstractCalc(double t, double * rpar, int * ipar)
{	
	_rodas_func ( &_dimension, _paramdata.odefunc, &_paramdata.autonome, & ( _t ), _y, &t, &_hinit, (_itol == 0 ? &_rtol : _rtol_vec), (_itol == 0 ? &_atol : _rtol_vec), &_itol, 
	_paramdata.jacobifunc, &_paramdata.has_jac, &_paramdata.ljac, &_paramdata.ujac,
	_paramdata.dftfunc, &_paramdata.has_dft, 
	_paramdata.massfunc, &_paramdata.has_mas, &_paramdata.lmas, &_paramdata.umas, 
	_paramdata.soloutfunc, &_paramdata.has_solout,
	_work, &_lwork, _iwork, &_liwork, rpar, ipar, &_did );

	if ( _did!=0 )
	{
		switch ( _did )
		{
			case -1: throw WrongSolverInputException(__DEBUGMESS("invalid solver initialization"));
			case -2: throw TooManyStepsException(__DEBUGMESS("solver needed too many steps"));
			case -3: throw TooSmallStepSizeException(__DEBUGMESS("the stepsize went too small"));
			case -4: throw SingularyMatrixException ( __DEBUGMESS ( "Singular Jacobian" ) );
		}
	}
}

LIB_EXPORT void yane::OdeSolve::Rodas::assertMemory()
{
	unsigned int sizejac, sizemas, sizee;

	if ( _paramdata.ljac == _paramdata.dimension )
	{
		sizejac = ( unsigned int ) _paramdata.dimension;
		sizee = ( unsigned int ) _paramdata.dimension;
	}
	else
	{
		sizejac = ( unsigned int ) _paramdata.ljac + ( unsigned int ) _paramdata.ujac + 1U;
		sizee = 2U * ( unsigned int ) _paramdata.ljac + ( unsigned int ) _paramdata.ujac + 1U;
	}

	if ( _paramdata.has_mas == 0 )
	{
		sizemas = 0;
	}
	else
	{
		if ( _paramdata.lmas == _paramdata.dimension )
		{
			sizemas = ( unsigned int ) _paramdata.dimension;
		}
		else
		{
			sizemas = ( unsigned int ) _paramdata.lmas + ( unsigned int ) _paramdata.umas + 1U;
		}
	}

	_lwork = ( unsigned int ) _paramdata.dimension * ( sizejac + sizemas + sizee + 14U ) + 20U;
	_liwork = ( unsigned int ) _paramdata.dimension + 20U;

	if ( ( _lwork << 3 ) < 0 || ( _liwork << 2 ) < 0 )
	{
		throw MemoryException ( __DEBUGMESS ( "working-arrays length overflow - the problem is too big" ) );
	}

	if ( _work != 0 ) delete _work;
	if ( _iwork != 0 ) delete _iwork;

	try
	{
		_work = new double[_lwork];
		_iwork = new int[_liwork];
	}
	catch ( std::bad_alloc )
	{
		throw MemoryException ( __DEBUGMESS ( "failed to allocate working-arrays" ) );
	}
}

LIB_EXPORT void yane::OdeSolve::Rodas::assertConfig()
{
	RodasConfig::assertValidConfigObject ( _config );
	OdeSolve::assertConfig();

	( ( RodasConfig* ) _config )->getMaxSteps ( _iwork[0] );
	( ( RodasConfig* ) _config )->getSafetyFactor ( _work[4] );
	( ( RodasConfig* ) _config )->getStepsizeSelectionParameters ( _work[2], _work[3] );
	( ( RodasConfig* ) _config )->getMaxStepsize ( _work[1] );
	( ( RodasConfig* ) _config )->getInitialStepsize ( _hinit );
	( ( RodasConfig* ) _config )->getCoefficientChoice (  _iwork[1] );

	T_STEPSIZESTRATEGY strat;
	( ( RodasConfig* ) _config )->getStepsizeStrategy ( strat );
	_iwork[2] = strat;

	_work[0] = DBL_EPSILON;

	_iwork[1] = 0;
	_iwork[8] = 0;
	_iwork[9] = 0;
}

LIB_EXPORT void yane::OdeSolve::Rodas::assertValidDGL(OdeFunction * dgl)
{
}
