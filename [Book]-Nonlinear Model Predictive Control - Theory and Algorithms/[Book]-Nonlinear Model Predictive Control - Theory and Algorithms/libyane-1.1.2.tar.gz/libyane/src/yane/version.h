/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */


#include <string>

namespace libyane
{
	void versionStringToInt(std::string versionstr, int & maj, int & min, int & rev);
	void checkVersionCompatibility(const char * chk_ver);
	std::string buildTimeStamp();
	std::string version();
	std::string name();

}
