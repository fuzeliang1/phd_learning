/***************************************************************************
 *                                                                         *
 * Equation System Library                                                 *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

/** \namespace yane::EqSys
	\brief Namespace of the Linear Equation Systems Solver
*/

#ifndef YANE_EQSYS_MAIN
#define YANE_EQSYS_MAIN

#include "eqsys/linearequations.h"
#include "eqsys/directmethods.h"
#include "eqsys/gauss.h"
#include "eqsys/qrhouseholder.h"
#include "eqsys/qrgivens.h"
#include "eqsys/cholesky.h"
#include "eqsys/iterativemethods.h"
#include "eqsys/gaussseidel.h"
#include "eqsys/jacobi.h"

#include "eqsys/nonlinearequations.h"
#include "eqsys/newton.h"
#include "eqsys/banachfp.h"

#endif
