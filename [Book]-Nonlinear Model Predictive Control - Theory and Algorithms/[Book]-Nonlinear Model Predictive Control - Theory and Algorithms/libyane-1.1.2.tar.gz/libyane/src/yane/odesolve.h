/***************************************************************************
 *                                                                         *
 * ODE Solver Library                                                      *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

/** \namespace yane::OdeSolve
	\brief Namespace of the Differential Equation Solvers
*/


#ifndef YANE_ODESOLVE_MAIN
#define YANE_ODESOLVE_MAIN

#include "odesolve/odefunction.h"
#include "odesolve/odesolex.h"

#include "odesolve/odesolve.h"
#include "odesolve/odesolvefirst.h"
#include "odesolve/dopri.h"
#include "odesolve/dopri5.h"
#include "odesolve/dopri853.h"
#include "odesolve/radau.h"
#include "odesolve/radau5.h"
#include "odesolve/radau5913.h"
#include "odesolve/euler.h"
#include "odesolve/heun.h"
#include "odesolve/rk4.h"
#include "odesolve/recursesequence.h"
#include "odesolve/rock2.h"
#include "odesolve/rock4.h"
#include "odesolve/rodas.h"


#include "odesolve/odeconfig.h"
#include "odesolve/dopriconfig.h"
#include "odesolve/radauconfig.h"
#include "odesolve/radau5913config.h"
#include "odesolve/rodasconfig.h"

#endif
