/***************************************************************************
 *                                                                         *
 * Interface Library for Minimizer NLPQLP                                  *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>             *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

/** \namespace yane
	\brief Main namespace
 */

/** \namespace yane::SqpFortran
	\brief Namespace of the SQP routine NLPQLP
*/

#ifndef YANE_SQPFORTRAN_MAIN
#define YANE_SQPFORTRAN_MAIN

#include "sqpfortran/sqpfortran.h""


#endif
