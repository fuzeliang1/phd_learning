/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_STATISTICSCLIENTINTCOUNTER_H
#define YANE_UTILS_STATISTICSCLIENTINTCOUNTER_H

#include "statisticsclient.h"

namespace yane
{

	namespace Utils
	{

		/** \class StatisticsClientIntCounter
		 * @see StatisticsMaster
		 * This class uses a StatisticsMaster to gather integer valued statistical information.
		 * @brief StatisticsClientIntCounter class
		 */
		class StatisticsClientIntCounter : public yane::Utils::StatisticsClient
		{
			public:
				/**
				 * Constructor
				 * @param master Pointer of the StatisticsMaster class the client belongs to
				 * @param group Group of clients the client belongs to
				 * @param name Name of the client
				 * @brief Constructor
				 */
				StatisticsClientIntCounter ( StatisticsMaster * master, const std::string & group,
				        const std::string & name );

				/**
				 * @brief Destructor
				 */
				virtual ~StatisticsClientIntCounter ( );

				/**
				 * Function to add an integer value to the statistical variable
				 * @param value Value to add to the variable
				 * @brief Function to add an integer value to the statistical variable
				 */
				void addValue ( int value );

				/**
				 * Function to set the value of the statistical variable
				 * @param value Value the variable is set to
				 * @brief Function to set the value of the statistical variable
				 */
				void setValue ( int value );

				virtual std::string formattedData ( );
				virtual void reset ( );

			protected:
				int _value; /**< @brief Value of the statistical variable */
		};

	}

}

#endif
