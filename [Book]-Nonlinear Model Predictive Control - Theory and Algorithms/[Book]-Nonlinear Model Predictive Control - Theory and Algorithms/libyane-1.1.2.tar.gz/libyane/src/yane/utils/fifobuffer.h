/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_FIFOBUFFER_H
#define YANE_UTILS_FIFOBUFFER_H

#include <pthread.h>

namespace yane
{

	namespace Utils
	{

		/** @class FIFOBuffer
		 * @brief Class generating a First-In-First-Out buffer to manage data
		 */
		class FIFOBuffer
		{
			public:
				/**
				 * Constructor
				 * @param maxsize Maximal size of the buffer
				 * @brief Constructor
				 */
				FIFOBuffer ( int maxsize );

				/**
				 * @brief Destructor
				 */
				~FIFOBuffer ( );

				/**
				 * Function to add data to the buffer
				 * @param src Data to be added to the buffer
				 * @param size Size of the data to be added
				 * @brief Function to add data to the buffer
				 */
				void push ( void * src, int size );

				/**
				 * Function to peek data within the buffer
				 * @param dest Variable to which the buffer data shall be copied to
				 * @param size Size of the data packet to be copied
				 * @brief Function to peek data within the buffer
				 */
				void peek ( void * dest, int size );

				/**
				 * Function to peek data within the buffer
				 * @param dest Variable to which the buffer data shall be copied to
				 * @param position Starting position upon which the buffer data shall be copied
				 * @param size Size of the data packet to be copied
				 * @brief Function to peek data within the buffer
				 */
				void peek ( void * dest, int position, int size );

				/**
				 * Function to return data from the beginning of the buffer and delete it
				 * @param dest Variable to which the buffer data shall be copied to
				 * @param size Size of the data packet to be copied and deleted from the buffer
				 * @brief Function to return data from the beginning of the buffer and delete it
				 */
				void pop ( void * dest, int size );

				/**
				 * Function to delete data from the beginning of the buffer
				 * @param size Size of the data packet to be deleted from the buffer
				 * @brief Function to delete data from the beginning of the buffer
				 */
				void discard ( int size );

				/**
				 * @brief Function to return the current size of the data stored in the buffer
				 */
				int size ( );

				/**
				 * @brief Function to clear the buffer
				 */
				void clear ( );

				/**
				 * @brief Function to lock the FIFOBuffer object
				 */
				void lock ( );

				/**
				 * @brief Function to unlcok the FIFOBuffer object
				 */
				void unlock ( );

			protected:
				/**
				 * Inline Function to return the index of the last element of the buffer if new data is added to buffer
				 * @param size Size of data to be added
				 * @brief Inline Function to return the index of the last element of the buffer if new data is added to buffer
				 */
				inline int end ( int size );

				pthread_mutex_t _locker; /**< @brief Auxilliary variable to lock the FIFOBuffer object */

				char * _buffer; /**< @brief Name of the buffer */
				int _start; /**< @brief Index of the current start of the buffer */
				int _size; /**< @brief Current size of the buffer */
				int _maxsize; /**< @brief Maximal size of the buffer */
		};

	}

}

#endif
