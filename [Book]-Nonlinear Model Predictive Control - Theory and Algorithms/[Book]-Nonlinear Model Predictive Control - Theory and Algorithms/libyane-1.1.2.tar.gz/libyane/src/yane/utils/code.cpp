/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "code.h"
#include <iostream>

#include "libexport.h"

using namespace  std;

LIB_EXPORT uint32_t yane::Utils::Code::grayToBinary(uint32_t gray)
{
	bool pos = true;
	uint32_t block = 0xFFFFFFFF;
	uint32_t ret = 0;

	for ( int i=31; i>=0; i--)
	{
		if ( (gray & (1<<i)) != 0 )
		{
			if (pos)
			{
				ret += block;
				pos = false;
			} else
			{
				ret -= block;
				pos = true;
			}
		}
		block >>= 1;
	}

	return ret;
}

LIB_EXPORT uint32_t yane::Utils::Code::binaryToGray(uint32_t binary)
{
	return binary ^ (binary >> 1);
}
