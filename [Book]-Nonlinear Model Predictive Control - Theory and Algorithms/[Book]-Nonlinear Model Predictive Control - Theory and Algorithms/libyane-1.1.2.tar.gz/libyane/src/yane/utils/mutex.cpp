/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "mutex.h"
#include "exceptions.h"

#include <iostream>

#include "libexport.h"

using namespace std;

// Constructor
LIB_EXPORT yane::Utils::Mutex::Mutex()
{
	if ( pthread_mutex_init ( &_mutex, NULL ) )
	{
		throw ThreadException ( __DEBUGMESS ( "Unable to create Mutex" ) );
	}
}

// Destructor
LIB_EXPORT yane::Utils::Mutex::~ Mutex()
{
	if ( pthread_mutex_destroy ( &_mutex ) )
	{
		throw ThreadException ( __DEBUGMESS ( "Unable to destroy Mutex" ) );
	}
}

// Lock Mutex
LIB_EXPORT void yane::Utils::Mutex::lock()
{
	if ( pthread_mutex_lock ( &_mutex ) )
	{
		throw ThreadException ( __DEBUGMESS ( "Unable to lock Mutex" ) );
	}
}

// Try to lock
LIB_EXPORT bool yane::Utils::Mutex::trylock()
{
	if ( pthread_mutex_trylock ( &_mutex ) == 0)
	{
		return true;
	}
	return false;

}

// Unlock mutex
LIB_EXPORT void yane::Utils::Mutex::unlock()
{
	if ( pthread_mutex_unlock ( &_mutex ) )
	{
		throw ThreadException ( __DEBUGMESS ( "Unable to unlock Mutex" ) );
	}
}

// Return wether Mutex is locked.
LIB_EXPORT bool yane::Utils::Mutex::isLocked()
{
#ifdef __WIN32
	// no access to pthread_mutex_t-struct { lock_idx, .... }.
	// return (_mutex.lock_idx != 0 );
	return ( (*((LONG*)(&_mutex))) != 0 );
#else
	bool tmp = trylock();
	if(tmp)
	{
		unlock();
		return true;
	}	
	else return false;
//	return ( _mutex.__data.__lock != 0 );
#endif
/*
#ifdef __WIN32
	if ( _mutex.lock_idx == 0 )
#else
	if ( _mutex.__data.__lock == 0 )
#endif
	{
		return false;
	}
	else
	{
		return true;
	}
*/
}

