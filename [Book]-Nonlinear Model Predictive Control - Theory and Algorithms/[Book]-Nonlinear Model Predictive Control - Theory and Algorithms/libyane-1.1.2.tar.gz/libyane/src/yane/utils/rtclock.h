/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_RTCLOCK_H
#define YANE_UTILS_RTCLOCK_H

#include <sys/time.h>

namespace yane
{

	namespace Utils
	{
		class Mutex;

		/** \class RTClock
			\brief Timer class
		*/
		class RTClock
		{

			public:

				/**
				 * @brief Constructor
				*/
				RTClock();

				/**
				 * @brief Destructor
				 */
				virtual ~RTClock();

				/**
				 * @brief Function to reset the timer
				*/
				void reset();

				/**
				 * @brief Function to reset the timer to a new initial time
				 * @param starttime Initial time for timer
				 */
				void reset ( const timeval & starttime );

				/**
				 * @brief Function to evaluate the passed time since start of the timer
				*/
				double elapsedSeconds();

				/**
				 * @brief Sets the elapsed seconds of this object to a specific value.
				 * @param seconds New value for elapsed seconds
				 * @see elapsedSeconds()
				 */
				void setElapsedSeconds(double seconds);
				
				/**
				 * @brief Function to pass the initial time of the timer to external routines
				 * @param time Initial time of the timer
				 */
				void getStartTime ( timeval * time );


			protected:
				timeval _starttime;		/**< @brief Initial time for timer */
				Mutex * _mutex;

		};


	}

}

#endif
