/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "statisticsclientaverage.h"
#include <iomanip>
#include <sstream>
#include <cmath>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::StatisticsClientAverage::StatisticsClientAverage ( StatisticsMaster* master,
        const std::string& group, const std::string& name, int prec, bool displaymin, bool displayavg, bool displaymax ) :
	StatisticsClient ( master, group, name )
{
	_value = 0.0;
	_minvalue = INFINITY;
	_maxvalue = - INFINITY;
	_amount = 0;
	_prec = prec;
	_displaymin = displaymin;
	_displaymax = displaymax;
	_displayavg = displayavg;
}

LIB_EXPORT yane::Utils::StatisticsClientAverage::~StatisticsClientAverage ( )
{
}

LIB_EXPORT std::string yane::Utils::StatisticsClientAverage::formattedData ( )
{
	stringstream out;
	out << fixed << setprecision ( _prec );
	if ( _displaymin )
	{
		out << _minvalue;
	}
	if ( _displayavg )
	{
		if ( _displaymin )
		{
			out << "/";
		}
		out << ( _value / ( double ) _amount );
	}
	if ( _displaymax )
	{
		if ( _displaymin || _displayavg )
		{
			out << "/";
		}
		out << _maxvalue;
	}

	return out.str ( );
}

LIB_EXPORT std::string yane::Utils::StatisticsClientAverage::name ( )
{
	stringstream out;
	out << StatisticsClient::name ( ) << " (";
	if ( _displaymin )
	{
		out << "min";
	}
	if ( _displayavg )
	{
		if ( _displaymin )
		{
			out << "/";
		}
		out << "avg";
	}
	if ( _displaymax )
	{
		if ( _displaymin || _displayavg )
		{
			out << "/";
		}
		out << "max";
	}
	out << ")";

	return out.str ( );
}

LIB_EXPORT void yane::Utils::StatisticsClientAverage::reset ( )
{
	_minvalue = INFINITY;
	_maxvalue = - INFINITY;
	_value = 0.0;
	_amount = 0;
}

LIB_EXPORT void yane::Utils::StatisticsClientAverage::addValue ( double value )
{
	if ( _displaymin )
	{
		if ( _minvalue > value ) _minvalue = value;
	}
	if ( _displayavg )
	{
		_value += value;
		++_amount;
	}
	if ( _displaymax )
	{
		if ( _maxvalue < value ) _maxvalue = value;
	}
}

