/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "exception.h"
#include <string>
#include <cstring>
#include <sstream>
#include <iomanip>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT bool yane::Utils::Exception::_printdebug=false;
LIB_EXPORT const std::string yane::Utils::Exception::TYPE=std::string("yane::Utils::Exception");

LIB_EXPORT yane::Utils::Exception::Exception(std::string mess, std::string debugm, yane::Utils::Exception * innerex) throw()
	: std::exception()
{
	if (innerex != 0)
	{
		_number = innerex->_number+1;
	} else
	{
		_number = 1;
	}

	std::stringstream debugout;
	debugout << std::setw(5) << _number << " --- " << mess << "\n";
	debugout << "          " << debugm;
	if (innerex != 0)
	{
		debugout << "\n\n";
		debugout << innerex->_debugmess;

		for (int i=0; i<innerex->_stacktypes.size(); i++)
		{
			_stacktypes.push_back(innerex->_stacktypes[i]);
		}
	}

	_debugmess = debugout.str();

	std::stringstream out;
	out << mess;

	if (_printdebug)
	{
		out << "\n\n";
		out << _debugmess;
	}

	_message = out.str();

	_types.push_back(TYPE);

	for (int i=0; i<_types.size(); i++)
	{
		_stacktypes.push_back(_types[i]);
	}
}

LIB_EXPORT yane::Utils::Exception::~ Exception() throw(  )
{
}

LIB_EXPORT const char * yane::Utils::Exception::what() const throw(  )
{
	return _message.c_str();
}

LIB_EXPORT const char * yane::Utils::Exception::debugmessage() const throw(  )
{
	return _debugmess.c_str();
}

LIB_EXPORT void yane::Utils::Exception::enableDebugMessage(bool enable)
{
	_printdebug=enable;
}

LIB_EXPORT std::string yane::Utils::Exception::concatDebugMessage(const char * functionname, int line, std::string message)
{
	stringstream out;
	out << "in \"" << functionname << "\", line " << line << ":\n          " << message;
	return out.str();
}

LIB_EXPORT std::string yane::Utils::Exception::concatMessage(const std::string & type, const std::string & message)
{
	stringstream out;
	out << message << " (" << type << ")";
	return out.str();
}


LIB_EXPORT void yane::Utils::Exception::addType(std::string type)
{
	_types.push_back(type);
}

LIB_EXPORT bool yane::Utils::Exception::isType(const std::string & type) const throw(  )
{
	for (int i=0; i<_types.size(); i++)
	{
		if (_types[i] == type) return true;
	}
	return false;
}

LIB_EXPORT bool yane::Utils::Exception::stackTraceContainsType(const std::string & type) const throw(  )
{
	for (int i=0; i<_stacktypes.size(); i++)
	{
		if (_stacktypes[i] == type) return true;
	}
	return false;
}

