/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "debugmasterconsole.h"
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::DebugMasterConsole::DebugMasterConsole ( RTClock * clock, int textwidth ) :
	DebugMasterTextStream ( clock, & cout, textwidth )
{
}

LIB_EXPORT yane::Utils::DebugMasterConsole::~DebugMasterConsole ( )
{
}
