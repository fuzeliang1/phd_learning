/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "thread.h"
#include "exceptions.h"
#include "debugmaster.h"
#include "debugclient.h"
#include "mutex.h"
#include "semaphore.h"

#include <sstream>
#include <cstring>
#include <sys/time.h>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::Thread::Thread ( const std::string & name, yane::Utils::DebugMaster * dm )
{
	if ( dm != 0 )
	{
		_debugclient = dm->newClient ( name.c_str() );
	}
	else
	{
		_debugclient = 0;
	}

	pthread_attr_init ( &_threadattr );
	pthread_attr_setdetachstate ( &_threadattr, PTHREAD_CREATE_JOINABLE );
	try
	{
		_mutex = new Mutex();
		_semaphore = new Semaphore();
	}
	catch ( Exception e )
	{
		throw Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of Mutex or Semaphore was not successful" ), &e );
	}

	_running = false;
	_abort = false;
}

LIB_EXPORT yane::Utils::Thread::~ Thread()
{
	stop();
	wait();

	if ( _debugclient ) delete _debugclient;
	delete _mutex;
	delete _semaphore;
}

LIB_EXPORT void yane::Utils::Thread::start()
{
	if ( _running )
	{
		debugMessage ( "Tried to start thread, but it's already active...", 0 );
		return;

	}
	int errcode = pthread_create ( &_thread, &_threadattr, threadWorker, this );
	if ( errcode != 0 )
	{
		stop();
		stringstream out;
		out << "creating thread failed (code=";
		out << errcode;
		out << ")";
		debugMessage ( out.str(), 0 );
		throw ThreadException ( __DEBUGMESS ( out.str() ) );
	}
}

LIB_EXPORT void yane::Utils::Thread::stop()
{
	lock();
	if ( _running )
	{
		_abort=true;
		unlock();
	}
	else
	{
		unlock();
	}
}

LIB_EXPORT void yane::Utils::Thread::wait()
{
	void * status;
	pthread_join ( _thread, &status );
}

LIB_EXPORT void yane::Utils::Thread::detach()
{
	pthread_detach ( _thread );
}

LIB_EXPORT void yane::Utils::Thread::trigger()
{
	_semaphore->release();
}

LIB_EXPORT bool yane::Utils::Thread::waitForTrigger ( unsigned int wait_msec, int debuglevel )
{
	//TODO: Unterschied?
	if ( wait_msec == 0 )
	{
		_semaphore->acquire();
		return true;
	}
	else
	{
		return _semaphore->tryAcquire ( 1, wait_msec );
	}
	return false;
}

LIB_EXPORT void yane::Utils::Thread::lock()
{
	_mutex->lock();
}

LIB_EXPORT bool yane::Utils::Thread::trylock()
{
	return _mutex->trylock();
}

LIB_EXPORT void yane::Utils::Thread::unlock()
{
	_mutex->unlock();
}

LIB_EXPORT void yane::Utils::Thread::debugMessage ( const std::string & message, int debuglevel )
{
	if ( _debugclient )
	{
		_debugclient->sendDebugMessage( message, debuglevel );
	}
}

LIB_EXPORT void yane::Utils::Thread::debugMessageDouble ( const std::string & message, const std::string & varname, int length, double * data, int debuglevel )
{
	if ( _debugclient )
	{
		_debugclient->sendDebugMessageDouble( message, varname, length, data, debuglevel );
	}
}

LIB_EXPORT void yane::Utils::Thread::debugMessageInt(const std::string & message, const std::string & varname, int length, int * data, int debuglevel)
{
	if ( _debugclient )
	{
		_debugclient->sendDebugMessageInt( message, varname, length, data, debuglevel );
	}
}


LIB_EXPORT void yane::Utils::Thread::debugMessageString ( const std::string & message, const std::string & varname, const char * data, int debuglevel )
{
	if ( _debugclient )
	{
		_debugclient->sendDebugMessageString( message, varname, data, debuglevel );
	}
}

void * yane::Utils::Thread::threadWorker ( void * arg )
{
	Thread * base = ( Thread* ) arg;
	base->_running = true;
	base->_abort = false;
	base->run();
	base->_running = false;

	pthread_exit ( NULL );
}

LIB_EXPORT bool yane::Utils::Thread::isRunning()
{
	return _running;
}

LIB_EXPORT bool yane::Utils::Thread::isLocked()
{
	return _mutex->isLocked();
}
