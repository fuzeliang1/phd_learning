/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "exceptions.h"

#include "libexport.h"

LIB_EXPORT const std::string yane::Utils::MemoryException::TYPE = std::string ( "yane::Utils::MemoryException" );

LIB_EXPORT yane::Utils::MemoryException::MemoryException ( std::string debugmessage, Exception * innerex ) :
	yane::Utils::Exception ( __EXCEPTIONMESS(TYPE, "allocating memory failed"), debugmessage, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::Utils::IndexException::TYPE = std::string ( "yane::Utils::IndexException" );

LIB_EXPORT yane::Utils::IndexException::IndexException ( std::string debugmessage, Exception * innerex ) :
	yane::Utils::Exception ( __EXCEPTIONMESS(TYPE, "index out of range"), debugmessage, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::Utils::ValueException::TYPE = std::string ( "yane::Utils::ValueException" );

LIB_EXPORT yane::Utils::ValueException::ValueException ( std::string debugmessage, Exception * innerex ) :
	yane::Utils::Exception ( __EXCEPTIONMESS(TYPE, "invalid value"), debugmessage, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::Utils::IOException::TYPE = std::string ( "yane::Utils::IOException" );

LIB_EXPORT yane::Utils::IOException::IOException ( std::string debugmessage, Exception * innerex ) :
	yane::Utils::Exception ( __EXCEPTIONMESS(TYPE, "file input/output error"), debugmessage, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::Utils::ThreadException::TYPE = std::string ( "yane::Utils::ThreadException" );

LIB_EXPORT yane::Utils::ThreadException::ThreadException ( std::string debugmessage, Exception * innerex ) :
	yane::Utils::Exception ( __EXCEPTIONMESS(TYPE, "file input/output error"), debugmessage, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::Utils::NotInitializedException::TYPE = std::string (
        "yane::Utils::NotInitializedException" );

LIB_EXPORT yane::Utils::NotInitializedException::NotInitializedException ( std::string debugmessage,
        Exception * innerex ) :
	yane::Utils::Exception ( __EXCEPTIONMESS(TYPE, "file input/output error"), debugmessage, innerex )
{
	addType ( TYPE );
}
