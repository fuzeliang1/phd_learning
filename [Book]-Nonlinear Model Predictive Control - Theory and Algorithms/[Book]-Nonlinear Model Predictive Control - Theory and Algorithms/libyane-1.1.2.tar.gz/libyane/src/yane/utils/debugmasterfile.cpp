/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "debugmasterfile.h"
#include <fstream>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::DebugMasterFile::DebugMasterFile ( RTClock * clock, std::string filename, int textwidth,
        bool overwrite ) :
	DebugMasterTextStream ( clock, new ofstream ( filename.c_str ( ) ), textwidth )
{
}

LIB_EXPORT yane::Utils::DebugMasterFile::~DebugMasterFile ( )
{
	( ( ofstream* ) _textstream )->close ( );
	delete _textstream;
}
