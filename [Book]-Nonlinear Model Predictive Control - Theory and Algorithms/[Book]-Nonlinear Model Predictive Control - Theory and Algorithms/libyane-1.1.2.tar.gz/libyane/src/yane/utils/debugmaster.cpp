/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "debugmaster.h"
#include "mutex.h"
#include "debugclient.h"

#include <iomanip>
#include <iostream>
#include <sstream>

#include <cstring>
#include <cstdlib>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::DebugMaster::DebugMaster ( RTClock * clock )
{
	_clock = clock;

	_mutex = new Mutex ( );
}

LIB_EXPORT yane::Utils::DebugMaster::~DebugMaster ( )
{
	delete _mutex;
}

LIB_EXPORT yane::Utils::DebugClient * yane::Utils::DebugMaster::newClient ( const char * clientname )
{
	return new DebugClient ( this, string ( clientname ) );
}

LIB_EXPORT string yane::Utils::DebugMaster::formatData ( void * data, int datalength, int datatype, int margin,
        int textwidth, int doubleprec, bool doublesci )
{
	stringstream out;

	string spacer = "";
	for ( int i = 0; i < margin; i++ )
	{
		spacer += " ";
	}

	out << spacer;

	if ( datatype == T_DOUBLE )
	{
		if ( doublesci ) out << std::scientific;
		out << setprecision ( doubleprec ) << * ( ( double* ) data );
	}
	else if ( datatype == T_INT )
	{
		out << * ( ( int* ) data );
	}
	else if ( datatype == T_STRING )
	{
		char * temp = ( char* ) malloc ( datalength + 1 );

		memcpy ( temp, data, datalength );
		temp [ datalength ] = 0;
		out << temp;
	}
	else if ( datatype == T_DOUBLEARRAY )
	{
		int arraysize = datalength / sizeof(double);
		double * dbl = ( double* ) data;
		int maxlength = 0;
		int maxindexlength = 0;
		for ( int i = 0; i < arraysize; i++ )
		{
			stringstream st;

			st << i;
			if ( st.str ( ).size ( ) > maxindexlength ) maxindexlength = st.str ( ).size ( );

			stringstream st2;

			st2 << ( doublesci == true ? scientific : fixed ) << setprecision ( doubleprec ) << dbl [ i ];
			if ( st2.str ( ).size ( ) > maxlength ) maxlength = st2.str ( ).size ( );
		}

		int columns = textwidth / ( maxlength + maxindexlength + 2 + 2 );
		int counter = 0;

		for ( int i = 0; i < arraysize; i++ )
		{
			out << setw ( maxindexlength ) << i << ": ";
			out << ( doublesci == true ? scientific : fixed ) << setw ( maxlength ) << setprecision ( doubleprec )
			        << dbl [ i ] << "  ";

			if ( ++counter == columns && i < arraysize - 1 )
			{
				out << endl << spacer;
				counter = 0;
			}
		}
	}
	else if ( datatype == T_INTARRAY )
	{
		int arraysize = datalength / sizeof(int);
		int * in = ( int* ) data;
		int maxlength = 0;
		int maxindexlength = 0;

		for ( int i = 0; i < arraysize; i++ )
		{
			stringstream st;

			st << i;
			if ( st.str ( ).size ( ) > maxindexlength ) maxindexlength = st.str ( ).size ( );

			stringstream st2;

			st2 << in [ i ];
			if ( st2.str ( ).size ( ) > maxlength ) maxlength = st2.str ( ).size ( );
		}

		int columns = textwidth / ( maxlength + maxindexlength + 2 + 2 );
		int counter = 0;

		for ( int i = 0; i < arraysize; i++ )
		{
			out << setw ( maxindexlength ) << i << ": " << setw ( maxlength ) << in [ i ] << "  ";

			if ( ++counter == columns && i < arraysize - 1 )
			{
				out << endl << spacer;
				counter = 0;
			}
		}
	}
	else if ( datatype == T_HEXCHARARRAY )
	{
		unsigned char * in = ( unsigned char* ) data;

		for ( int i = 0; i < datalength; i++ )
		{
			if ( ( i & 0x0000000F ) == 0 )
			{
				out << setfill ( '0' ) << setw ( 4 ) << setbase ( 16 ) << i << ": ";
			}
			out << setfill ( '0' ) << setw ( 2 ) << setbase ( 16 ) << ( unsigned int ) in [ i ] << " ";

			if ( ( i & 0x0000000F ) == 0x0000000F && i < datalength - 1 )
			{
				out << endl << spacer;
			}
		}
	}

	out << resetiosflags ( ios_base::scientific | ios_base::fixed );
	return out.str ( );
}

LIB_EXPORT void yane::Utils::DebugMaster::setLevel ( int level )
{
	_debuglevel = level;
}

LIB_EXPORT int yane::Utils::DebugMaster::level ( )
{
	return _debuglevel;
}
