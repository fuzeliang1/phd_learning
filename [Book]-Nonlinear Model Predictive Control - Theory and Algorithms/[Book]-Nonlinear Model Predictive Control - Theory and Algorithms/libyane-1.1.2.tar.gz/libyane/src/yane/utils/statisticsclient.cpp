/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "statisticsclient.h"
#include "statisticsmaster.h"

#include "libexport.h"

LIB_EXPORT yane::Utils::StatisticsClient::StatisticsClient ( StatisticsMaster * master, const std::string & group,
        const std::string & name )
{
	_master = master;
	_name = name;
	_group = _group;

	_master->registerClient ( this, group );
}

LIB_EXPORT yane::Utils::StatisticsClient::~StatisticsClient ( )
{
}

LIB_EXPORT std::string yane::Utils::StatisticsClient::name ( )
{
	return _name;
}
