/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_CRC32_H
#define YANE_UTILS_CRC32_H

namespace yane
{

	namespace Utils
	{

		/**
		 * Static class for crc32 computation
		 *
		 * @brief Class with a static method for crc32 computation
		*/
		class CRC32
		{
			public:
				/**
				 * Computes the crc32 checksum of data
				 * @param data Pointer to the data, that has to be proceeded
				 * @param size size of the given data in bytes
				 * @return crc32 checksum value of the given data
				 */
				static unsigned int compute(void * data, int size);

			private:

				/**
				 * Abstract destructor, so no objects can be constucted
				 */
				virtual ~CRC32()=0;

		};

	}

}

#endif
