/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_EXCEPTIONS_H
#define YANE_UTILS_EXCEPTIONS_H

#include "exception.h"

#include <string>

namespace yane
{

	namespace Utils
	{

		/**
		 * @brief Exception due to failure during memory allocation
		 */
		class MemoryException : public Exception
		{
			public:
				MemoryException ( std::string debugmessage = "", Exception * innerex = 0 );
				static const std::string TYPE;

		};

		/**
		 * @brief Exception due to accessing invalid array index
		 */
		class IndexException : public Exception
		{
			public:
				IndexException ( std::string debugmessage = "", Exception * innerex = 0 );
				static const std::string TYPE;

		};

		/**
		 * @brief Exception due to invalid value
		 */
		class ValueException : public Exception
		{
			public:
				ValueException ( std::string debugmessage = "", Exception * innerex = 0 );
				static const std::string TYPE;

		};

		/**
		 * @brief Exception due to failure in accessing a file
		 */
		class IOException : public Exception
		{
			public:
				IOException ( std::string debugmessage = "", Exception * innerex = 0 );
				static const std::string TYPE;

		};

		/**
		 * @brief Exception due to failure in thread context
		 */
		class ThreadException : public Exception
		{
			public:
				ThreadException ( std::string debugmessage = "", Exception * innerex = 0 );
				static const std::string TYPE;

		};

		/**
		 * @brief Exception that is thrown, if an uninizialized Object shall be used
		 */
		class NotInitializedException : public Exception
		{
			public:
				NotInitializedException ( std::string debugmessage = "", Exception * innerex = 0 );
				static const std::string TYPE;

		};

	}

}

#endif
