/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_DEBUGMASTER_H
#define YANE_UTILS_DEBUGMASTER_H

#include <string>

namespace yane
{

	namespace Utils
	{

		class DebugClient;
		class Mutex;
		class RTClock;
		class Uuid;

		/** \class DebugMaster
		 * Class to use and create the DebugMaster. A DebugMaster is used to debug data or output messages.
		 * Usually there is one DebugMaster in every program and at least (usually more than) one DebugClient.
		 * This class is used as following:
		 * @li create DebugMaster from a class that inherits from DebugMaster (e.g. DebugMasterFile, DebugMasterConsole)
		 * @li create DebugClient by master->newClient();
		 * @li debug some messages
		 * @li delete both.
		 * @brief DebugMaster base class
		 */

		class DebugMaster
		{
			public:

				/** \enum
				 * This enum specifies the data type of the appended data to a debug message.
				 * @brief Enum to specify datatype
				 */
				enum
				{
					T_VOID = 0,
					T_DOUBLE = 1,
					T_INT = 2,
					T_STRING = 3,
					T_DOUBLEARRAY = 4,
					T_INTARRAY = 5,
					T_HEXCHARARRAY = 6
				};

				/**
				 * This creates the DebugMaster object.
				 * @param clock Clock the current program is using.
				 @brief Constructor
				 */
				DebugMaster ( RTClock * clock );

				/**
				 * Destroys the object.
				 * @brief Destructor
				 */
				virtual ~DebugMaster ( );

				/**
				 * Add some messages and/or data. Needs to be overwritten to provide your own functionality.
				 * @param clientname Client from which the debug message was forwarded.
				 * @param message Debug message
				 * @param dataname Name of the data
				 * @param data Pointer to the data
				 * @param datasize Size of the data
				 * @param datatype Type of the data
				 * @param level Debug level of the data
				 * @brief Add some messages and/or data
				 */
				virtual void addDebugInfo ( std::string clientname, std::string message, std::string dataname,
				        void* data, int datasize, int datatype, int level ) = 0;

				/**
				 * Creates new DebugClient with current master as master.
				 * @param clientname Name of the client which is displayed in the debug messages.
				 * @return DebugClient
				 * @brief Creates new DebugClient
				 */
				virtual DebugClient * newClient ( const char * clientname );

				/**
				 * Sets a new level
				 * @param level New debug level
				 * @brief Sets a new level
				 */
				virtual void setLevel ( int level );

				/**
				 * Get the current level
				 * @return Current debug level
				 * @brief Get current level
				 */
				virtual int level ( );

			protected:
				/**
				 * Formats the appended data of a debug message.
				 * @param data Pointer to the appended data.
				 * @param datalength Length of the data.
				 * @param datatype Type of the data.
				 * @param margin Space after which the message starts.
				 * @param textwidth Width after which a line is wrapped.
				 * @param doubleprec Precision of a double.
				 * @param doublesci Wether fixed or scientific is used.
				 * @return Formated string
				 * @brief Format appended data
				 */
				virtual std::string formatData ( void * data, int datalength, int datatype, int margin, int textwidth,
				        int doubleprec, bool doublesci );

				/**< Mutex this object is using. */
				Mutex * _mutex;
				/**< Clock this object is using. */
				RTClock * _clock;
				/**< Current debug level. */
				int _debuglevel;

		};

	}

}

#endif
