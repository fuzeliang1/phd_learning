/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_GRIDIO_H
#define YANE_UTILS_GRIDIO_H

#include <cstdio>
#include <string>

namespace yane
{

	namespace Utils
	{
//TODO Documentation of class GridIO
		/** @class GridIO
		 * @brief not yet documented
		 */
		class GridIO
		{
			public:
				GridIO ( const char * filename, unsigned int dimension, unsigned int * gridsize, double * lb,
				        double * ub );
				GridIO ( const char * filename );

				~GridIO ( );

				void setCoordName ( unsigned int coord, const char * name );
				void getCoordName ( unsigned int coord, char * name );

				void setTitle ( const char * name );
				void getTitle ( char * name );
				unsigned int getFrameCount ( );
				double getFirstT ( );
				double getLastT ( );
				void getBounds ( double * lbound, double * ubound );

				void reset ( );
				void writeCluster ( unsigned char value, unsigned int count );
				void writeFrameBreak ( double t );
				void readCluster ( unsigned char * value, unsigned int * count );
				double readFrameBreak ( );
				void getGridSize ( unsigned int * gridsize );
				unsigned int getDimension ( );

				bool eof ( );

			protected:

				inline void writeData ( unsigned char value, unsigned int count );
				inline void readData ( unsigned char * value, unsigned int * count );

				void updateHeader ( );

				struct
				{
						unsigned int dimension;
						unsigned int frames;
						double t0;
						double T;
						char title [ 128 ];
						unsigned int code;
				} header;

				unsigned int * gridsize;
				double * lbound;
				double * ubound;
				char * coordnames;
				std::string fname;
				FILE* fp;

				unsigned int filesize;
				unsigned int gridlength;

				static const unsigned char FB_VALUE;
				static const unsigned int FB_COUNT;

		};
	}
}

#endif
