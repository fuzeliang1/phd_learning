/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_UUID_H
#define YANE_UTILS_UUID_H

#ifdef __WIN32__
#include <rpc.h>
#else
#include <uuid/uuid.h>
#endif
#include <string>

namespace yane
{

	namespace Utils
	{

		/**
		 * This class allows to generate and manage identifiers which are unique. The class
		 * wraps the functions of libuuid1 (version 1.40.8-20.1) contained in the package
		 * 'e2fsprogs' or directly in 'libuuid1'.
		 * Upon installation the header package 'libuuid-devel' is required. For further
		 * information on the UUID principle see the man pages of 'uuid' or the
		 * corresponding homepage.
		 *
		 * @brief Class for generating and managing universally unique identifiers (UUID)
		 * @sa http://linux.die.net/man/3/uuid
		 */
		class Uuid
		{
			public:

				/**
				 * @brief Constructor
				 */
				Uuid ( );

				/**
				 * This constructor generates an instance using a specified UUID
				 * @param input User specified UUID
				 * @brief Copy constructor
				 */
				Uuid ( const Uuid & input );

				/**
				 * This constructor generates an instance using a UUID in string format.
				 * The string must be in the format xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx where
				 * 'x' is a hex number.
				 * @param inputstr User specified UUID in string format
				 * @throw uuidFormatException is thrown if the string format is not correct
				 * @brief Copy constructor using string format
				 */
				Uuid ( std::string & inputstr );

				/**
				 * This constructor generates an instance using a 128 bit data input.
				 * @param inputdata Pointer of a 16 byte array containing the user supplied UUID
				 * @brief Copy constructor using 128 bit data input
				 */
				Uuid ( const unsigned char * inputdata );

				/**
				 * @brief Destructor
				 */
				~Uuid ( );

				/**
				 * Set operator using a UUID
				 * @param input User specified UUID
				 * @return Pointer of the set UUID
				 * @brief Set operator using a UUID
				 */
				Uuid & operator= ( const Uuid & input );

				/**
				 * Set operator using a UUID in string format
				 *
				 * @param inputstr User specified UUID in string format
				 * @throw uuidFormatException is thrown if the string format is not correct
				 * @return Pointer of the set UUID
				 * @sa Uuid(std::string & inputstr)
				 * @brief Set operator using a UUID in string format
				 */
				Uuid & operator= ( const std::string & inputstr );

				/**
				 * Set operator using a 128 bit data input
				 * @param inputdata Pointer of a 16 byte array containing the user supplied UUID
				 * @return Pointer of the set UUID
				 * @sa Uuid(const unsigned char * inputdata)
				 * @brief Set operator using a 128 bit data input
				 */
				Uuid & operator= ( const unsigned char * & inputdata );

				/**
				 * Equality comparison operator
				 * @param input UUID the instance shall be compared with
				 * @return true if UUIDs are identical
				 * @brief Equality comparison operator
				 */
				bool operator== ( const Uuid & input ) const;

				/**
				 * Inquality comparison operator
				 * @param input UUID the instance shall be compared with
				 * @return true if UUIDs are not identical
				 * @brief Inequality comparison operator
				 */
				bool operator!= ( const Uuid & input ) const;

				/**
				 * Comparison operator checking if UUID is smaller than a given reference
				 * @param input UUID the instance shall be compared with
				 * @return true if UUIDs is smaller than a given reference
				 * @brief Comparison operator checking if UUID is smaller than a given reference
				 */
				bool operator< ( const Uuid & input ) const;

				/**
				 * Comparison operator checking if UUID is smaller than or equal to a given reference
				 * @param input UUID the instance shall be compared with
				 * @return true if UUIDs is smaller than or equal to a given reference
				 * @brief Comparison operator checking if UUID is smaller than or equal to a given reference
				 */
				bool operator<= ( const Uuid & input ) const;

				/**
				 * Comparison operator checking if UUID is larger than a given reference
				 * @param input UUID the instance shall be compared with
				 * @return true if UUIDs is larger than a given reference
				 * @brief Comparison operator checking if UUID is larger than a given reference
				 */
				bool operator> ( const Uuid & input ) const;

				/**
				 * Comparison operator checking if UUID is larger than or equal to a given reference
				 * @param input UUID the instance shall be compared with
				 * @return true if UUIDs is larger than or equal to a given reference
				 * @brief Comparison operator checking if UUID is larger than or equal to a given reference
				 */
				bool operator>= ( const Uuid & input ) const;

				/**
				 * @brief Function to set a UUID to zero (i.e. 00000000-0000-0000-0000-000000000000)
				 */
				void setNull ( );

				/**
				 * Function to check if a UUID is zero
				 * @return true if UUID is zero
				 * @brief Function to check if a UUID is zero
				 */
				bool isNull ( ) const;

				/**
				 * Function to return the UUID in string format
				 * @param uppercase Decision variable whether hex numbers shall be displayed in large letters
				 * @return UUID in string format
				 * @sa Uuid(std::string & inputstr)
				 * @brief Function to return the UUID in string format
				 */
				std::string toString ( bool uppercase = false ) const;

				/**
				 * Function to copy the memory array in which the UUID is stored
				 * @param out Pointer of the array to which the UUID shall be copied to. The array is required to be 16 byte long.
				 * @brief Function to copy the memory array in which the UUID is stored
				 */
				void toCharPtr ( unsigned char * out ) const;

				/**
				 * @brief Function to generate a new UUID
				 */
				void reset ( );

			protected:
#ifdef _WIN32
				UUID * data; /**< @brief Pointer of a UUID if operating system is Windows */
#else
				uuid_t data; /**< @brief Pointer of a UUID if operating system is not Windows */
#endif
		};

	}

}

#endif
