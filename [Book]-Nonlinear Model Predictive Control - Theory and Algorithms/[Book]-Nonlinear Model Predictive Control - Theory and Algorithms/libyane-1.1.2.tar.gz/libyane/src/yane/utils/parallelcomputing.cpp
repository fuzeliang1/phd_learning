/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "parallelcomputing.h"
#include "exceptions.h"
#include "debugmaster.h"
#include "debugclient.h"
#include "semaphore.h"

#include <sstream>

#include "libexport.h"

using namespace std;

// Create manager
LIB_EXPORT yane::Utils::ParallelComputing::ParallelComputing ( const std::string & name, yane::Utils::DebugMaster * dm, int threads )
{
	// Create Debugclient
	if ( dm != 0 )
	{
		stringstream str;
		str << name << "(Manager)";
		_debugclient = dm->newClient ( str.str().c_str() );
	}
	else
	{
		_debugclient = 0;
	}

	_thread_count = threads;
	_thread_array = new T_THREADINFO[threads];
	_abort = false;

	_producesem = new Semaphore ( 0 );
	_consumesem = new Semaphore ( 0 );
	_update = true;

	// Initialiase threads
	for ( int i = 0; i < _thread_count; i++ )
	{
		_thread_array[i].manager = this;
		if (dm != 0)
		{
			stringstream str;
			str << name << " (" << i << ")";
			_thread_array[i].debugclient = dm->newClient(str.str().c_str());
		} else
		{
			_thread_array[i].debugclient = 0;
		}
		pthread_attr_init ( &_thread_array[i].attr );
		pthread_attr_setdetachstate ( &_thread_array[i].attr, PTHREAD_CREATE_JOINABLE );
	}

	// Create and start threads
	for ( int i = 0; i < _thread_count; i++ )
	{
		int errcode = pthread_create ( &_thread_array[i].thread, &_thread_array[i].attr, threadWorker, &_thread_array[i] );

		if ( errcode != 0 )
		{
			stringstream out;
			out << "creating inputthread failed (code=";
			out << errcode;
			out << ")";
			_debugclient->sendDebugInfo ( out.str() );
			throw ThreadException ( __DEBUGMESS ( out.str() ) );
		}
	}
	_consumesem->acquire ( _thread_count );
}

// Destructor
LIB_EXPORT yane::Utils::ParallelComputing::~ ParallelComputing()
{
	// Stop threads
	_abort = true;

	_producesem->release ( _thread_count );

	// Wait until threads finished
	for ( int i = 0; i < _thread_count; i++ )
	{
		void * status;
		pthread_join ( _thread_array[i].thread, &status );
	}

	for ( int i = 0; i < _thread_count; i++ )
	{
		delete _thread_array[i].debugclient;
	}

	// Delete threads
	delete[] _thread_array;
	delete _producesem;
	delete _consumesem;
}

// Threadworker
void * yane::Utils::ParallelComputing::threadWorker ( void * arg )
{
	T_THREADINFO * base = ( T_THREADINFO* ) arg;

	while ( true )
	{
		// Release and acquire next semaphore
		base->manager->_consumesem->release();
		base->manager->_producesem->acquire();

		if ( base->manager->_abort )
		{
			break;
		}

		// start computation
		for ( int i = 0; i < base->queue.size(); i++ )
		{
			base->manager->compute ( &base->queue[i], base->debugclient );
		}
	}

	base->manager->_consumesem->release();

	pthread_exit ( NULL );
}

// Add item with index
LIB_EXPORT void yane::Utils::ParallelComputing::addItem ( int index, double weight )
{
	T_TASKINFO task;
	task.isPtr = false;
	task.task_data.index = index;
	_items.insert ( pair<double, T_TASKINFO> ( weight, task ) );

	_update = true;
}

// Add item with pointer
LIB_EXPORT void yane::Utils::ParallelComputing::addItem ( void * ptr, double weight )
{
	T_TASKINFO task;
	task.isPtr = true;
	task.task_data.ptr = ptr;
	_items.insert ( pair<double, T_TASKINFO> ( weight, task ) );

	_update = true;
}

// Clear items
LIB_EXPORT void yane::Utils::ParallelComputing::clearItems()
{
	_items.clear();
	_update=true;
}

// start Computation
LIB_EXPORT void yane::Utils::ParallelComputing::startComputing()
{
	// Schedule
	if ( _update )
	{
		// Clear thread queues
		for ( int i = 0; i < _thread_count; i++ )
		{
			_thread_array[i].queue.clear();
			_thread_array[i].weights = 0;
		}

		for ( map<double, T_TASKINFO>::const_reverse_iterator taskiter = _items.rbegin(); taskiter != _items.rend(); ++taskiter )
		{
			int thread_min = 0;
			// Compute weight minimum of threads
			for ( int i = 1; i < _thread_count; i++ )
			{
				if ( _thread_array[i].weights < _thread_array[thread_min].weights )
				{
					thread_min = i;
				}
			}

			// Appends current task to thread with minimum weights
			_thread_array[thread_min].queue.push_back ( _items[taskiter->first] );
			_thread_array[thread_min].weights += taskiter->first;
		}
	}

	// start Computation
	_producesem->release ( _thread_count );
	_consumesem->acquire ( _thread_count );
}



