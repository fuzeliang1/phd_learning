/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
  *   Benjamin Hell <hellben@gmx.de>                                        *
*                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
	@author Benjamin Hell <hellben@gmx.de>
 */

#ifndef YANE_UTILS_MATRIXCOMPUTATION_H
#define YANE_UTILS_MATRIXCOMPUTATION_H

using namespace std;

namespace yane
{

	namespace Utils
	{

		/** \class MatrixComputation
		\brief Class for executing matrix multiplication
		 */
		class MatrixComputation
		{
			public:
				static void multiplyMatrixMatrix ( double ** A, int rowsizeA, int columnsizeA, double ** B, int rowsizeB, int columnsizeB, double ** AB, int firstrowindexA = 0, int firstcolumnindexA = 0, int firstrowindexB = 0, int firstcolumnindexB = 0, int firstrowindexAB = 0, int firstcolumnindexAB = 0 );
				static void multiplyMatrixVector ( double ** A, int rowsizeA, int columnsizeA, double * X, int rowsizeX, double * Y );
				static void multiplyVectorMatrix( double * X, int rowsizeX, double ** A, int rowsizeA, int columnsizeA, double * Y );
				static void multiplyMatrixScalar ( double ** A, int rowsizeA, int columnsizeA, double S );
		};
	}
}


#endif
