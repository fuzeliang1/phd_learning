/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "statisticsmaster.h"
#include "statisticsclient.h"

#include <sstream>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::StatisticsMaster::StatisticsMaster ( )
{
}

LIB_EXPORT yane::Utils::StatisticsMaster::~StatisticsMaster ( )
{ //TODO Destruktor pruefen
//	for (std::map<std::string, std::vector<StatisticsClient*> >::iterator it = _clients.begin(); it != _clients.end(); ++it)
//	{
//		for (int i=0; i<it->second.size(); i++)
//		{
//			delete it->second[i];
//		}
//	}
}

LIB_EXPORT void yane::Utils::StatisticsMaster::registerClient ( StatisticsClient * client, const std::string & group )
{
	_clients [ group ].push_back ( client );
}

LIB_EXPORT std::string yane::Utils::StatisticsMaster::evaluateStatistics ( )
{
	if ( _clients.size ( ) == 0 ) return "";
	stringstream out;

	int namewidth = 0;
	int groupwidth = 0;
	int valuewidth = 0;
	int totalwidth = 0;
	for ( std::map < std::string, std::vector < StatisticsClient* > >::iterator it = _clients.begin ( ); it
	        != _clients.end ( ); ++it )
	{
		if ( it->first.size ( ) > groupwidth )
		{
			groupwidth = it->first.size ( );
		}
		for ( int i = 0; i < it->second.size ( ); i++ )
		{
			if ( it->second [ i ]->name ( ).size ( ) > namewidth )
			{
				namewidth = it->second [ i ]->name ( ).size ( );
			}
			if ( it->second [ i ]->formattedData ( ).size ( ) > valuewidth )
			{
				valuewidth = it->second [ i ]->formattedData ( ).size ( );
			}
		}
	}

	namewidth += 2;
	valuewidth += 1;
	totalwidth = namewidth + valuewidth;
	if ( groupwidth > totalwidth )
	{
		totalwidth = groupwidth;
	}

	for ( std::map < std::string, std::vector < StatisticsClient* > >::iterator it = _clients.begin ( ); it
	        != _clients.end ( ); ++it )
	{
		for ( int i = 0; i < totalwidth; i++ )
		{
			out << "=";
		}
		out << endl;
		out << it->first << endl;
		for ( int i = 0; i < totalwidth; i++ )
		{
			out << "-";
		}
		out << endl;
		for ( int i = 0; i < it->second.size ( ); i++ )
		{
			string name = it->second [ i ]->name ( ) + ": ";
			string value = string ( " " ) + it->second [ i ]->formattedData ( );
			int counter = 0;
			while ( name.size ( ) + value.size ( ) < totalwidth )
			{
				if ( counter % 2 == 0 )
				{
					name += ".";
				}
				else
				{
					name += " ";
				}
				++counter;
			}
			out << name << value << endl;
		}
	}
	for ( int i = 0; i < totalwidth; i++ )
	{
		out << "=";
	}
	out << endl;
	return out.str ( );
}

LIB_EXPORT std::string yane::Utils::StatisticsMaster::evaluateStatisticsTable ( const vector < string > & list )
{
	if ( _clients.size ( ) == 0 ) return "";
	stringstream out;

	for ( int i = 0; i < list.size ( ); i++ )
	{
		for ( std::map < std::string, std::vector < StatisticsClient* > >::iterator it = _clients.begin ( ); it
		        != _clients.end ( ); ++it )
		{
			for ( int j = 0; j < it->second.size ( ); j++ )
			{
				if ( list [ i ] == it->first + string ( " $$ " ) + it->second [ j ]->name ( ) )
				{
					string value = string ( " " ) + it->second [ j ]->formattedData ( ) + string ( " " );
					out << value;
				}
			}
		}
	}
	out << endl;
	return out.str ( );
}

LIB_EXPORT std::string yane::Utils::StatisticsMaster::evaluateStatisticsLatexTable ( const vector < string > & list )
{
	if ( _clients.size ( ) == 0 ) return "";
	stringstream out;

	for ( int i = 0; i < list.size ( ); i++ )
	{
		for ( std::map < std::string, std::vector < StatisticsClient* > >::iterator it = _clients.begin ( ); it
		        != _clients.end ( ); ++it )
		{
			for ( int j = 0; j < it->second.size ( ); j++ )
			{
				if ( list [ i ] == it->first + string ( " $$ " ) + it->second [ j ]->name ( ) )
				{
					string value = string ( " " ) + it->second [ j ]->formattedData ( ) + string ( " &" );
					out << value;
				}
			}
		}
	}
	out << " \\\\" << endl;
	return out.str ( );
}

LIB_EXPORT void yane::Utils::StatisticsMaster::reset ( )
{
	for ( std::map < std::string, std::vector < StatisticsClient* > >::iterator it = _clients.begin ( ); it
	        != _clients.end ( ); ++it )
	{
		for ( int i = 0; i < it->second.size ( ); i++ )
		{
			it->second [ i ]->reset ( );
		}
	}
}
