/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_DEBUGMASTERCONSOLE_H
#define YANE_UTILS_DEBUGMASTERCONSOLE_H

#include "debugmastertextstream.h"

namespace yane
{

	namespace Utils
	{
		class RTClock;

		/** \class DebugMasterConsole
		 * @see DebugMasterTextStream
		 * This class extends DebugMasterTextStream to write the textstream to the console.
		 * @brief DebugMaster that writes to a class.
		 */
		class DebugMasterConsole : public DebugMasterTextStream
		{
			public:
				/**
				 * This creates the debugmasterconsole object.
				 * @param clock Clock the current program is using.
				 * @param textwidth Width after which a line is wrapped.
				 @brief Constructor
				 */
				DebugMasterConsole ( RTClock * clock, int textwidth = 80 );

				/**
				 * Destroys the object.
				 * @brief Destructor
				 */
				virtual ~DebugMasterConsole ( );
		};

	}

}

#endif
