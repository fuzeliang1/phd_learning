/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_STATISTICSMASTER_H
#define YANE_UTILS_STATISTICSMASTER_H

#include <string>
#include <map>
#include <vector>

namespace yane
{

	namespace Utils
	{

		class StatisticsClient;

		/** \class StatisticsMaster
		 * Class to use and create the StatisticsMaster. A StatisticsMaster is used to gather statistical data.
		 * Usually there is one StatisticsMaster in every program and at least (usually more than) one StatisticsClient.
		 * @brief StatisticsMaster base class
		 */
		class StatisticsMaster
		{
				friend class StatisticsClient;

			public:
				/**
				 * @brief Constructor
				 */
				StatisticsMaster ( );

				/**
				 * @brief Destructor
				 */
				virtual ~StatisticsMaster ( );

				/**
				 * @brief Function to evaluate the statistic clients as list
				 */
				virtual std::string evaluateStatistics ( );

				/**
				 * Function to evaluate the statictic clients as table
				 * @param list List of statistical data to be evaluated
				 * @brief Function to evaluate the statictic clients as table
				 */
				virtual std::string evaluateStatisticsTable ( const std::vector < std::string > & list );

				/**
				 * Function to evaluate the statictic clients as latex table
				 * @param list List of statistical data to be evaluated
				 * @brief Function to evaluate the statictic clients as latex table
				 */
				virtual std::string evaluateStatisticsLatexTable ( const std::vector < std::string > & list );

				/**
				 * @brief Function to reset all connected statistic clients
				 */
				virtual void reset ( );

			protected:
				/**
				 * Function to register a client
				 * @param client Object of class StatisticsClient to be registered
				 * @param group Group to which the client will be registered to
				 * @brief Function to register a client
				 */
				void registerClient ( StatisticsClient * client, const std::string & group );

				std::map < std::string, std::vector < StatisticsClient* > > _clients; /**< @brief List of statistic clients */

		};

	}

}

#endif
