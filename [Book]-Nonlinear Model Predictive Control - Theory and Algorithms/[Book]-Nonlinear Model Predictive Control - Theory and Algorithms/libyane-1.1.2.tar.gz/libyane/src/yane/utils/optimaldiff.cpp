/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "optimaldiff.h"

#include <cmath>
#include <iostream>

#include "libexport.h"

using namespace std;

double yane::Utils::OptimalDiff::_diffacc = 1E-5;

yane::Utils::OptimalDiff::OptimalDiff ( )
{
}

LIB_EXPORT void yane::Utils::OptimalDiff::calc ( )
{
	double ub = - 1.0;
	double lb = - 15.0;
	int counter = 0;

	while ( fabs ( failure ( ub ) - failure ( lb ) ) > 1E-10 && counter < 1000 )
	{
		double newlb = lb + ( ub - lb ) * ( 1.0 / 1.3 );
		double newub = lb + ( ub - lb ) * ( 2.0 / 3.0 );

		if ( failure ( newlb ) > failure ( lb ) )
		{
			ub = newlb;
		}
		else if ( failure ( newub ) > failure ( ub ) )
		{
			lb = newub;
		}
		else if ( failure ( newlb ) > failure ( newub ) )
		{
			lb = newlb;
		}
		else
		{
			ub = newub;
		}
		counter++ ;
	}

	if ( counter < 1000 ) _diffacc = pow ( 10.0, lb + ( ub - lb ) / 2.0 );
}

LIB_EXPORT double yane::Utils::OptimalDiff::get ( )
{
	return _diffacc;
}

void yane::Utils::OptimalDiff::set ( double newdiffacc )
{
	_diffacc = newdiffacc;
}

double yane::Utils::OptimalDiff::testfun ( double x )
{
	return 1.0 / ( x - 1.0 ); // (x-1.0)*(x-1.0);
}

double yane::Utils::OptimalDiff::testfun_derive ( double x )
{
	return - pow ( x - 1.0, - 2.0 ); // 2.0*(x-1.0);
}

double yane::Utils::OptimalDiff::failure ( double value )
{
	double h = pow ( 10.0, value );
	return fabs ( testfun_derive ( 0.0 ) - ( testfun ( h ) - testfun ( 0.0 ) ) / h );
}
