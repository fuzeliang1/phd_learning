/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "uuid.h"
#include "exceptions.h"

#include <cstdio>
#include <cstring>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::Uuid::Uuid ( )
{
#ifdef _WIN32
	data = new UUID;
	UuidCreate( data );
#else
	uuid_generate ( data );
#endif
}

LIB_EXPORT yane::Utils::Uuid::~Uuid ( )
{
#ifdef _WIN32
	delete data;
#else
	uuid_clear ( data );
#endif
}

LIB_EXPORT yane::Utils::Uuid::Uuid ( const Uuid & input )
{
#ifdef _WIN32
	data = new UUID;
	memcpy( data, input.data, sizeof(UUID) );
#else
	uuid_copy ( data, input.data );
#endif
}

LIB_EXPORT yane::Utils::Uuid & yane::Utils::Uuid::operator = ( const yane::Utils::Uuid & input )
{
#ifdef _WIN32
	memcpy( data, input.data, sizeof(UUID));
#else
	uuid_copy ( data, input.data );
#endif

	return * this;
}

LIB_EXPORT yane::Utils::Uuid::Uuid ( std::string & inputstr )
{
#ifdef _WIN32
	RPC_STATUS status = UuidFromString( (unsigned char*) inputstr.c_str(), data);

	if( status == RPC_S_INVALID_STRING_UUID ) throw ValueException(__DEBUGMESS("invalid input format"));
#else
	int result = uuid_parse ( inputstr.c_str ( ), data );

	if ( result != 0 ) throw ValueException ( __DEBUGMESS("invalid input format") );
#endif
}

LIB_EXPORT yane::Utils::Uuid & yane::Utils::Uuid::operator = ( const std::string & inputstr )
{
#ifdef _WIN32
	RPC_STATUS status = UuidFromString( (unsigned char*) inputstr.c_str(), data);

	if( status == RPC_S_INVALID_STRING_UUID ) throw ValueException(__DEBUGMESS("invalid input format"));
#else
	int result = uuid_parse ( inputstr.c_str ( ), data );

	if ( result != 0 ) throw ValueException ( __DEBUGMESS("invalid input format") );
#endif

	return * this;
}

LIB_EXPORT yane::Utils::Uuid::Uuid ( const unsigned char * inputdata )
{
#ifdef _WIN32
	memcpy( data, inputdata, 16);
#else
	uuid_copy ( data, inputdata );
#endif
}

LIB_EXPORT yane::Utils::Uuid & yane::Utils::Uuid::operator = ( const unsigned char *& inputdata )
{
#ifdef _WIN32
	memcpy(data, inputdata, 16);
#else
	uuid_copy ( data, inputdata );
#endif
	return * this;
}

LIB_EXPORT bool yane::Utils::Uuid::operator == ( const yane::Utils::Uuid & input ) const
{
#ifdef _WIN32
	RPC_STATUS status;
	return (UuidCompare( data, input.data, &status) == 0);
#else
	return ( uuid_compare ( data, input.data ) == 0 );
#endif
}

LIB_EXPORT bool yane::Utils::Uuid::operator != ( const yane::Utils::Uuid & input ) const
{
#ifdef _WIN32
	RPC_STATUS status;
	return (UuidCompare( data, input.data, &status) != 0);
#else
	return ( uuid_compare ( data, input.data ) != 0 );
#endif
}

LIB_EXPORT bool yane::Utils::Uuid::operator < ( const yane::Utils::Uuid & input ) const
{
#ifdef _WIN32
	RPC_STATUS status;
	return (UuidCompare( data, input.data, &status) < 0);
#else
	return ( uuid_compare ( data, input.data ) < 0 );
#endif
}

LIB_EXPORT bool yane::Utils::Uuid::operator <= ( const yane::Utils::Uuid & input ) const
{
#ifdef _WIN32
	RPC_STATUS status;
	return (UuidCompare( data, input.data, &status) <= 0);
#else
	return ( uuid_compare ( data, input.data ) <= 0 );
#endif
}

LIB_EXPORT bool yane::Utils::Uuid::operator > ( const yane::Utils::Uuid & input ) const
{
#ifdef _WIN32
	RPC_STATUS status;
	return (UuidCompare( data, input.data, &status) > 0);
#else
	return ( uuid_compare ( data, input.data ) > 0 );
#endif
}

LIB_EXPORT bool yane::Utils::Uuid::operator >= ( const yane::Utils::Uuid & input ) const
{
#ifdef _WIN32
	RPC_STATUS status;
	return (UuidCompare( data, input.data, &status) >= 0);
#else
	return ( uuid_compare ( data, input.data ) >= 0 );
#endif
}

LIB_EXPORT void yane::Utils::Uuid::setNull ( )
{
#ifdef _WIN32
	UuidCreateNil( data );
#else
	uuid_clear ( data );
#endif
}

LIB_EXPORT std::string yane::Utils::Uuid::toString ( bool uppercase ) const
{
#ifdef _WIN32
	// TODO WINDOWS toupper, tolower ziemlich ineffizient, was anderes ueberlegen.

	unsigned char * c;

	UuidToString( data, &c);

	if( uppercase )
	{
		for(int i=0; i<36; i++)
		{
			c[i] = toupper(c[i]);
		}
	}
	else
	{
		for(int i=0; i<36; i++)
		{
			c[i] = tolower(c[i]);
		}
	}

	string s((char*)c);
	RpcStringFree(&c);
	return string((char*)c);
#else
	char c [ 40 ]; // warum 40?

	if ( uppercase )
	{
		uuid_unparse_upper ( data, c );
	}
	else
	{
		uuid_unparse_lower ( data, c );
	}

	return string ( c );
#endif
}

LIB_EXPORT void yane::Utils::Uuid::toCharPtr ( unsigned char * out ) const
{
#ifdef _WIN32
	memcpy(out, data, 16);
#else
	memcpy ( out, & data [ 0 ], 16 );
#endif
}

LIB_EXPORT bool yane::Utils::Uuid::isNull ( ) const
{
#ifdef _WIN32
	RPC_STATUS status;
	return (UuidIsNil( data, &status ) == 1);
#else
	return uuid_is_null ( data ) == 1;
#endif
}

LIB_EXPORT void yane::Utils::Uuid::reset ( )
{
#ifdef _WIN32
	UuidCreate( data );
#else
	uuid_generate ( data );
#endif
}
