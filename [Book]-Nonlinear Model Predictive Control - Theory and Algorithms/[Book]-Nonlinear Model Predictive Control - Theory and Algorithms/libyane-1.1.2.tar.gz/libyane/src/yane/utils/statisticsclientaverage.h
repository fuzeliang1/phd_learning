/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_STATISTICSCLIENTAVERAGE_H
#define YANE_UTILS_STATISTICSCLIENTAVERAGE_H

#include "statisticsclient.h"

namespace yane
{

	namespace Utils
	{

		/** \class StatisticsClientAverage
		 * @see StatisticsMaster
		 * This class uses a StatisticsMaster to gather averaged statistical information.
		 * @brief StatisticsClientAverage class
		 */
		class StatisticsClientAverage : public StatisticsClient
		{
			public:
				/**
				 * Constructor
				 * @param master Pointer of the StatisticsMaster class the client belongs to
				 * @param group Group of clients the client belongs to
				 * @param name Name of the client
				 * @paran prec Precision of output
				 * @param displaymin Decision variable whether minimal occuring value shall be displayed
				 * @param displayavg Decision variable whether average value shall be displayed
				 * @param displaymax Decision variable whether maximal occuring value shall be displayed
				 * @brief Constructor
				 */
				StatisticsClientAverage ( StatisticsMaster* master, const std::string& group, const std::string& name,
				        int prec, bool displaymin, bool displayavg, bool displaymax );

				/**
				 * @brief Destructor
				 */
				virtual ~StatisticsClientAverage ( );

				/**
				 * Function to add an double value to the statistical data
				 * @param value Value to add to the data
				 * @brief Function to add an double value to the statistical data
				 */
				void addValue ( double value );

				virtual std::string formattedData ( );
				virtual std::string name ( );
				virtual void reset ( );

			protected:
				double _minvalue; /**< @brief Minimal occuring value */
				double _value; /**< @brief Averaged value */
				double _maxvalue; /**< @brief Maximal occuring value */
				int _amount; /**< @brief Number of added values to statistical data */
				int _prec; /**< @brief Precision of output */
				bool _displaymin; /**< @brief Decision variable whether minimal occuring value shall be displayed */
				bool _displayavg; /**< @brief Decision variable whether average value shall be displayed */
				bool _displaymax; /**< @brief Decision variable whether maximal occuring value shall be displayed */
		};

	}

}

#endif
