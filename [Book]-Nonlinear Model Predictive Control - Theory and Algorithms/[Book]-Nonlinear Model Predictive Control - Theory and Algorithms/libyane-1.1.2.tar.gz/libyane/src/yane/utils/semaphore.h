/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_SEMAPHORE_H
#define YANE_UTILS_SEMAPHORE_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#ifdef _WIN32
	#include <windows.h>
#else
	#include <sys/sem.h>
#endif

namespace yane
{

	namespace Utils
	{

		/** \class Semaphore
		Class to use and create semaphore objects. A semaphore is needed if two or more threads have to work with limited resources.
		Usually this class is used as following:
		@li acquire resources
		@li do some stuff
		@li release resources
		Remark: It is possible to release resources without acquiring some before.
		@brief Semaphore class
		 */
		class Semaphore
		{
			public:
				/**
				* Create new semaphore object with available resources.
				* @param resources Quantity of resources
				* @throw threadException Thrown if thread creation failed
				* @brief Constructor.
				*/
				Semaphore ( int resources = 0 );
				~Semaphore();

				/**
				* Try to acquire resources. If resources > available, the calling thread is blocked until resources are available.
				* @param resources Quantity of resources to acquire
				* @throw threadException Thrown if acquire failed
				* @throw valueException Thrown if resources are out of range
				* @brief Acquire resources.
				*/
				virtual void acquire ( int resources = 1 );

				/**
				 * Try to acquire resources. If resources > available the thread will be blocked for some time.
				 * The function will return false unless the ressources could be acquired until then.
				 * @param resources Quantity of resources to acquire
				 * @param wait_msec If resources aren't available the thread will be blocked for given milliseconds.
				 * @return True, if acquiring was successful
				 * @throw valueException Thrown if resources are out of range
				 * @brief Acquire resources optionally without blocking the calling thread
				*/
				virtual bool tryAcquire ( int resources = 1, unsigned int wait_msec = 0 );


				/**
				* Return how many resources are available
				* @return Quantity of available resources
				* @brief Return how many resources are available.
				*/
				virtual int available ();


				/**
				* Release resources
				* @param resources Quantity of resources to release
				* @throw threadException Thrown if release failed
				* @throw valueException Thrown if resources are out of range
				* @brief Release resources.
				*/
				virtual void release ( int resources = 1 );

			private:
				bool operation ( int resources, unsigned int wait_msec ); /**< @brief Function which is used by release and acquire */

#ifdef __WIN32
				HANDLE _semaphore;
#else
				int _semaphore; /**< @brief Semaphoreid on which this class is based. */
				struct sembuf _semop;
#endif
		};
	}
}

#endif
