/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_CODE_H
#define YANE_UTILS_CODE_H

#include <stdint.h>

namespace yane
{

	namespace Utils
	{

		/**
		 * Static class for code conversions.
		 *
		 * @class Code
		 * @brief Class with static methods for code conversions
		*/
		class Code
		{
			public:
				/**
				 * Converts a gray coded value to a binary coded value
				 * @param gray gray coded value
				 * @return binary coded value
				 */
				static uint32_t grayToBinary(uint32_t gray);

				/**
				 * Converts a binary coded value to a gray coded value
				 * @param binary binary coded value
				 * @return gray coded value
				 */
				static uint32_t binaryToGray(uint32_t binary);
			private:

				/**
				 * Abstract destructor, so no objects can be constucted
				 */
				virtual ~Code()=0;
		};

	}

}

#endif
