/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Benjamin Hell <hellben@gmx.de>                                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
	@author Benjamin Hell <hellben@gmx.de>
 */

#include "exceptions.h"
#include "matrixcomputation.h"

#include "libexport.h"

LIB_EXPORT void yane::Utils::MatrixComputation::multiplyMatrixMatrix( double ** A, int rowsizeA, int columnsizeA, double ** B, int rowsizeB, int columnsizeB, double ** AB, int firstrowindexA, int firstcolumnindexA, int firstrowindexB, int firstcolumnindexB, int firstrowindexAB, int firstcolumnindexAB )
{
	if ( columnsizeA != rowsizeB )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Dimensionality problem within matrix multiplication" ) );
	}
	for ( int i = 0; i < rowsizeA; i++ )
	{
		for ( int j = 0; j < columnsizeB; j++ )
		{
			AB[firstrowindexAB + i][firstcolumnindexAB + j] = 0.0;
			for ( int k = 0; k < columnsizeA; k++ )
			{
				AB[firstrowindexAB + i][firstcolumnindexAB + j] += A[firstrowindexA + i][firstcolumnindexA + k] * B[firstrowindexB + k][firstcolumnindexB + j];
			}
		}
	}
}

LIB_EXPORT void yane::Utils::MatrixComputation::multiplyMatrixVector( double ** A, int rowsizeA, int columnsizeA, double * X, int rowsizeX, double * Y )
{
	if ( columnsizeA != rowsizeX )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Dimensionality problem within matrix vector multiplication" ) );
	}
	for ( int i = 0; i < rowsizeA; i++ )
	{
		Y[i] = 0.0;
		for ( int j = 0; j < columnsizeA; j++ )
			Y[i] += A[i][j] * X[j];
	}
}

LIB_EXPORT void yane::Utils::MatrixComputation::multiplyVectorMatrix( double * X, int rowsizeX, double ** A, int rowsizeA, int columnsizeA, double * Y )
{
	if ( rowsizeA != rowsizeX )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Dimensionality problem within vector matrix multiplication" ) );
	}
	for ( int i = 0; i < columnsizeA; i++ )
	{
		Y[i] = 0.0;
		for ( int j = 0; j < rowsizeA; j++ )
			Y[i] += A[j][i] * X[j];
	}
}

LIB_EXPORT void yane::Utils::MatrixComputation::multiplyMatrixScalar( double ** A, int rowsizeA, int columnsizeA, double S )
{
	for ( int i = 0; i < rowsizeA; i++ )
	{
		for ( int j = 0; j < columnsizeA; j++ )
		{
			A[i][j] *= S;
		}
	}
}



