/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "statisticsclientpersecond.h"
#include "statisticsclientaverage.h"
#include "rtclock.h"

#include <iomanip>
#include <sstream>
#include <cmath>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::StatisticsClientPerSecond::StatisticsClientPerSecond ( StatisticsMaster* master,
        const std::string& group, const std::string& name, int prec ) :
	StatisticsClient ( master, group, name )
{
	_value = 0.0;
	_clock = new RTClock ( );
	_prec = prec;
}

LIB_EXPORT yane::Utils::StatisticsClientPerSecond::~StatisticsClientPerSecond ( )
{
	delete _clock;
}

LIB_EXPORT std::string yane::Utils::StatisticsClientPerSecond::formattedData ( )
{
	stringstream out;
	out << fixed << setprecision ( _prec ) << ( _value / _clock->elapsedSeconds ( ) );

	return out.str ( );
}

LIB_EXPORT void yane::Utils::StatisticsClientPerSecond::reset ( )
{
	_value = 0.0;
	_clock->reset ( );
}

LIB_EXPORT void yane::Utils::StatisticsClientPerSecond::addValue ( double value )
{
	_value += value;
}

