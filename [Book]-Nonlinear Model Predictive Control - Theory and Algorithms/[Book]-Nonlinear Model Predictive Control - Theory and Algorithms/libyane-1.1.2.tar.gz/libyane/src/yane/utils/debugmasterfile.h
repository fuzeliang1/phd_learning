/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_DEBUGMASTERFILE_H
#define YANE_UTILS_DEBUGMASTERFILE_H

#include "debugmastertextstream.h"
#include <string>

namespace yane
{

	namespace Utils
	{
		class RTClock;

		/** \class DebugMasterFile
		 * @see DebugMasterTextStream
		 * This class extends DebugMasterTextStream to write the textstream to the console.
		 * @brief DebugMaster that writes to a file
		 */
		class DebugMasterFile : public DebugMasterTextStream
		{
			public:
				/**
				 * This creates the debugmasterfile object.
				 * @param clock Clock the current program is using.
				 * @param filename Name of the file the textstream is written to.
				 * @param textwidth Width after which a line is wrapped.
				 * @param overwrite True if existing file should be overwritten.
				 @brief Constructor
				 */
				DebugMasterFile ( RTClock * clock, std::string filename, int textwidth = 80, bool overwrite = false );

				/**
				 * Destroys the object.
				 * @brief Destructor
				 */
				virtual ~DebugMasterFile ( );

		};

	}

}

#endif
