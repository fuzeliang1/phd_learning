/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "savedata.h"
#include "exceptions.h"

#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <sstream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::SaveData::SaveData ( int dimension_x, int dimension_u, int horizon, int controlhorizon )
{
	_dimension_x = dimension_x;
	_dimension_u = dimension_u;
	static fstream file;
	file.open ( "problemdata.dat", ios::out );
	if ( !file )
	{
		throw IOException (__DEBUGMESS("could not open file"));
	}
	file.setf ( ios::fixed );
	file << dimension_x << endl;
	file << dimension_u << endl;
	if ( horizon != 0 )
	{
		file << horizon << endl;
	}
	if ( controlhorizon != 0 )
	{
		file << controlhorizon << endl;
	}
	file.close ();
	file.clear ();
	deleteFiles ();
}

LIB_EXPORT yane::Utils::SaveData::~SaveData ()
{
}

LIB_EXPORT void yane::Utils::SaveData::save2Files ( double * t, double * x, double * u )
{
	int i;
	char * xfilename, * ufilename;

	string name, i_string, dimension_x_string, dimension_u_string;
	static fstream file;

	IntToString ( _dimension_x, dimension_x_string );
	xfilename = new char[dimension_x_string.size() + 10];
	IntToString ( _dimension_u, dimension_u_string );
	ufilename = new char[dimension_u_string.size() + 10];

	for ( i = 0; i < _dimension_x; i++ )
	{
		IntToString ( i, i_string );
		name = "tmp_x" + i_string + ".dat";
		StringToChar ( name, xfilename );
		file.open ( xfilename, ios::out | ios::app );
		if ( !file )
		{
			throw IOException (__DEBUGMESS("could not open file"));
		}
		file.setf ( ios::fixed );
		file << setprecision ( 8 ) << setw ( 12 ) << t[0] << "     " << setprecision ( 8 ) << setw ( 12 ) << x[i] << endl;
		file.close ();
		file.clear ();
	}
	for ( i = 0; i < _dimension_u; i++ )
	{
		IntToString ( i, i_string );
		name = "tmp_u" + i_string + ".dat";
		StringToChar ( name, ufilename );
		file.open ( ufilename, ios::out | ios::app );
		if ( !file )
		{
			throw IOException (__DEBUGMESS("could not open file"));
		}
		file.setf ( ios::fixed );
		file << setprecision ( 8 ) << setw ( 12 ) << t[0] << "     " << setprecision ( 8 ) << setw ( 12 ) << u[i] << endl;
		file.close ();
		file.clear ();
	}
	delete[] ufilename;
	delete[] xfilename;
}

void yane::Utils::SaveData::IntToString ( int input, string & output )
{
	ostringstream temp;
	temp << input;
	output = temp.str();
}

void yane::Utils::SaveData::StringToChar ( string input, char * output )
{
	strcpy ( output, input.c_str() );
}

void yane::Utils::SaveData::deleteFiles ( void )
{
	int i;
	char * xfilename, * ufilename;
	string name, i_string, dimension_x_string, dimension_u_string;
	static fstream file;

	file.open ( "computingdata.dat", ios::out | ios::trunc );
	if ( !file )
	{
		throw IOException (__DEBUGMESS("could not open file"));
	}
	file.close ();
	file.clear ();

	IntToString ( _dimension_x, dimension_x_string );
	xfilename = new char[dimension_x_string.size() + 10];
	IntToString ( _dimension_u, dimension_u_string );
	ufilename = new char[dimension_u_string.size() + 10];

	for ( i = 0; i < _dimension_x; i++ )
	{
		IntToString ( i, i_string );
		name = "tmp_x" + i_string + ".dat";
		StringToChar ( name, xfilename );
		file.open ( xfilename, ios::out | ios::trunc );
		if ( !file )
		{
			throw IOException (__DEBUGMESS("could not open file"));
		}
		file.close ();
		file.clear ();
	}
	for ( i = 0; i < _dimension_u; i++ )
	{
		IntToString ( i, i_string );
		name = "tmp_u" + i_string + ".dat";
		StringToChar ( name, ufilename );
		file.open ( ufilename, ios::out | ios::trunc );
		if ( !file )
		{
			throw IOException (__DEBUGMESS("could not open file"));
		}
		file.close ();
		file.clear ();
	}
	delete[] ufilename;
	delete[] xfilename;
}

LIB_EXPORT void yane::Utils::SaveData::saveOpenloop2Files ( int iter, int horizon, double * t, double * x, double * u )
{
	int i, j;
	char * xfilename, * ufilename;
	string name, i_string, iter_string, dimension_x_string, dimension_u_string;
	static fstream file;

	IntToString ( iter, iter_string );
	IntToString ( _dimension_x, dimension_x_string );
	xfilename = new char[iter_string.size() + dimension_x_string.size() + 10];
	IntToString ( _dimension_u, dimension_u_string );
	ufilename = new char[iter_string.size() + dimension_u_string.size() + 10];

	for ( i = 0; i < _dimension_x; i++ )
	{
		IntToString ( i, i_string );
		name = "tmp" + iter_string + "_x" + i_string + ".dat";
		StringToChar ( name, xfilename );
		file.open ( xfilename, ios::out | ios::trunc );
		if ( !file )
		{
			throw IOException (__DEBUGMESS("could not open file"));
		}
		file.setf ( ios::fixed );
		for ( j = 0; j < horizon + 1; j++ )
		{
			file << setprecision ( 8 ) << setw ( 12 ) << t[j] << "     " << setprecision ( 8 ) << setw ( 12 ) << x[j * _dimension_x + i] << endl;
		}
		file.close ();
		file.clear ();
	}
	for ( i = 0; i < _dimension_u; i++ )
	{
		IntToString ( i, i_string );
		name = "tmp" + iter_string + "_u" + i_string + ".dat";
		StringToChar ( name, ufilename );
		file.open ( ufilename, ios::out | ios::trunc );
		if ( !file )
		{
			throw IOException (__DEBUGMESS("could not open file"));
		}
		file.setf ( ios::fixed );
		for ( j = 0; j < horizon; j++ )
		{
			file << setprecision ( 8 ) << setw ( 12 ) << t[j] << "     " << setprecision ( 8 ) << setw ( 12 ) << u[j * _dimension_u + i] << endl;
		}
		file.close ();
		file.clear ();
	}
	delete[] ufilename;
	delete[] xfilename;
}

//TODO saveClosedloopcost2File() verursacht Speicherfehler bei OpenSuse 11.0

LIB_EXPORT void yane::Utils::SaveData::saveClosedloopcost2File ( double closedloopcost, double computingtime )
{
	fstream file ( "computingdata.dat", fstream::out | fstream::trunc );
	if ( !file )
	{
		throw IOException (__DEBUGMESS("could not open file"));
	}
	file.setf ( ios::fixed );
	if ( computingtime != 0.0 )
	{
		file << setprecision ( 8 ) << setw ( 12 ) << computingtime << "     " << setprecision ( 8 ) << setw ( 12 ) << closedloopcost << endl;
	}
	else
	{
		file << setprecision ( 8 ) << setw ( 12 ) << closedloopcost << endl;
	}
	file.close ();
	file.clear ();
}

