/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "fifobuffer.h"
#include "exceptions.h"

#include <cstring>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::FIFOBuffer::FIFOBuffer ( int maxsize )
{
	_start = 0;
	_size = 0;
	_maxsize = maxsize;
	_buffer = new char [ _maxsize ];

	pthread_mutex_init ( & _locker, NULL );
}

LIB_EXPORT yane::Utils::FIFOBuffer::~FIFOBuffer ( )
{
	delete [ ] _buffer;
}

LIB_EXPORT void yane::Utils::FIFOBuffer::push ( void * src, int size )
{
	if ( _size + size <= _maxsize )
	{
		int __end = _start + _size;
		if ( __end >= _maxsize )
		{
			__end -= _maxsize;
		}
		if ( __end + size < _maxsize )
		{
			memcpy ( & _buffer [ __end ], src, size );
		}
		else
		{
			memcpy ( & _buffer [ __end ], src, _maxsize - __end );
			memcpy ( & _buffer [ 0 ], & ( ( char* ) src ) [ _maxsize - __end ], size - ( _maxsize - __end ) );
		}
		_size += size;
	}
	else
	{
		throw ValueException ( __DEBUGMESS("fifo buffer overflow") );
	}
}

LIB_EXPORT void yane::Utils::FIFOBuffer::peek ( void * dest, int position, int size )
{
	if ( position + size <= _size )
	{
		int __start = _start + position;
		if ( __start + size <= _maxsize )
		{
			memcpy ( dest, & _buffer [ __start ], size );
		}
		else
		{
			memcpy ( dest, & _buffer [ __start ], _maxsize - __start );
			memcpy ( & ( ( char* ) dest ) [ _maxsize - __start ], & _buffer [ 0 ], size - ( _maxsize - __start ) );
		}
	}
	else
	{
		throw ValueException ( __DEBUGMESS("tried to read too much bytes from fifo buffer") );
	}
}

LIB_EXPORT void yane::Utils::FIFOBuffer::peek ( void * dest, int size )
{
	peek ( dest, 0, size );
}

LIB_EXPORT void yane::Utils::FIFOBuffer::discard ( int size )
{
	if ( size <= _size )
	{
		_start += size;
		if ( _start >= _maxsize )
		{
			_start -= _maxsize;
		}
		_size -= size;
	}
	else
	{
		throw ValueException ( __DEBUGMESS("tried to discard too much bytes from fifo buffer") );
	}
}

LIB_EXPORT void yane::Utils::FIFOBuffer::pop ( void * dest, int size )
{
	try
	{
		peek ( dest, size );
		discard ( size );
	}
	catch ( ValueException e )
	{
		throw ValueException ( __DEBUGMESS("tried to read too much bytes from fifo buffer"), & e );
	}

}

LIB_EXPORT int yane::Utils::FIFOBuffer::size ( )
{
	return _size;
}

LIB_EXPORT void yane::Utils::FIFOBuffer::clear ( )
{
	_size = 0;
	_start = 0;
}

LIB_EXPORT int yane::Utils::FIFOBuffer::end ( int size )
{
	int __end = _start + _size + size;
	return __end < _maxsize ? __end : ( __end - _maxsize );
}

LIB_EXPORT void yane::Utils::FIFOBuffer::lock ( )
{
	pthread_mutex_lock ( & _locker );
}

LIB_EXPORT void yane::Utils::FIFOBuffer::unlock ( )
{
	pthread_mutex_unlock ( & _locker );
}

