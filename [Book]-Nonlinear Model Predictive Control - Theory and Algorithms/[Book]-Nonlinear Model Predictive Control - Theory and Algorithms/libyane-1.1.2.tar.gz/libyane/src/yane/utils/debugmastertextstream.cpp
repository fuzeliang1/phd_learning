/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "debugmastertextstream.h"
#include "mutex.h"
#include "rtclock.h"

#include <iomanip>
#include <sstream>
#include <string>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::DebugMasterTextStream::DebugMasterTextStream ( RTClock * clock, std::ostream * textstream,
        int textwidth ) :
	DebugMaster ( clock )
{
	_textwidth = textwidth;
	_textstream = textstream;
}

LIB_EXPORT void yane::Utils::DebugMasterTextStream::addDebugInfo ( std::string clientname, std::string message,
        std::string dataname, void* data, int datasize, int datatype, int )
{

	_mutex->lock ( );
	if ( _textstream == 0 )
	{
		_mutex->unlock ( );
		return;
	}

	stringstream header;
	header << setw ( 10 ) << setprecision ( 6 ) << fixed << _clock->elapsedSeconds ( ) << " | ";
	//<< clientname << " ~~ ";
	int headerlength = header.str ( ).size ( );
	string leer = "";
	for ( int i = 0; i < headerlength; i++ )
	{
		leer += " ";
	}

	( * _textstream ) << header.str ( ) << "[" << clientname << "] " << message << endl;
	string dataheader = string ( "DATA: " ) + dataname;
	if ( data != 0 && datasize > 0 )
	{
		( * _textstream ) << leer;
		int headerlineleft = ( _textwidth - headerlength - dataheader.size ( ) - 2 ) / 2;
		for ( int i = 0; i < headerlineleft; i++ )
		{
			( * _textstream ) << "-";
		}
		( * _textstream ) << " " << dataheader << " ";
		for ( int i = 0; i < _textwidth - headerlength - dataheader.size ( ) - 2 - headerlineleft; i++ )
		{
			( * _textstream ) << "-";
		}
		( * _textstream ) << endl;
		( * _textstream ) << formatData ( data, datasize, datatype, headerlength, _textwidth - headerlength, 5, false )
		        << endl;
	}

	_mutex->unlock ( );
}

