/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_MUTEX_H
#define YANE_UTILS_MUTEX_H

#include <pthread.h>

namespace yane
{

	namespace Utils
	{

		/** \class Mutex
		Class to use and create mutex objects. A mutex is needed if two or more threads read or write a shared object.
		Usually this class is used as following:
		@li lock the mutex
		@li do some critical stuff
		@li unlock the mutex
		@brief Mutex class
		 */
		class Mutex
		{
			public:
				/**
				 * Create new mutex object.
				 * @throw threadException Thrown if mutex creation failed
				 * @brief Constructor.
				*/
				Mutex();

				/**
				* Destroys the object.
				* @brief Destructor
				*/
				~Mutex();

				/**
				 * Try to lock the mutex. If mutex is already locked, the function is waiting until the mutex is unlocked.
				 * @throw threadException Thrown if lock failed because of technical reasons
				 * @brief Lock the mutex.
				 */
				virtual void lock();

				/**
				 * Try to lock the mutex. If mutex is already locked, the function returns.
				 * @return True if successful, false if an error occurred.
				 * @brief Try to lock the mutex.
				 */
				virtual bool trylock();

				/**
				 * Unlock the mutex.
				 * @throw threadException Thrown if unlock failed because of technical reasons
				 * @brief Unlock the mutex.
				 */
				virtual void unlock();

				/**
				 * Return wether the mutex is locked or unlocked.
				 * @return True if locked, false if unlocked.
				 * @brief Return wether the mutex is locked or unlocked.
				 */
				virtual bool isLocked();

			private:
				pthread_mutex_t _mutex; /**< Pthread Mutex on which this class is based. */

		};

	}

}

#endif
