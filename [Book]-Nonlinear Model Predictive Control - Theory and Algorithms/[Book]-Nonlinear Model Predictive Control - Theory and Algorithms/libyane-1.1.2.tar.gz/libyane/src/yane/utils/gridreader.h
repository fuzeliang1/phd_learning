/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_GRIDREADER_H
#define YANE_UTILS_GRIDREADER_H

#include "gridio.h"

namespace yane
{

	namespace Utils
	{
//TODO Documentation of class GridReader
		/** @class GridReader
		 * @brief not yet documented
		 */
		class GridReader : public GridIO
		{
			public:
				GridReader ( const char * filename );

				~GridReader ( );

				void readFrame ( unsigned char * grid, double * t, bool binarydata = false );
		};
	}
}

#endif
