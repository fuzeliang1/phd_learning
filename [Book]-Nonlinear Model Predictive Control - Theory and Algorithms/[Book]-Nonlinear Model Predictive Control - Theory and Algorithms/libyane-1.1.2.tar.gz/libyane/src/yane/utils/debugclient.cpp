/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "debugclient.h"
#include "debugmaster.h"
#include "rtclock.h"
#include "uuid.h"

#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::DebugClient::DebugClient ( DebugMaster * master, const std::string & clientname )
{
	_master = master;
	_clientname = clientname;
}

LIB_EXPORT yane::Utils::DebugClient::DebugClient ( const DebugClient & input )
{
	_master = input._master;
	_clientname = input._clientname;
}

LIB_EXPORT yane::Utils::DebugClient::~DebugClient ( )
{
}

LIB_EXPORT void yane::Utils::DebugClient::sendDebugInfo ( std::string message, std::string dataname, void * data,
        int datasize, int datatype, int level )
{
	if ( _master == 0 ) return;

	if ( level <= _master->level ( ) )
	{
		_master->addDebugInfo ( _clientname, message, dataname, data, datasize, datatype, level );
	}
}

LIB_EXPORT void yane::Utils::DebugClient::sendDebugInfo ( const char * message, const char * dataname, void * data,
        int datasize, int datatype, int level )
{
	if ( _master == 0 ) return;
	if ( level <= _master->level ( ) )
	{
		if ( dataname == 0 )
		{
			_master->addDebugInfo ( _clientname, string ( message ), string ( "" ), data, datasize, datatype, level );
		}
		else
		{
			_master->addDebugInfo ( _clientname, string ( message ), string ( dataname ), data, datasize, datatype,
			        level );
		}
	}
}

LIB_EXPORT yane::Utils::DebugClient & yane::Utils::DebugClient::operator = ( const DebugClient & input )
{
	_master = input._master;
	_clientname = input._clientname;

	return * this;
}

LIB_EXPORT std::string yane::Utils::DebugClient::name ( ) const
{
	return _clientname;
}

LIB_EXPORT void yane::Utils::DebugClient::sendDebugMessage ( const std::string & message, int debuglevel )
{
	sendDebugInfo ( message, "", 0, 0, 0, debuglevel );
}

LIB_EXPORT void yane::Utils::DebugClient::sendDebugMessageDouble ( const std::string & message,
        const std::string & varname, int length, double * data, int debuglevel )
{
	sendDebugInfo ( message, varname, ( void* ) data, sizeof(double) * length, yane::Utils::DebugMaster::T_DOUBLEARRAY,
	        debuglevel );
}

LIB_EXPORT void yane::Utils::DebugClient::sendDebugMessageInt ( const std::string & message,
        const std::string & varname, int length, int * data, int debuglevel )
{
	sendDebugInfo ( message, varname, ( void* ) data, sizeof(int) * length, yane::Utils::DebugMaster::T_INTARRAY,
	        debuglevel );
}

LIB_EXPORT void yane::Utils::DebugClient::sendDebugMessageString ( const std::string & message,
        const std::string & varname, const char * data, int debuglevel )
{
	sendDebugInfo ( message, varname, ( void* ) data, strlen ( data ) + 1, yane::Utils::DebugMaster::T_STRING,
	        debuglevel );
}

