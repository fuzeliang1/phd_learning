/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "gridwriter.h"

#include <cstring>

#include "libexport.h"

LIB_EXPORT yane::Utils::GridWriter::GridWriter ( const char * filename, unsigned int dimension,
        unsigned int * gridsize, double * lb, double * ub ) :
	yane::Utils::GridIO ( filename, dimension, gridsize, lb, ub )
{
	filledcellscount = 0;
}

LIB_EXPORT yane::Utils::GridWriter::~GridWriter ( )
{
}

LIB_EXPORT void yane::Utils::GridWriter::writeFrame ( unsigned char * grid, double t, bool binarydata )
{
	unsigned int count = 0;
	filledcellscount = 0;

	writeFrameBreak ( t );

	unsigned int bytepos = 0;
	unsigned int bitpos = 0;
	unsigned char newvalue;
	unsigned char value;

	if ( binarydata )
	{
		value = ( ( grid [ bytepos ] & ( 1 << bitpos ) ) != 0 );
	}
	else
	{
		value = grid [ bytepos ];
	}

	for ( unsigned int i = 0; i < gridlength; i++ )
	{
		if ( binarydata )
		{
			newvalue = ( ( grid [ bytepos ] & ( 1 << bitpos ) ) != 0 );
			bitpos++ ;
			if ( bitpos > 7 )
			{
				bitpos = 0;
				bytepos++ ;
			}
		}
		else
		{
			newvalue = grid [ i ];
		}

		if ( value == newvalue )
		{
			++count;
		}
		else
		{
			if ( value != 0 )
			{
				filledcellscount += count;
			}
			writeCluster ( value, count );
			value = newvalue;
			count = 1;
		}

	}
	writeCluster ( value, count );
	if ( value != 0 )
	{
		filledcellscount += count;
	}
}

LIB_EXPORT unsigned int yane::Utils::GridWriter::getFilledCellsCount ( )
{
	return filledcellscount;
}

