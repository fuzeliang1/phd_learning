/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_DEBUGCLIENT_H
#define YANE_UTILS_DEBUGCLIENT_H

#include <string>
#include <cstring>

namespace yane
{

	namespace Utils
	{

		class DebugMaster;

		/** \class DebugClient
		 * @see DebugMaster
		 * This class uses a DebugMaster to debug information. Usually this class is used as the following example :
		 * @code
		 RTClock::RTClock *clock = new RTClock::RTClock();
		 DebugMasterConsole::DebugMasterConsole *master = new DebugMasterConsole::DebugMasterConsole(clock, 90);
		 DebugClient::DebugClient *debug = master->newClient("Main");
		 debug->sendDebugInfo("Testmessage", 0, 0, 0, 0, 6);
		 debug->sendDebugInfo("Testmessage");
		 delete clock;
		 delete master;
		 delete debug;
		 * @endcode
		 * Every program has usually only one DebugMaster and more than one DebugClient (e.g. threads have their own DebugClient, ...).
		 * @brief DebugClient class
		 */
		class DebugClient
		{
			public:
				/**
				 * Creates a new DebugClient object. You should use master->newClient instead.
				 * @param master Associated master
				 * @param clientname Name of the client, is shown in the debug messages.
				 * @brief Constructor
				 */
				DebugClient ( DebugMaster * master, const std::string & clientname );

				/**
				 * Creates a new DebugClient object.
				 * @param input DebugClient
				 * @brief Copy Constructor
				*/
				DebugClient ( const DebugClient & input );

				/**
				 * Destroys the object.
				 * @brief Destructor
				*/
				~DebugClient();

				/**
				 * Adds a debug message and data to the master. Depending on the master the message is written to file (DebugMasterFile) or Console (DebugMasterConsole).
				 * @param message Debug message
				 * @param dataname Name of the data
				 * @param data Pointer to the data
				 * @param datasize Size of the data
				 * @param datatype Type of the data
				 * @param level Debug level
				 * @brief Adds a debug message and data to the master
				 */
				void sendDebugInfo ( std::string message, std::string dataname = "", void*data = 0, int datasize=0, int datatype=0, int level=0 );

				/**
				 * Adds a debug message and data to the master. Depending on the master the message is written to file (DebugMasterFile) or Console (DebugMasterConsole).
				 * @param message Debug message
				 * @param dataname Name of the data
				 * @param data Pointer to the data
				 * @param datasize Size of the data
				 * @param datatype Type of the data
				 * @param level Debug level
				 * @brief Adds a debug message and data to the master
				 */
				void sendDebugInfo ( const char * message, const char * dataname = 0, void*data = 0, int datasize=0, int datatype=0, int level=0 );

				/**
				 * Added for convenient  handling
				 * @param message Message which is debugged
				 * @param debuglevel Level with which the message is debugged.
				 * @brief Submit a debugmessage.
				 */
				virtual void sendDebugMessage ( const std::string & message, int debuglevel );

				/**
				 * Added for convenient  handling
				 * @param message Message which is debugged
				 * @param varname Data name
				 * @param length Length of data array
				 * @param data Data which is added.
				 * @param debuglevel Level with which the message is debugged.
				 * @brief Submit a debugmessage with doublevalued data.
				 */
				virtual void sendDebugMessageDouble ( const std::string & message, const std::string & varname, int length, double * data, int debuglevel );

				/**
				 * Added for convenient  handling
				 * @param message Message which is debugged
				 * @param varname Data name
				 * @param length Length of data array
				 * @param data Data which is added.
				 * @param debuglevel Level with which the message is debugged.
				 * @brief Submit a debugmessage with integervalued data.
				 */
				virtual void sendDebugMessageInt ( const std::string & message, const std::string & varname, int length, int * data, int debuglevel );

				/**
				 * Added for convenient  handling
				 * @param message Message which is debugged
				 * @param varname Data name
				 * @param data Pointer to an additional nullterminated character array, that has to be stored as data
				 * @param debuglevel Level with which the message is debugged.
				 * @brief Submit a debugmessage with textstring data.
				 */
				virtual void sendDebugMessageString ( const std::string & message, const std::string & varname, const char * data, int debuglevel );

				/**
				 * assignment operator
				 * @param input DebugClient
				 * @return DebugClient
				 * @brief assignment operator
				 */
				DebugClient & operator= ( const DebugClient & input );

				/**
				 * Returns name of the Client
				 * @return name of the client
				 * @brief Get Name
				 */
				std::string name() const;

			protected:
				/**< Master this object is using. */
				DebugMaster * _master;
				/**< Name of the client. */
				std::string _clientname;
		};

	}

}

#endif
