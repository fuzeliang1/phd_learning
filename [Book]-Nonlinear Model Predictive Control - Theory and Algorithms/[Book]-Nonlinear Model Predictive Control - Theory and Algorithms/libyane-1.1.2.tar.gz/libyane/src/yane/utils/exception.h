/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_EXCEPTION_H
#define YANE_UTILS_EXCEPTION_H

#include <exception>
#include <string>
#include <sstream>
#include <vector>

#define __DEBUGMESS(__mess) (yane::Utils::Exception::concatDebugMessage(__PRETTY_FUNCTION__, __LINE__, __mess))
#define __EXCEPTIONMESS(__type, __mess) (yane::Utils::Exception::concatMessage(__type, __mess))

namespace yane
{

	namespace Utils
	{

		/**
		 * Class to easen the processing of error and debug messages
		 * @brief Base class for handling exceptions in the YANE framework
		 * */
		class Exception : public std::exception
		{
			public:

				/**
				 * Generates an exception with a what() message and debug information. An exception which has caused this exception can bee added to it.
				 * @param mess Message to be printed out using the what() function
				 * @param debugmessage Debug information
				 * @param innerex Pointer of the exception which has caused this exception
				 * @brief Constructor
				 */
				Exception ( std::string mess = "unknown exception", std::string debugmessage = "no debuginfo",
				        Exception * innerex = 0 ) throw ( );

				/**
				 * @brief Destructor
				 */
				virtual ~Exception ( ) throw ( );

				/**
				 * Function to display the error message
				 * @return Error message
				 * @brief Function to display the error message
				 */
				virtual const char* what ( ) const throw ( );

				/**
				 * Function to return debug information
				 * @return Debug information
				 * @brief Function to return debug information
				 */
				const char* debugmessage ( ) const throw ( );

				/**
				 * Function to check if the invocation line of this instance is of the given type
				 * @param type Type string
				 * @return true if the type is contained within the invocation line of this instance
				 * @brief Function to check if the invocation line of this instance is of the given type
				 */
				bool isType ( const std::string & type ) const throw ( );

				/**
				 * Function to check if a certain type of exception is contained in the invocation line of this instance
				 * @param type Type string
				 * @return true if the type is contained within the invocation line of this instance
				 * @brief Function to check if a certain type of exception is contained in the invocation line of this instance
				 */
				bool stackTraceContainsType ( const std::string & type ) const throw ( );

				/**
				 * Function to globally set the output of debug information using the what() message
				 * @param enable true if debug information is to be displayed
				 * @brief Function to globally set the output of debug information using the what() message
				 */
				static void enableDebugMessage ( bool enable = false );

				/**
				 * Function to generate a debug error message using the name of the function in which the error occured, the corresponding line number
				 * and the error message
				 * @param functionname Name of the function in which the error occured
				 * @param line Line number in which the error occured
				 * @param message Error message
				 * @return Formated output of the debug error message
				 * @brief Function to generate a debug error message using the name of the function in which the error occured, the corresponding line number
				 * and the error message
				 */
				static std::string concatDebugMessage ( const char * functionname, int line, std::string message );

				/**
				 * Function to generate a formated error message from a string and an error message
				 * @param type Type string
				 * @param message Error message
				 * @return Formated error message
				 * @brief Function to generate a formated error message from a string and an error message
				 */
				static std::string concatMessage ( const std::string & type, const std::string & message );

				static const std::string TYPE; /**< @brief Type string of the exception */

			protected:
				/**
				 * Function to add a type string
				 * @param type Type string
				 * @brief Function to add a type string
				 */
				void addType ( std::string type );

				//TODO remove _message
				std::string _message; /**< @brief Error message, deprecated and to be removed in next release */
				//TODO remove _debugmess
				std::string _debugmess; /**< @brief Debug information, deprecated and to be remove in next release */

				static bool _printdebug; /**< @brief Decision variable whether debug information are to be displayed */
				int _number; /**< @brief Length of the invocation line */

				std::vector < std::string > _types; /**< @brief Type strings of all elements of the invocation line */
				std::vector < std::string > _stacktypes; /**< @brief Type strings of the exception stack */
		};

	}

}

#endif
