/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_COMPUTETHREADMANAGER_H
#define YANE_UTILS_COMPUTETHREADMANAGER_H

#include <pthread.h>
#include <string>
#include <vector>
#include <map>

namespace yane
{

	namespace Utils
	{

		class Semaphore;
		class DebugMaster;
		class DebugClient;

		/** \class ParallelComputing
		This class is used to do parallel computations. To provide your own functionality overwrite compute(task). Task contains eather an index int or a pointer, depending on how the items has been added. The ParallelComputing class creates its own threads and schedules / distributes the items to the threads by calling compute() with the task as argument. After the computation the list of items to compute isn't cleared!
		Usually this class is used as following:
		@li create ParallelComputing
		@li add some Items
		@li start Computation
		@li clear items
		@li delete ParallelComputing
		@brief Class to do parallel computations
		*/

		class ParallelComputing
		{
			public:
				/** \struct T_TASKINFO
				This struct contains a bool, which is true if task_data is a pointer otherwise false. task_data eather contains an int or a pointer.
				@brief Struct to specify computations
				 */
				struct T_TASKINFO
				{
					bool isPtr;

					union
					{
						void * ptr;
						int index;
					} task_data;
				};

				/**
				 * This creates the manager object.
				 *
				 * @param name Name prefix of the created threads
				 * @param dm Debugmaster to debug on.
				 * @param threads Count of threads to create and use.
				@brief Constructor
				*/
				ParallelComputing ( const std::string & name, DebugMaster * dm, int threads );

				/**
				* Destroys the object.
				@brief Destructor
				*/
				~ParallelComputing();

				/**
				 * This class deletes all items added by addItem before.
				@brief Clears all added items.
				*/
				void clearItems();

				/**
				 * Adds an item to the current list of
				 * @param index Number of the item, e.g. the range of the computation.
				 * @param weight Weight of the item, i.e. computation time
				@brief Adds an item to the list of work to do.
				 */
				void addItem ( int index, double weight );

				/**
				 * Adds an item to the current list.
				 * @param ptr Pointer to some data, e.g. a struct of computation info.
				 * @param weight Weight of the item, i.e. computation time
				@brief Adds an item to the list of work to do.
				 */
				void addItem ( void * ptr, double weight );

				/**
				 * Starts the computation by distributing the items to the threads and starting compute() for every thread. Without a clear() after that the items stay in the list.
				@brief Starts the computation.
				*/
				void startComputing();

			protected:

				/**
				* Overwrite this function to provide your own functionality for every thread.
				@param task Task data with which the compute function is called (eather an int or a pointer to data).
				@brief Computation which needs to be overwirtten.
				*/
				virtual void compute ( ParallelComputing::T_TASKINFO * task, DebugClient * debugclient ) = 0;

				/**
				 * Use the debugclient to debug data.
				@brief Debugclient of the manager.
				*/
				DebugClient * _debugclient;

			private:

				/**< Informations about a single thread */
				struct T_THREADINFO
				{

					pthread_t thread;
					pthread_attr_t attr;

					ParallelComputing * manager;
					DebugClient * debugclient;

					std::vector<T_TASKINFO> queue;
					double weights;
				};

				static void* threadWorker ( void* arg );

				/**< Array of threads */
				T_THREADINFO * _thread_array;
				int _thread_count;
				bool _abort;

				/**< Semaphores that are used*/
				Semaphore * _producesem;
				Semaphore * _consumesem;

				/**< List of items to compute */
				std::map<double, T_TASKINFO> _items;
				bool _update;

		};

	}

}

#endif
