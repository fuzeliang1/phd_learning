/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_DEBUGMASTERPTS_H
#define YANE_UTILS_DEBUGMASTERPTS_H

#include "debugmastertextstream.h"

namespace yane
{

	namespace Utils
	{

		class DebugMasterPTS : public DebugMasterTextStream
		{
			public:
				DebugMasterPTS ( const char * pts, RTClock* clock, int textwidth = 80 );
				virtual ~DebugMasterPTS ( );

				virtual void addDebugInfo ( std::string clientname, std::string message, std::string dataname,
				        void* data, int datasize, int datatype, int level );

			protected:
				char * _buffer;
				char * _command;
				char * _ptsdev;

		};

	}

}

#endif
