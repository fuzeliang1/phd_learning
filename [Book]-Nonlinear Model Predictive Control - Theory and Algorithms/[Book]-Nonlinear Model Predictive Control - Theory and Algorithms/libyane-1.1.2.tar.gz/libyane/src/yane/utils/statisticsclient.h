/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_STATISTICSCLIENT_H
#define YANE_UTILS_STATISTICSCLIENT_H

#include <string>

namespace yane
{

	namespace Utils
	{

		class StatisticsMaster;

		/** \class StatisticsClient
		 * @see StatisticsMaster
		 * This class uses a StatisticsMaster to gather statistical information.
		 * Every program has usually only one StatisticsMaster and more than one StatisticsClient (e.g. threads have their own StatisticsClient, ...).
		 * @brief StatisticsClient class
		 */
		class StatisticsClient
		{
			public:
				/**
				 * @brief Constructor
				 */
				StatisticsClient ( StatisticsMaster * master, const std::string & group, const std::string & name );

				/**
				 * @brief Destructor
				 */
				virtual ~StatisticsClient ( );

				/**
				 * @brief Output format of the statistical data
				 */
				virtual std::string formattedData ( ) = 0;

				/**
				 * @brief Function to reset the client
				 */
				virtual void reset ( ) = 0;

				/**
				 * @brief Function returning the name of the client
				 */
				virtual std::string name ( );

			protected:
				StatisticsMaster * _master; /**< @brief Pointer of the StatisticsMaster object to which the client is connected to */
				std::string _name; /**< @brief Name of client */
				std::string _group; /**< @brief Name of the group the client belongs to */
		};

	}

}

#endif
