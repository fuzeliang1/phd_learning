/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_GRIDWRITER_H
#define YANE_UTILS_GRIDWRITER_H

#include "gridio.h"

namespace yane
{

	namespace Utils
	{
//TODO Documentation of class GridWriter
		/** @class GridWriter
		 * @brief not yet documented
		 */
		class GridWriter : public GridIO
		{
			public:
				GridWriter ( const char * filename, unsigned int dimension, unsigned int * gridsize, double * lb,
				        double * ub );

				~GridWriter ( );

				void writeFrame ( unsigned char * grid, double t, bool binarydata = false );
				unsigned int getFilledCellsCount ( );

			protected:
				unsigned int filledcellscount;
		};
	}
}

#endif
