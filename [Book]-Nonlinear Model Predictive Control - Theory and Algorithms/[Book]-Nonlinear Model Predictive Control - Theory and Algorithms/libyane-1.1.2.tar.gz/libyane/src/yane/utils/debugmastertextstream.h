/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_DEBUGMASTERTEXTSTREAM_H
#define YANE_UTILS_DEBUGMASTERTEXTSTREAM_H

#include "debugmaster.h"
#include <ostream>

namespace yane
{

	namespace Utils
	{
		/** \class DebugMasterTextStream
		 * @see DebugMaster
		 * This class extends DebugMaster and adds the functionality to write to a textstream.The output looks like the following:<br><br>
		 Without appended data:
		 @code
		 0.000365 | [Client name] Message
		 @endcode
		 With appended data:
		 @code
		 0.000365 | [Client name] Message
		 ------------------------------ DATA: Dataname -------------------------------
		 Data
		 @endcode
		 @brief DebugMaster that writes to a textstream.
		 */
		class DebugMasterTextStream : public DebugMaster
		{
			public:
				/**
				 * This creates the DebugMasterTextStream object.
				 * @param clock Clock the current program is using.
				 * @param textstream Textstream the data is written into.
				 * @param textwidth Width after which a line is wrapped.
				 @brief Constructor
				 */
				DebugMasterTextStream ( RTClock * clock, std::ostream * textstream, int textwidth = 80 );

				/**
				 * Overwrites the addDebugInfo class from DebugMaster to write the data to a textstream.
				 * @param clientname Client from which the debug message was forwarded.
				 * @param message Debug message
				 * @param dataname Name of the data
				 * @param data Pointer to the data
				 * @param datasize Size of the data
				 * @param datatype Type of the data
				 * @param level Debug level of the data
				 * @brief Add some messages and/or data
				 */
				virtual void addDebugInfo ( std::string clientname, std::string message, std::string dataname,
				        void* data, int datasize, int datatype, int level );

			protected:
				/**< Width after which a line is wrapped. */
				int _textwidth;
				/**< Textstream this object is using. */
				std::ostream * _textstream;

		};

	}

}

#endif
