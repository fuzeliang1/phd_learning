/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_STATISTICSCLIENTPERSECOND_H
#define YANE_UTILS_STATISTICSCLIENTPERSECOND_H

#include "statisticsclient.h"

namespace yane
{

	namespace Utils
	{

		class RTClock;

		/** @class StatisticsClientPerSecond
		 * @see StatisticsMaster
		 * This class uses a StatisticsMaster to gather averaged statistical information.
		 * @brief StatisticsClientPerSecond class
		 */
		class StatisticsClientPerSecond : public StatisticsClient
		{
			public:
				/**
				 * Constructor
				 * @param master Pointer of the StatisticsMaster class the client belongs to
				 * @param group Group of clients the client belongs to
				 * @param name Name of the client
				 * @param prec Precision of output
				 * @brief Constructor
				 */
				StatisticsClientPerSecond ( StatisticsMaster* master, const std::string& group,
				        const std::string& name, int prec );

				/**
				 * @brief Destructor
				 */
				virtual ~StatisticsClientPerSecond ( );

				/**
				 * Function to add an double value to the statistical data
				 * @param value Value to add to the data
				 * @brief Function to add an double value to the statistical data
				 */
				void addValue ( double value );

				virtual std::string formattedData ( );
				virtual void reset ( );

			protected:
				double _value; /**< @brief Per seconds value of the statistical data */
				RTClock * _clock; /**< @brief Pointer of class yane::Utils::RTClock object */
				int _prec; /**< @brief Precision of output */
		};

	}

}

#endif
