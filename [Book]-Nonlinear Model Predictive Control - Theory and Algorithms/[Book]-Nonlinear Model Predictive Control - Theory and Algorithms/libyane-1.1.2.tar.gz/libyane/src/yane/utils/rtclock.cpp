/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "rtclock.h"
#include "mutex.h"
#include <cstring>
#include <cmath>

#include "libexport.h"

LIB_EXPORT yane::Utils::RTClock::RTClock()
{
	_mutex = new Mutex();
	gettimeofday ( & ( _starttime ), NULL );
//	this->reset();
}

LIB_EXPORT yane::Utils::RTClock::~ RTClock()
{
	delete _mutex;
}

LIB_EXPORT double yane::Utils::RTClock::elapsedSeconds()
{
	_mutex->lock();

	timeval end;
	gettimeofday ( &end, NULL );

	double result = ( double ) end.tv_sec- ( double ) _starttime.tv_sec + ( double ) ( end.tv_usec - _starttime.tv_usec )  /1000000.0;
	_mutex->unlock();

	return result;

}

LIB_EXPORT void yane::Utils::RTClock::reset()
{
	_mutex->lock();
	gettimeofday ( & ( _starttime ), NULL );
	_mutex->unlock();
}


LIB_EXPORT void yane::Utils::RTClock::reset ( const timeval & starttime )
{
	_mutex->lock();
	_starttime.tv_sec = starttime.tv_sec;
	_starttime.tv_usec = starttime.tv_usec;
	_mutex->unlock();
}

LIB_EXPORT void yane::Utils::RTClock::getStartTime ( timeval * time )
{
	_mutex->lock();
	time->tv_sec = _starttime.tv_sec;
	time->tv_usec = _starttime.tv_usec;
	_mutex->unlock();
}

LIB_EXPORT void yane::Utils::RTClock::setElapsedSeconds(double seconds)
{
	_mutex->lock();
	timeval time;
	gettimeofday ( &time, NULL );
	time.tv_sec -= (time_t)floor(seconds);
	time_t usec = (time_t)((seconds-floor(seconds))*1E+6);

	if (time.tv_usec < usec)
	{
		time.tv_usec += 1E+6;
		time.tv_sec -= 1;
	}
	time.tv_usec -= usec;

	_starttime.tv_sec = time.tv_sec;
	_starttime.tv_usec = time.tv_usec;
	_mutex->unlock();

}
