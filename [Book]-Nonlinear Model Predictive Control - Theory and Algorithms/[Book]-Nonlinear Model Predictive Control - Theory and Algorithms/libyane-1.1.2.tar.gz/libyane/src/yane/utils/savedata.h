/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_SAVEDATA_H
#define YANE_UTILS_SAVEDATA_H

#include <string>

namespace yane
{

	namespace Utils
	{

		/** \class SaveData
			\brief Class to save state and control values
		*/
		class SaveData
		{
			public:
				/**
				* @brief Constructor
				 * @param dimension_x Dimension of the state
				 * @param dimension_u Dimension of the control
				 * @param horizon Length of the horizon (optional)
				 * @param controlhorizon Length of the control horizon (optional)
				 */
				SaveData ( int dimension_x, int dimension_u, int horizon = 0, int controlhorizon = 0 );

				/**
					@brief Destructor
				*/
				~SaveData();

				/**
				 * @brief Function to save closed-loop data to harddisk \n
				This function saves the current time instant together with control and state values in one individual file. These files are denoted by <b>tmp_x???.dat</b> and <b>tmp_u???.dat</b> (where ??? denotes the component of the state or control variable).
				 * @param t Current time grid
				 * @param x Initial state vector
				 * @param u Control vector on the time gird
				 */
				void save2Files ( double * t, double * x, double * u );

				/**
				 * @brief Function to save open-loop data to harddisk \n
				This function save the current time grid together with control and strate trajectories in one individual file. These files are denoted by <b>tmp_!!_x??.dat</b> und <b>tmp_!!_u??.dat</b> (where !! denotes the time index and ?? denotes the component of the state or control variable).
				 * @param iter Current iterate
				 * @param horizon Length of the horizon
				 * @param t Current time grid
				 * @param x Open-loop state trajectories
				 * @param u Open-loop control trajectories
				 */
				void saveOpenloop2Files ( int iter, int horizon, double * t, double * x, double * u );

				/**
				 * @brief Function to save the running costs and computing times to harddisk
				 * @param closedloopcost Current running cost
				 * @param computingtime Required computing time
				 */
				void saveClosedloopcost2File ( double closedloopcost, double computingtime = 0.0 );

			private:
				/**
					@brief Function to transform an integer into a string variable
					@param input Input integer
					@param output Output string
				*/
				void IntToString ( int input, std::string & output );

				/**
					@brief Function to transform a string into a char array
					@param input Input string
					@param output Output char array
				*/
				void StringToChar ( std::string input, char * output );

				/**
					@brief Function to delete all standard files
				*/
				void deleteFiles ( void );

				int _dimension_x;		/**< @brief Dimension of the state */
				int _dimension_u;		/**< @brief Dimension of the control */

		};

	}

}

#endif
