/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_OPTIMALDIFF_H
#define YANE_UTILS_OPTIMALDIFF_H

namespace yane
{

	namespace Utils
	{

		/** @class OptimalDiff
		 * @brief Class to compute the optimal differentiation step size
		 */
		class OptimalDiff
		{
			public:
				/**
				 * @brief Function to compute the optimal differentiation step size
				 */
				static void calc ( );

				/**
				 * @brief Function to return the optimal differentialtion step size
				 */
				static double get ( );

				/**
				 * @brief Function to set the internal value of the optimal differentialtion step size
				 */
				static void set ( double newdiffacc );

			private:
				/**
				 @brief Constructor
				 */
				OptimalDiff ( );

				/**
				 * Test function to be used to compute the optimal differentiation step size
				 * @param x Test value
				 * @brief Test function to be used to compute the optimal differentiation step size
				 */
				static double testfun ( double x );

				/**
				 * Derivative of the test function
				 * @param x Test value
				 * @brief Derivative of the test function
				 */
				static double testfun_derive ( double x );

				/**
				 * Function to compute the deviation of the numerical derivative from the analytical derivative
				 * @param value Test value
				 * @brief Function to compute the deviation of the numerical derivative from the analytical derivative
				 */
				static double failure ( double value );

				static double _diffacc; /**< @brief Optimal differentiation step size */

		};

	}

}

#endif
