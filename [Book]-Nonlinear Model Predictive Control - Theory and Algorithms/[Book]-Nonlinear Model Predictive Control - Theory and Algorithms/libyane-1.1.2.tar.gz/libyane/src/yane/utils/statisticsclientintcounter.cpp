/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Juergen Pannek <juergen.pannek@uni-bayreuth.de>                       *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Juergen Pannek <juergen.pannek@uni-bayreuth.de>
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "statisticsclientintcounter.h"
#include "statisticsmaster.h"

#include <sstream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::StatisticsClientIntCounter::StatisticsClientIntCounter ( StatisticsMaster * master,
        const std::string & group, const std::string & name ) :
	yane::Utils::StatisticsClient ( master, group, name )
{
	_value = 0;
}

LIB_EXPORT yane::Utils::StatisticsClientIntCounter::~StatisticsClientIntCounter ( )
{
}

LIB_EXPORT void yane::Utils::StatisticsClientIntCounter::addValue ( int value )
{
	_value += value;
}

LIB_EXPORT void yane::Utils::StatisticsClientIntCounter::setValue ( int value )
{
	_value = value;
}

LIB_EXPORT std::string yane::Utils::StatisticsClientIntCounter::formattedData ( )
{
	stringstream out;
	out << _value;
	return out.str ( );
}

LIB_EXPORT void yane::Utils::StatisticsClientIntCounter::reset ( )
{
	_value = 0;
}
