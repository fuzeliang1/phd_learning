/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "semaphore.h"
#include "exceptions.h"

#ifndef _WIN32
	#include <sys/types.h>
	#include <sys/ipc.h>
	#include <csignal>
	#include <errno.h>
	#include <time.h>
	#include <iostream>
	#include <unistd.h>
#endif

#include "libexport.h"

using namespace std;


#ifndef _WIN32
volatile int _alarm_triggered = 0;
void alarm_handler ( int sig )
{
    _alarm_triggered = 1;
}
#endif


// Constructor
LIB_EXPORT yane::Utils::Semaphore::Semaphore ( int resources )
{
#ifdef _WIN32
	// CreateSemaphore( SecurityAttributes, InitialValue, MaxValue, Name)
	// TODO WINDOWS Pruefen ob SecAttr gesetzt werden muss, werd da nicht recht schlau draus.
	// TODO WINDOWS Pruefen ob init=max sinnvoll ist.
	if( (_semaphore = CreateSemaphore(NULL, resources, resources, NULL)) == NULL )
	{
		throw ThreadException ( __DEBUGMESS ( "Unable to create Semaphore" ) );
	}
#else
	// Create one private Semaphore with rights 0600
	_semaphore = semget ( IPC_PRIVATE, 1, IPC_CREAT | 0600 );

	if ( _semaphore == -1 )
	{
		throw ThreadException ( __DEBUGMESS ( "Unable to create Semaphore" ) );
	}

	// Set resources as first value
	if ( semctl ( _semaphore, 0, SETVAL, resources ) )
	{
		throw ThreadException ( __DEBUGMESS ( "Unable to set Semaphore resources" ) );
	}

	_semop.sem_num = 0;
	_semop.sem_flg = 0;
#endif
}

// Destructor
LIB_EXPORT yane::Utils::Semaphore::~ Semaphore()
{
#ifdef _WIN32
	if( CloseHandle(_semaphore) != 0 ) throw ThreadException ( __DEBUGMESS( "unable to close semaphore-handle" ) );
#else
	semctl ( _semaphore, 0, IPC_RMID );
#endif
}

// Acquire resources
LIB_EXPORT void yane::Utils::Semaphore::acquire ( int resources )
{
	if ( resources < 1 )
	{
		throw ValueException ( __DEBUGMESS ( "resources parameter out of range, must be greater than zero" ) );
	}

	if ( !operation ( -resources, 0 ) )
	{
		throw ThreadException ( __DEBUGMESS ( "Unable to acquire semaphore" ) );
	}
}

// Try acquire resources
LIB_EXPORT bool yane::Utils::Semaphore::tryAcquire ( int resources, unsigned int wait_msec )
{
	if ( resources < 1 )
	{
		throw ValueException ( __DEBUGMESS ( "resources parameter out of range, must be greater than zero" ) );
	}
#ifdef _WIN32
	return operation ( -resources, wait_msec );
#else
	//TODO: Unterschied??? Warum nicht gleich wait_msec = 0 benutzen?
	if (wait_msec == 0)
	{
		_semop.sem_flg = IPC_NOWAIT;
		bool result = operation ( -resources, 0 );
		_semop.sem_flg = 0;
		return result;
	} else
	{
		return operation ( -resources, wait_msec );
	}
#endif

}

// Return how many resources are available
LIB_EXPORT int yane::Utils::Semaphore::available()
{
#ifdef _WIN32
	long value;
	ReleaseSemaphore( _semaphore, 0, &value );
	return value;
#else
	return semctl ( _semaphore, 0, GETVAL );
#endif
}

// Release resources
LIB_EXPORT void yane::Utils::Semaphore::release ( int resources )
{
	if ( resources < 1 )
	{
		throw ValueException ( __DEBUGMESS ( "resources parameter out of range, must be greater than zero" ) );
	}

	if ( !operation ( resources, 0 ) )
	{
		throw ThreadException ( __DEBUGMESS ( "Unable to release semaphore" ) );
	}
}

// Does the operation
bool yane::Utils::Semaphore::operation ( int resources, unsigned int wait_msec )
{
#ifdef _WIN32
	if( wait_msec == 0)
	{
		if( resources < 0)	// aquire
		{
			// TODO WINDOWS, vielleicht was anderes ueberlegen.
			// siehe elseq-Fall mit WaitMultipleObjects
			while( ++resources <= 0)
			{
				WaitForSingleObject( _semaphore, 0 ) ;
			}
			return true;
		}
		if( resources > 0) // release
		{
			return ( ReleaseSemaphore(_semaphore, resources, NULL) != 0 );
		}
	}
	else
	{
		// TODO WINDOWS Time-Semaphore-Operation
		// Vielleicht mit WaitForMultipleObjects und Handle-Array HANDLE* = {_semaphore, _semaphore, _semaphore, ...}
		// Allerdings koennte es sein, das wenn der _semaphore einmal dekrementiert wird, WaitForMultipleObjects sofort endet.
		throw ThreadException ( __DEBUGMESS( "timed semaphore-operations not implemented yet" ) );
	}
#else
	// Set timedop variables
	_semop.sem_op = resources;
	if ( wait_msec == 0 )
	{
		if ( semop ( _semaphore, &_semop, 1 ) )
		{
			return false;
		}
	}
	else
	{
//		timespec * timeout;
//
//		// Set timeout
//		if ( wait_msec > 0 )
//		{
//			timespec ts = {wait_msec / 1000, ( wait_msec%1000 ) *1000*1000};
//			timeout = &ts;
//		}
//		else
//		{
//			timeout = NULL;
//		}
//
//		// Do semtimedop
//		if ( semtimedop ( _semaphore, &_semop, 1, timeout ) ) // Not available for Mac OS X
//		{
//			return false;
//		}
//		throw ThreadException ( __DEBUGMESS( "timed semaphore-operations not implemented yet" ) );
// 		Mac Time-Semaphore-Operation
		signal ( SIGALRM, alarm_handler );
		useconds_t timeout = wait_msec * 1000;
		ualarm ( timeout, 0 );
		int returnvalue = semop ( _semaphore, &_semop, 1 );
		if ( returnvalue == -1 && errno == EINTR)
		{
			if ( _alarm_triggered )
			{
				return false;
			}
		}
		ualarm(0, 0);
	}

	return true;
#endif
}
