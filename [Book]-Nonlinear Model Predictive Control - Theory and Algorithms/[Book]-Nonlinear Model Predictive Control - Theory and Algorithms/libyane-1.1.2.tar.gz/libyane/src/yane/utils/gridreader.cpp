/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "gridreader.h"

#include <iostream>
#include <cstring>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::GridReader::GridReader ( const char * filename ) :
	yane::Utils::GridIO ( filename )
{
}

LIB_EXPORT yane::Utils::GridReader::~GridReader ( )
{
}

LIB_EXPORT void yane::Utils::GridReader::readFrame ( unsigned char * grid, double * t, bool binarydata )
{
	* t = readFrameBreak ( );

	unsigned int readcells = 0;
	unsigned int count;
	unsigned char value;

	unsigned int bytepos;
	unsigned int bitpos;

	while ( readcells < gridlength )
	{
		readCluster ( & value, & count );
		if ( binarydata )
		{
			for ( int i = 0; i < count; i++ )
			{
				grid [ bytepos ] |= ( 1 << bitpos );
				bitpos++ ;
				if ( bitpos > 7 )
				{
					bitpos = 0;
					bytepos++ ;
				}
			}
		}
		else
		{
			memset ( & grid [ readcells ], value, count * sizeof(unsigned char) );
		}
		readcells += count;
	}
}

