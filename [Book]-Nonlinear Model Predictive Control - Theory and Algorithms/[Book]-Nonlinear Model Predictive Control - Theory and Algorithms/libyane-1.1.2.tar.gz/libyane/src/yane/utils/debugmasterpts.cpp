/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "debugmasterpts.h"
#include "mutex.h"

#include <sstream>
#include <iostream>
#include <cstring>
#include <cstdlib>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Utils::DebugMasterPTS::DebugMasterPTS ( const char * pts, RTClock * clock, int textwidth ) :
	DebugMasterTextStream ( clock, new stringstream ( ), textwidth )
{
	_buffer = new char [ textwidth + 200 ];
	_command = new char [ textwidth + 200 + 30 ];
	_ptsdev = new char [ strlen ( pts ) + 1 ];
	strcpy ( _ptsdev, pts );
}

LIB_EXPORT yane::Utils::DebugMasterPTS::~DebugMasterPTS ( )
{
	delete _textstream;
	delete _buffer;
	delete _command;
	delete _ptsdev;
}

LIB_EXPORT void yane::Utils::DebugMasterPTS::addDebugInfo ( std::string clientname, std::string message,
        std::string dataname, void * data, int datasize, int datatype, int level )
{
	DebugMasterTextStream::addDebugInfo ( clientname, message, dataname, data, datasize, datatype, level );

	_mutex->lock ( );

	stringstream * str = ( stringstream* ) _textstream;

	while ( ! str->eof ( ) )
	{
		str->getline ( _buffer, _textwidth + 200 );
		if ( _buffer [ 0 ] != 0 )
		{
			strcpy ( _command, "echo \"" );

			int counter = strlen ( _command );
			for ( int i = 0; str->gcount ( ) && counter < _textwidth + 198; i++ )
			{
				if ( _buffer [ i ] == '"' )
				{
					_command [ counter ] = '\\';
					++counter;
				}

				_command [ counter ] = _buffer [ i ];
				++counter;
			}

			strcat ( _command, "\" > " );
			strcat ( _command, _ptsdev );

			system ( _command );
		}
	}

	delete _textstream;
	_textstream = new stringstream ( );

	_mutex->unlock ( );
}

