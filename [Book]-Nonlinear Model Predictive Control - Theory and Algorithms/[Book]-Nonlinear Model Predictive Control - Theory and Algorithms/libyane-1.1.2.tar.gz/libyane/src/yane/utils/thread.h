/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_UTILS_CONTROLLERTHREAD_H
#define YANE_UTILS_CONTROLLERTHREAD_H

#include <pthread.h>
#include <string>

namespace yane
{
	namespace Utils
	{
		class DebugMaster;
		class DebugClient;
		class Mutex;
		class Semaphore;


		/** \class Thread
		This class is able to create a thread. To provide your own functionality overwrite the run() function. Usually you should use a loop like the following:
		@code
		while(!_abort)
		{
			// do stuff
		}
		@endcode
		Usually this class is used as following:<br>
		@li Create and start thread:<br>
		@code
		thread = new Thread(..);
		thread->start();
		@endcode
		@li Run the thread:<br>
		start() creates a new Thread and starts the run() function, therefore you need to overwrite this function.
		@li Stop and finish threads:<br>
		@code
		thread->stop();
		thread->wait();
		@endcode
		Stop sets the _abort variable, if _abort is set your run() function should abort. With wait main is blocked until a thread is finished.
		<b>Remark:</b> The constructor only creates a thread object, the actual thread is created in start().

		@brief Class to create a thread
		*/
		class Thread
		{
			public:
				/**
				 * This creates a thread object, not the thread itself.
				 * @param name
				 * @param dm
				   @brief Constructor
				 */
				Thread ( const std::string & name = "Thread", DebugMaster * dm = 0 );

				/**
				 * @brief Destructor
				 */
				virtual ~Thread();

				/**
				   This function creates the thread and should be called after creating the object.
				 * @brief Creates the thread
				 */
				virtual void start();

				/**
				 * This function sets _abort to false, your thread should stop now.
				 * @brief Stops the thread
				 */
				virtual void stop();

				/**
				 * The calling thread is blocked until the thread is finished, possible return information
				 * @brief Blocks until thread is finished, possible return information
				 */
				virtual void wait();

				/**
				 * The calling thread is blocked until the thread is finished, no return information
				 * @brief Blocks until thread is finished, no return information
				 */
				virtual void detach();

				/**
				 * Signal a thread to resume, if it's blocked due to a call to waitForTrigger()
				 * @brief Signal / Trigger the thread.
				 * @see waitForTrigger()
				 */
				virtual void trigger();

				/**
				 * Locks the thread. If already locked the calling thread is blocked until the thread is unlocked.
				 * @brief Locks the thread, if already locked blocks.
				 */
				virtual void lock();

				/**
				 * Locks the thread. If already locked returns immediately.
				 * @return true if successful
				 * @brief Locks the thread but returns immediately.
				 */
				virtual bool trylock();

				/**
				 * Unlocks the thread.
				 * @brief Unlock the thread
				 */
				virtual void unlock();

				/**
				 * Returns wether the thread is running (_abort = false) or not.
				 * @return true if thread is running.
				 * @brief Returns if thread is running.
				 */
				virtual bool isRunning();

				/**
				 * Returns wether the thread is locked or not.
				 * @return true if thread is locked.
				 * @brief Returns if thread is locked.
				 */
				virtual bool isLocked();

			protected:

				/**
				 * Overwrite this function to provide your own functionality.
				     * @brief Function which is called after the thread is created.
				 */
				virtual void run() = 0;

				/**
				 * The calling function (usually the thread) is blocked until the function is triggered.
				 * @param wait_msec Time until waiting is aborted.
				 * @param debuglevel Debuglevel with which the abort message is stored.
				 * @return true if successful
				 * @brief Block until triggered.
				 */
				virtual bool waitForTrigger ( unsigned int wait_msec=0, int debuglevel=0 );

				/**
				 * Added for convenient  handling
				 * @param message Message which is debugged
				 * @param debuglevel Level with which the message is debugged.
				 * @brief Submit a debugmessage.
				 */
				virtual void debugMessage ( const std::string & message, int debuglevel );
				
				/**
				 * Added for convenient  handling
				 * @param message Message which is debugged
				 * @param varname Data name
				 * @param length Length of data array
				 * @param data Data which is added.
				 * @param debuglevel Level with which the message is debugged.
				 * @brief Submit a debugmessage with doublevalued data.
				 */
				virtual void debugMessageDouble ( const std::string & message, const std::string & varname, int length, double * data, int debuglevel );
				
				/**
				 * Added for convenient  handling
				 * @param message Message which is debugged
				 * @param varname Data name
				 * @param length Length of data array
				 * @param data Data which is added.
				 * @param debuglevel Level with which the message is debugged.
				 * @brief Submit a debugmessage with integervalued data.
				 */
				virtual void debugMessageInt ( const std::string & message, const std::string & varname, int length, int * data, int debuglevel );
				
				/**
				 * Added for convenient  handling
				 * @param message Message which is debugged
				 * @param varname Data name
				 * @param data Pointer to an additional nullterminated character array, that has to be stored as data
				 * @param debuglevel Level with which the message is debugged.
				 * @brief Submit a debugmessage with textstring data.
				 */
				virtual void debugMessageString ( const std::string & message, const std::string & varname, const char * data, int debuglevel );

				/**
				* If true thread should be stopped. Value is changed by stop().
				*/
				bool _abort;

				/**
				* Debugclient the debug messages are stored into.
				*/
				DebugClient * _debugclient;

			private:

				static void* threadWorker ( void* arg );

				pthread_t _thread;
				pthread_attr_t _threadattr;
				Mutex * _mutex;
				Semaphore * _semaphore;

				bool _running;

		};
	}
}

#endif
