/***************************************************************************
 *                                                                         *
 * Utility Library                                                         *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 */

#include "gridio.h"
#include "exceptions.h"
#include <sstream>
#include <cstring>
#include <iostream>
#include <cmath>

#include "libexport.h"

#define CODE 0x2f87a0be
#define MAXCOORDNAMELENGTH 50

using namespace std;

LIB_EXPORT const unsigned char yane::Utils::GridIO::FB_VALUE = - 1;
LIB_EXPORT const unsigned int yane::Utils::GridIO::FB_COUNT = - 1;

LIB_EXPORT yane::Utils::GridIO::GridIO ( const char * filename, unsigned int dimension, unsigned int * gridsize,
        double * lb, double * ub )
{
	this->gridsize = new unsigned int [ dimension ];
	this->lbound = new double [ dimension ];
	this->ubound = new double [ dimension ];
	coordnames = new char [ MAXCOORDNAMELENGTH * dimension ];

	memcpy ( this->gridsize, gridsize, sizeof(unsigned int) * dimension );
	memcpy ( this->lbound, lb, sizeof(double) * dimension );
	memcpy ( this->ubound, ub, sizeof(double) * dimension );
	memset ( coordnames, 0, sizeof(char) * MAXCOORDNAMELENGTH * dimension );

	header.dimension = dimension;
	header.frames = 0;
	header.t0 = INFINITY;
	header.T = 0.0;
	header.code = CODE;

	memset ( header.title, 0, sizeof(char) * 128 );

	fp = fopen ( filename, "w+b" );
	if ( fp == NULL )
	{
		stringstream s;
		s << "cannot open file \"" << filename << "\"";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	unsigned int writecounter = 0;

	writecounter = fwrite ( & header, sizeof ( header ), 1, this->fp );
	if ( writecounter != 1 )
	{
		stringstream s;
		s << "error creating file \"" << filename << "\" (err #1)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	writecounter = fwrite ( this->gridsize, sizeof(unsigned int), dimension, this->fp );
	if ( writecounter != dimension )
	{
		stringstream s;
		s << "error creating file \"" << filename << "\" (err #2)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	writecounter = fwrite ( this->lbound, sizeof(double), dimension, this->fp );
	if ( writecounter != dimension )
	{
		stringstream s;
		s << "error creating file \"" << filename << "\" (err #3)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	writecounter = fwrite ( this->ubound, sizeof(double), dimension, this->fp );
	if ( writecounter != dimension )
	{
		stringstream s;
		s << "error creating file \"" << filename << "\" (err #4)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	writecounter = fwrite ( this->coordnames, sizeof(char), dimension * MAXCOORDNAMELENGTH, this->fp );
	if ( writecounter != dimension * MAXCOORDNAMELENGTH )
	{
		stringstream s;
		s << "error creating file \"" << filename << "\" (err #5)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	fname = filename;
	filesize = ftell ( fp );

	gridlength = 1;
	for ( unsigned int i = 0; i < dimension; i++ )
	{
		gridlength *= this->gridsize [ i ];
	}

}

LIB_EXPORT yane::Utils::GridIO::GridIO ( const char * filename )
{
	fp = fopen ( filename, "r+b" );
	if ( fp == NULL )
	{
		stringstream s;
		s << "cannot open file \"" << filename << "\"";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	fseek ( fp, 0, SEEK_END );
	filesize = ftell ( fp );
	fseek ( fp, 0, SEEK_SET );

	unsigned int readcounter = 0;

	readcounter = fread ( & header, sizeof ( header ), 1, fp );
	if ( readcounter != 1 )
	{
		stringstream s;
		s << "error reading file \"" << filename << "\": corrupted header (err #1)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	if ( header.code != CODE )
	{
		stringstream s;
		s << "error reading file \"" << filename << "\": corrupted header (signatur failed)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	gridsize = new unsigned int [ header.dimension ];
	readcounter = fread ( gridsize, sizeof(unsigned int), header.dimension, fp );
	if ( readcounter != header.dimension )
	{
		stringstream s;
		s << "error reading file \"" << filename << "\": corrupted header (err #2)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	lbound = new double [ header.dimension ];
	readcounter = fread ( lbound, sizeof(double), header.dimension, fp );
	if ( readcounter != header.dimension )
	{
		stringstream s;
		s << "error reading file \"" << filename << "\": corrupted header (err #3)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	ubound = new double [ header.dimension ];
	readcounter = fread ( ubound, sizeof(double), header.dimension, fp );
	if ( readcounter != header.dimension )
	{
		stringstream s;
		s << "error reading file \"" << filename << "\": corrupted header (err #4)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	coordnames = new char [ header.dimension * MAXCOORDNAMELENGTH ];
	readcounter = fread ( coordnames, sizeof(char), header.dimension * MAXCOORDNAMELENGTH, fp );
	if ( readcounter != header.dimension * MAXCOORDNAMELENGTH )
	{
		stringstream s;
		s << "error reading file \"" << filename << "\": corrupted header (err #5)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	fname = filename;
	gridlength = 1;
	for ( unsigned int i = 0; i < header.dimension; i++ )
	{
		gridlength *= this->gridsize [ i ];
	}
}

LIB_EXPORT yane::Utils::GridIO::~GridIO ( )
{
	fclose ( fp );
	delete gridsize;
	delete lbound;
	delete ubound;
}

LIB_EXPORT void yane::Utils::GridIO::writeCluster ( unsigned char value, unsigned int count )
{
	writeData ( value, count );
}

LIB_EXPORT void yane::Utils::GridIO::readCluster ( unsigned char * value, unsigned int * count )
{
	readData ( value, count );
	if ( ( * count == FB_COUNT ) && ( * value == FB_VALUE ) )
	{
		stringstream s;
		s << "error during reading file: unexpected frame break in \"" << fname << "\"";
		throw IOException ( __DEBUGMESS(s.str()) );
	}
}

LIB_EXPORT void yane::Utils::GridIO::writeFrameBreak ( double t )
{
	header.frames++ ;
	header.T = t;
	if ( header.t0 == INFINITY )
	{
		header.t0 = t;
	}
	updateHeader ( );

	writeData ( FB_VALUE, FB_COUNT );

	unsigned int writecounter;
	writecounter = fwrite ( & t, sizeof(double), 1, this->fp );
	if ( writecounter != 1 )
	{
		stringstream s;
		s << "error writing frame break \"" << fname << "\"";
		throw IOException ( __DEBUGMESS(s.str()) );
	}
	filesize += sizeof(double);
}

LIB_EXPORT double yane::Utils::GridIO::readFrameBreak ( )
{
	unsigned char breakvalue = 0;
	unsigned int breakcount = 0;
	unsigned int readcounter;

	readData ( & breakvalue, & breakcount );

	if ( ( breakvalue != FB_VALUE ) || ( breakcount != FB_COUNT ) )
	{
		stringstream s;
		s << "error during reading file: unexpected frame break in \"" << fname << "\"";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	double result;

	readcounter = fread ( & result, sizeof(double), 1, this->fp );
	if ( readcounter != 1 )
	{
		stringstream s;
		s << "error reading frame break in \"" << fname << "\"";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	return result;
}

LIB_EXPORT void yane::Utils::GridIO::reset ( )
{
	fseek ( fp, sizeof ( header ) + sizeof(unsigned int) * header.dimension + sizeof(double) * header.dimension * 2
	        + sizeof(char) * header.dimension * MAXCOORDNAMELENGTH, SEEK_SET );
}

LIB_EXPORT bool yane::Utils::GridIO::eof ( )
{
	return filesize == ftell ( fp );
}

LIB_EXPORT void yane::Utils::GridIO::writeData ( unsigned char value, unsigned int count )
{
	unsigned int writecounter;

	if ( ftell ( fp ) != filesize )
	{
		fseek ( fp, 0, SEEK_END );
	}

	writecounter = fwrite ( & count, sizeof(unsigned int), 1, this->fp );
	if ( writecounter != 1 )
	{
		stringstream s;
		s << "error writing file \"" << fname << "\" (err #1)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}
	filesize += sizeof(unsigned int);

	writecounter = fwrite ( & value, sizeof(unsigned char), 1, this->fp );
	if ( writecounter != 1 )
	{
		stringstream s;
		s << "error writing file \"" << fname << "\" (err #2)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	filesize += sizeof(unsigned char);
}

LIB_EXPORT void yane::Utils::GridIO::readData ( unsigned char * value, unsigned int * count )
{
	unsigned int readcounter;

	readcounter = fread ( count, sizeof(unsigned int), 1, this->fp );
	if ( readcounter != 1 )
	{
		stringstream s;
		s << "error reading file \"" << fname << "\" (err #1)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	readcounter = fread ( value, sizeof(unsigned char), 1, this->fp );
	if ( readcounter != 1 )
	{
		stringstream s;
		s << "error reading file \"" << fname << "\" (err #2)";
		throw IOException ( __DEBUGMESS(s.str()) );
	}
}

LIB_EXPORT void yane::Utils::GridIO::getGridSize ( unsigned int * gridsize )
{
	memcpy ( gridsize, this->gridsize, sizeof(unsigned int) * header.dimension );
}

LIB_EXPORT unsigned int yane::Utils::GridIO::getDimension ( )
{
	return header.dimension;
}

LIB_EXPORT void yane::Utils::GridIO::updateHeader ( )
{
	unsigned int oldpos = ftell ( fp );

	fseek ( fp, 0, SEEK_SET );

	unsigned int writecounter = 0;
	writecounter = fwrite ( & header, sizeof ( header ), 1, this->fp );
	if ( writecounter != 1 )
	{
		stringstream s;
		s << "error updating header";
		throw IOException ( __DEBUGMESS(s.str()) );
	}

	fseek ( fp, oldpos, SEEK_SET );
}

LIB_EXPORT void yane::Utils::GridIO::setCoordName ( unsigned int coord, const char * name )
{
	memset ( & coordnames [ MAXCOORDNAMELENGTH * coord ], 0, sizeof(char) * MAXCOORDNAMELENGTH );
	strncpy ( & coordnames [ MAXCOORDNAMELENGTH * coord ], name, MAXCOORDNAMELENGTH );

	unsigned int oldpos = ftell ( fp );

	fseek ( fp, sizeof ( header ) + sizeof(unsigned int) * header.dimension + sizeof(double) * header.dimension * 2,
	        SEEK_SET );

	unsigned int writecounter = 0;
	writecounter = fwrite ( coordnames, sizeof(char), header.dimension * MAXCOORDNAMELENGTH, this->fp );
	if ( writecounter != header.dimension * MAXCOORDNAMELENGTH )
	{
		stringstream s;
		s << "error updating coordnames";
		throw IOException ( __DEBUGMESS(s.str()) );
	}
	fseek ( fp, oldpos, SEEK_SET );
}

LIB_EXPORT void yane::Utils::GridIO::setTitle ( const char * name )
{
	memset ( header.title, 0, sizeof(char) * 128 );
	strncpy ( header.title, name, 128 );

	updateHeader ( );

}

LIB_EXPORT void yane::Utils::GridIO::getCoordName ( unsigned int coord, char * name )
{
	strncpy ( name, & coordnames [ coord * MAXCOORDNAMELENGTH ], MAXCOORDNAMELENGTH );
	name [ MAXCOORDNAMELENGTH ] = '\0';
}

LIB_EXPORT void yane::Utils::GridIO::getTitle ( char * name )
{
	strncpy ( name, header.title, 128 );
	name [ 128 ] = '\0';
}

LIB_EXPORT unsigned int yane::Utils::GridIO::getFrameCount ( )
{
	return header.frames;
}

LIB_EXPORT double yane::Utils::GridIO::getFirstT ( )
{
	return header.t0;
}

LIB_EXPORT double yane::Utils::GridIO::getLastT ( )
{
	return header.T;
}

LIB_EXPORT void yane::Utils::GridIO::getBounds ( double * lbound, double * ubound )
{
	memcpy ( lbound, this->lbound, sizeof(double) * header.dimension );
	memcpy ( ubound, this->ubound, sizeof(double) * header.dimension );
}

