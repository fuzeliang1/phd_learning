/***************************************************************************
 *                                                                         *
 * Interface Library for Minimization Routines                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#include "gaussnewton.h"
#include "exceptions.h"

#include "../utils.h"

#include <cstdlib>
#include <iostream>

#include "libexport.h"

using namespace std;

namespace yane
{
	namespace MinProg
	{

		extern "C"
		{
			void btgsnt_ ( int * dim_x, int * dim_a, int * l, double * a,
			double * x, double * y, double * rpar, int * ipar, T_GNFUNC f,
			T_GNFUNC df, int * usedf, double * work, int * lwork, 
			int * iterations, int * maxit, int* idid );
		}
	}
}

LIB_EXPORT yane::MinProg::GaussNewton::GaussNewton ( int dim_x, int dim_a, int dim_y, double * x, double * y, T_GNFUNC function, T_GNFUNC grad )
{
	_dimx = dim_x;
	_dima = dim_a;
	_dimy = dim_y;
	_x = x;
	_y = y;
	_f = function;
	_df = grad;

	_lwork = 3 + (3 + 2 * _dima) * _dima + (1 + _dima) * _dimy;
	_work = new double[_lwork];

	_usedf = ( grad != 0 ? 1 : 0 );
	_maxit = 100;
	_iterations = 0;
	_delta = 1E-5;
}

LIB_EXPORT yane::MinProg::GaussNewton::~ GaussNewton()
{
	delete[] _work;
}

LIB_EXPORT void yane::MinProg::GaussNewton::resize ( int dim_x, int dim_a, int dim_y )
{
	_dimy = dim_y;
	_dima = dim_a;
	_dimx = dim_x;

	delete[] _work;
	_lwork = 3 + (3 + 2 * _dima) * _dima + (1 + _dima) * _dimy;
	_work = new double[_lwork];
}

LIB_EXPORT void yane::MinProg::GaussNewton::setData ( double * x, double * y )
{
	_x = x;
	_y = y;
}

LIB_EXPORT void yane::MinProg::GaussNewton::setFunction ( T_GNFUNC function, T_GNFUNC grad )
{
	_f = function;
	_df = grad;
	_usedf = ( grad != 0 ? 1 : 0 );
}

LIB_EXPORT void yane::MinProg::GaussNewton::setMaxIterations ( int max_it )
{
	_maxit = max_it;
}

LIB_EXPORT void yane::MinProg::GaussNewton::setAccuracy ( double acc )
{
	_delta = acc;
}

LIB_EXPORT void yane::MinProg::GaussNewton::calcParams ( double * a, int datalength, double * rpar, int * ipar )
{
	if(datalength > _dimy) throw SolverError(__DEBUGMESS("invalid solver input"));

	_work[0] = _delta;
	_work[1] = 1E-8;

	btgsnt_ ( &_dimx, &_dima, &datalength, a, _x, _y, rpar, ipar, _f, _df, &_usedf, _work, &_lwork, &_iterations, &_maxit, &_did );

	if ( _did!=0 )
	{
		switch ( _did )
		{
			case -1: throw SolverError(__DEBUGMESS("invalid solver input"));
			case -2: throw SolverError(__DEBUGMESS("cholesky failed"));
			case -3: throw SolverWarning(__DEBUGMESS("too many iterations"));
			case -4: throw SolverWarning(__DEBUGMESS("unable to improve parameters"));
		}
	}
}

LIB_EXPORT int yane::MinProg::GaussNewton::iterations()
{
	return _iterations;
}

