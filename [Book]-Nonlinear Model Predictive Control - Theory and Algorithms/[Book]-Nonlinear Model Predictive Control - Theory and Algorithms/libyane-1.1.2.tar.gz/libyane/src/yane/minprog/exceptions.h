/***************************************************************************
 *                                                                         *
 * Interface Library for Minimization Routines                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MINPROG_EXCEPTIONS_H
#define YANE_MINPROG_EXCEPTIONS_H

#include "../utils/exception.h"

namespace yane
{

	namespace MinProg
	{

		/** \class MinProgException
		 \brief Exception in minimization algorithms
		*/
		class MinProgException : public yane::Utils::Exception
		{
			public:
				MinProgException ( std::string mess = "unknown exception", std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string Type;
		};

		/* \class MemoryException
		 \brief Exception if memory allocation fails
		*/
// 		class MemoryException : public MinProgException
// 		{
// 			public:
// 				MemoryException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
// 				static const std::string Type;
// 		};

		/** \class InitializingException
		 \brief Exception if initialization of SQP algorithms fails
		*/
		class InitializingException : public MinProgException
		{
			public:
				InitializingException ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string Type;
		};

		/** \class SolverError
		 \brief Minimization routine has produced an critical error
		*/
		class SolverError : public MinProgException
		{
			public:
				SolverError ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string Type;
		};

		/** \class SolverWarning
		 \brief Minimization routine has finisched with an noncritical warning
		 */
		class SolverWarning : public MinProgException
		{
			public:
				SolverWarning ( std::string debug = "no debuginfo", yane::Utils::Exception * innerex = 0 );
				static const std::string Type;
		};
	}
}

#endif

