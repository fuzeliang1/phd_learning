/***************************************************************************
 *                                                                         *
 * Interface Library for Minimization Routines                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>                     *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_MINPROG_GAUSSNEWTON_H
#define YANE_MINPROG_GAUSSNEWTON_H

#include "../minprog/typedefs.h"

namespace yane
{

	namespace MinProg
	{

		/** \class GaussNewton
		Class to solve a minimization problem using GaussNewton. Setup :
		\f{eqnarray*}{
			\mbox{Minimize} \; & \sum\limits_{i=1}^{dim\_y}(f(x_{i,1}, ..., x_{i,dim\_x}) - y_{i})^2 \\
			\mbox{Model function} \; & f(x_{1}, ..., x_{dim\_x}) = y \\
			\mbox{with parameters} \; & a_{1}, ..., a_{dim\_a} \\
			\mbox{and measurement data} \; &  (x_{i},y_{i}) \qquad 1 \le i \le dim\_y
		\f}
		Therefore x is an 1-dim array with length dim_x*dim_y, y an 1-dim array with length dim_y and a an 1-dim array with length dim_a.<br><br>
		Usually this class is used as following: <br>
		@li create GaussNewton
		@li set settings (e.g. maxIter, epsilon)
		@li calcParams
		@li delete GaussNewton
		@brief Class to solve an optimization problem using the Gauss-Newton method				
		*/
		class GaussNewton
		{
			public:
				/**
				 * @brief Constructor
				 * @param dim_x Dimension of the measurement instances
				 * @param dim_a Dimension of the modelfunction parameter
				 * @param dim_y Amount of measurement values
				 * @param x Measurement instances with dimension dim_x * dim_y
				 * @param y Measurement values with dimension dim_y
				 * @param function Model function
				 * @param grad Gradient respective a of the model function
				 */
				GaussNewton ( int dim_x, int dim_a, int dim_y, double * x, double * y, T_GNFUNC function, T_GNFUNC grad = 0 );

				/**
				 * @brief Destructor
				 */
				~GaussNewton();

				/**
				 * @brief Function to set the maximal number of iterations of a GaussNewton object
				 * @param max_it Maximal number of iterations
				 */
				virtual void setMaxIterations ( int max_it );

				/**
				 * @brief Function to initialize a GaussNewton object with data values
				 * @param x Measurement instances
				 * @param y Measurement values
				 */
				void setData ( double * x, double * y );

				/**
				 * @brief Funtion to initialize a GaussNewton object with function pointers
				 * @param function Model function
				 * @param grad Gradient of the model function
				 */
				void setFunction ( T_GNFUNC function, T_GNFUNC grad = 0 );

				/**
				 * @brief Function to set the accuracy of a GaussNewton object
				 * @param epsilon Accuracy of the minimization
				 */
				void setAccuracy ( double acc );

				/**
				 * @brief Funtion to resize the minimization problem
				 * @param dim_x	Dimension of the measurement instances
				 * @param dim_a Dimension of the modelfunction parameters
				 * @param dim_y Amount of measurement values
				 */
				void resize ( int dim_x, int dim_a, int dim_y );

				/**
				 * @brief Funtion to start the optimization
				 * @param a Optimal parameter of the fitting problem, initialized with starting values with dimension <= dim_y
				 * @param datalength Amount of measurement values
				@throw yane::MinProg::SolverError Is thrown of solver input is invalid
				@throw yane::MinProg::SolverError Is thrown if Cholesky failed
				@throw yane::MinProg::SolverWarning Is thrown if GaussNewton neede to many steps
				@throw yane::MinProg::SolverWarning Is thrown if parameter improvement is impossible
				 */
				void calcParams ( double * a, int datalength, double * rpar, int * ipar);

				/**
				 * @brief Function to obtain the number of iteration steps
				 * @return Number of executed optimization steps
				 */
				int iterations();

			private:
				int _dimx;
				int _dima;
				int _dimy;
				double * _a;
				double * _x;
				double * _y;
				T_GNFUNC _f;
				T_GNFUNC _df;
				int _usedf;
				double * _work;
				int _lwork;
				double _delta;
				int _iterations;
				int _maxit;
				int _did;
		};

	}

}

#endif
