/***************************************************************************
 *                                                                         *
 * Interface Library for Minimization Routines                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "exceptions.h"

#include "libexport.h"

LIB_EXPORT const std::string yane::MinProg::MinProgException::Type = "yane::MinProg::MinProgException";

LIB_EXPORT yane::MinProg::MinProgException::MinProgException ( std::string mess, std::string debug, yane::Utils::Exception * innerex )
		: yane::Utils::Exception ( mess, debug, innerex )
{
	addType ( Type );
}

// const std::string yane::MinProg::MemoryException::Type = "yane::MinProg::MemoryException";
// 
// yane::MinProg::MemoryException::MemoryException ( std::string debug, yane::Utils::Exception * innerex )
// 		: MinProgException ( __EXCEPTIONMESS ( Type, "Failed allocating memory" ), debug, innerex )
// {
// 	addType ( Type );
// }

LIB_EXPORT const std::string yane::MinProg::InitializingException::Type = "yane::MinProg::InitializingException";

LIB_EXPORT yane::MinProg::InitializingException::InitializingException ( std::string debug, yane::Utils::Exception * innerex )
		: MinProgException ( __EXCEPTIONMESS ( Type, "Failed initializing minimizer" ), debug, innerex )
{
	addType ( Type );
}

LIB_EXPORT const std::string yane::MinProg::SolverError::Type = "yane::MinProg::SolverError";

LIB_EXPORT yane::MinProg::SolverError::SolverError ( std::string debug, yane::Utils::Exception * innerex )
		: MinProgException ( __EXCEPTIONMESS ( Type, "Critical minimizer error" ), debug, innerex )
{
	addType ( Type );
}

LIB_EXPORT const std::string yane::MinProg::SolverWarning::Type = "yane::MinProg::SolverWarning";

LIB_EXPORT yane::MinProg::SolverWarning::SolverWarning ( std::string debug, yane::Utils::Exception * innerex )
		: MinProgException ( __EXCEPTIONMESS ( Type, "Minimizerwarning" ), debug, innerex )
{
	addType ( Type );
}
