/***************************************************************************
 *                                                                         *
 * Interface Library for Minimization Routines                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>             *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "nlp.h"
#include "exceptions.h"
#include "../utils.h"

#include <cstdlib>
#include <cmath>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::MinProg::NLP::NLP()
{
	_aborttime = INFINITY;
	func_params = 0;
	restr_params = 0;
	_clock = 0;
}

LIB_EXPORT yane::MinProg::NLP::NLP ( int n, T_FUNC func, T_FUNC rest, int nrest, int nrest_eq, T_FUNC df, T_FUNC dg )
{
	_aborttime = INFINITY;
	func_params = 0;
	restr_params = 0;
	_clock = 0;
	init ( n, func, rest, nrest, nrest_eq, df, dg );
}

LIB_EXPORT yane::MinProg::NLP::~NLP()
{
	freememory();
}

LIB_EXPORT void yane::MinProg::NLP::init ( int n, T_FUNC func, T_FUNC rest, int nrest, int nrest_eq, T_FUNC df, T_FUNC dg )
{
	freememory();

	_clock = new yane::Utils::RTClock();	// TODO (vielleicht nur reset und anlegen im construktor)
	_dimension = n;
	_dimension_resteq = nrest_eq;
	_dimension_rest = nrest;
	_function = func;
	_restrictions = rest;
	_function_diff = df;
	_restrictions_diff = dg;

	try
	{
		func_params = new T_FUNCTIONSTRUCT;
		restr_params = new T_RESTRICTIONSTRUCT;
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "func_params or restr_params could not be allocated" ) );
	}
	restr_params->active = 0;
	if ( nrest > 0 )
	{
		try
		{
			restr_params->active = new int[nrest];
		}
		catch ( std::bad_alloc )
		{
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "restr_params->active could not be allocated" ) );
		}
	}

	func_params->base = this;
	restr_params->base = this;

//  if ( !_isinit )
//  {
//   _aborttime = INFINITY;
//
//
//   func_params = ( T_FUNCTIONSTRUCT* ) malloc ( sizeof ( T_FUNCTIONSTRUCT ) );
//   try
//   {
//    memorycheck ( func_params );
//   }
//   catch ( memoryException e )
//   {
//    throw yane::Utils::MemoryException ( __DEBUGMESS ( "func_params could not be allocated" ), &e );
//   }
//
//   restr_params = ( T_RESTRICTIONSTRUCT* ) malloc ( sizeof ( T_RESTRICTIONSTRUCT ) );
//   try
//   {
//    memorycheck ( restr_params );
//   }
//   catch ( memoryException e )
//   {
//    throw yane::Utils::MemoryException ( __DEBUGMESS ( "restr_params could not be allocated" ), &e );
//   }
//   if ( nrest > 0 )
//   {
//    restr_params->active = ( int* ) malloc ( sizeof ( int ) * _dimension_rest );
//    try
//    {
//     memorycheck ( restr_params->active );
//    }
//    catch ( memoryException e )
//    {
//     throw yane::Utils::MemoryException ( __DEBUGMESS ( "restr_params->active could not be allocated" ), &e );
//    }
//   }
//   else
//   {
//    restr_params->active = 0;
//   }
//
//   func_params->base = this;
//   restr_params->base = this;
//  }
//  else
//  {
//   if ( nrest > 0 )
//   {
//    free ( restr_params->active );
//    restr_params->active = ( int* ) malloc ( sizeof ( int ) * _dimension_rest );
//    try
//    {
//     memorycheck ( restr_params->active );
//    }
//    catch ( memoryException e )
//    {
//     throw yane::Utils::MemoryException ( __DEBUGMESS ( "restr_params->active could not be allocated" ), &e );
//    }
//   }
//   else
//   {
//    restr_params->active = 0;
//   }
//  }
//
//  _isinit = true;
}

// void yane::NLP::NLP::memorycheck ( void * ptr )
// {
// 	if ( ptr == 0 )
// 	{
// 		freememory ();
// 		throw memoryException ( _DEBUGMESS ("failed allocating memory") );
// 	}
// }

void yane::MinProg::NLP::freememory()
{
	if ( _clock != 0 ) delete _clock;
	if ( func_params != 0 ) delete func_params;
	if ( restr_params != 0 )
	{
		if ( restr_params->active != 0 ) delete[] restr_params->active;
		delete restr_params;
	}
	_clock = 0;
	func_params = 0;
	restr_params = 0;
}

LIB_EXPORT void yane::MinProg::NLP::setAbortTime ( double time )
{
	_aborttime = time;
}

LIB_EXPORT double yane::MinProg::NLP::abortTime()
{
	return _aborttime;
}

