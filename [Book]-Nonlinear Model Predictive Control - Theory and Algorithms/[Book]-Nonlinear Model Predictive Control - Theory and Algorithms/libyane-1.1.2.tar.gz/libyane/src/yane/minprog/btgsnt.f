      SUBROUTINE BTGSNT(DIMX,DIMA,DIMY,A,X,Y,RPAR,IPAR,F,DF,USEDF,
     &                  WORK,LWORK,IT,MAXIT,IDID)
C
C     NUMERICAL SOLUTION OF A GAUSS-NEWTON OPTIMIZATION PROBLEM.
C     SETUP :
C     MINIMIZE | F(X) - Y |^2
C     F(X_1,...,X_DIMX) = MODELFUNCTION WITH PARAMETERS A
C     (X,Y) MEASUREMENT VALUES
C-----------------------------------------------------------------------
C 
C     INPUT PARAMETERS  
C     ----------------  
C     DIMX              DIMENSION OF THE MEASUREMENT INSTANCES
C
C     DIMA              DIMENSION OF MODEL FUNCTION PARAMETERS
C
C     DIMY              DIMENSION OF THE MEASUREMENT DATA
C
C     X(DIMX, DIMY)     MEASUREMENTS INSTANCES
C
C     A(DIMA)           MODEL FUNCTION PARAMETERS
C
C     Y(DIMY)           MEASUREMENT VALUES
C
C     F                 MODEL FUNCTION
C
C     DF                GRADIENT OF MODEL FUNCTION RESPECTIVE A
C
C     USEDF             SWITCH FOR CALLING THE SUBROUTINE DF:
C                         USEDF=0: SUBROUTINE IS NEVER CALLED
C                         USEDF=1: SUBROUTINE IS USED AS GRADIENT.
C
C     MAXIT             MAXIMAL NUMBER OF ITERATIONS
C
C-----------------------------------------------------------------------
C 
C     SOPHISTICATED SETTING OF PARAMETERS
C     -----------------------------------
C    WORK(1)  THIS IS ACCURACY OF THE MINIMIZATION
C    WORK(2)  THIS IS THE DIFFACC
C
C----------------------------------------------------------------------
C
C     OUTPUT PARAMETERS 
C     ----------------- 
C     A           OPTIMAL SOLUTION
C     IT          AMOUNT OF ITERATIONS
C
C     IDID        REPORTS ON SUCCESSFULNESS UPON RETURN:
C                   IDID=  1  COMPUTATION SUCCESSFUL,
C                   IDID= -1  INPUT IS NOT CONSISTENT,
C                   IDID= -2  CHOLESKY FAILED,
C                   IDID= -3  TOO MANY ITERATIONS
C                   IDID= -4  UNABLE TO MATCH TOL
C-----------------------------------------------------------------------
C *** *** *** *** *** *** *** *** *** *** *** *** ***
C          DECLARATIONS 
C *** *** *** *** *** *** *** *** *** *** *** *** ***
      IMPLICIT NONE
      INTEGER DIMX,DIMA,DIMY,LWORK,IT,MAXIT,IDID,IDT,IDTD,IG,IR,IB,
     &        IS,ITEMP,ISTORE,IPAR
      DOUBLE PRECISION A,X,Y,WORK,RPAR
      DIMENSION A(*),X(*),Y(*),WORK(LWORK),RPAR(*),IPAR(*)
      LOGICAL USEDF, ACH
      EXTERNAL F,DF

C ------- PREPARE THE ENTRY-POINTS FOR THE ARRAYS IN WORK -----
      IDT=3
      IDTD=IDT+DIMA*DIMY
      IG=IDTD+DIMA*DIMA
      IR=IG+DIMA*DIMA
      IB=IR+DIMY
      IS=IB+DIMA
      ITEMP=IS+DIMA

C ------ TOTAL STORAGE REQUIREMENT -----------
      ISTORE=ITEMP+DIMA
      IF(ISTORE.GT.LWORK)THEN
         WRITE(6,*) ' INSUFFICIENT STORAGE FOR WORK ',ISTORE,LWORK
         IDID=-1
         RETURN
      END IF

C ------ CHECK INPUT -----------
      IF(DIMY.LT.DIMA)THEN
         WRITE(6,*) ' NOT ENOUGH MEASUREMENT DATA'
         IDID=-1
         RETURN
      END IF

C ------ CALL CORE -----------
      CALL GNCOR(DIMX,DIMA,DIMY,A,X,Y,WORK(IDT),WORK(IDTD),WORK(IG),
     &                  WORK(IR),WORK(IB),WORK(IS),WORK(ITEMP),F,DF,
     &                  USEDF,WORK(2),WORK(1),IT,MAXIT,IDID,RPAR,IPAR)

      RETURN
      END

C  ----- ... AND HERE IS THE CORE  ----------
C
      SUBROUTINE GNCOR(DIMX,DIMA,DIMY,A,X,Y,DT,DTD,G,R,B,S,TEMP,F,DF,
     &                  USEDF,DIFFACC,DELTA,IT,MAXIT,IDID,RPAR,IPAR)
      
      IMPLICIT NONE
      INTEGER DIMX,DIMA,DIMY,IDID,I,J,K,IT,MAXIT,IPAR,ISTEP
      DOUBLE PRECISION A,X,Y,DT,DTD,DELTA,Y1,Y2,OLDA,FN,FOLD,
     &                 DIFFACC,R,B,G,S,TEMP,SIZ,RPAR,OLDSIZ
      DIMENSION A(DIMA),Y(DIMY),X(DIMX,DIMY),DT(DIMA,DIMY),
     &          DTD(DIMA,DIMA),R(DIMY),B(DIMA),G(DIMA,DIMA),
     &          S(DIMA),TEMP(DIMA),RPAR(*),IPAR(*)
      LOGICAL USEDF, ACH
      EXTERNAL F,DF,BTCHLG

      IT=0
      IDID=0
      ACH=.FALSE.
      OLDSIZ=0.0D0
      FN=1.0D10
      
C------------------------------------------------------------------
C     MAIN ITERATION
C------------------------------------------------------------------
1000  CONTINUE


C     CALCULATE TRANSPOSED JACOBIMATRIX DT
      FOLD=FN
      FN=0.0D0
      ACH=.TRUE.
      IF (USEDF) THEN
         DO 1 I=1,DIMY
            CALL DF(I,DIMX,DIMA,A,ACH,X(1,I),DT(1,I),RPAR,IPAR)
            CALL F(I,DIMX,DIMA,A,ACH,X(1,I),Y1,RPAR,IPAR)
            ACH=.FALSE.
            R(I)=Y1-Y(I)
            FN=FN+DABS(Y1)
1        CONTINUE
      ELSE
         DO 11 I=1,DIMY
            CALL F(I,DIMX,DIMA,A,ACH,X(1,I),Y1,RPAR,IPAR)
            ACH=.FALSE.
            R(I)=Y1-Y(I)
            FN=FN+Y1
11       CONTINUE
         DO 2 J=1,DIMA
            OLDA=A(J)
            A(J)=A(J)+DIFFACC
            ACH=.TRUE.
            DO 3 I=1,DIMY
               CALL F(I,DIMX,DIMA,A,ACH,X(1,I),Y2,RPAR,IPAR)
               ACH=.FALSE.
               DT(J,I)=(Y2-R(I)-Y(I))/DIFFACC
3           CONTINUE
            A(J)=OLDA
2        CONTINUE
      ENDIF

C     CALCULATE RIGHT SIDE OF LGS

      DO 4 I=1,DIMA
         B(I)=0.0D0
         DO 5 J=1,DIMY
            B(I)=B(I)+DT(I,J)*R(J)
5        CONTINUE
4     CONTINUE
      
C     CALCULATE DTD

      DO 6 I=1,DIMA
         DTD(I,I)=0.0D0
         DO 7 K=1,DIMY
            DTD(I,I)=DTD(I,I)+(DT(I,K)**2.0D0)
7        CONTINUE
         DO 8 J=I+1,DIMA
            DTD(I,J)=0.0D0
            DO 9 K=1,DIMY
               DTD(I,J)=DTD(I,J)+(DT(I,K)*DT(J,K))
9           CONTINUE
            DTD(J,I)=DTD(I,J)
8        CONTINUE
6     CONTINUE

C     SOLVE LGS -> CALCULATE S

      CALL BTCHLG(DIMA,DTD,G,B,S,TEMP,IDID)
      IF (IDID.NE.0) THEN
         WRITE(6,*) ' CHOLESKY FAILED ',IDID
         IDID=-2
         RETURN
      ENDIF

C     CALC NEXT PARAMETERVALUE

      SIZ=0.0D0
      DO 10 I=1,DIMA
         A(I)=A(I)-S(I)
         SIZ=SIZ+(S(I)**2.0D0)
10    CONTINUE
      SIZ=DSQRT(SIZ)
      
      IT=IT+1
      IF (IT.EQ.MAXIT) THEN
         WRITE(6,*) ' TOO MANY ITERATIONS ',IT
         IDID=-3
         RETURN
      END IF

      IF (FN.GT.FOLD) THEN
         WRITE(6,*) ' UNABLE TO IMPROVE PARAMETERS ',FN
         IDID=-4
         RETURN
      END IF

      IF (SIZ.LT.DELTA) RETURN
      
	GOTO 1000
      
      END
