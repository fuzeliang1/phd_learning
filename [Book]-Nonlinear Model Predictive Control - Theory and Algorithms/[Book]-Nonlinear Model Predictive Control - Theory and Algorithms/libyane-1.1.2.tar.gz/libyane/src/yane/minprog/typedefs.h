/***************************************************************************
 *                                                                         *
 * Interface Library for Minimization Routines                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MINPROG_TYPEDEFS_H
#define YANE_MINPROG_TYPEDEFS_H

namespace yane
{

	namespace MinProg
	{

		/** \typedef T_FUNC
			\brief Functionpointer to commit the values to the differential or difference equation
			\param x Vector containing the point of evaluation
			\param fx Vector containing the functionvalues after evaluation
			\param params Vector with parameters vor the function
		*/
		typedef void ( *T_FUNC ) ( const double * x, double * fx, void * params );

		/** \typedef T_GNFUNC
			\brief Functionpointer for the Gauss Newton method
			\param i GaussNewton step
			\param dim_x Dimension of the measurement instances
			\param dim_a dimension of the model function parameters
			\param a Model function parameters
			\param achanged true if a changed, otherwise false
			\param x Vector containing the point of evaluation
			\param fx Vector containing the functionvalues after evaluation
			\param rpar real-valued parameters
			\param ipar integere parameters
		 */
		typedef void ( *T_GNFUNC ) ( int * i, int * dim_x, int * dim_a, double * a, bool * achanged, double * x, double * fx, double * rpar, int * ipar );

		/** \struct T_RESTRICTIONSTRUCT
			\brief structure to commit parameters to the restrictionfunction
			\param active Indexset of activ and inactive restrictions
			\param rpar real-valued parameters
			\param ipar integere parameters
			\param base pointer to restriction
		*/
		typedef struct
		{
			int * active;
			double * rpar;
			int * ipar;
			void * base;
		} T_RESTRICTIONSTRUCT;

		/** \struct T_FUNCTIONSTRUCT
			\brief structure to commit parameters to the optimal control problem
			\param rpar real-valued parameters
			\param ipar integer parameters
			\param base pointer to function
			\param abort decision variable to stop optimization
		*/
		typedef struct
		{
			double * rpar;
			int * ipar;
			void * base;
			bool abort;
		} T_FUNCTIONSTRUCT;

		/** \enum T_MEMMODEL
		*/
		typedef enum
		{
			BYLINE,   /**< use line-by-line saving (C) */
			BYCOLUMN  /**< use column-by-column saving (FORTRAN) */
		} T_MEMMODEL;
	}
}

#endif

