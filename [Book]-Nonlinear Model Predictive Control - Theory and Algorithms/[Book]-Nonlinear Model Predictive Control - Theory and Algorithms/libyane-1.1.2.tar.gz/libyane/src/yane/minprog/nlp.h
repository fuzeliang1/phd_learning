/***************************************************************************
 *                                                                         *
 * Interface Library for Minimization Routines                             *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>             *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Bodenschatz <michael.bodenschatz@uni-bayreuth.de>
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MINPROG_H
#define YANE_MINPROG_H

#include <iostream>

#include "../minprog/typedefs.h"

namespace yane
{
	namespace Utils
	{
		class RTClock;
	}

	namespace MinProg
	{

		/** \class NLP
			Class to solve minimization problems subject to restrictions \n
			Objects of the class can be used to solve nonlinear optimization problems in standard form (NLP)
			\f{eqnarray*}{
			\mbox{Minimize} \; F(x) && \\
			\mbox{subject to} \; G(x) & = & 0 \\
			H(x) & \geq & 0
			\f}
			@brief Class to solve minimization problems subject to restrictions
		 */
		class NLP
		{
			public:

				/**
					@brief Default-constructor without any initialization
				*/
				NLP();

				/**
					@brief Constructor
					\param n Dimension of the optimization variable
					\param func Objective function
					\param rest Consrraints
					\param nrest Number of constraints (both equality and inequality constraints)
					\param nrest_eq Number of equality constraints \n
						These constraints have to be listed first within the definition of the constraints
					\param df Gradient of the objective function
					\param dg Jacobian matrix of the constraints \n
					This matrix has to be saved by-line or by-column based on the choice of the minimization-routine
				*/
				NLP ( int n, T_FUNC func, T_FUNC rest = 0, int nrest = 0, int nrest_eq = 0, T_FUNC df = 0, T_FUNC dg = 0 );

				/**
					@brief Destructor
				*/
				virtual ~NLP();

				/**
					@brief Function to initialize the minimization problem
					\param n Dimension of the optimizationvariable
					\param func Objective function
					\param rest Consrraints
					\param nrest Number of constraints (both equality and inequality constraints)
					\param nrest_eq Number of equality constraints \n
						These have to be listed first within the definition of the constraints
					\param df Gradient of the objective function
					\param dg Jacobian matrix of the constraints \n
					@throw yane::Utils::MemoryException Is thrown, if memory allocation fails
					@throw yane::Utils::Exception Is thrown, if initialization of the NLP object fails
				*/
				virtual void init ( int n, T_FUNC func, T_FUNC rest = 0, int nrest = 0, int nrest_eq = 0, T_FUNC df = 0, T_FUNC dg = 0 );

				/**
					@brief Function which solves the minimization problem
					\param x Initial guess of the optimization variable \n
						Once the algorithm terminates successfully it contains the minimizer of the objective function
					\param fx Optimal objective function value
					\param lb Lower bounds for the optimization variable
					\param ub Upper bounds for the optimization variable
					\param rpar Vector of real-valued parameters
					\param ipar Vector of integer paramaters
					@throw SolverWarning Is thrown, if optimization terminates with an noncritical error
					@throw SolverError Is thrown, if optimization terminates with a known critical error
					@throw yane::MinProg::MinProgException Is thrown, if optimization terminates with an unknown error
					@throw yane::Utils::Exception Is thrown, if evaluations could not be done
				*/
				virtual void calcMin ( double * x0, double * fx, double * lb, double * ub, double * rpar = 0, int* ipar = 0 ) = 0;

				/**
					@brief Function to specify the memorymodel (by-line or by-column)
				*/
				virtual T_MEMMODEL memoryModel() const = 0;

				/**
					@brief Function to clone the object with the current configuration
					@throw yane::Utils::MemoryException Is thrown, if memory allocation of the clone fails
					@return Pointer to the cloned NLP object
				*/
				virtual NLP * clone() = 0;

				/**
					@brief Function to set the accuracy of the optimization routine
					\param acc Accuracy of the minimization routine
					@throw InitializingException Is thrown, if acc <= 0.0
				*/
				virtual void setAccuracy ( double acc ) = 0;

				/**
					@brief Function to set the maximum number of iterations for the optimization routine
					\param num Maximal number of iterations
					@throw InitializingException Is thrown, if num <= 0
				*/
				virtual void setMaxIterations ( int num ) = 0;

				/**
					@brief Function to set abort time, after which the optimization will be stopped.
					@param time Abort time in seconds
				*/
				virtual void setAbortTime ( double time );

				/**
					@brief Function which returns the current abort time, after which the optimization would be stopped.
					@return Abort time in seconds
				*/
				virtual double abortTime();

				/**
					@brief Function which returns the Jacobian of the Restriction.
					\param jac Pointer to an array of length dimension * dimension_rest \n
						After termination of this function, jac contains the jacobian saved by-line or by-column
					@throw yane::Utils::MemoryException Is thrown, if jac is a zero-pointer
					@throw yane::Utils::Exception Is thrown, if calculation fails
				*/
				virtual void getRestrictionJacobi ( double * jac ) = 0;

				/**
					@brief Function which returns the Lagrange parameters of the nonlinear contraints regarding to the calculated optimal solution.
					\param lambda Pointer to an array of length dimension_rest, contains the Lagrange parameters
					@throw yane::Utils::MemoryException Is thrown, if lambda is a zero-pointer
				*/
				virtual void getLagrangeParameters ( double * lambda ) = 0;

				T_FUNCTIONSTRUCT * func_params;  /**< @brief Structure containing the dynamic of the system */
				T_RESTRICTIONSTRUCT * restr_params; /**< @brief Structure containing the restrictions of the system */

			protected:
				int _dimension;    /**< @brief Dimension of the optimization variable */
				int _dimension_resteq;   /**< @brief Number of equality constraints  */
				int _dimension_rest;   /**< @brief Number of constriants */

				T_FUNC _function;    /**< @brief Function pointer of the objective function */
				T_FUNC _restrictions;   /**< @brief Function pointer of the constraints */
				T_FUNC _function_diff;   /**< @brief Function pointer of the gradient of the objective function*/
				T_FUNC _restrictions_diff;   /**< @brief Function pointer of the Jacobian of the constraints */

				double _aborttime;   /**< @brief Saves the maximal allowed runtime for the optimization */
				yane::Utils::RTClock * _clock;  /**< @brief Internal clock (time measurement for aborttime) */

			private:
//    /**
//     @brief Function to check the internally allocated memory
//     \param ptr Pointer of array which needs to be checked
//     @throw memoryException Is thrown if memory allocation failed
//    */
//    void memorycheck ( void * ptr );

				/**
					@brief Function to free different variables/values
				*/
				void freememory();

//				bool _isinit;    /**< @brief Decision variable to check if problem is initialized */

		};

	}

}

#endif
