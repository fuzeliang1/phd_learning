/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "dualdecompositionmpcparallel.h"

#include "libexport.h"

LIB_EXPORT yane::MPC::DualDecompositionMPCParallel::DualDecompositionMPCParallel()
{
}

LIB_EXPORT yane::MPC::DualDecompositionMPCParallel::~DualDecompositionMPCParallel()
{
}
