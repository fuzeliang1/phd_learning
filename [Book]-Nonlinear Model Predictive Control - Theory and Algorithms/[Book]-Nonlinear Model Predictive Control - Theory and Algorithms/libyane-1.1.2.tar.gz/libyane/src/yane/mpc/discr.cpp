/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "discr.h"
#include "exceptions.h"
#include "odemanager.h"
#include "modelshootingdata.h"
#include "mpc.h"

#include "../utils.h"
#include "../minprog.h"

#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>


using namespace std;


yane::MPC::Discretization::Discretization ( OdeManager * odemanager, yane::MinProg::NLP * minimizer, yane::Model::Model * model, int horizon, ModelShootingData * shootingdata, double infty )
{
	_iscloned = false;
	_abortsuboptimalitydegree = INFINITY;

	_infty = infty;

	_odemanager = odemanager;
	_minimizer = minimizer;

	_model = model;
	_dimension_x = _model->dimensionState();
	_dimension_u = _model->dimensionControl();
	_dimension_restr = _model->restrictionSize();
	_shootingdata = shootingdata;
	_horizon = horizon;
	_sdata = 0;
	_lbound_x = 0;
	_ubound_x = 0;
	_lbound_u = 0;
	_ubound_u = 0;
	_u_zero = 0;

	if ( _odemanager == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "invalid _odemanager specified, got NULL" ) );
	}

	if ( _minimizer == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "invalid _minimizer specified, got NULL" ) );
	}

	if ( _model == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "invalid _model specified, got NULL" ) );
	}

	if ( _shootingdata != 0 )
	{
		_sdatalength = _shootingdata->shootingDataLength ( _horizon );
	}
	else
	{
		_sdatalength = 0;
	}

	try
	{

		if ( _sdatalength > 0 )
		{
			if ( _horizon < 2 )
			{
				stringstream mess;
				mess << "_horizon=" << _horizon << " does not accept _shootingdata. Horizon must be > 1 to handle this.";
				throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str().c_str() ) );
			}

			_sdata = new T_SHOOTINGDATA[_shootingdata->shootingDataLength ( _horizon ) ];
			_shootingdata->shootingDataInfo ( _horizon, _sdata );

			for ( int i = 0; i < _sdatalength; i++ )
			{
				if ( _sdata[i].horizonindex >= _horizon - 1 || _sdata[i].horizonindex <= 0 )
				{
					stringstream mess;
					mess << "invalid horizontindex of shootingnode " << i << ": got " << _sdata[i].horizonindex << ", valid values 'v' are 0 < v < " << _horizon - 1;
					throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str().c_str() ) );
				}

				if ( _sdata[i].varindex >= _model->dimensionState() || _sdata[i].varindex < 0 )
				{
					stringstream mess;
					mess << "invalid varindex of shootingnode " << i << ": got " << _sdata[i].varindex << ", valid values 'v' are 0 <= v < " << _model->dimensionState();
					throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str().c_str() ) );
				}
			}
		}
		else
		{
			_sdata = 0;
		}

		_lbound_x = new double [ _model->dimensionState() ];
		_ubound_x = new double [ _model->dimensionState() ];

		_lbound_u = new double [ _dimension_u * _horizon + _sdatalength];
		_ubound_u = new double [ _dimension_u * _horizon + _sdatalength];

		_u_zero = new double [ _dimension_u ];
	}
	catch ( std::bad_alloc )
	{
		if ( _sdata != 0 )
		{
			delete[] _sdata;
			_sdata = 0;
		}
		if ( _lbound_x != 0 )
		{
			delete[] _lbound_x;
			_lbound_x = 0;
		}
		if ( _ubound_x != 0 )
		{
			delete[] _ubound_x;
			_ubound_x = 0;
		}
		if ( _lbound_u != 0 )
		{
			delete[] _lbound_u;
			_lbound_u = 0;
		}
		if ( _ubound_u != 0 )
		{
			delete[] _ubound_u;
			_ubound_u = 0;
		}
		if ( _u_zero != 0 )
		{
			delete[] _u_zero;
			_u_zero = 0;
		}

		throw yane::Utils::MemoryException ( __DEBUGMESS ( "allocation of bounds or _sdata failed" ) );
	}

	_model->getModelBounds ( _lbound_x, _ubound_x );

	for ( int i = 0; i < _horizon; i++ )
	{
		_model->getControlBounds ( &_lbound_u[i * _dimension_u], &_ubound_u[i * _dimension_u] );
	}
	for ( int i = 0; i < _sdatalength; i++ )
	{
		_lbound_u[_horizon * _dimension_u + i] = -_infty;
		_ubound_u[_horizon * _dimension_u + i] = _infty;
	}

	for ( int i = 0; i < _dimension_u; i++ )
	{
		_u_zero[i] = 0.0;
	}

	_memmodel = _minimizer->memoryModel();

	_totalRestrictionNumber = ( _horizon * _dimension_restr ) + ( _horizon * 2 * _dimension_x ) + _sdatalength;

	for ( int i = 0; i < _dimension_x; i++ )
	{
		if ( _lbound_x[i] <= -_infty )
		{
			_totalRestrictionNumber -= _horizon;
		}
		if ( _ubound_x[i] >= _infty )
		{
			_totalRestrictionNumber -= _horizon;
		}
	}

	try
	{
		_odemanager->setFunctions ( _horizon, _totalRestrictionNumber, _model, restriction, _sdatalength, _sdata );
		_odemanager->setAuxilliaryObjects ( this );
	}
	catch ( yane::Utils::MemoryException e )
	{
		throw yane::MinProg::MinProgException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Odemanager could not be initialized" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Odemanager could not be initialized" ), &e );
	}

	try
	{
		_minimizer->init ( _dimension_u * _horizon + _sdatalength, min_func, min_restr, _totalRestrictionNumber, _sdatalength, min_func_grad, min_restr_grad );
	}
	catch ( yane::MinProg::MinProgException e )
	{
		throw yane::MinProg::MinProgException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Minimizer could not be initialized" ), &e );
	}
}

yane::MPC::Discretization::~Discretization()
{
	if ( _iscloned )
	{
		delete _minimizer;
		delete _odemanager;
	}
	if ( _sdata != 0 )
	{
		delete[] _sdata;
		_sdata = 0;
	}
	if ( _lbound_x != 0 )
	{
		delete[] _lbound_x;
		_lbound_x = 0;
	}
	if ( _ubound_x != 0 )
	{
		delete[] _ubound_x;
		_ubound_x = 0;
	}
	if ( _lbound_u != 0 )
	{
		delete[] _lbound_u;
		_lbound_u = 0;
	}
	if ( _ubound_u != 0 )
	{
		delete[] _ubound_u;
		_ubound_u = 0;
	}
	if ( _u_zero != 0 )
	{
		delete[] _u_zero;
		_u_zero = 0;
	}
}

void yane::MPC::Discretization::restriction ( double * t, double * x, double * u, double * fx, void * discretizationptr, void * configurationptr )
{
	Discretization * discretization = ( Discretization * ) discretizationptr;
	int dimx = discretization->dimension_x();
	int dimu = discretization->dimension_u();
	int horizon = discretization->horizon();
	int dimension_restr = discretization->dimension_restr();
	int sdatalength = discretization->sdatalength();
	double infty = discretization->infty();
	yane::Model::Model * model = discretization->model();
	for ( int i = 0; i < sdatalength; i++ )
	{
		fx[i] = u[horizon * dimu + i] - x[ dimx * discretization->sdata()[i].horizonindex + discretization->sdata()[i].varindex];
	}

	int index = horizon * dimension_restr + sdatalength;

	for ( int h = 0; h < horizon - 1; h++ )
	{
		if ( dimension_restr > 0 )
		{
			model->restrictionFunction ( t[ h + 1 ], &x[ h * dimx ], &u[ h * dimu ], &fx[ h * dimension_restr + sdatalength ] );
		}
		for ( int i = 0; i < dimx; i++ )
		{
			if ( discretization->lbound_x()[i] > -infty )
			{
				fx[index] = x[ ( h * dimx ) + i ] - discretization->lbound_x()[i];
				index++;
			}
			if ( discretization->ubound_x()[i] < infty )
			{
				fx[index] = -x[ ( h * dimx ) + i ] + discretization->ubound_x()[i];
				index++;
			}
		}
	}
	if ( dimension_restr > 0 )
	{
		model->restrictionFunction ( t[ horizon ], &x[ ( horizon - 1 ) *dimx], discretization->u_zero(), &fx[ ( horizon - 1 ) * dimension_restr + sdatalength ] );
	}
	for ( int i = 0; i < dimx; i++ )
	{
		if ( discretization->lbound_x()[i] > -infty )
		{
			fx[index] = x[ ( ( horizon - 1 ) * dimx ) + i ] - discretization->lbound_x()[i];
			index++;
		}
		if ( discretization->ubound_x()[i] < infty )
		{
			fx[index] = -x[ ( ( horizon - 1 ) * dimx ) + i ] + discretization->ubound_x()[i];
			index++;
		}
	}
}

void yane::MPC::Discretization::min_func ( const double * x, double * fx, void * params )
{
	yane::MinProg::T_FUNCTIONSTRUCT * data = ( yane::MinProg::T_FUNCTIONSTRUCT* ) params;
	Discretization * discretization = ( Discretization * ) data->rpar;

	try
	{
		discretization->_odemanager->calcObjectiveFunction ( discretization->_timesteps, discretization->_currentx, ( double * ) x, fx );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Differential equation solver caused an error" ), &e );
	}

	if ( !data->abort && discretization->abortSuboptimalityDegree() < INFINITY )
	{
		data->abort = discretization->suboptimalityCheck ( fx[0] );
	}
}

void yane::MPC::Discretization::min_restr ( const double * x, double * fx, void * params )
{
	yane::MinProg::T_RESTRICTIONSTRUCT * data = ( yane::MinProg::T_RESTRICTIONSTRUCT* ) params;
	Discretization * discretization = ( Discretization * ) data->rpar;

	try
	{
		discretization->_odemanager->calcRestrFunction ( discretization->_timesteps, discretization->_currentx, ( double * ) x, fx );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Differential equation solver caused an error" ), &e );
	}
}

void yane::MPC::Discretization::min_func_grad ( const double * x, double * fx, void * params )
{
	yane::MinProg::T_FUNCTIONSTRUCT * data = ( yane::MinProg::T_FUNCTIONSTRUCT* ) params;
	Discretization * discretization = ( Discretization * ) data->rpar;

	try
	{
		discretization->_odemanager->calcObjectiveFunctionGrad ( discretization->_timesteps, discretization->_currentx, ( double * ) x, fx );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Differential equation solver caused an error" ), &e );
	}
}

void yane::MPC::Discretization::min_restr_grad ( const double * x, double * fx, void * params )
{
	yane::MinProg::T_RESTRICTIONSTRUCT * data = ( yane::MinProg::T_RESTRICTIONSTRUCT* ) params;
	Discretization * discretization = ( Discretization * ) data->rpar;

	try
	{
		discretization->_odemanager->calcRestrFunctionGrad ( discretization->_timesteps, discretization->_currentx, ( double * ) x, fx, discretization->_memmodel,  data->active );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Differential equation solver caused an error" ), &e );
	}
}

void yane::MPC::Discretization::initCalc ( double * t, double * u0 )
{
	this->_timesteps = t;
	_u = u0;
}


void yane::MPC::Discretization::calc ( double * x, int realtimesteps, double aborttimeoffset )
{
	if ( realtimesteps < 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "positive value for realtimesteps expected" ) );
	}
	if ( realtimesteps > 0 )
	{
		if ( realtimesteps > _horizon )
		{
			throw yane::Utils::ValueException ( __DEBUGMESS ( "realtimesteps must be smaller or equal to horizonlength" ) );
		}
		if ( _timesteps[realtimesteps] - _timesteps[0] + aborttimeoffset <= 0.0 )
		{
			throw yane::Utils::ValueException ( __DEBUGMESS ( "aborttimeoffset shifts aborttime to a negative value" ) );
		}
	}
	double fx;

	_currentx = x;

	try
	{
		_minimizer->setAbortTime ( realtimesteps > 0 ? ( _timesteps[realtimesteps] - _timesteps[0] + aborttimeoffset ) : INFINITY );
		_minimizer->calcMin ( _u, &fx, _lbound_u, _ubound_u, ( double * ) this );
	}
	catch ( yane::MinProg::SolverWarning e )
	{
		throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Optimization problem could not be solved" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Differential equation solver caused a problem" ), &e );
	}
}

yane::MPC::Discretization * yane::MPC::Discretization::clone ( int horizon )
{
	try
	{
		OdeManager * odemanagerclone = _odemanager->clone();

		yane::MinProg::NLP * minimizerclone = _minimizer->clone();

		Discretization * result = new Discretization ( odemanagerclone, minimizerclone, _model, ( horizon == -1 ? _horizon : horizon ), _shootingdata, _infty );

		result->_iscloned = true;

		return result;
	}
	catch ( yane::MinProg::MinProgException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cloning the optimization problem failed" ), &e );;
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cloning the optimization problem failed" ), &e );;
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "Cloning the optimization problem failed due to allocation error" ) );
	}
}

yane::MPC::OdeManager * yane::MPC::Discretization::odeManager()
{
	return _odemanager;
}

yane::MinProg::NLP * yane::MPC::Discretization::minimizer()
{
	return _minimizer;
}

int yane::MPC::Discretization::horizon()
{
	return _horizon;
}

bool yane::MPC::Discretization::suboptimalityCheck ( double currentcostfunctionvalue )
{
	if ( ( ( _previouscostfunctionvalue - currentcostfunctionvalue ) / _previousrunningcostvalue ) > _abortsuboptimalitydegree && _abortsuboptimalitydegree < INFINITY )
	{
		return true;
	}
	else
	{
		return false;
	}
}

void yane::MPC::Discretization::setAbortSuboptimalityCriterionValues ( double abortsuboptimalitydegree, double previouscostfunctionvalue, double previousrunningcostvalue )
{
	_abortsuboptimalitydegree = abortsuboptimalitydegree;
	_previouscostfunctionvalue = previouscostfunctionvalue;
	_previousrunningcostvalue = previousrunningcostvalue;
}

double yane::MPC::Discretization::abortSuboptimalityDegree ( void )
{
	return _abortsuboptimalitydegree;
}

int yane::MPC::Discretization::totalRestrictionNumber()
{
	return _totalRestrictionNumber;
}

yane::MPC::OdeManager * yane::MPC::Discretization::odemanager()
{
	return _odemanager;
}

yane::MPC::T_SHOOTINGDATA * yane::MPC::Discretization::sdata()
{
	return _sdata;
}

int yane::MPC::Discretization::sdatalength()
{
	return _sdatalength;
}

yane::Model::Model * yane::MPC::Discretization::model()
{
	return _model;
}

int yane::MPC::Discretization::dimension_u()
{
	return _dimension_u;
}

int yane::MPC::Discretization::dimension_x()
{
	return _dimension_x;
}

int yane::MPC::Discretization::dimension_restr()
{
	return _dimension_restr;
}

double yane::MPC::Discretization::infty()
{
	return _infty;
}

double * yane::MPC::Discretization::lbound_x()
{
	return _lbound_x;
}

double * yane::MPC::Discretization::ubound_x()
{
	return _ubound_x;
}

double * yane::MPC::Discretization::lbound_u()
{
	return _lbound_u;
}

double * yane::MPC::Discretization::ubound_u()
{
	return _ubound_u;
}

double * yane::MPC::Discretization::u_zero()
{
	return _u_zero;
}

double * yane::MPC::Discretization::currentx()
{
	return _currentx;
}

double * yane::MPC::Discretization::timesteps()
{
	return _timesteps;
}
