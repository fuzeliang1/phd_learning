/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "networkedmpcconfig.h"
#include "exceptions.h"
#include "discr.h"

#include "../utils.h"
#include "../model/model.h"

#include <iostream>
#include <cstring>
#include <algorithm>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::MPC::NetworkedMPCConfig::NetworkedMPCConfig()
{
	_setting_uuid = new yane::Utils::Uuid();
	_displaywarnings = false;

	_inputNeighbours.clear();
	_outputNeighbours.clear();

	_inputNeighbourTimesteps.clear();
	_inputNeighbourState.clear();
	_inputNeighbourControl.clear();
}

LIB_EXPORT yane::MPC::NetworkedMPCConfig::~NetworkedMPCConfig()
{
	delete _setting_uuid;

	_inputNeighbours.clear();
	_outputNeighbours.clear();

	int networksize = _inputNeighbours.size();
	for ( int i = 0; i < networksize; i++ )
	{
		_inputNeighbourTimesteps[i].clear();
		_inputNeighbourState[i].clear();
		_inputNeighbourControl[i].clear();
	}
	_inputNeighbourTimesteps.clear();
	_inputNeighbourState.clear();
	_inputNeighbourControl.clear();
}

LIB_EXPORT yane::Utils::Uuid * yane::MPC::NetworkedMPCConfig::configID()
{
	return _setting_uuid;
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::setMPCPointer(MPC * mpc)
{
	_mpc = mpc;
}

LIB_EXPORT yane::MPC::MPC * yane::MPC::NetworkedMPCConfig::mpc()
{
	return _mpc;
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::addInputNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		addInputNeighbour ( neighbour->configID(), neighbour->mpc()->model()->dimensionState(), neighbour->mpc()->model()->dimensionControl(), neighbour->mpc()->horizon(), neighbour->mpc()->precedesteps() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::addInputNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps )
{
	if ( _mpc->problem() != 0 )
	{
		if ( _mpc->horizon() != horizon )
		{
			if ( _displaywarnings )
			{
				throw yane::MPC::NetworkedMPCConfigWarning ( __DEBUGMESS ( "MPC controlled systems exhibit different control horizons" ) );
			}
		}
		bool insert = true;
		if ( _setting_uuid == uuid )
		{
			insert = false;
			if ( _displaywarnings )
			{
				throw yane::MPC::NetworkedMPCConfigWarning ( __DEBUGMESS ( "MPC controlled system cannot be added as its own neighbour" ) );
			}
		}
		for ( int i = 0; i < _inputNeighbours.size(); i++ )
		{
			if ( _inputNeighbours[i].uuid == uuid )
			{
				insert = false;
				if ( _displaywarnings )
				{
					throw yane::MPC::NetworkedMPCConfigWarning ( __DEBUGMESS ( "MPC controlled system already in neighbouring list, not adding" ) );
				}
			}
		}
		if ( insert )
		{
			T_NETWORKINPUTMPCDATA newneighbour;
			newneighbour.uuid = uuid;
			newneighbour.outdated = true;
			newneighbour.dimensionState = dimensionState;
			newneighbour.dimensionControl = dimensionControl;
			newneighbour.horizon = horizon;
			newneighbour.precedesteps = precedesteps;
			_inputNeighbours.push_back ( newneighbour );

			_inputNeighbourTimesteps.resize ( _inputNeighbourTimesteps.size() + 1 );
			_inputNeighbourTimesteps[ _inputNeighbourTimesteps.size() - 1].resize ( precedesteps + horizon + 1 );
			_inputNeighbourState.resize ( _inputNeighbourState.size() + 1 );
			_inputNeighbourState[ _inputNeighbourState.size() - 1].resize ( ( precedesteps + horizon + 1 ) * dimensionState );
			_inputNeighbourControl.resize ( _inputNeighbourControl.size() + 1 );
			_inputNeighbourControl[ _inputNeighbourControl.size() - 1].resize ( ( precedesteps + horizon + 1 ) * dimensionControl );

			_resetDiscretizationRequired = true;
		}
	}
	else
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "MPC object must be initialized, call the reset() method before this one." ) );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::removeInputNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		removeInputNeighbour ( neighbour->configID() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::removeInputNeighbour(yane::Utils::Uuid * uuid)
{
	if ( _mpc->problem() != 0 )
	{
		bool remove = false;
		int counter = 0;
		int networksize = _inputNeighbours.size();
		while ( !remove && counter < networksize )
		{
			if ( _inputNeighbours[counter].uuid == uuid )
			{
				remove = true;
				_inputNeighbours.erase ( _inputNeighbours.begin() + counter );

				_inputNeighbourTimesteps.erase ( _inputNeighbourTimesteps.begin() + counter );
				_inputNeighbourState.erase ( _inputNeighbourState.begin() + counter );
				_inputNeighbourControl.erase ( _inputNeighbourControl.begin() + counter );

				_resetDiscretizationRequired = true;
			}
			counter++;
		}
		if ( !remove && _displaywarnings )
		{
			throw yane::MPC::NetworkedMPCConfigWarning ( __DEBUGMESS ( "MPC controlled system to be deleted is not contained in local list" ) );
		}
	}
	else
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "MPC object must be initialized, call the reset() method before this one." ) );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::listOfInputNeighbours()
{
	for ( int i = 0; i < _inputNeighbours.size(); i++ )
	{
		cout << _inputNeighbours[i].uuid->toString() << endl;
	}
}

LIB_EXPORT int yane::MPC::NetworkedMPCConfig::numberOfInputNeighbours()
{
	return _inputNeighbours.size();
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::addOutputNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		addOutputNeighbour ( neighbour->configID() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding output neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::addOutputNeighbour ( yane::Utils::Uuid * uuid )
{
	if ( _mpc->problem() != 0 )
	{
		bool insert = true;
		if ( _setting_uuid == uuid )
		{
			insert = false;
			if ( _displaywarnings )
			{
				throw yane::MPC::NetworkedMPCConfigWarning ( __DEBUGMESS ( "MPC controlled system cannot be added as its own neighbour" ) );
			}
		}
		for ( int i = 0; i < _outputNeighbours.size(); i++ )
		{
			if ( _outputNeighbours[i].uuid == uuid )
			{
				insert = false;
				if ( _displaywarnings )
				{
					throw yane::MPC::NetworkedMPCConfigWarning ( __DEBUGMESS ( "MPC controlled system already in neighbouring list, not adding" ) );
				}
			}
		}
		if ( insert )
		{
			T_NETWORKOUTPUTMPCDATA newneighbour;
			newneighbour.uuid = uuid;
			newneighbour.outdated = true;
			_outputNeighbours.push_back ( newneighbour );
		}
	}
	else
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "MPC object must be initialized, call the reset() method before this one." ) );
	}

}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::removeOutputNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		removeOutputNeighbour ( neighbour->configID() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding output neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::removeOutputNeighbour(yane::Utils::Uuid * uuid)
{
	if ( _mpc->problem() != 0 )
	{
		bool remove = false;
		int counter = 0;
		int networksize = _outputNeighbours.size();
		while ( !remove && counter < networksize )
		{
			if ( _outputNeighbours[counter].uuid == uuid )
			{
				remove = true;
				_outputNeighbours.erase ( _outputNeighbours.begin() + counter );
			}
			counter++;
		}
		if ( !remove && _displaywarnings )
		{
			throw yane::MPC::NetworkedMPCConfigWarning ( __DEBUGMESS ( "MPC controlled system to be deleted is not contained in local list" ) );
		}
	}
	else
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the reset() method before this one." ) );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::listOfOutputNeighbours()
{
	for ( int i = 0; i < _outputNeighbours.size(); i++ )
	{
		cout << _outputNeighbours[i].uuid->toString() << endl;
	}
}

LIB_EXPORT int yane::MPC::NetworkedMPCConfig::numberOfOutputNeighbours()
{
	return _outputNeighbours.size();
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::addNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		addNeighbour ( neighbour->configID(), neighbour->mpc()->model()->dimensionState(), neighbour->mpc()->model()->dimensionControl(), neighbour->mpc()->horizon(), neighbour->mpc()->precedesteps() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::addNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps )
{
	try
	{
		addInputNeighbour ( uuid, dimensionState, dimensionControl, horizon, precedesteps );
		addOutputNeighbour ( uuid );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::removeNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		removeNeighbour ( neighbour->configID() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::removeNeighbour(yane::Utils::Uuid * uuid)
{
	try
	{
		removeInputNeighbour ( uuid );
		removeOutputNeighbour ( uuid );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::setDisplaywarnings(bool displaywarnings)
{
	_displaywarnings = displaywarnings;
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::outdateAllNeighbours()
{
	outdateAllInputNeighbours();
	outdateAllOutputNeighbours();
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::outdateAllInputNeighbours()
{
	for ( int i = 0; i < _inputNeighbours.size(); i++ )
	{
		_inputNeighbours[i].outdated = true;
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::outdateAllOutputNeighbours()
{
	for ( int i = 0; i < _outputNeighbours.size(); i++ )
	{
		_outputNeighbours[i].outdated = true;
	}
}

LIB_EXPORT void yane::MPC::NetworkedMPCConfig::setResetDiscretization(bool resetDiscretization)
{
	_resetDiscretizationRequired = resetDiscretization;
}
