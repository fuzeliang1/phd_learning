/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "multithreadcacheodemanager.h"
#include "cache.h"
#include "asynccachecalculator.h"
#include "exceptions.h"

#include "../utils.h"
#include "../odesolve.h"

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iomanip>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::MPC::MultiThreadCacheOdeManager::MultiThreadCacheOdeManager(int threadcount_par)
{
	_dgl = 0;
	_model = 0;
	_mass = 0;
	_cache = 0;
	_cachecalc = 0;

	_weightcf = 0.0;
	_weightint = 1.0;

	_horizon = -1;

	_threadcount = threadcount_par;

	_abort = false;

	_jacthreads = new pthread_t[_threadcount];
	_jacthread_attrs = new pthread_attr_t[_threadcount];
	_jacthread_lockers = new pthread_mutex_t[_threadcount];
	_jacthread_conds = new pthread_cond_t[_threadcount];
	_jacthread_running = new bool[_threadcount];

	_gradthreads = new pthread_t[_threadcount];
	_gradthread_attrs = new pthread_attr_t[_threadcount];
	_gradthread_lockers = new pthread_mutex_t[_threadcount];
	_gradthread_conds = new pthread_cond_t[_threadcount];
	_gradthread_running = new bool[_threadcount];

	_cachecalc = new ASyncCacheCalculator*[_threadcount];
	_threaddata = new T_THREADDATA[_threadcount];
	_scheduler = new vector<int>[_threadcount];

	for (int i=0; i<_threadcount; i++)
	{
		_threaddata[i].threadidx = i;
		_threaddata[i].base = this;

		pthread_attr_init ( &_jacthread_attrs[i] );
		pthread_attr_setdetachstate ( &_jacthread_attrs[i], PTHREAD_CREATE_JOINABLE );
		pthread_mutex_init ( &_jacthread_lockers[i], NULL );
		pthread_cond_init ( &_jacthread_conds[i], NULL );

		pthread_attr_init ( &_gradthread_attrs[i] );
		pthread_attr_setdetachstate ( &_gradthread_attrs[i], PTHREAD_CREATE_JOINABLE );
		pthread_mutex_init ( &_gradthread_lockers[i], NULL );
		pthread_cond_init ( &_gradthread_conds[i], NULL );

		_cachecalc[i] = 0;
	}

	for (int i=0; i<_threadcount; i++)
	{
		pthread_create ( &_jacthreads[i], &_jacthread_attrs[i], jacThreadWorker, &_threaddata[i] );
	}

	for (int i=0; i<_threadcount; i++)
	{
		pthread_create ( &_gradthreads[i], &_gradthread_attrs[i], gradThreadWorker, &_threaddata[i] );
	}

}

void yane::MPC::MultiThreadCacheOdeManager::freeFunctionMem()
{
	if ( _dgl != 0 ) delete _dgl;
	if ( _cache != 0 ) delete _cache;
	for (int i=0; i<_threadcount; i++)
	{
		if ( _cachecalc[i] != 0 ) delete _cachecalc[i];
		_cachecalc[i] = 0;
	}
	if ( _mass != 0 ) delete _mass;

	_dgl = 0;
	_cache = 0;
	_mass = 0;
}

LIB_EXPORT yane::MPC::MultiThreadCacheOdeManager::~ MultiThreadCacheOdeManager()
{
	_abort = true;
	for (int i=0; i<_threadcount; i++)
	{
		pthread_mutex_lock( & _gradthread_lockers[i] );
		pthread_cond_signal ( & _gradthread_conds[i] );
		pthread_mutex_unlock( & _gradthread_lockers[i] );

		pthread_mutex_lock( & _jacthread_lockers[i] );
		pthread_cond_signal ( & _jacthread_conds[i] );
		pthread_mutex_unlock( & _jacthread_lockers[i] );
	}

	void * status;

	for (int i=0; i<_threadcount; i++)
	{
		pthread_join ( _jacthreads[i], &status );
		pthread_join ( _gradthreads[i], &status );

		pthread_mutex_destroy(&_gradthread_lockers[i]);
		pthread_cond_destroy(&_gradthread_conds[i]);
		pthread_mutex_destroy(&_jacthread_lockers[i]);
		pthread_cond_destroy(&_jacthread_conds[i]);
	}

	freeFunctionMem();

	delete _jacthreads;
	delete _jacthread_attrs;
	delete _jacthread_lockers;
	delete _jacthread_conds;

	delete _gradthreads;
	delete _gradthread_attrs;
	delete _gradthread_lockers;
	delete _gradthread_conds;

	delete _threaddata;
	delete _cachecalc;
	delete[] _scheduler;
}

LIB_EXPORT void yane::MPC::MultiThreadCacheOdeManager::setFunctions ( int horizon_par, int total_restr,  yane::Model::Model * _model_par, T_DISCRRESTRFUNC restrfunc, int sdatalength_par, T_SHOOTINGDATA * sdata_par )
{
	freeFunctionMem();

	double * tempmass = 0;

	_model = _model_par;
	_dimension = _model->dimensionState();
	_dimension_u = _model->dimensionControl();

	_horizon = horizon_par;
	_dim_restr = total_restr;

	_sdata = sdata_par;
	_sdatalength = sdatalength_par;

	freeFunctionMem();

	try
	{
		_dgl = new yane::OdeSolve::OdeFunction ( combinedOdeSystem, _dimension + 1 );
		tempmass = new double[_dimension*_dimension];

		try
		{
			_model->massMatrix ( tempmass );

			_mass = new double [ ( _dimension + 1 ) * ( _dimension + 1 ) ];

			memset ( _mass, 0, sizeof ( double ) * ( _dimension + 1 ) * ( _dimension + 1 ) );
			_mass[(_dimension + 1) * (_dimension + 1) - 1] = 1.0;
			for ( int i = 0; i < _dimension; i++ )
			{
				memcpy(&_mass[i*(_dimension+1)], &tempmass[i*_dimension], sizeof(double)*_dimension);
			}
			_dgl->setMassMatrix ( combinedMassMatrix );
		}
		catch ( yane::Model::UndefinedException ) { }

		delete tempmass;

		_cache = new Cache(_horizon, _model, _sdata, _sdatalength, Cache::ASYNCMODE, _threadcount);
		for (int i=0; i<_threadcount; i++)
		{
			_cachecalc[i] = new ASyncCacheCalculator(this, _cache, _dgl, _dim_restr, restrfunc);
			_threaddata[i].cachecalc = _cachecalc[i];
		}

	}
	catch (std::bad_alloc)
	{
		if (tempmass != 0) delete tempmass;

		freeFunctionMem();

		throw yane::Utils::MemoryException( __DEBUGMESS( "failed allocating memory" ));
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Reset of the ode solver failed" ), &e );
	}

	_model->getObjectiveWeight ( _weightint, _weightcf );

	// Threadaufgaben verteilen
	for (int i=0; i<_threadcount; i++)
	{
		_scheduler[i].clear();
	}

	int horizindex = _horizon*_dimension_u-1;
	int sdataindex = _sdatalength-1;
	int threadidx = 0;

	int calcsteps[_threadcount];

	for (int i=0; i<_threadcount; i++)
	{
		calcsteps[i] = 0;
	}

	//TODO: Aufteilung optimieren: thread mit wenigsten Aufgaben bekommt aufgabe, nicht einfach nur durchiterieren
	while (horizindex>=0 && sdataindex >=0)
	{
		if (horizindex/_dimension_u > _sdata[sdataindex].horizonindex -1)
		{
			_scheduler[threadidx].push_back(horizindex);
			calcsteps[threadidx] += horizindex;
			horizindex--;
		} else
		{
			_scheduler[threadidx].push_back(_horizon*_dimension_u + sdataindex);
			calcsteps[threadidx] += _sdata[sdataindex].horizonindex -1;
			sdataindex--;
		}

		for (int i=0; i<_threadcount; i++)
		{
			if (calcsteps[i] < calcsteps[threadidx]) threadidx = i;
		}
	}

	while (sdataindex >= 0)
	{
		_scheduler[threadidx].push_back(_horizon*_dimension_u + sdataindex);
		calcsteps[threadidx] += _sdata[sdataindex].horizonindex -1;
		sdataindex--;

		for (int i=0; i<_threadcount; i++)
		{
			if (calcsteps[i] < calcsteps[threadidx]) threadidx = i;
		}
	}

	while (horizindex >= 0)
	{
		_scheduler[threadidx].push_back(horizindex);
		calcsteps[threadidx] += horizindex;
		horizindex--;

		for (int i=0; i<_threadcount; i++)
		{
			if (calcsteps[i] < calcsteps[threadidx]) threadidx = i;
		}
	}
}

void yane::MPC::MultiThreadCacheOdeManager::combinedOdeSystem ( int * n, double * t, double * y, double * dy, double * rpar, int * ipar )
{
	T_MPCDATA * data = ( T_MPCDATA* ) rpar;
	MultiThreadCacheOdeManager * baseobject = ( MultiThreadCacheOdeManager* ) data->odemanager;

	baseobject->_model->odeFunction ( *t, y, data->u, dy );
	dy[baseobject->_dimension] = baseobject->_model->continuousCostfunction ( *t, y, data->u );
}

void yane::MPC::MultiThreadCacheOdeManager::combinedMassMatrix ( int * n, double * M, int * lmas, double * rpar, int * ipar )
{
	T_MPCDATA * data = ( T_MPCDATA* ) rpar;
	MultiThreadCacheOdeManager * baseobject = ( MultiThreadCacheOdeManager* ) data->odemanager;

	memcpy(M, baseobject->_mass, sizeof ( double ) * ( baseobject->_dimension + 1 ) * ( baseobject->_dimension + 1 ) );
}

LIB_EXPORT void yane::MPC::MultiThreadCacheOdeManager::setAuxilliaryObjects ( void * discretization, void * configuration )
{
	_discretization = discretization;
	_configuration = configuration;
}

void * yane::MPC::MultiThreadCacheOdeManager::jacThreadWorker(void * arg)
{
	T_THREADDATA * data = (T_THREADDATA *)arg;
	MultiThreadCacheOdeManager * base = data->base;

	pthread_mutex_lock( &base->_jacthread_lockers[data->threadidx] );

	while (true)
	{
		base->_jacthread_running[data->threadidx] = false;
		pthread_cond_wait ( & base->_jacthread_conds[data->threadidx], &base->_jacthread_lockers[data->threadidx] );

		if (base->_abort) break;

		try
		{
			bool first = true;
			for (vector<int>::iterator it = base->_scheduler[data->threadidx].begin(); it != base->_scheduler[data->threadidx].end(); it++)
			{
				data->cachecalc->restrJacobi(data->fx, *it, data->discretization, data->memmodel, data->needc, first, data->configuration, data->threadidx);
				first = false;
			}
			data->result = 0;

			pthread_cond_signal ( &base->_jacthread_conds[data->threadidx] );
		}
		catch (yane::Utils::Exception e)
		{
			cout << e.what() << endl;
			data->result = 1;
			break;
		}

	}

	base->_jacthread_running[data->threadidx] = false;
	pthread_cond_signal ( &base->_jacthread_conds[data->threadidx] );

	pthread_mutex_unlock( &base->_jacthread_lockers[data->threadidx] );

	pthread_exit ( NULL );
}

void * yane::MPC::MultiThreadCacheOdeManager::gradThreadWorker(void * arg)
{
	T_THREADDATA * data = (T_THREADDATA *)arg;
	MultiThreadCacheOdeManager * base = data->base;

	pthread_mutex_lock( &base->_gradthread_lockers[data->threadidx] );

	while (true)
	{
		base->_gradthread_running[data->threadidx] = false;
		pthread_cond_wait ( & base->_gradthread_conds[data->threadidx], &base->_gradthread_lockers[data->threadidx] );

		if (base->_abort) break;

		try
		{
			for (vector<int>::iterator it = base->_scheduler[data->threadidx].begin(); it != base->_scheduler[data->threadidx].end(); it++)
			{
				data->cachecalc->objGradient(data->fx, *it, data->threadidx);
			}
			data->result = 0;
			pthread_cond_signal ( &base->_gradthread_conds[data->threadidx] );
		}
		catch (yane::Utils::Exception e)
		{
			cout << e.what() << endl;
			data->result = 1;
			break;
		}

	}

	base->_gradthread_running[data->threadidx] = false;

	pthread_cond_signal ( &base->_gradthread_conds[data->threadidx] );

	pthread_mutex_unlock( &base->_gradthread_lockers[data->threadidx] );

	pthread_exit ( NULL );
}

LIB_EXPORT void yane::MPC::MultiThreadCacheOdeManager::calcObjectiveFunction ( double * t, double * x, double * u, double * fx )
{
	_cache->setStamp( t, x, u);

	try
	{
		*fx = _cachecalc[0]->objValue();
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::MultiThreadCacheOdeManager::calcObjectiveFunctionGrad ( double * t, double * x, double * u, double * fx )
{
	_cache->setStamp( t, x, u);

	for (int i=0; i<_threadcount; i++)
	{
		_threaddata[i].fx = fx;
	}

	for (int i=0; i<_threadcount; i++)
	{
		pthread_mutex_lock( & _gradthread_lockers[i] );
		_gradthread_running[i] = true;
		pthread_cond_signal ( & _gradthread_conds[i] );
		pthread_mutex_unlock( & _gradthread_lockers[i] );
	}

	for (int i=0; i<_threadcount; i++)
	{
		pthread_mutex_lock( & _gradthread_lockers[i] );
		while (_gradthread_running[i])
		{
			pthread_cond_wait ( & _gradthread_conds[i], &_gradthread_lockers[i] );
		}
		pthread_mutex_unlock( & _gradthread_lockers[i] );
	}
	for (int i=0; i<_threadcount; i++)
	{
		if (_threaddata[i].result!=0) throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ) );
	}
}

LIB_EXPORT void yane::MPC::MultiThreadCacheOdeManager::calcRestrFunction ( double * t, double * x, double * u, double * fx )
{
	if ( _dim_restr == 0 ) return;

	_cache->setStamp( t, x, u);

	try
	{
		_cachecalc[0]->restrValues(fx, _discretization, _configuration);
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::MultiThreadCacheOdeManager::calcRestrFunctionGrad ( double * t, double * x, double * u, double * fx, yane::MinProg::T_MEMMODEL memmodel, int * needc )
{
	if ( _dim_restr == 0 ) return;

	_cache->setStamp( t, x, u);

	for (int i=0; i<_threadcount; i++)
	{
		_threaddata[i].fx = fx;
		_threaddata[i].memmodel = memmodel;
		_threaddata[i].needc = needc;
		_threaddata[i].discretization = _discretization;
		_threaddata[i].configuration = _configuration;
	}

	for (int i=0; i<_threadcount; i++)
	{
		pthread_mutex_lock( & _jacthread_lockers[i] );
		_jacthread_running[i] = true;
		pthread_cond_signal ( & _jacthread_conds[i] );
		pthread_mutex_unlock( & _jacthread_lockers[i] );
	}

	for (int i=0; i<_threadcount; i++)
	{
		pthread_mutex_lock( & _jacthread_lockers[i] );
		while (_jacthread_running[i])
		{
			pthread_cond_wait ( & _jacthread_conds[i], &_jacthread_lockers[i] );
		}
		pthread_mutex_unlock( & _jacthread_lockers[i] );
	}

	for (int i=0; i<_threadcount; i++)
	{
		if (_threaddata[i].result!=0) throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ) );
	}
}

LIB_EXPORT void yane::MPC::MultiThreadCacheOdeManager::getObjFunValues ( double * t, double * x, double * u, double * fx, double * trajectory )
{
	_cache->setStamp( t, x, u);

	try
	{
		_cachecalc[0]->objValue();
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	memcpy ( fx, _cache->objHorizonValues(), sizeof ( double ) * _horizon );
	fx[_horizon] = 0.0;
	for ( int i = 0; i < _horizon + 1; i++ )
	{
		fx[i] *= _weightint;
	}

	memcpy ( trajectory, x, sizeof ( double ) * _dimension );
	memcpy ( &trajectory[_dimension], _cache->trajectoryValues(), sizeof ( double ) * _horizon * _dimension );

	if ( _weightcf != 0.0 )
	{
		for ( int i = 0; i < _horizon + 1; i++ )
		{
			fx[i] += _weightcf * _model->discreteCostfunction ( i, _horizon, t, trajectory, u );
		}
	}

}

LIB_EXPORT yane::MPC::OdeManager * yane::MPC::MultiThreadCacheOdeManager::clone()
{
	return new MultiThreadCacheOdeManager(_threadcount);
}

LIB_EXPORT void * yane::MPC::MultiThreadCacheOdeManager::configuration()
{
	return _configuration;
}
