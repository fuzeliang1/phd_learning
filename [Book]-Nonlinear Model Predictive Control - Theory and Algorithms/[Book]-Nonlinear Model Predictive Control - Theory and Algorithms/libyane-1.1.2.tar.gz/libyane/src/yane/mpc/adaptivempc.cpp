/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "adaptivempc.h"
#include "exceptions.h"
#include "modelshootingdata.h"
#include "odemanager.h"
#include "discr.h"

#include "../utils.h"
#include "../minprog.h"
#include "../odesolve.h"

#include <cstring>

#include "libexport.h"

LIB_EXPORT yane::MPC::AdaptiveMPC::AdaptiveMPC ( double h_new, double INFTY ) : yane::MPC::SuboptimalityMPC::SuboptimalityMPC ( h_new, INFTY )
{
	_adaptive_initialized = false;
	_showsqperror = false;
	_shorteningCheckNextStep = true;
	_optimizegamma = true;
	_N0 = 2;
	_sigma = 5;
	_estimate = APOSTERIORIPRACTICAL;
	_implementation = SIMPLE;

	_x_predicted_check = 0;
	_u_current_check = 0;
	_timesteps_current_check = 0;
}

LIB_EXPORT yane::MPC::AdaptiveMPC::~ AdaptiveMPC()
{
	if ( _x_predicted_check != 0 )
	{
		delete[] _x_predicted_check;
		_x_predicted_check = 0;
	}
	if ( _u_current_check != 0 )
	{
		delete[] _u_current_check;
		_u_current_check = 0;
	}
	if ( _timesteps_current_check != 0 )
	{
		delete[] _timesteps_current_check;
		_timesteps_current_check = 0;
	}
}

LIB_EXPORT void yane::MPC::AdaptiveMPC::calc ( double * x, int realtimesteps, double aborttimeoffset, double abortsuboptimalitydegree )
{
	_optimalitystate = OK;
	if ( !_adaptive_initialized )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the configAdaptiveMPC() method before this one." ) );
	}

	if ( ( _implementation != 0 && _implementation != 1 && _implementation != 2 && _implementation != 3 ) || ( _estimate != 0 && _estimate != 1 && _estimate != 2 && _estimate != 3 && _estimate != 4 ) )
	{
		stringstream mess;
		mess << "configuration of the AdaptiveMPC object is not allowed, received _implementation = " << _implementation << " and _estimate = " << _estimate << ".";
		throw EstimationException ( __DEBUGMESS ( mess.str() ) );
	}
	_abortsuboptimalitydegree = abortsuboptimalitydegree;
	try
	{
		if ( _implementation == NOADAPTION )
		{
			try
			{
				yane::MPC::MPC::calc ( x, realtimesteps, aborttimeoffset );
			}
			catch ( yane::MinProg::SolverWarning & e )
			{
				_optimalitystate = SQPBROKEN;
				if ( _showsqperror )
				{
					throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
				}
			}
			catch ( MPCException & e )
			{
				throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "MPC calc() failed" ), &e );
			}
			catch ( yane::Utils::Exception & e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
			}
			try
			{
				if ( _estimate == APOSTERIORI )
				{
					aposterioriEstimate ( x, _alpha );
				}
				else if ( _estimate == APOSTERIORIPRACTICAL )
				{
					aposterioriPracticalEstimate ( x, _alpha );
				}
				else if ( _estimate == APRIORI )
				{
					aprioriEstimate ( x, _alpha, _gamma, _N0 );
				}
				else if ( _estimate == APRIORIPRACTICAL )
				{
					aprioriPracticalEstimate ( x, _alpha, _gamma, _N0 );
				}
			}
			catch ( SuboptimalityException & e )
			{
				_optimalitystate = SUBOPTIMAL;
			}
			catch ( PracticalException & e )
			{
				_optimalitystate = PRACTICAL;
			}
			catch ( yane::MinProg::SolverWarning & e )
			{
				_optimalitystate = SQPBROKEN;
				if ( _showsqperror )
				{
					throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
				}
			}
			catch ( MPCException & e )
			{
				throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
			}
			catch ( yane::Utils::Exception & e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Computation of _estimate was aborted on computation" ), &e );
			}
		}

		if ( _implementation == SIMPLE )
		{
			calcSimple ( x, realtimesteps, aborttimeoffset );
		}

		if ( _implementation == FIXEDPOINT )
		{
			calcSimpleFixpoint ( x, realtimesteps, aborttimeoffset );
		}

		if ( _implementation == MONOTONE )
		{
			calcSimpleMonotone ( x, realtimesteps, aborttimeoffset );
		}
	}
	catch ( yane::MinProg::SolverWarning & e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( MPCException & e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "MPC calc() failed" ), &e );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Computation of _estimate was aborted on computation" ), &e );
	}
}

void yane::MPC::AdaptiveMPC::calcSimple ( double * x, int realtimesteps, double aborttimeoffset )
{
	setSingle ( true );

	try
	{
		calcAlpha ( x, realtimesteps, aborttimeoffset );
	}
	catch ( yane::MinProg::SolverWarning & e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( MPCException & e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Computation of _estimate was aborted on computation" ), &e );
	}

	if ( _alpha < _alphabound )
	{
		try
		{
//			cout << "Prolongation" << endl;
			simpleProlongation ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Prolongation may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Prolongation was aborted on computation" ), &e );
		}
	}
	else if ( ( _horizon > _N0 && ( _estimate == APOSTERIORI || _estimate == APOSTERIORIPRACTICAL ) ) || ( ( _horizon > _N0 && _N0 > 1 && ( _estimate == APRIORI || _estimate == APRIORIPRACTICAL ) ) ) )
	{
		try
		{
//			cout << "Shortening" << endl;
			if ( _shorteningCheckNextStep )
			{
				simpleShorteningCheckNextStep ( x, realtimesteps, aborttimeoffset );
			}
			else
			{
				simpleShortening ( x, realtimesteps, aborttimeoffset );
			}
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Shortening may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Shortening was aborted on computation" ), &e );
		}
	}
}

void yane::MPC::AdaptiveMPC::calcSimpleFixpoint ( double * x, int realtimesteps, double aborttimeoffset )
{
	setSingle ( true );

	try
	{
		calcAlpha ( x, realtimesteps, aborttimeoffset );
	}
	catch ( yane::MinProg::SolverWarning & e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( MPCException & e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Computation of _estimate was aborted on computation" ), &e );
	}

	if ( _alpha < _alphabound )
	{
		try
		{
			fixpointProlongation ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Prolongation may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Prolongation was aborted on computation" ), &e );
		}
	}
	else if ( _horizon > _N0 && _N0 > 1 )
	{
		try
		{
			if ( _shorteningCheckNextStep )
			{
				simpleShorteningCheckNextStep ( x, realtimesteps, aborttimeoffset );
			}
			else
			{
				simpleShortening ( x, realtimesteps, aborttimeoffset );
			}
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Shortening may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Shortening was aborted on computation" ), &e );
		}
	}
}

void yane::MPC::AdaptiveMPC::calcSimpleMonotone ( double * x, int realtimesteps, double aborttimeoffset )
{
	setSingle ( true );

	try
	{
		calcAlpha ( x, realtimesteps, aborttimeoffset );
	}
	catch ( yane::MinProg::SolverWarning & e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( MPCException & e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Computation of _estimate was aborted on computation" ), &e );
	}
	if ( _alpha < _alphabound )
	{
		try
		{
			monotoneProlongation ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Prolongation may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Prolongation was aborted on computation" ), &e );
		}
	}
	else if ( _horizon > _N0 && _N0 > 1 )
	{
		try
		{
			if ( _shorteningCheckNextStep )
			{
				simpleShorteningCheckNextStep ( x, realtimesteps, aborttimeoffset );
			}
			else
			{
				simpleShortening ( x, realtimesteps, aborttimeoffset );
			}
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Shortening may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Shortening was aborted on computation" ), &e );
		}
	}
}

void yane::MPC::AdaptiveMPC::simpleShortening ( double * x, int realtimesteps, double aborttimeoffset )
{
	try
	{
		resizeHorizon ( _horizon - 1, _h_new );
	}
	catch ( MPCException & e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Error" ), __DEBUGMESS ( "Modified optimal control problem could not be allocated" ), &e );
	}
}

void yane::MPC::AdaptiveMPC::simpleShorteningCheckNextStep ( double * x, int realtimesteps, double aborttimeoffset )
{
	int shootingdatalength = 0;
	if (_shootingdata != 0)
	{
		shootingdatalength = _shootingdata->maxShootingDataLength ( _maxhorizon );
	}

	if ( _u_current_check == 0 )
	{
		try
		{
			_u_current_check = new double [ _model->dimensionControl() * ( _maxhorizon + _precedesteps ) + shootingdatalength ];
		}
		catch ( std::bad_alloc & e )
		{
			if ( _u_current_check != 0 )
			{
				delete[] _u_current_check;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_u_current_check'" ) );
		}
	}
	memcpy ( _u_current_check, _u_preceded, sizeof ( double ) * ( _model->dimensionControl() * ( _maxhorizon + _precedesteps ) + shootingdatalength ) );
	if ( _timesteps_current_check == 0 )
	{
		try
		{
			_timesteps_current_check = new double [ _maxhorizon + 1 + _precedesteps ];
		}
		catch ( std::bad_alloc & )
		{
			if ( _timesteps_current_check != 0 )
			{
				delete[] _timesteps_current_check;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_timesteps_current_check'" ) );
		}
	}
	memcpy ( _timesteps_current_check, _timesteps_preceded, sizeof ( double ) * ( _maxhorizon + _precedesteps + 1 ) );
	if ( _x_predicted_check == 0 )
	{
		try
		{
			_x_predicted_check = new double [ _model->dimensionState() ];
		}
		catch ( std::bad_alloc & )
		{
			if ( _x_predicted_check != 0 )
			{
				delete[] _x_predicted_check;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_x_predicted_check'" ) );
		}
	}
	memcpy ( _x_predicted_check, x, sizeof ( double ) * _model->dimensionState() );
	if ( _nextcontrols == 0 )
	{
		try
		{
			_nextcontrols = new double [ _model->dimensionControl() ];
		}
		catch ( std::bad_alloc & )
		{
			if ( _nextcontrols != 0 )
			{
				delete[] _nextcontrols;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_nextcontrols'" ) );
		}
	}
	if ( _nexttimesteps == 0 )
	{
		try
		{
			_nexttimesteps = new double [ 2 ];
		}
		catch ( std::bad_alloc & )
		{
			if ( _nexttimesteps != 0 )
			{
				delete[] _nexttimesteps;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_nexttimesteps'" ) );
		}
	}

	try
	{
		shiftHorizon ( _nextcontrols, _nexttimesteps, 1, _x_predicted_check, _h_new );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Error during Shift occured" ), &e );
	}
	try
	{
		_modelsim->predictSequence ( 1, _nexttimesteps, _x_predicted_check, _nextcontrols );
	}
	catch ( yane::OdeSolve::OdeSolEx & e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
	}

	try
	{
		resizeHorizon ( _horizon - 1, _h_new );
	}
	catch ( MPCException & e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Error" ), __DEBUGMESS ( "Modified optimal control problem could not be allocated" ), &e );
	}

	try
	{
		calcAlpha ( _x_predicted_check, realtimesteps, aborttimeoffset );
	}
	catch ( yane::MinProg::SolverWarning & e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( MPCException & e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Computation of _estimate was aborted on computation" ), &e );
	}
	if ( _alpha < _alphabound || _optimalitystate == PRACTICAL )
	{
		try
		{
			resizeHorizon ( _horizon + 1, _h_new );
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Error" ), __DEBUGMESS ( "Modified optimal control problem could not be allocated" ), &e );
		}
	}
	memcpy ( _timesteps_preceded, _timesteps_current_check, sizeof ( double ) * ( _maxhorizon + _precedesteps + 1 ) );
	memcpy ( _u_preceded, _u_current_check, sizeof ( double ) * ( _model->dimensionControl() * ( _maxhorizon + _precedesteps ) + shootingdatalength ) );
}

void yane::MPC::AdaptiveMPC::simpleProlongation ( double * x, int realtimesteps, double aborttimeoffset )
{
	while ( _alpha < _alphabound && _horizon < _maxhorizon )
	{
// 		cout << setw(10) << setprecision(5) << "Verlaengern: " << _horizon + 1 << endl;
		try
		{
			resizeHorizon ( _horizon + 1, _h_new );
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Error" ), __DEBUGMESS ( "Modified optimal control problem could not be allocated" ), &e );
		}
// 		cout << setw(10) << setprecision(5) << _horizon << " " << _alpha << endl;
		try
		{
			calcAlpha ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Computation of _estimate was aborted on computation" ), &e );
		}
// 		cout << setw(10) << setprecision(5) << _horizon << " " << _alpha << endl;
	}
	if ( _horizon == _maxhorizon && _alpha < _alphabound )
	{
		stringstream mess;
		mess << "new horizonlength (=" << _horizon << ") exceeds maximum length of " << _maxhorizon;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}
}

void yane::MPC::AdaptiveMPC::fixpointProlongation ( double * x, int realtimesteps, double aborttimeoffset )
{
	int phi_help;
	while ( _alpha < _alphabound && _horizon < _maxhorizon )
	{
		if ( _estimate == APOSTERIORI || _estimate == APOSTERIORIPRACTICAL )
		{
			if ( _optimizegamma )
			{
				_phi = _maxhorizon;
				for ( int N0_local = 2; N0_local <= _horizon; N0_local++ )
				{
					try
					{
						aposterioriGamma ( N0_local );
					}
					catch ( MPCException & e )
					{
						throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the _gamma caused an error" ), &e );
					}
					phi_help = ( int ) ceil ( ( ( double ) N0_local ) + ( 2.0 * log ( _gamma ) - log ( 1.0 - _alphabound ) ) / ( log ( _gamma + 1.0 ) - log ( _gamma ) ) );
					if ( phi_help < _horizon )
					{
						phi_help = _maxhorizon;
					}
					_phi = min ( _phi, phi_help );
// 					cout << setw(10) << setprecision(5) << "Verlaengern: " << _phi << endl;
// 					cout << setw(10) << setprecision(5) << _horizon << " " << _alpha << endl;
				}
			}
			else
			{
				try
				{
					aposterioriGamma ( _N0 );
				}
				catch ( MPCException & e )
				{
					throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the _gamma caused an error" ), &e );
				}
				_phi = ( int ) ceil ( ( ( double ) _N0 ) + ( 2.0 * log ( _gamma ) - log ( 1.0 - _alphabound ) ) / ( log ( _gamma + 1.0 ) - log ( _gamma ) ) );
				if ( _phi < _horizon )
				{
					_phi = _maxhorizon;
				}
// 				cout << setw(10) << setprecision(5) << "Verlaengern: " << _phi << endl;
// 				cout << setw(10) << setprecision(5) << _horizon << " " << _alpha << endl;
			}
		}
		else if ( _estimate == APRIORI || _estimate == APRIORIPRACTICAL )
		{
			_phi = ( int ) ceil ( ( ( double ) _N0 ) + ( 2.0 * log ( _gamma ) - log ( 1.0 - _alphabound ) ) / ( log ( _gamma + 1.0 ) - log ( _gamma ) ) );
			if ( _phi < _horizon )
			{
				_phi = _horizon + 1;
			}
		}
		_phi = max ( max ( min ( _maxhorizon, min ( _horizon + _sigma, _phi ) ), _horizon - _sigma ), _N0 );
		try
		{
			resizeHorizon ( _phi, _h_new );
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Error" ), __DEBUGMESS ( "Modified optimal control problem could not be allocated" ), &e );
		}
		try
		{
			calcAlpha ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Computation of _estimate was aborted on computation" ), &e );
		}
// 		cout << setw(10) << setprecision(5) << _horizon << " " << _alpha << endl;
	}
	if ( _horizon == _maxhorizon && _alpha < _alphabound )
	{
		stringstream mess;
		mess << "new horizonlength (=" << _horizon << ") exceeds maximum length of " << _maxhorizon;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}
}

void yane::MPC::AdaptiveMPC::monotoneProlongation ( double * x, int realtimesteps, double aborttimeoffset )
{
	int phi_help;
	_theta = 1.0;
	_gamma = 1.0;
	while ( _alpha < _alphabound && _horizon < _maxhorizon )
	{
		double gamma_help = _gamma;
// 		_delta = (_alphabound - _alpha) / 2.0;
		_delta = _alphabound - _alpha;
		if ( _estimate == APOSTERIORI || _estimate == APOSTERIORIPRACTICAL )
		{
			if ( _optimizegamma )
			{
				_phi = _maxhorizon;
				for ( int N0_local = 2; N0_local <= _horizon; N0_local++ )
				{
					try
					{
						aposterioriGamma ( N0_local );
					}
					catch ( MPCException & e )
					{
						throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the _gamma caused an error" ), &e );
					}
					phi_help = ( int ) ceil ( ( ( double ) N0_local ) + ( ( log ( pow ( _gamma / ( _gamma + 1.0 ), _horizon - N0_local ) - _delta / ( _gamma * _gamma ) ) - 2.0 * log ( _theta ) ) / ( log ( _theta * _gamma ) - log ( _theta * _gamma + 1.0 ) ) ) );
					if ( phi_help < _horizon )
					{
						phi_help = _maxhorizon;
					}
					_phi = min ( _phi, phi_help );
// 					cout << setw(10) << setprecision(5) << "Verlaengern: " << _phi << endl;
// 					cout << setw(10) << setprecision(5) << _horizon << " " << _alpha << endl;
				}
			}
			else
			{
				try
				{
					aposterioriGamma ( _N0 );
				}
				catch ( MPCException & e )
				{
					throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the _gamma caused an error" ), &e );
				}
				_phi = ( int ) ceil ( ( ( double ) _N0 ) + ( ( log ( pow ( _gamma / ( _gamma + 1.0 ), _horizon - _N0 ) - _delta / ( _gamma * _gamma ) ) - 2.0 * log ( _theta ) ) / ( log ( _theta * _gamma ) - log ( _theta * _gamma + 1.0 ) ) ) ) ;
// 				cout << setw(10) << setprecision(5) << "Verlaengern: " << _phi << endl;
// 				cout << setw(10) << setprecision(5) << _horizon << " " << _alpha << endl;
				if ( _phi < _horizon )
				{
					_phi = _maxhorizon;
				}
			}
		}
		else if ( _estimate == APRIORI || _estimate == APRIORIPRACTICAL )
		{
			_phi = ( int ) ceil ( ( ( double ) _N0 ) + ( ( log ( pow ( _gamma / ( _gamma + 1.0 ), _horizon - _N0 ) - _delta / ( _gamma * _gamma ) ) - 2.0 * log ( _theta ) ) / ( log ( _theta * _gamma ) - log ( _theta * _gamma + 1.0 ) ) ) ) ;
			if ( _phi < _horizon )
			{
				_phi = _horizon + 1;
			}
		}
		_theta = max ( _theta, _gamma / gamma_help );
		_phi = min ( _maxhorizon, min ( _horizon + _sigma, _phi ) );
		try
		{
			resizeHorizon ( _phi, _h_new );
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Error" ), __DEBUGMESS ( "Modified optimal control problem could not be allocated" ), &e );
		}
		try
		{
			calcAlpha ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException & e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Computation of _estimate was aborted on computation" ), &e );
		}
	}
	if ( _horizon == _maxhorizon && _alpha < _alphabound )
	{
		stringstream mess;
		mess << "new horizonlength (=" << _horizon << ") exceeds maximum length of " << _maxhorizon;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}
}

LIB_EXPORT void yane::MPC::AdaptiveMPC::setConfigAdaptiveMPC ( double alphabound, T_ESTIMATE estimate, T_IMPLEMENTATION implementation, int N0, double epsilon, int sigma, bool shorteningCheckNextStep, bool optimizegamma )
{
	if ( alphabound < 0.0 )
	{
		stringstream mess;
		mess << "'_alphabound' should be greater than zero, got " << alphabound;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}
	try
	{
		setConfigSuboptimalityMPC ( estimate, N0 );
		setEpsilon ( epsilon );
	}
	catch ( yane::Utils:: Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Configuration of SuboptimalityMPC failed" ), &e );
	}
	_alphabound = alphabound;
	_implementation = implementation;
	_shorteningCheckNextStep = shorteningCheckNextStep;
	_optimizegamma = optimizegamma;
	if ( optimizegamma && N0 > 2 )
	{
		cout << "Warning: _N0 was defined larger than 2, got " << N0 << endl;
	}
	_sigma = sigma;

	_adaptive_initialized = true;
}

LIB_EXPORT double yane::MPC::AdaptiveMPC::alpha ( void )
{
	return _alpha;
}
