/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_MODELSHOOTINGDATA_H
#define YANE_MPC_MODELSHOOTINGDATA_H

#include "mpc.h"

namespace yane
{

	namespace MPC
	{

		/** \class ModelShootingData
		\brief Class for utilizing shooting nodes within a class yane::MPC::MPC object
		 */
		class ModelShootingData
		{
			public:
				/**
				@brief Constructor
				 */
				ModelShootingData();

				/**
				Destructor
				 */
				virtual ~ModelShootingData();

				/**
				Function to return the number of shooting nodes for a given horizon
				@param horizont Length of the horizon
				@return Number of shooting nodes
				@brief Function to return the number of shooting nodes for a given horizon
				 */
				virtual int shootingDataLength ( int horizont ) = 0;

				/**
				Function to return the maximal number of shooting nodes for the maximal horizon. This function is used by the class yane::MPC::MPC object to allocate its internal memory for storing the shooting data values.
				@param maxhorizont Maximal horizon length
				@return Number of shooting nodes
				@brief Function to return the maximal number of shooting nodes for the maximal horizon
				 */
				virtual int maxShootingDataLength ( int maxhorizont ) = 0;

				/**
				Function to define the shooting nodes
				@param sdata Array of shooting nodes where data can be stored
				@param horizont Length of the horizon
				@brief Function to define the shooting data values
				 */
				virtual void shootingDataInfo ( int horizont, T_SHOOTINGDATA * sdata ) = 0;

				/**
				Function to define the shooting node values. This function is called before each start of the optimization within the class yane::MPC::MPC object and allows to reset shooting values.
				@param horizont Length of the horizon
				@param t Time grid
				@param x State vector
				@param sdatavalues Array of shooting data values
				@brief Function to define the shooting node values
				 */
				virtual void applyShootingData ( int horizont, double * t, double * x, double * sdatavalues ) = 0;

		};

	}

}

#endif
