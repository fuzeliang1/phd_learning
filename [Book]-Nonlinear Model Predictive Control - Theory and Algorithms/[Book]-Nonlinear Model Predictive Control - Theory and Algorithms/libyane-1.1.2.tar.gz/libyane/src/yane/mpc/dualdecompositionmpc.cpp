/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "dualdecompositionmpc.h"
#include "exceptions.h"
#include "odemanager.h"
#include "discr.h"

#include "../model/model.h"
#include "../minprog.h"
#include "../utils.h"

#include "libexport.h"

LIB_EXPORT yane::MPC::DualDecompositionMPC::DualDecompositionMPC() : NetworkedMPCConfig()
{
	_resetDiscretizationRequired = false;
	_resetMultiplierNLP = false;
	_multiplier = 0;
	_lbound_multiplier = 0;
	_ubound_multiplier = 0;
	_inputNeighbourMultiplier.clear();
}

LIB_EXPORT yane::MPC::DualDecompositionMPC::~DualDecompositionMPC()
{
	int networksize = _inputNeighbours.size();
	for ( int i = 0; i < networksize; i++ )
	{
		_inputNeighbourMultiplier[i].clear();
	}
	_inputNeighbourMultiplier.clear();
	if ( _multiplier != 0 )
	{
		delete[] _multiplier;
		_multiplier = 0;
	}
	if ( _lbound_multiplier != 0 )
	{
		delete[] _lbound_multiplier;
		_lbound_multiplier = 0;
	}
	if ( _ubound_multiplier != 0 )
	{
		delete[] _ubound_multiplier;
		_ubound_multiplier = 0;
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::addInputNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		addInputNeighbour ( neighbour->configID(), neighbour->mpc()->model()->dimensionState(), neighbour->mpc()->model()->dimensionControl(), neighbour->mpc()->horizon(), neighbour->mpc()->precedesteps() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::addInputNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps )
{
	try
	{
		NetworkedMPCConfig::addInputNeighbour ( uuid, dimensionState, dimensionControl, horizon, precedesteps );
		if ( _resetDiscretizationRequired )
		{
			_inputNeighbourMultiplier.resize ( _inputNeighbourMultiplier.size() + 1 );
			_inputNeighbourMultiplier[ _inputNeighbourMultiplier.size() - 1].resize ( ( precedesteps + horizon + 1 ) * dimensionState );
		}
		_resetDiscretizationRequired = false;
		_resetMultiplierNLP = true;
		resetDiscretization ( _mpc->problem() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::removeInputNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		removeInputNeighbour ( neighbour->configID() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::removeInputNeighbour(yane::Utils::Uuid * uuid)
{
	try
	{
		NetworkedMPCConfig::removeInputNeighbour ( uuid );
		if ( _resetDiscretizationRequired )
		{
			bool remove = false;
			int counter = 0;
			int networksize = _inputNeighbours.size();
			while ( !remove && counter < networksize )
			{
				if ( _inputNeighbours[counter].uuid == uuid )
				{
					remove = true;
					_inputNeighbourMultiplier.erase ( _inputNeighbourMultiplier.begin() + counter );
				}
				counter++;
			}
			_resetDiscretizationRequired = false;
			_resetMultiplierNLP = true;
			resetDiscretization ( _mpc->problem() );
		}
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::addNeighbour ( NetworkedMPCConfig* neighbour )
{
	try
	{
		addNeighbour ( neighbour->configID(), neighbour->mpc()->model()->dimensionState(), neighbour->mpc()->model()->dimensionControl(), neighbour->mpc()->horizon(), neighbour->mpc()->precedesteps() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::addNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps )
{
	try
	{
		addInputNeighbour ( uuid, dimensionState, dimensionControl, horizon, precedesteps );
		addOutputNeighbour ( uuid );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::removeNeighbour ( NetworkedMPCConfig* neighbour )
{
	try
	{
		removeNeighbour ( neighbour->configID() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::removeNeighbour(yane::Utils::Uuid * uuid)
{
	try
	{
		removeInputNeighbour ( uuid );
		removeOutputNeighbour ( uuid );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::resetDiscretization(Discretization * problem)
{
	if ( _resetDiscretizationRequired )
	{
		try
		{
			problem->minimizer()->init ( problem->dimension_u() * problem->horizon() + problem->sdatalength(), networkCostfunction, problem->min_restr, problem->totalRestrictionNumber(), problem->sdatalength(), problem->min_func_grad, problem->min_restr_grad );
		}
		catch ( yane::MinProg::MinProgException e )
		{
			throw yane::MinProg::MinProgException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Minimizer could not be initialized" ), &e );
		}
		_resetDiscretizationRequired = false;
	}

	if ( _resetMultiplierNLP ) //TODO Reset ueberarbeiten
	{
		if ( _minimizer != 0 )
		{
			delete _minimizer;
			_minimizer = 0;
		}
		//TODO numberOfMultipliers berechnen
		_numberOfMultipliers = 0;

		if ( _multiplier != 0 )
		{
			delete[] _multiplier;
			_multiplier = 0;
		}
		if ( _lbound_multiplier != 0 )
		{
			delete[] _lbound_multiplier;
			_lbound_multiplier = 0;
		}
		if ( _ubound_multiplier != 0 )
		{
			delete[] _ubound_multiplier;
			_ubound_multiplier = 0;
		}
		//TODO _multiplier, _lbound_multiplier, _ubound_multiplier anlegen

		boxConstraintsMultiplierNLP ( _numberOfMultipliers, _lbound_multiplier, _ubound_multiplier );
// 		_minimizer = new yane::MinProg::???; //TODO Minimierer implementieren

		_resetMultiplierNLP = false;
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::networkCostfunction ( const double * x, double * fx, void * params )
{
	yane::MinProg::T_FUNCTIONSTRUCT * data = ( yane::MinProg::T_FUNCTIONSTRUCT* ) params;
	Discretization * discretization = ( Discretization * ) data->rpar;
	int horizon = discretization->horizon();
	int dimx = discretization->dimension_x();
	yane::Model::Model * model = discretization->model();
	DualDecompositionMPC * configuration = ( DualDecompositionMPC * ) (discretization->odemanager()->configuration());
	int numberOfNeighbours = configuration->numberOfInputNeighbours();
	int precedesteps = configuration->mpc()->precedesteps();
	int horizonNeighbour;

	double * trajectory;
	try
	{
		trajectory = new double[ ( horizon + 1 ) * horizon ];
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating memory" ) );
	}

	try
	{
		discretization->odemanager()->calcObjectiveFunction ( discretization->timesteps(), discretization->currentx(), ( double * ) x, fx );
		configuration->mpc()->modelsim()->trajectory ( horizon, discretization->timesteps(), discretization->currentx(), ( double * ) x, trajectory );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Differential equation solver caused an error" ), &e );
	}

	for ( int i = 0; i < numberOfNeighbours; i++ )
	{
		horizonNeighbour = min ( horizon, configuration->_inputNeighbours[i].horizon + configuration->_inputNeighbours[i].precedesteps - precedesteps );
		*fx += model->networkCostfunction ( horizonNeighbour, horizonNeighbour, discretization->timesteps(), trajectory, ( double * ) x, &configuration->_inputNeighbourState[i][precedesteps * configuration->_inputNeighbours[i].dimensionState], &configuration->_inputNeighbourControl[i][precedesteps * configuration->_inputNeighbours[i].dimensionControl], &configuration->_inputNeighbourMultiplier[i][precedesteps * configuration->_inputNeighbours[i].dimensionState] );
	}

	if ( !data->abort && discretization->abortSuboptimalityDegree() < INFINITY )
	{
		data->abort = discretization->suboptimalityCheck ( fx[0] );
	}
	delete[] trajectory;
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::updateInputNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, double * multiplier, int precedesteps )
{
	if ( _mpc->problem() != 0 )
	{
		bool update = false;
		int counter = 0;
		int networksize = _inputNeighbours.size();
		while ( !update && counter < networksize )
		{
			if ( _inputNeighbours[counter].uuid == uuid )
			{
				update = true;
				if ( _inputNeighbours[counter].horizon != horizon || _inputNeighbours[counter].precedesteps != precedesteps )
				{
					_inputNeighbours[counter].horizon = horizon;
					_inputNeighbours[counter].precedesteps = precedesteps;
					_inputNeighbourTimesteps[counter].resize ( precedesteps + horizon + 1 );
					_inputNeighbourControl[counter].resize ( ( precedesteps + horizon ) * _inputNeighbours[counter].dimensionControl );
					_inputNeighbourState[counter].resize ( ( precedesteps + horizon + 1 ) * _inputNeighbours[counter].dimensionState );
					_inputNeighbourMultiplier[counter].resize ( ( precedesteps + horizon + 1 ) * _inputNeighbours[counter].dimensionState );
					_resetMultiplierNLP = true;
				}
				copy ( timesteps, timesteps + precedesteps + horizon + 1, _inputNeighbourTimesteps[counter].begin() );
				copy ( control, control + ( precedesteps + horizon ) * _inputNeighbours[counter].dimensionControl, _inputNeighbourControl[counter].begin() );
				copy ( state, state + ( precedesteps + horizon + 1 ) * _inputNeighbours[counter].dimensionState, _inputNeighbourState[counter].begin() );
				copy ( multiplier, multiplier + ( precedesteps + horizon + 1 ) * _inputNeighbours[counter].dimensionState, _inputNeighbourMultiplier[counter].begin() );
			}
			counter++;
		}
		if ( !update && _displaywarnings )
		{
			throw yane::MPC::NetworkedMPCConfigWarning ( __DEBUGMESS ( "MPC controlled system to be updated is not contained in local list" ) );
		}
	}
	else
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "MPC object must be initialized, call the reset() method before this one." ) );
	}
	resetDiscretization ( _mpc->problem() );
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::updateOutputNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, double * multiplier, int precedesteps )
{
	//TODO Output update implementieren
//  throw yane::MPC::NetworkedMPCConfigException ( __DEBUGMESS ( "Method not implemented yet" ) );
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::updateNeighbour ( NetworkedMPCConfig * neighbour, double * timesteps, double * control, double * state, double * multiplier )
{
	try
	{
		updateNeighbour ( neighbour->configID(), neighbour->mpc()->horizon(), timesteps, control, state, multiplier, neighbour->mpc()->precedesteps() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Updating neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::updateNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, double * multiplier, int precedesteps )
{
	try
	{
		updateInputNeighbour ( uuid, horizon, timesteps, control, state, multiplier, precedesteps );
		updateOutputNeighbour ( uuid, horizon, timesteps, control, state, multiplier, precedesteps );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Updating neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::computeNewMultiplier()
{
	double costfunctionValue = 0.0;
	_multiplier = 0; //TODO _multiplier zusammenkopieren
	try
	{
// 		_minimizer->calcMin ( _multiplier, &costfunctionValue, _lbound_multiplier, _ubound_multiplier, ( double * ) this );
	}
	catch ( yane::MinProg::SolverWarning e )
	{
		throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Optimization problem could not be solved" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Differential equation solver caused a problem" ), &e );
	}
	//TODO _multiplier zurueckkopieren
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::objectivFunctionMultiplierNLP ( const double *x, double *fx, void *params )
{
	fx[0] = 0.0;
}

LIB_EXPORT void yane::MPC::DualDecompositionMPC::boxConstraintsMultiplierNLP ( int numberOfMultipliers, double * _lbound_multiplier, double * _ubound_multiplier )
{
	for ( int i = 0; i < numberOfMultipliers; i++ )
	{
		_lbound_multiplier[i] = 0.0;
		_ubound_multiplier[i] = 0.0;
	}
}
