/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "strategyexchangempc.h"
#include "discr.h"
#include "odemanager.h"
#include "exceptions.h"

#include "../model/model.h"
#include "../utils.h"

#include <cstring>

#include "libexport.h"

LIB_EXPORT yane::MPC::StrategyExchangeMPC::StrategyExchangeMPC() : NetworkedMPCConfig()
{
	_resetDiscretizationRequired = false;
	_reducedNumberOfConstraints = false;
}

LIB_EXPORT yane::MPC::StrategyExchangeMPC::~StrategyExchangeMPC()
{
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::extendedFullRestrictionFunction ( double * t, double * x, double * u, double * fx, void * discretizationptr, void * configurationptr )
{
	Discretization * discretization = ( Discretization * ) discretizationptr;
	int dimx = discretization->dimension_x();
	int dimu = discretization->dimension_u();
	int horizon = discretization->horizon();
	int dimension_restr = discretization->dimension_restr();
	int sdatalength = discretization->sdatalength();
	double infty = discretization->infty();
	yane::Model::Model * model = discretization->model();
	StrategyExchangeMPC * configuration = ( StrategyExchangeMPC * ) configurationptr;
	int numberOfNeighbours = configuration->numberOfInputNeighbours();
	int networkRestrictionSize = model->networkRestrictionSize();
	int horizonNeighbour;
	int precedesteps = configuration->mpc()->precedesteps();

	for ( int i = 0; i < sdatalength; i++ )
	{
		fx[i] = u[horizon * dimu + i] - x[ dimx * discretization->sdata() [i].horizonindex + discretization->sdata() [i].varindex];
	}

	int index = horizon * dimension_restr + sdatalength;
	for ( int i = 0; i < configuration->numberOfInputNeighbours(); i++ )
	{
		index += min ( horizon, configuration->_inputNeighbours[i].horizon + configuration->_inputNeighbours[i].precedesteps - precedesteps ) * networkRestrictionSize;
	}

	for ( int h = 0; h < horizon - 1; h++ )
	{
		if ( dimension_restr > 0 )
		{
			model->restrictionFunction ( t[ h + 1 ], &x[ h * dimx ], &u[ h * dimu ], &fx[ h * dimension_restr + sdatalength ] );
		}
		for ( int i = 0; i < dimx; i++ )
		{
			if ( discretization->lbound_x()[i] > -infty )
			{
				fx[index] = x[ ( h * dimx ) + i ] - discretization->lbound_x()[i];
				index++;
			}
			if ( discretization->ubound_x()[i] < infty )
			{
				fx[index] = -x[ ( h * dimx ) + i ] + discretization->ubound_x()[i];
				index++;
			}
		}
	}
	if ( dimension_restr > 0 )
	{
		model->restrictionFunction ( t[ horizon ], &x[ ( horizon - 1 ) * dimx ], discretization->u_zero(), &fx[ ( horizon - 1 ) * dimension_restr + sdatalength ] );
	}
	for ( int i = 0; i < dimx; i++ )
	{
		if ( discretization->lbound_x()[i] > -infty )
		{
			fx[index] = x[ ( ( horizon - 1 ) * dimx ) + i ] - discretization->lbound_x()[i];
			index++;
		}
		if ( discretization->ubound_x()[i] < infty )
		{
			fx[index] = -x[ ( ( horizon - 1 ) * dimx ) + i ] + discretization->ubound_x()[i];
			index++;
		}
	}

	if ( networkRestrictionSize > 0 )
	{
		index = horizon * dimension_restr + sdatalength;
		for ( int i = 0; i < numberOfNeighbours; i++ )
		{
			horizonNeighbour = min ( horizon, configuration->_inputNeighbours[i].horizon + configuration->_inputNeighbours[i].precedesteps - precedesteps );
			for ( int j = 0; j < horizonNeighbour - 1; j++ )
			{
				model->networkRestrictionFunction ( t[ j + 1 ], &x[ j * dimx ], &u[ j * dimu ], &configuration->_inputNeighbourState[ i ][ ( j + 1 + precedesteps ) * configuration->_inputNeighbours[i].dimensionState ], &configuration->_inputNeighbourControl[ i ][ ( j + 1 + precedesteps ) * configuration->_inputNeighbours[i].dimensionControl ], &fx[ index ] );
				index += networkRestrictionSize;
			}
			model->networkRestrictionFunction ( t[ horizonNeighbour ], &x[ ( horizonNeighbour - 1 ) * dimx ], discretization->u_zero(), & configuration->_inputNeighbourState[i][ ( horizonNeighbour + precedesteps ) * configuration->_inputNeighbours[i].dimensionState ], discretization->u_zero(), &fx[ index ] );
			index += networkRestrictionSize;
		}
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::extendedReducedRestrictionFunction ( double * t, double * x, double * u, double * fx, void * discretizationptr, void * configurationptr )
{
	Discretization * discretization = ( Discretization * ) discretizationptr;
	int dimx = discretization->dimension_x();
	int dimu = discretization->dimension_u();
	int horizon = discretization->horizon();
	int dimension_restr = discretization->dimension_restr();
	int sdatalength = discretization->sdatalength();
	double infty = discretization->infty();
	yane::Model::Model * model = discretization->model();
	StrategyExchangeMPC * configuration = ( StrategyExchangeMPC * ) configurationptr;
	int numberOfNeighbours = configuration->numberOfInputNeighbours();
	int networkRestrictionSize = model->networkRestrictionSize();
	int horizonNeighbour;
	int precedesteps = configuration->mpc()->precedesteps();

	for ( int i = 0; i < sdatalength; i++ )
	{
		fx[i] = u[horizon * dimu + i] - x[ dimx * discretization->sdata() [i].horizonindex + discretization->sdata() [i].varindex];
	}

	int index = horizon * dimension_restr + sdatalength + configuration->numberOfInputNeighbours() * networkRestrictionSize;

	for ( int h = 0; h < horizon - 1; h++ )
	{
		if ( dimension_restr > 0 )
		{
			model->restrictionFunction ( t[ h + 1 ], &x[ h * dimx ], &u[ h * dimu ], &fx[ h * dimension_restr + sdatalength ] );
		}
		for ( int i = 0; i < dimx; i++ )
		{
			if ( discretization->lbound_x() [i] > -discretization->infty() )
			{
				fx[index] = x[ ( h * dimx ) + i ] - discretization->lbound_x() [i];
				index++;
			}
			if ( discretization->ubound_x() [i] < discretization->infty() )
			{
				fx[index] = -x[ ( h * dimx ) + i ] + discretization->ubound_x() [i];
				index++;
			}
		}
	}
	if ( dimension_restr > 0 )
	{
		model->restrictionFunction ( t[ horizon ], &x[ ( horizon - 1 ) * dimx ], discretization->u_zero(), &fx[ ( horizon - 1 ) * dimension_restr + sdatalength ] );
	}
	for ( int i = 0; i < dimx; i++ )
	{
		if ( discretization->lbound_x()[i] > -infty )
		{
			fx[index] = x[ ( ( horizon - 1 ) * dimx ) + i ] - discretization->lbound_x()[i];
			index++;
		}
		if ( discretization->ubound_x()[i] < infty )
		{
			fx[index] = -x[ ( ( horizon - 1 ) * dimx ) + i ] + discretization->ubound_x()[i];
			index++;
		}
	}

	if ( networkRestrictionSize > 0 )
	{
		double * auxilliary_restriction;
		auxilliary_restriction = new double [ networkRestrictionSize ];
		index = horizon * dimension_restr + sdatalength;
		for ( int i = 0; i < numberOfNeighbours; i++ )
		{

			horizonNeighbour = min ( horizon, configuration->_inputNeighbours[i].horizon + configuration->_inputNeighbours[i].precedesteps - precedesteps );
			for ( int j = 0; j < networkRestrictionSize; j++ )
			{
				fx[ index + j ] = 0.0;
			}
			for ( int j = 0; j < horizonNeighbour - 1; j++ )
			{
				model->networkRestrictionFunction ( t[ j + 1 ], &x[ j * dimx ], &u[ j * dimu ], & configuration->_inputNeighbourState[ i ][ ( j + 1 + precedesteps ) * configuration->_inputNeighbours[i].dimensionState ], &configuration->_inputNeighbourControl[ i ][ ( j + 1 + precedesteps ) * configuration->_inputNeighbours[i].dimensionControl ], auxilliary_restriction );
				for ( int k = 0; k < networkRestrictionSize; k++ )
				{
					fx[ index + k ] += auxilliary_restriction[k];
				}
			}
			model->networkRestrictionFunction ( t[ horizonNeighbour ], &x[ ( horizonNeighbour - 1 ) * dimx ], discretization->u_zero(), &configuration->_inputNeighbourState[i][ ( horizonNeighbour + precedesteps ) * configuration->_inputNeighbours[i].dimensionState ], discretization->u_zero(), auxilliary_restriction );
			for ( int j = 0; j < networkRestrictionSize; j++ )
			{
				fx[ index + j ] += auxilliary_restriction[j];
			}
			index += networkRestrictionSize;
		}
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::resetDiscretization ( Discretization * problem )
{
	if ( _resetDiscretizationRequired )
	{
		int dimx = problem->dimension_x();
		int horizon = problem->horizon();
		int dimension_restr = problem->dimension_restr();
		int sdatalength = problem->sdatalength();
		double infty = problem->infty();
		int totalRestrictionNumber = ( horizon * dimension_restr ) + ( horizon * 2 * dimx ) + sdatalength;
		for ( int i = 0; i < dimx; i++ )
		{
			if ( problem->lbound_x() [i] <= -infty )
			{
				totalRestrictionNumber -= horizon;
			}
			if ( problem->ubound_x() [i] >= infty )
			{
				totalRestrictionNumber -= horizon;
			}
		}

		if ( _reducedNumberOfConstraints )
		{
			resetReducedDiscretization ( problem, horizon, sdatalength, totalRestrictionNumber );
		}
		else
		{
			resetFullDiscretization ( problem, horizon, sdatalength, totalRestrictionNumber );
		}
		_resetDiscretizationRequired = false;
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::resetFullDiscretization ( Discretization * problem, int horizon, int sdatalength, int totalRestrictionNumber )
{
	int networkRestrictionSize = problem->model()->networkRestrictionSize();
	for ( int i = 0; i < numberOfInputNeighbours(); i++ )
	{
		totalRestrictionNumber += min ( horizon, _inputNeighbours[i].horizon ) * networkRestrictionSize;
	}

	try
	{
		problem->odemanager()->setFunctions ( horizon, totalRestrictionNumber, problem->model(), extendedFullRestrictionFunction, sdatalength, problem->sdata() );
		problem->odemanager()->setAuxilliaryObjects ( problem, this );
	}
	catch ( yane::Utils::MemoryException e )
	{
		throw yane::MinProg::MinProgException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Odemanager could not be initialized" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Odemanager could not be initialized" ), &e );
	}

	// TODO Checken, ob problem->minimizer()->init umgeschrieben werden sollte
	try
	{
		problem->minimizer()->init ( problem->dimension_u() * horizon + sdatalength, problem->min_func, problem->min_restr, totalRestrictionNumber, sdatalength, problem->min_func_grad, problem->min_restr_grad );
	}
	catch ( yane::MinProg::MinProgException e )
	{
		throw yane::MinProg::MinProgException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Minimizer could not be initialized" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::resetReducedDiscretization ( Discretization * problem, int horizon, int sdatalength, int totalRestrictionNumber )
{
	totalRestrictionNumber += numberOfInputNeighbours() * problem->model()->networkRestrictionSize();

	try
	{
		problem->odemanager()->setFunctions ( horizon, totalRestrictionNumber, problem->model(), extendedReducedRestrictionFunction, sdatalength, problem->sdata() );
		problem->odemanager()->setAuxilliaryObjects ( problem, this );
	}
	catch ( yane::Utils::MemoryException e )
	{
		throw yane::MinProg::MinProgException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Odemanager could not be initialized" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Odemanager could not be initialized" ), &e );
	}

	// TODO Checken, ob problem->minimizer()->init umgeschrieben werden sollte
	try
	{
		problem->minimizer()->init ( problem->dimension_u() * horizon + sdatalength, problem->min_func, problem->min_restr, totalRestrictionNumber, sdatalength, problem->min_func_grad, problem->min_restr_grad );
	}
	catch ( yane::MinProg::MinProgException e )
	{
		throw yane::MinProg::MinProgException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Minimizer could not be initialized" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::addInputNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		addInputNeighbour ( neighbour->configID(), neighbour->mpc()->model()->dimensionState(), neighbour->mpc()->model()->dimensionControl(), neighbour->mpc()->horizon(), neighbour->mpc()->precedesteps() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::addInputNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps )
{
	try
	{
		NetworkedMPCConfig::addInputNeighbour ( uuid, dimensionState, dimensionControl, horizon, precedesteps );
		resetDiscretization ( _mpc->problem() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::removeInputNeighbour ( NetworkedMPCConfig * neighbour )
{
	try
	{
		removeInputNeighbour ( neighbour->configID() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::removeInputNeighbour(yane::Utils::Uuid * uuid)
{
	try
	{
		NetworkedMPCConfig::removeInputNeighbour ( uuid );
		resetDiscretization ( _mpc->problem() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing input neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::addNeighbour ( NetworkedMPCConfig* neighbour )
{
	try
	{
		addNeighbour ( neighbour->configID(), neighbour->mpc()->model()->dimensionState(), neighbour->mpc()->model()->dimensionControl(), neighbour->mpc()->horizon(), neighbour->mpc()->precedesteps() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::addNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps )
{
	try
	{
		addInputNeighbour ( uuid, dimensionState, dimensionControl, horizon, precedesteps );
		addOutputNeighbour ( uuid );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Adding neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::removeNeighbour ( NetworkedMPCConfig* neighbour )
{
	try
	{
		removeNeighbour ( neighbour->configID() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::removeNeighbour(yane::Utils::Uuid * uuid)
{
	try
	{
		removeInputNeighbour ( uuid );
		removeOutputNeighbour ( uuid );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Removing neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::setReducedNumberOfConstraints ( bool reducedNumberOfConstraints )
{
	_reducedNumberOfConstraints = reducedNumberOfConstraints;
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::updateInputNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, int precedesteps )
{
	if ( _mpc->problem() != 0 )
	{
		bool update = false;
		int counter = 0;
		int networksize = _inputNeighbours.size();
		while ( !update && counter < networksize )
		{
			if ( _inputNeighbours[counter].uuid == uuid )
			{
				update = true;
				if ( _inputNeighbours[counter].horizon != horizon || _inputNeighbours[counter].precedesteps != precedesteps )
				{
					_inputNeighbours[counter].horizon = horizon;
					_inputNeighbours[counter].precedesteps = precedesteps;
					_inputNeighbourTimesteps[counter].resize ( precedesteps + horizon + 1 );
					_inputNeighbourControl[counter].resize ( ( precedesteps + horizon ) * _inputNeighbours[counter].dimensionControl );
					_inputNeighbourState[counter].resize ( ( precedesteps + horizon + 1 ) * _inputNeighbours[counter].dimensionState );
					_resetDiscretizationRequired = true;
				}
				copy ( timesteps, timesteps + precedesteps + horizon + 1, _inputNeighbourTimesteps[counter].begin() );
				copy ( control, control + ( precedesteps + horizon ) * _inputNeighbours[counter].dimensionControl, _inputNeighbourControl[counter].begin() );
				copy ( state, state + ( precedesteps + horizon + 1 ) * _inputNeighbours[counter].dimensionState, _inputNeighbourState[counter].begin() );
			}
			counter++;
		}
		if ( !update && _displaywarnings )
		{
			throw yane::MPC::NetworkedMPCConfigWarning ( __DEBUGMESS ( "MPC controlled system to be updated is not contained in local list" ) );
		}
	}
	else
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "MPC object must be initialized, call the reset() method before this one." ) );
	}
	resetDiscretization ( _mpc->problem() );
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::updateOutputNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, int precedesteps )
{
	//TODO Output update implementieren
//  throw yane::MPC::NetworkedMPCConfigException ( __DEBUGMESS ( "Method not implemented yet" ) );
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::updateNeighbour ( NetworkedMPCConfig * neighbour, double * timesteps, double * control, double * state )
{
	try
	{
		updateNeighbour ( neighbour->configID(), neighbour->mpc()->horizon(), timesteps, control, state, neighbour->mpc()->precedesteps() );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Updating neighbour failed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::StrategyExchangeMPC::updateNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, int precedesteps )
{
	try
	{
		updateInputNeighbour ( uuid, horizon, timesteps, control, state, precedesteps );
		updateOutputNeighbour ( uuid, horizon, timesteps, control, state, precedesteps );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Updating neighbour failed" ), &e );
	}
}
