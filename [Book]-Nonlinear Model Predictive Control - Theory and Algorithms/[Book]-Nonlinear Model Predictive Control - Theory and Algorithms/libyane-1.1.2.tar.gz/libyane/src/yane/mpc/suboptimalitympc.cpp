/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "suboptimalitympc.h"
#include "exceptions.h"
#include "odemanager.h"
#include "discr.h"
#include "modelshootingdata.h"

#include "../utils.h"
#include "../odesolve.h"

#include <cstring>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::MPC::SuboptimalityMPC::SuboptimalityMPC ( double h_new, double infty ) : yane::MPC::MPC::MPC ( infty )
{
	setSingle ( true );
	setEpsilon ( 1E-6 );
	_runningcost_previous = 0.;
	_valuefunction_previous = 0.;
	_newtonIterMax = 100;
	_h_new = h_new;
	_storeValuefunction = false;
	_controlAlreadyOptimal = false;

	_valuefunction_simulated = 0;
	_valuefunction_base = 0;
	_valuefunction_predicted = 0;
	_trajectory_simulated = 0;
	_subproblem = 0;
	_subproblemcurrentvaluefunction = 0;
	_subproblemtrajectory = 0;
	_subproblemcontrol = 0;

	_x_predicted = 0;
	_u_current = 0;
	_timesteps_current = 0;
	_nextcontrols = 0;
	_nexttimesteps = 0;
}

LIB_EXPORT yane::MPC::SuboptimalityMPC::~SuboptimalityMPC ()
{
	freeValueAndTrajectory();
	freeSubproblem();
	if ( _x_predicted != 0 )
	{
		delete[] _x_predicted;
		_x_predicted = 0;
	}
	if ( _u_current != 0 )
	{
		delete[] _u_current;
		_u_current = 0;
	}
	if ( _timesteps_current != 0 )
	{
		delete[] _timesteps_current;
		_timesteps_current = 0;
	}
	if ( _nextcontrols != 0 )
	{
		delete[] _nextcontrols;
		_nextcontrols = 0;
	}
	if ( _nexttimesteps != 0 )
	{
		delete[] _nexttimesteps;
		_nexttimesteps = 0;
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::aposterioriEstimate ( double * x, double & alpha, bool saveprevious, bool restart )
{
	try
	{
		mstepAposterioriEstimate ( x, alpha, 1, saveprevious, restart );
	}
	catch ( SuboptimalityException e )
	{
		throw SuboptimalityException ( __DEBUGMESS ( "Computation of aposteriori estimate was erroneous" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Computation of aposteriori estimate was aborted on Computation" ), &e );
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::mstepAposterioriEstimate ( double * x, double & alpha, int m, bool saveprevious, bool restart )
{
	if ( x == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'x' must not be NULL" ) );
	}
	if ( m > _horizon )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'m' must not be larger than _horizon" ) );
	}

	memcpy ( _x_simulated, x, sizeof ( double ) * _model->dimensionState() );

	try
	{
		_modelsim->predictSequence ( _precedesteps, _timesteps_preceded, _x_simulated, _u_preceded );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
	}

	try
	{
		_odemanager->getObjFunValues ( _timesteps, _x_simulated, _u, _valuefunction_simulated, _trajectory_simulated );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation was aborted" ), &e );
	}

	if ( !restart )
	{
		_alpha2 = ( _valuefunction_previous - _valuefunction_simulated[_horizon - 1] ) / _runningcost_previous;

		// Standardfall
		if ( _single )
		{
			alpha = _alpha2;
		}
		else
		{
			if ( _alpha2 < alpha )
			{
				alpha = _alpha2;
			}
		}
		// Aufstieg
		if ( _valuefunction_simulated[_horizon - 1] > _valuefunction_previous )
		{
// 			alpha = 0.0;
			_valuefunction_previous = _valuefunction_simulated[_horizon - 1];
			_runningcost_previous = _valuefunction_simulated[m - 1];
			throw SuboptimalityException ( __DEBUGMESS ( "Current value function exhibits larger value than in previous step" ) );
		}
		// Verrechnet im Schritt zuvor
		else if ( _alpha2 > 1.0 )
		{
			if ( alpha > 1.0 )
			{
				alpha = 1.0;
			}
			_valuefunction_previous = _valuefunction_simulated[_horizon - 1];
			_runningcost_previous = _valuefunction_simulated[m - 1];
			throw SuboptimalityException ( __DEBUGMESS ( "Computed alpha value is greater than 1" ) );
		}
	}
	else
	{
		alpha = 1.0;
	}
	if ( saveprevious )
	{
		_valuefunction_previous = _valuefunction_simulated[_horizon - 1];
		_runningcost_previous = _valuefunction_simulated[m - 1];
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::aprioriEstimate ( double * x, double & alpha, double & gamma, int N0 )
{
	if ( x == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'x' must not be NULL" ) );
	}
	if ( N0 > _horizon )
	{
		stringstream mess;
		mess << "'N0' must not be larger than _horizon = " << _horizon << ", got " << N0;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}

	memcpy ( _x_simulated, x, sizeof ( double ) * _model->dimensionState() );

	try
	{
		_modelsim->predictSequence ( _precedesteps, _timesteps_preceded, _x_simulated, _u_preceded );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
	}

	// Extrahiere Daten Hauptproblem
	try
	{
		_odemanager->getObjFunValues ( _timesteps, _x_simulated, _u, _valuefunction_simulated, _trajectory_simulated );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation for main problem was aborted" ), &e );
	}

	// Speicherallokation Unterproblem
	allocateSubproblem ( N0 );

	_maxsubproblemcurrentrunningcost = 0.0;
	for ( int i = 2; i <= N0; i++ )
	{
		// Diskretisiere Unterproblem
		try
		{
			_subproblem = _problem->clone ( i - 1 );
		}
		catch ( MPCException e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of cloned discretized _problem was not successful" ), &e );
		}
		// Initialisiere Unterproblem
		try
		{
			_subproblem->initCalc ( &_timesteps[_horizon - i], _subproblemcontrol );
		}
		catch ( MPCException e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Initializing the discretized _problem failed" ), &e );
		}
		// Event ausloesen (Shootingknoten etc)
		if ( _shootingdata != 0 ) _shootingdata->applyShootingData ( i - 1, &_timesteps[_horizon - i], &_trajectory_simulated[ ( _horizon - i ) * _model->dimensionState() ], &_u[_maxhorizon * _model->dimensionControl() ] );

		_subproblem->setAbortSuboptimalityCriterionValues ( INFINITY );
		// Loese Unterproblem
		try
		{
			_subproblem->calc ( &_trajectory_simulated[ ( _horizon - i ) * _model->dimensionState() ] );
		}
		catch ( yane::MinProg::SolverWarning e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
		}

		// Extrahiere Daten Unterroblem
		try
		{
			_subproblem->odeManager()->getObjFunValues ( &_timesteps[_horizon - i], &_trajectory_simulated[ ( _horizon - i ) * _model->dimensionState() ], _subproblemcontrol, _subproblemcurrentvaluefunction, _subproblemtrajectory );
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation for _subproblem was aborted" ), &e );
		}
		if ( _maxsubproblemcurrentrunningcost < _subproblemcurrentvaluefunction[0] )
		{
			_maxsubproblemcurrentrunningcost = _subproblemcurrentvaluefunction[0];
		}

		// Speicherfreigabe Unterproblem
		delete _subproblem;
	}
	freeSubproblem();

	if ( _single )
	{
		gamma = -1.0e20;
	}

	// gamma aus 1. Ungleichung
	if ( gamma < ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - N0] ) / _maxsubproblemcurrentrunningcost - 1.0 )
	{
		gamma = ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - N0] ) / _maxsubproblemcurrentrunningcost - 1.0;
	}

	// gamma aus 2. Ungleichung
	for ( int i = N0 + 1; i < _horizon; i++ )
	{
		if ( gamma < ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - i] ) / ( _valuefunction_simulated[_horizon - i] - _valuefunction_simulated[_horizon - 1 - i] ) - 1.0 )
		{
			gamma = ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - i] ) / ( _valuefunction_simulated[_horizon - i] - _valuefunction_simulated[_horizon - 1 - i] ) - 1.0;
		}
	}

	// Berechnung von alpha
	_alpha2 = ( pow ( gamma + 1.0, _horizon - N0 ) - pow ( gamma, _horizon - N0 + 2 ) ) / ( pow ( gamma + 1.0, _horizon - N0 ) );

	// Ruecksetzen des Modells
	if ( _shootingdata != 0 ) _shootingdata->applyShootingData ( _horizon, _timesteps, x, &_u[_maxhorizon * _model->dimensionControl() ] );

	// Standardfall
	if ( _single )
	{
		alpha = _alpha2;
	}
	else
	{
		if ( _alpha2 < alpha )
		{
			alpha = _alpha2;
		}
	}
	// Verrechnet im Schritt zuvor
	if ( _alpha2 > 1.0 )
	{
		// Verrechnet
		if ( alpha > 1.0 )
		{
			alpha = 1.0;
		}
		throw SuboptimalityException ( __DEBUGMESS ( "Computed alpha value is greater than 1" ) );
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::aposterioriPracticalEstimate ( double * x, double & alpha, bool saveprevious, bool restart )
{
	try
	{
		mstepAposterioriPracticalEstimate ( x, alpha, 1, saveprevious, restart );
	}
	catch ( SuboptimalityException e )
	{
		throw SuboptimalityException ( __DEBUGMESS ( "Computation of aposteriori estimate was erroneous" ), &e );
	}
	catch ( PracticalException e )
	{
		throw PracticalException ( __DEBUGMESS ( "Computation of aposteriori estimate was aborted due to reaching practical stability region" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Computation of aposteriori estimate was aborted on Computation" ), &e );
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::mstepAposterioriPracticalEstimate ( double * x, double & alpha, int m, bool saveprevious, bool restart )
{
	if ( x == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'x' must not be NULL" ) );
	}
	if ( m > _horizon )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'m' must not be larger than _horizon" ) );
	}

	memcpy ( _x_simulated, x, sizeof ( double ) * _model->dimensionState() );

	try
	{
		_modelsim->predictSequence ( _precedesteps, _timesteps_preceded, _x_simulated, _u_preceded );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
	}

	try
	{
		_odemanager->getObjFunValues ( _timesteps, _x_simulated, _u, _valuefunction_simulated, _trajectory_simulated );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation for main problem was aborted" ), &e );
	}

	if ( !restart )
	{
		_alpha2 = ( _valuefunction_previous - _valuefunction_simulated[_horizon - 1] ) / ( _runningcost_previous - m * _epsilon );

		// praktische Menge erreicht
		if ( _runningcost_previous < m * _epsilon )
		{
			if ( _single )
			{
				alpha = 1.;
			}
			else
			{
				if ( alpha > 1.0 )
				{
					alpha = 1.0;
				}
			}
			_valuefunction_previous = _valuefunction_simulated[_horizon - 1];
			_runningcost_previous = _valuefunction_simulated[m - 1];
			_optimalitystate = PRACTICAL;
			throw PracticalException ( __DEBUGMESS ( "Running cost smaller than _epsilon" ) );
		}
		// Standardfall
		if ( _single )
		{
			alpha = _alpha2;
		}
		else
		{
			if ( _alpha2 < alpha )
			{
				alpha = _alpha2;
			}
		}
		// Aufstieg
		if ( _valuefunction_simulated[_horizon - 1] > _valuefunction_previous )
		{
// 			alpha = 0.0;
			_valuefunction_previous = _valuefunction_simulated[_horizon - 1];
			_runningcost_previous = _valuefunction_simulated[m - 1];
			_optimalitystate = SUBOPTIMAL;
			throw SuboptimalityException ( __DEBUGMESS ( "Current value function exhibits larger value than in previous step" ) );
		}
		// Verrechnet im Schritt zuvor
		else if ( _alpha2 > 1.0 )
		{
			if ( alpha > 1.0 )
			{
				alpha = 1.0;
			}
			_valuefunction_previous = _valuefunction_simulated[_horizon - 1];
			_runningcost_previous = _valuefunction_simulated[m - 1];
			_optimalitystate = SUBOPTIMAL;
			throw SuboptimalityException ( __DEBUGMESS ( "Computed alpha value is greater than 1" ) );
		}
	}
	else
	{
		alpha = 1.0;
	}
	if ( saveprevious )
	{
		_valuefunction_previous = _valuefunction_simulated[_horizon - 1];
		_runningcost_previous = _valuefunction_simulated[m - 1];
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::aprioriPracticalEstimate ( double * x, double & alpha, double & gamma, int N0 )
{
	bool notfulfilled = false;
	if ( x == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'x' must not be NULL" ) );
	}
	if ( N0 > _horizon )
	{
		stringstream mess;
		mess << "'N0' must not be larger than _horizon = " << _horizon << ", got " << N0;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}

	memcpy ( _x_simulated, x, sizeof ( double ) * _model->dimensionState() );

	try
	{
		_modelsim->predictSequence ( _precedesteps, _timesteps_preceded, _x_simulated, _u_preceded );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
	}

	// Extrahiere Daten Hauptproblem
	try
	{
		_odemanager->getObjFunValues ( _timesteps, _x_simulated, _u, _valuefunction_simulated, _trajectory_simulated );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation for main problem was aborted" ), &e );
	}

	// Speicherallokation Unterproblem
	allocateSubproblem ( N0 );
	_maxsubproblemcurrentrunningcost = 0.0;
	for ( int i = 2; i <= N0; i++ )
	{
		// Diskretisiere Unterproblem
		try
		{
			_subproblem = _problem->clone ( i - 1 );
		}
		catch ( MPCException e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of cloned discretized _problem was not successful" ), &e );
		}
		// Initialisiere Unterproblem
		try
		{
			_subproblem->initCalc ( &_timesteps[_horizon - i], _subproblemcontrol );
		}
		catch ( MPCException e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Initializing the discretized _problem failed" ), &e );
		}
		// Event ausloesen (Shootingknoten etc)
		if ( _shootingdata != 0 )
		{
			_shootingdata->applyShootingData ( i - 1, &_timesteps[_horizon - i], &_trajectory_simulated[ ( _horizon - i ) * _model->dimensionState() ], &_u[_maxhorizon * _model->dimensionControl() ] );
		}

		_subproblem->setAbortSuboptimalityCriterionValues ( INFINITY );
		// Loese Unterproblem
		try
		{
			_subproblem->calc ( &_trajectory_simulated[ ( _horizon - i ) * _model->dimensionState() ] );
		}
		catch ( yane::MinProg::SolverWarning e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
		}

		// Extrahiere Daten Unterproblem
		try
		{
			_subproblem->odeManager()->getObjFunValues ( &_timesteps[_horizon - i], &_trajectory_simulated[ ( _horizon - i ) * _model->dimensionState() ], _subproblemcontrol, _subproblemcurrentvaluefunction, _subproblemtrajectory );
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation for _subproblem was aborted" ), &e );
		}

		if ( _maxsubproblemcurrentrunningcost < _subproblemcurrentvaluefunction[0] )
		{
			_maxsubproblemcurrentrunningcost = _subproblemcurrentvaluefunction[0];
		}

		// Speicherfreigabe Unterproblem
		delete _subproblem;
	}
	freeSubproblem();

	if ( _single )
	{
		gamma = -1.0e20;
	}

	// gamma aus 1. Ungleichung
	if ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - N0] - _maxsubproblemcurrentrunningcost - _epsilon < 0.0 || _maxsubproblemcurrentrunningcost - ( double ( N0 ) - 1.0 ) * _epsilon < 0.0 )
	{
		notfulfilled = true;
	}
	if ( gamma < ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - N0] - _maxsubproblemcurrentrunningcost - _epsilon ) / _maxsubproblemcurrentrunningcost - ( double ( N0 ) - 1.0 ) * _epsilon )
	{
		gamma = ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - N0] - _maxsubproblemcurrentrunningcost - _epsilon ) / _maxsubproblemcurrentrunningcost - ( double ( N0 ) - 1.0 ) * _epsilon;
	}

	// gamma aus 2. Ungleichung
	for ( int i = N0 + 1; i < _horizon; i++ )
	{
		if ( gamma < ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - i] - double ( i )  * _epsilon ) / ( _valuefunction_simulated[_horizon - i] - _valuefunction_simulated[_horizon - 1 - i] - _epsilon ) - 1.0 )
		{
			gamma = ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - i] - double ( i )  * _epsilon ) / ( _valuefunction_simulated[_horizon - i] - _valuefunction_simulated[_horizon - 1 - i] - _epsilon ) - 1.0;
		}
		if ( !notfulfilled )
		{
			if ( _valuefunction_simulated[_horizon - 1] - _valuefunction_simulated[_horizon - 1 - i] - double ( i ) * _epsilon < 0.0 || _valuefunction_simulated[_horizon - i] - _valuefunction_simulated[_horizon - 1 - i] - _epsilon < 0.0 )
			{
				notfulfilled = true;
			}
		}
	}
	// Berechnung von alpha
	_alpha2 = ( pow ( gamma + 1.0, _horizon - N0 ) - pow ( gamma, _horizon - N0 + 2 ) ) / ( pow ( gamma + 1.0, _horizon - N0 ) );

	// Ruecksetzen des Modells
	if ( _shootingdata != 0 ) _shootingdata->applyShootingData ( _horizon, _timesteps, x, &_u[_maxhorizon * _model->dimensionControl() ] );


	// praktische Menge erreicht
	if ( _valuefunction_simulated[1] - _valuefunction_simulated[0] < _epsilon )
	{
		if ( _single )
		{
			alpha = 1.;
		}
		else
		{
			if ( alpha > 1.0 )
			{
				alpha = 1.0;
			}
		}
		throw PracticalException ( __DEBUGMESS ( "running cost smaller than _epsilon" ) );
	}
	// Standardfall
	if ( _single )
	{
		alpha = _alpha2;
	}
	else
	{
		if ( _alpha2 < alpha )
		{
			alpha = _alpha2;
		}
	}
	// Verrechnet
	if ( _alpha2 > 1.0 )
	{
		if ( alpha > 1.0 )
		{
			alpha = 1.0;
		}
		throw SuboptimalityException ( __DEBUGMESS ( "Computed alpha value is greater than 1" ) );
	}
	// Verletzung der Bedingungen
	if ( notfulfilled )
	{
		throw SuboptimalityException ( __DEBUGMESS ( "Assumptions for suboptimality degree are violated" ) );
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::reset ( OdeManager * odemanager, yane::MinProg::NLP * minimizer, yane::Model::Model * model, int horizon, int precedesteps, ModelShootingData * shootingdata )
{
	try
	{
		yane::MPC::MPC::reset ( odemanager, minimizer, model, horizon, precedesteps, shootingdata );
	}
	catch ( MPCException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of discretized problem was not successful" ), &e );;
	}

	try
	{
		allocateValueAndTrajectory();;
	}
	catch ( MPCException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "'failed allocating value- and trajectoryarrays" ), &e );
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::resizeHorizon ( int newhorizon, double h_new )
{
	try
	{
		yane::MPC::MPC::resizeHorizon ( newhorizon, h_new );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Resizing the _horizon failed" ), &e );
	}

	try
	{
		allocateValueAndTrajectory();
	}
	catch ( MPCException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "'failed allocating value- and trajectoryarrays" ), &e );
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::setSingle ( bool single )
{
	_single = single;
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::setEpsilon ( double epsilon )
{
	if ( epsilon < 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "epsilon must be larger than 0" ) );
	}
	_epsilon = epsilon;
}

void yane::MPC::SuboptimalityMPC::allocateSubproblem ( int N0 )
{
	freeSubproblem();

	try
	{
		_subproblemcontrol = new double[_model->dimensionControl() * ( N0 - 1 ) ];

		memcpy ( _subproblemcontrol, &_u[_model->dimensionControl() * ( _horizon - N0 - 1 ) ], sizeof ( double ) * _model->dimensionControl() * ( N0 - 1 ) );

		_subproblemtrajectory = new double[ ( N0 + 1 ) * _model->dimensionState() ];
		_subproblemcurrentvaluefunction = new double[N0];
	}
	catch ( std::bad_alloc )
	{
		freeSubproblem();
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating subproblem arrays" ) );
	}
}

void yane::MPC::SuboptimalityMPC::freeSubproblem()
{
	if ( _subproblemcontrol != 0 ) delete[] _subproblemcontrol;
	if ( _subproblemtrajectory != 0 ) delete[] _subproblemtrajectory;
	if ( _subproblemcurrentvaluefunction != 0 ) delete[] _subproblemcurrentvaluefunction;

	_subproblemcontrol = 0;
	_subproblemtrajectory = 0;
	_subproblemcurrentvaluefunction = 0;
}

void yane::MPC::SuboptimalityMPC::allocateValueAndTrajectory()
{
	freeValueAndTrajectory();
	try
	{
		_valuefunction_simulated = new double [_horizon+1];
		_valuefunction_base = new double [_horizon+1];
		_valuefunction_predicted = new double [_horizon+1];
		_trajectory_simulated = new double[ ( _horizon + 1 ) * _model->dimensionState() ];
	}
	catch ( std::bad_alloc )
	{
		freeValueAndTrajectory();
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating valuefunction and trajectory arrays" ) );
	}
}

void yane::MPC::SuboptimalityMPC::freeValueAndTrajectory()
{
	if ( _valuefunction_simulated != 0 ) delete[] _valuefunction_simulated;
	if ( _valuefunction_base != 0 ) delete[] _valuefunction_base;
	if ( _valuefunction_predicted != 0 ) delete[] _valuefunction_predicted;
	if ( _trajectory_simulated != 0 ) delete[] _trajectory_simulated;

	_valuefunction_simulated = 0;
	_valuefunction_base = 0;
	_valuefunction_predicted = 0;
	_trajectory_simulated = 0;
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::setConfigSuboptimalityMPC ( T_ESTIMATE estimate, int N0 )
{
	_estimate = estimate;
	if ( N0 < 2 && ( estimate == APRIORI || estimate == APRIORIPRACTICAL ) )
	{
		stringstream mess;
		mess << "'_N0' should be at least 2, got " << N0;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}
	_N0 = N0;
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::calcAlpha ( double * x, int realtimesteps, double aborttimeoffset )
{
	_controlAlreadyOptimal = false;
	if ( _estimate == APOSTERIORI || _estimate == APOSTERIORIPRACTICAL )
	{
		try
		{
			predictedAposterioriEstimate ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Computation of aposteriori estimate was aborted on computation" ), &e );
		}
	}
	else if ( _estimate == APRIORI || _estimate == APRIORIPRACTICAL )
	{
		if ( _horizon > 3 )
		{
			_N0 = _horizon - 1;
		}
		try
		{
			aprioriCalculatedEstimate ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Estimation Error" ), __DEBUGMESS ( "Computation of apriori estimate was aborted on computation" ), &e );
		}
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::aposterioriGamma ( int N0_local )
{
	if ( _alpha == 1.0 )
	{
		_gamma = 0.0;
	}
	else
	{
		_gamma = 1.0;
		double gamma_old = _gamma + 1.0;
		int counter = 0;
		while ( counter < _newtonIterMax && fabs ( gamma_old - _gamma ) > 1e-6 )
		{
			gamma_old = _gamma;
			_gamma = _gamma + ( 1.0 - _alpha - ( pow ( _gamma, _horizon - N0_local + 2 ) ) / pow ( _gamma + 1.0, _horizon - N0_local ) ) / ( pow ( _gamma / ( _gamma + 1 ), _horizon - N0_local + 1 ) * ( 2.0 * _gamma + ( ( double ) _horizon - N0_local ) + 2.0 ) );
			counter++;
		}
		if ( counter == _newtonIterMax && fabs ( gamma_old - _gamma ) > 1e-6 )
		{
			stringstream mess;
			mess << "more than " << _newtonIterMax << " iterations required to compute _gamma";
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Computation Error" ), __DEBUGMESS ( mess.str() ) );
		}
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::predictedAposterioriEstimate ( double * x, int realtimesteps, double aborttimeoffset )
{
	try
	{
		mstepPredictedAposterioriEstimate ( x, 1, realtimesteps, aborttimeoffset );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::mstepPredictedAposterioriEstimate ( double * x, int m, int realtimesteps, double aborttimeoffset )
{
	int shootingdatalength = 0;
	if ( _shootingdata != 0 )
	{
		shootingdatalength = _shootingdata->maxShootingDataLength ( _maxhorizon );
	}

	if ( !_controlAlreadyOptimal )
	{
		try
		{
			yane::MPC::MPC::calc ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "MPC calc() failed" ), &e );
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
		}
	}
	try
	{
		if ( _estimate == APOSTERIORI )
		{
			mstepAposterioriEstimate ( x, _alpha, m, true, true );
		}
		else if ( _estimate == APOSTERIORIPRACTICAL )
		{
			mstepAposterioriPracticalEstimate ( x, _alpha, m, true, true );
		}
	}
	catch ( SuboptimalityException e )
	{
		_optimalitystate = SUBOPTIMAL;
	}
	catch ( PracticalException e )
	{
		_optimalitystate = PRACTICAL;
	}
	catch ( yane::MinProg::SolverWarning e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( MPCException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Computation of aposteriori estimate was aborted on computation" ), &e );
	}
	if ( _storeValuefunction )
	{
		memcpy ( _valuefunction_base, _valuefunction_simulated, sizeof ( double ) * ( _horizon + 1 ) );
	}

	if ( _u_current == 0 )
	{
		try
		{
			_u_current = new double [ _model->dimensionControl() * ( _maxhorizon + _precedesteps ) + shootingdatalength ];
		}
		catch ( std::bad_alloc )
		{
			if ( _u_current != 0 )
			{
				delete[] _u_current;
				_u_current = 0;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_u_current'" ) );
		}
	}
	memcpy ( _u_current, _u_preceded, sizeof ( double ) * ( _model->dimensionControl() * ( _maxhorizon + _precedesteps ) + shootingdatalength ) );
	if ( _timesteps_current == 0 )
	{
		try
		{
			_timesteps_current = new double [ _maxhorizon + _precedesteps + 1 ];
		}
		catch ( std::bad_alloc )
		{
			if ( _timesteps_current != 0 )
			{
				delete[] _timesteps_current;
				_timesteps_current = 0;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_timesteps_current'" ) );
		}
	}
	memcpy ( _timesteps_current, _timesteps_preceded, sizeof ( double ) * ( _maxhorizon + _precedesteps + 1 ) );
	if ( _x_predicted == 0 )
	{
		try
		{
			_x_predicted = new double [ _model->dimensionState() ];
		}
		catch ( std::bad_alloc )
		{
			if ( _x_predicted != 0 )
			{
				delete[] _x_predicted;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_x_predicted'" ) );
		}
	}
	memcpy ( _x_predicted, x, sizeof ( double ) * _model->dimensionState() );
	if ( _nextcontrols != 0 )
	{
		delete[] _nextcontrols;
		_nextcontrols = 0;
	}
	if ( _nextcontrols == 0 )
	{
		try
		{
			_nextcontrols = new double [ _model->dimensionControl() * m ];
		}
		catch ( std::bad_alloc )
		{
			if ( _nextcontrols != 0 )
			{
				delete[] _nextcontrols;
				_nextcontrols = 0;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_nextcontrols'" ) );
		}
	}
	if ( _nexttimesteps != 0 )
	{
		delete[] _nexttimesteps;
		_nexttimesteps = 0;
	}
	if ( _nexttimesteps == 0 )
	{
		try
		{
			_nexttimesteps = new double [ m + 1 ];
		}
		catch ( std::bad_alloc )
		{
			if ( _nexttimesteps != 0 )
			{
				delete[] _nexttimesteps;
				_nexttimesteps = 0;
			}
			throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_nexttimesteps'" ) );
		}
	}

	// Shift by one but predict by _precedesteps + m to avoid calling yane::MPC::MPC::calc which would possibly update tracking signal
	try
	{
		yane::MPC::MPC::shiftHorizon ( _nextcontrols, _nexttimesteps, m, _x_predicted, _h_new );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Error during Shift occured" ), &e );
	}
	try
	{
		_modelsim->predictSequence ( _precedesteps + m, _timesteps_current, _x_predicted, _u_current );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
	}

	try
	{
		_optimalitystate = OK;
		_problem->calc ( _x_predicted, realtimesteps, aborttimeoffset );
	}
	catch ( yane::MinProg::SolverWarning e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
	}

	// Re-predict for suboptimalty _estimate
	memcpy ( _x_predicted, x, sizeof ( double ) * _model->dimensionState() );
	try
	{
		_modelsim->predictSequence ( m, _timesteps_current, _x_predicted, _u_current );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
	}
	try
	{
		if ( _estimate == APOSTERIORI )
		{
			mstepAposterioriEstimate ( _x_predicted, _alpha, m, false, false );
		}
		else if ( _estimate == APOSTERIORIPRACTICAL )
		{
			mstepAposterioriPracticalEstimate ( _x_predicted, _alpha, m, false, false );
		}
	}
	catch ( SuboptimalityException e )
	{
		_optimalitystate = SUBOPTIMAL;
	}
	catch ( PracticalException e )
	{
		_optimalitystate = PRACTICAL;
	}
	catch ( yane::MinProg::SolverWarning e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( MPCException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Calculation of the estimation for the auxilliary optimal control problem may be erroneous" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Computation of aposteriori estimate was aborted on computation of the auxilliary optimal control problem" ), &e );
	}

	if ( _storeValuefunction )
	{
		memcpy ( _valuefunction_predicted, _valuefunction_simulated, sizeof ( double ) * ( _horizon + 1 ) );
	}
	memcpy ( _timesteps_preceded, _timesteps_current, sizeof ( double ) * ( _maxhorizon + _precedesteps + 1 ) );
	memcpy ( _u_preceded, _u_current, sizeof ( double ) * ( _model->dimensionControl() * ( _maxhorizon + _precedesteps ) + shootingdatalength ) );
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::aprioriCalculatedEstimate ( double * x, int realtimesteps, double aborttimeoffset )
{
	if ( !_controlAlreadyOptimal )
	{
		try
		{
			yane::MPC::MPC::calc ( x, realtimesteps, aborttimeoffset );
		}
		catch ( yane::MinProg::SolverWarning e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
			}
		}
		catch ( MPCException e )
		{
			throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "MPC calc() failed" ), &e );
		}
		catch ( yane::Utils::Exception e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
		}
	}
	try
	{
		if ( _estimate == APRIORI )
		{
			aprioriEstimate ( x, _alpha, _gamma, _N0 );
		}
		else if ( _estimate == APRIORIPRACTICAL )
		{
			aprioriPracticalEstimate ( x, _alpha, _gamma, _N0 );
		}
	}
	catch ( SuboptimalityException e )
	{
		_optimalitystate = SUBOPTIMAL;
	}
	catch ( PracticalException e )
	{
		_optimalitystate = PRACTICAL;
	}
	catch ( yane::MinProg::SolverWarning e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( MPCException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Calculation of the estimation may be erroneous" ), &e );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Computation of aposteriori estimate was aborted on computation" ), &e );
	}
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::setNewtonItermax ( int newtonitermax )
{
	_newtonIterMax = newtonitermax;
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::setSamplingLength ( double h_new )
{
	if ( h_new < 0.0 )
	{
		stringstream mess;
		mess << "'h_new' must be greater then zero, got " << h_new;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}
	else if ( h_new == 0.0 )
	{
		_h_new = _timesteps[_horizon] - _timesteps[_horizon-1];
	}
	else
	{
		_h_new = h_new;
	}
}

LIB_EXPORT double yane::MPC::SuboptimalityMPC::samplingLength()
{
	return _h_new;
}

LIB_EXPORT void yane::MPC::SuboptimalityMPC::setStoreValuefunction( bool storeValuefunction )
{
	_storeValuefunction = storeValuefunction;
}

LIB_EXPORT double yane::MPC::SuboptimalityMPC::alpha()
{
	return _alpha;
}
