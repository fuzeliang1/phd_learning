/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "mpc.h"
#include "exceptions.h"
#include "discr.h"
#include "modelshootingdata.h"
#include "odemanager.h"
#include "networkedmpcconfig.h"

#include "../utils.h"
#include "../odesolve.h"
#include "../model.h"

#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iomanip>
#include <sstream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::MPC::MPC::MPC ( double infty, NetworkedMPCConfig * configuration )
{
	_maxhorizon = 0;
	_horizon = 0;
	_model = 0;
	_problem = 0;
	_timesteps = 0;
	_timesteps_preceded = 0;
	_u = 0;
	_u_preceded = 0;
	_x_simulated = 0;
	_precedesteps = 0;
	_modelsim = 0;
	_modelsimconfig = 0;
	_rtolvec = 0;
	_atolvec = 0;
	_shootingdata = 0;

	_infty = infty;
	_configuration = configuration;
	if ( _configuration != 0 )
	{
		_configuration->setMPCPointer ( this );
	}
	_problem_shift = 0;

	_minimizer = 0;
	_odemanager = 0;

	_showsqperror = true;
	_abortsuboptimalitydegree = INFINITY;
	_optimize = STANDARD;
	_returndata = PREDICTED_DATA;
	_optimalitystate = OK;
}

LIB_EXPORT yane::MPC::MPC::~ MPC()
{
	freeMem();
}

LIB_EXPORT void yane::MPC::MPC::freeMem()
{
	if ( _problem != 0 )
		delete _problem;
	if ( _problem_shift != 0 )
		delete _problem_shift;
	if ( _modelsim != 0 )
		delete _modelsim;
	if ( _modelsimconfig != 0 )
		delete _modelsimconfig;
	if ( _atolvec != 0 )
		delete[] _atolvec;
	if ( _rtolvec != 0 )
		delete[] _rtolvec;
	if ( _x_simulated != 0 )
		delete[] _x_simulated;

	_problem = 0;
	_problem_shift = 0;
	_modelsim = 0;
	_modelsimconfig = 0;
	_rtolvec = 0;
	_atolvec = 0;
	_x_simulated = 0;
}

LIB_EXPORT void yane::MPC::MPC::reset ( OdeManager * odemanager, yane::MinProg::NLP * minimizer, yane::Model::Model * model, int horizon, int precedesteps, ModelShootingData * shootingdata )
{
	if ( odemanager == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'_odemanager' must not be NULL" ) );
	}
	if ( minimizer == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'_minimizer' must not be NULL" ) );
	}
	if ( model == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'_model' must not be NULL" ) );
	}
	if ( precedesteps < 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'_precedesteps' must be > 0" ) );
	}
	if ( horizon < 1 )
	{
		stringstream mess;
		mess << "'_horizon' must be greater then zero, got " << horizon;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}

	_shootingdata = shootingdata;

	freeMem();

	_maxhorizon = _horizon = horizon;
	_precedesteps = precedesteps;
	_model = model;
	_minimizer = minimizer;
	_odemanager = odemanager;

	try
	{
		_modelsim = new yane::Model::Simulator ( _model );
		_x_simulated = new double[_model->dimensionState() ];
		_problem = new yane::MPC::Discretization ( _odemanager, _minimizer, _model, _horizon, _shootingdata, _infty );
	}
	catch ( yane::MinProg::MinProgException & e )
	{
		throw yane::MinProg::MinProgException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of discretized _problem was not successful" ), &e );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of discretized _problem was not successful" ), &e );
	}
	catch ( std::bad_alloc & )
	{
		freeMem();

		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating memory" ) );
	}
	this->_problem->setAbortSuboptimalityCriterionValues ( INFINITY, 0.0, 0.0 );

	if ( _configuration != 0 )
	{
		try
		{
			_configuration->setResetDiscretization ( true );
			_configuration->resetDiscretization ( _problem );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Resetting the discretized problem was not successful" ), &e );
		}
	}
}

LIB_EXPORT void yane::MPC::MPC::initCalc ( double * timesteps, double * u )
{
	if ( timesteps == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'_timesteps' must not be NULL" ) );
	}
	if ( u == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'_u' must not be NULL" ) );
	}

	if ( _problem == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the reset() method before this one." ) );
	}

	_timesteps_preceded = timesteps;
	_timesteps = & ( _timesteps_preceded[_precedesteps] );
	_u_preceded = u;
	_u = & ( _u_preceded[_precedesteps*_model->dimensionControl() ] );


	_problem->initCalc ( _timesteps, _u );
}

LIB_EXPORT void yane::MPC::MPC::calc ( double * x, int realtimesteps, double aborttimeoffset, double abortsuboptimalitydegree )
{
	if ( x == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'x' must not be NULL" ) );
	}

	if ( _problem == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the reset() method before this one." ) );
	}
	_abortsuboptimalitydegree = abortsuboptimalitydegree;

	// _precedesteps Ueberspringen
	memcpy ( _x_simulated, x, sizeof ( double ) * _model->dimensionState() );

	try
	{
		_modelsim->predictSequence ( _precedesteps, _timesteps_preceded, _x_simulated, _u_preceded );
	}
	catch ( yane::OdeSolve::OdeSolEx & e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
	}

	if ( _shootingdata != 0 )
	{
		_shootingdata->applyShootingData ( _horizon, _timesteps, _x_simulated, &_u[_maxhorizon * _model->dimensionControl() ] );
	}
	_model->eventBeforeMPC ( _horizon, _timesteps, _x_simulated, &_u[_maxhorizon * _model->dimensionControl() ] );

	try
	{
		_optimalitystate = OK;
		_problem->calc ( _x_simulated, realtimesteps, aborttimeoffset );
	}
	catch ( yane::MinProg::SolverWarning & e )
	{
		_optimalitystate = SQPBROKEN;
		if ( _showsqperror )
		{
			throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Minimization routine failed" ), &e );
		}
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
	}
}

LIB_EXPORT void yane::MPC::MPC::resizeHorizon ( int newhorizon, double h_new )
{
	if ( newhorizon < 1 )
	{
		stringstream mess;
		mess << "'newhorizon' must be greater then zero, got " << newhorizon;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}

	if ( h_new <= 0.0 )
	{
		stringstream mess;
		mess << "'h_new' must be greater then zero, got " << h_new;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}

	if ( _problem == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( " object must be initialized, call the reset() method before this one." ) );
	}
	if ( newhorizon > _maxhorizon )
	{
		stringstream mess;
		mess << "new horizonlength (=" << newhorizon << ") exceeds maximum length of " << _maxhorizon;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}

	if ( _timesteps == 0 || _u == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the initCalc() method before this one." ) );
	}
	if ( newhorizon > _horizon )
	{
		for ( int i = _horizon + 1; i < newhorizon + 1; i++ )
		{
			_timesteps[i] = _timesteps[_horizon] + ( double ( i - _horizon ) ) * h_new;
			if ( i != newhorizon )
			{
				_model->getDefaultControl ( & _u[i * _model->dimensionControl() ] );
			}
		}
	}
	_horizon = newhorizon;

	delete _problem;
	_problem = 0;

	try
	{
		_problem = new yane::MPC::Discretization ( _odemanager, _minimizer, _model, _horizon, _shootingdata, _infty );
	}
	catch ( yane::MinProg::MinProgException & e )
	{
		throw yane::MinProg::MinProgException ( __EXCEPTIONMESS ( yane::MinProg::MinProgException::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of discretized problem was not successful" ), &e );;
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of discretized problem was not successful" ), &e );
	}
	catch ( std::bad_alloc & )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed creating '_problem'" ) );
	}

	_problem->initCalc ( _timesteps, _u );

	if ( _configuration != 0 )
	{
		try
		{
			_configuration->setResetDiscretization ( true );
			_configuration->resetDiscretization ( _problem );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Resizing the discretized problem was not successful" ), &e );
		}
	}
}

LIB_EXPORT void yane::MPC::MPC::shiftHorizon ( double * nextControls, double * nextTimesteps, int m, double * x, double h_new )
{
	if ( _problem == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "Object must be initialized, call the reset() method before this one." ) );
	}

	if ( nextControls == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'nextControls' must not be NULL" ) );
	}
	if ( nextTimesteps == 0 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'nextTimesteps' must not be NULL" ) );
	}
	if ( m > _horizon )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'m' must not be greater than the number of control instances N" ) );
	}
	else if ( m < 1 )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'m' must not be smaller than one" ) );
	}
	if ( x == 0 && ( _optimize == ONESTEP || _optimize == REPEATED ) )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'x' must not be NULL if optimization-based shift is to be used" ) );
	}
	if ( h_new < 0.0 )
	{
		stringstream mess;
		mess << "'h_new' must be greater then zero, got " << h_new;
		throw yane::Utils::ValueException ( __DEBUGMESS ( mess.str() ) );
	}

	if ( h_new == 0.0 )
	{
		h_new = _timesteps[_horizon] - _timesteps[_horizon-1];
	}

	if ( _abortsuboptimalitydegree < INFINITY )
	{
		try
		{
			setAbortSuboptimalityValues ( x );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Resetting the suboptimality abortion criterion was aborted" ), &e );
		}
	}

	int dimension_u = _model->dimensionControl();

	if ( _optimize == STANDARD || _optimize == ONESTEP )
	{
		if ( _optimize == ONESTEP )
		{
			// Zustand bis vor neu zu berechnenden Block praedizieren
			memcpy ( _x_simulated, x, sizeof ( double ) *_model->dimensionState() );
			try
			{
				_modelsim->predictSequence ( _precedesteps + _horizon - m, _timesteps_preceded, _x_simulated, _u_preceded );
			}
			catch ( yane::OdeSolve::OdeSolEx & e )
			{
				throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
			}
			catch ( yane::Utils::Exception & e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
			}
		}

		// Horizont verschieben
		if ( _returndata == CURRENT_DATA )
		{
			memcpy ( nextControls, _u_preceded, sizeof ( double ) * dimension_u * m );
			memcpy ( nextTimesteps, _timesteps_preceded, sizeof ( double ) * ( m + 1 ) );
		}
		else if ( _returndata == PREDICTED_DATA )
		{
			memcpy ( nextControls, _u, sizeof ( double ) * dimension_u * m );
			memcpy ( nextTimesteps, _timesteps, sizeof ( double ) * ( m + 1 ) );
		}
		memmove ( _u_preceded, &_u_preceded[dimension_u * m], sizeof ( double ) * dimension_u * ( _horizon + _precedesteps - m ) );
		memmove ( _timesteps_preceded, &_timesteps_preceded[m], sizeof ( double ) * ( _horizon + _precedesteps - m + 1 ) );

		for ( int i = _horizon - m + 1; i < _horizon + 1; i++ )
		{
			_timesteps[i] = _timesteps[i-1] + h_new;
		}

		_optimalitystate = OK;

		// ggf. Neue Steuerungen quasi optimal bestimmen
		if ( _optimize == ONESTEP )
		{
			// Subproblem anlegen
			try
			{
				if ( _problem_shift == 0 )
				{
					_problem_shift = _problem->clone ( m );
				}
				else
					if ( _problem_shift->horizon() != m )
					{
						delete _problem_shift;
						_problem_shift = _problem->clone ( m );
					}
			}
			catch ( yane::Utils::Exception & e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of cloned discretized _problem was not successful" ), &e );
			}
			catch ( std::bad_alloc & )
			{
				throw yane::Utils::MemoryException ( __DEBUGMESS ( " '_problem_shift' could not be allocated" ) );
			}
			if ( _configuration != 0 )
			{
				try
				{
					_configuration->setResetDiscretization ( true );
					_configuration->resetDiscretization ( _problem_shift );
				}
				catch ( yane::Utils::Exception & e )
				{
					throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Resetting the discretized problem was not successful" ), &e );
				}
			}

			// Und letzte m Schritte neu optimieren
			_problem_shift->initCalc ( &_timesteps[_horizon - m], &_u[dimension_u * ( _horizon - m ) ] );
			_problem_shift->setAbortSuboptimalityCriterionValues ( INFINITY );
			try
			{
				_problem_shift->calc ( _x_simulated );
			}
			catch ( yane::MinProg::SolverWarning & e )
			{
				_optimalitystate = SQPBROKEN;
				if ( _showsqperror )
				{
					throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Additional optimization _problem could not be solved" ), &e );
				}
			}
			catch ( yane::Utils::Exception & e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
			}
		}
	}
	else if ( _optimize == REPEATED )
	{
		_optimalitystate = OK;

		// Zustand bis vor neu zu berechnenden Block praedizieren
		memcpy ( _x_simulated, x, sizeof ( double ) * _model->dimensionState() );
		try
		{
			_modelsim->predictSequence ( _precedesteps + m, _timesteps_preceded, _x_simulated, _u_preceded );
		}
		catch ( yane::OdeSolve::OdeSolEx & e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
		}

		if ( _returndata == CURRENT_DATA )
		{
			memcpy ( nextControls, _u_preceded, sizeof ( double ) * dimension_u * m );
			memcpy ( nextTimesteps, _timesteps_preceded, sizeof ( double ) * ( m + 1 ) );
		}
		else if ( _returndata == PREDICTED_DATA )
		{
			memcpy ( nextControls, _u, sizeof ( double ) * dimension_u * m );
			memcpy ( nextTimesteps, _timesteps, sizeof ( double ) * ( m + 1 ) );
		}
		memmove ( _u_preceded, &_u_preceded[dimension_u * m], sizeof ( double ) * dimension_u * ( _horizon + _precedesteps - m ) );
		memmove ( _timesteps_preceded, &_timesteps_preceded[m], sizeof ( double ) * ( _horizon + _precedesteps - m + 1 ) );

		for ( int i = _horizon - m + 1; i < _horizon + 1; i++ )
		{
			_timesteps[i] = _timesteps[i - 1] + h_new;
		}

		for ( int length = _horizon - m; length < _horizon; length++ )
		{
			if ( _problem_shift != 0 )
			{
				delete _problem_shift;
				_problem_shift = 0;
			}
			// Subproblem anlegen
			try
			{
				_problem_shift = _problem->clone ( length );
			}
			catch ( yane::Utils::Exception & e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of cloned discretized _problem was not successful" ), &e );
			}
			catch ( std::bad_alloc & )
			{
				throw yane::Utils::MemoryException ( __DEBUGMESS ( " '_problem_shift' could not be allocated" ) );
			}
			if ( _configuration != 0 )
			{
				try
				{
					_configuration->setResetDiscretization ( true );
					_configuration->resetDiscretization ( _problem_shift );
				}
				catch ( yane::Utils::Exception & e )
				{
					throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Resetting the discretized problem was not successful" ), &e );
				}
			}

			_problem_shift->initCalc ( _timesteps, _u );
			_problem_shift->setAbortSuboptimalityCriterionValues ( INFINITY );
			try
			{
				_problem_shift->calc ( _x_simulated );
			}
			catch ( yane::MinProg::SolverWarning & e )
			{
				_optimalitystate = SQPBROKEN;
				if ( _showsqperror )
				{
					throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Additional optimization _problem could not be solved" ), &e );
				}
			}
			catch ( yane::Utils::Exception & e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
			}
		}
		if ( _problem_shift != 0 )
		{
			delete _problem_shift;
			_problem_shift = 0;
		}

		// Letzten Schritt nocheinzeln optimieren
		try
		{
			_modelsim->predictSequence ( _horizon - 1, _timesteps, _x_simulated, _u );
		}
		catch ( yane::OdeSolve::OdeSolEx & e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "ODE solver could not precede steps" ) );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
		}
		try
		{
			_problem_shift = _problem->clone ( 1 );
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of cloned discretized _problem was not successful" ), &e );
		}
		catch ( std::bad_alloc & )
		{
			throw yane::Utils::MemoryException ( __DEBUGMESS ( " '_problem_shift' could not be allocated" ) );
		}
		if ( _configuration != 0 )
		{
			try
			{
				_configuration->setResetDiscretization ( true );
				_configuration->resetDiscretization ( _problem_shift );
			}
			catch ( yane::Utils::Exception & e )
			{
				throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Resetting the discretized problem was not successful" ), &e );
			}
		}

		_problem_shift->initCalc ( &_timesteps[_horizon - 1], &_u[dimension_u * ( _horizon - 1 ) ] );
		_problem_shift->setAbortSuboptimalityCriterionValues ( INFINITY );
		try
		{
			_problem_shift->calc ( _x_simulated );
		}
		catch ( yane::MinProg::SolverWarning & e )
		{
			_optimalitystate = SQPBROKEN;
			if ( _showsqperror )
			{
				throw yane::MinProg::SolverWarning ( __DEBUGMESS ( "Additional optimization _problem could not be solved" ), &e );
			}
		}
		catch ( yane::Utils::Exception & e )
		{
			throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
		}
		if ( _problem_shift != 0 )
		{
			delete _problem_shift;
			_problem_shift = 0;
		}
	}
}

LIB_EXPORT void yane::MPC::MPC::setInternalSimulatorPrecision ( double rtol, double atol )
{
	if ( _rtolvec != 0 )
	{
		delete[] _rtolvec;
		_rtolvec = 0;
	}
	if ( _atolvec != 0 )
	{
		delete[] _atolvec;
		_atolvec = 0;
	}

	try
	{
		_rtolvec = new double[_model->dimensionState() ];
		_atolvec = new double[_model->dimensionState() ];
	}
	catch ( std::bad_alloc & )
	{
		if ( _rtolvec != 0 )
			delete[] _rtolvec;
		if ( _atolvec != 0 )
			delete[] _atolvec;

		throw yane::Utils::MemoryException ( __DEBUGMESS ( "tolerance vectors have not been allocated" ) );
	}

	for ( int i = 0; i < _model->dimensionState(); i++ )
	{
		_rtolvec[i] = rtol;
		_atolvec[i] = atol;
	}

	try
	{
		setInternalSimulatorPrecision ( _rtolvec, _atolvec );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "failed setting tolerances" ), &e );
	}
	catch ( std::bad_alloc & )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed setting tolerances" ) );
	}
}

LIB_EXPORT void yane::MPC::MPC::setInternalSimulatorPrecision ( double * rtol, double * atol )
{
	delete _modelsim;
	if ( _modelsimconfig != 0 )
		delete _modelsimconfig;
	_modelsim = 0;
	_modelsimconfig = 0;

	try
	{
		if ( atol == 0 || rtol == 0 )
		{
			_modelsim = new yane::Model::Simulator ( _model );
		}
		else
		{
			_modelsimconfig = _model->odeConfig()->clone();
			_modelsimconfig->setToleranceVector ( rtol, atol );

			_modelsim = new yane::Model::Simulator ( _model, _modelsimconfig );
		}
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "failed creating a simulator" ), &e );
	}
	catch ( std::bad_alloc & )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed create a simulator" ) );
	}
}

LIB_EXPORT void yane::MPC::MPC::setConfigShiftHorizon ( T_SHIFTSTATE optimize, T_SHIFTRETURNDATA returndata )
{
	if ( _modelsim == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the reset() method before this one." ) );
	}

	if ( optimize != STANDARD && optimize != ONESTEP && optimize != REPEATED )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'_optimize' must be 'STANDARD', 'ONESTEP' or 'REPEATED'" ) );
	}
	_optimize = ( T_SHIFTSTATE ) optimize;

	if ( returndata != CURRENT_DATA && returndata != PREDICTED_DATA )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "'_returndata' must be 'CURRENT_DATA' or 'PREDICTED_DATA'" ) );
	}
	_returndata = ( T_SHIFTRETURNDATA ) returndata;
}

LIB_EXPORT void yane::MPC::MPC::allocateMemory ( double *& t, double *& u )
{
	if ( _problem == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the () method before this one." ) );
	}

	t = 0;
	u = 0;

	int shootingdatalength = ( _shootingdata == 0 ? 0 : _shootingdata->maxShootingDataLength ( _maxhorizon ) );

	try
	{
		t = new double [ _maxhorizon+_precedesteps + 1 ];
		u = new double [ _model->dimensionControl() * ( _maxhorizon+_precedesteps ) + shootingdatalength ];

		for ( int i = 0; i < _maxhorizon + _precedesteps; i++ )
		{
			_model->getDefaultControl ( &u[i*_model->dimensionControl() ] );
		}
	}
	catch ( std::bad_alloc & )
	{
		if ( t != 0 )
			delete[] t;
		if ( u != 0 )
			delete[] u;

		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating 't' or 'u'" ) );
	}

}

LIB_EXPORT void yane::MPC::MPC::setShowSqpError ( bool _showsqperror )
{
	this->_showsqperror = _showsqperror;
}

LIB_EXPORT yane::Model::Model * yane::MPC::MPC::model()
{
	if ( _model == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the reset() method before this one." ) );
	}
	return _model;
}

LIB_EXPORT int yane::MPC::MPC::maxHorizon()
{
	if ( _problem == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the reset() method before this one." ) );
	}
	return _maxhorizon;
}

LIB_EXPORT void yane::MPC::MPC::generateTimeGrid ( double * t, double t_start, double h_new )
{
	if ( _problem == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the reset() method before this one." ) );
	}

	t[0] = t_start;
	for ( int i = 1; i < _maxhorizon + _precedesteps + 1; i++ )
	{
		t[i] = t[i-1] + h_new;
	}
}

LIB_EXPORT int yane::MPC::MPC::horizon()
{
	if ( _problem == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the reset() method before this one." ) );
	}
	return _horizon;
}

LIB_EXPORT yane::MPC::T_OPTIMALITYSTATE yane::MPC::MPC::optimalitystate ( )
{
	return _optimalitystate;
}

LIB_EXPORT void yane::MPC::MPC::setAbortSuboptimalityValues ( double * x )
{
	double * suboptimalityValueFunction = new double [ _horizon + 1 ];
	double * suboptimalityTrajectory = new double [ ( _horizon + 1 ) * _model->dimensionState() ];

	try
	{
		_odemanager->getObjFunValues ( _timesteps, x, _u, suboptimalityValueFunction, suboptimalityTrajectory );
	}
	catch ( yane::Utils::Exception & e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Computing the cost functional values was aborted" ), &e );
	}

	_problem->setAbortSuboptimalityCriterionValues ( _abortsuboptimalitydegree, suboptimalityValueFunction[_horizon - 1], suboptimalityValueFunction[0] );

	delete[] suboptimalityValueFunction;
	delete[] suboptimalityTrajectory;
}

LIB_EXPORT int yane::MPC::MPC::precedesteps()
{
	if ( _problem == 0 )
	{
		throw yane::Utils::NotInitializedException ( __DEBUGMESS ( "object must be initialized, call the reset() method before this one." ) );
	}
	return _precedesteps;
}

LIB_EXPORT yane::MPC::Discretization * yane::MPC::MPC::problem()
{
	return _problem;
}

LIB_EXPORT yane::Model::Simulator * yane::MPC::MPC::modelsim()
{
	return _modelsim;
}
