/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "syncodemanager.h"
#include "cache.h"
#include "exceptions.h"

#include "../utils.h"
#include "../odesolve.h"

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iomanip>

#include "libexport.h"

LIB_EXPORT yane::MPC::SyncOdeManager::SyncOdeManager()
{
	_dgl = 0;
	_ode = 0;
	_model = 0;

	_x = 0;
	_data = 0;
	_cache = 0;

	try
	{
		_data = new T_MPCDATA;
	} catch (std::bad_alloc)
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating '_data'" ) );
	}

	_data->odemanager = this;
	_data->u = 0;
	_mass = 0;
	_diffmass = 0;

	_tempx = 0;
	_tempr1 = 0;
	_tempr2 = 0;

	_xdiff = 0;
	_udiff = 0;
	_diffdgl = 0;
	_diffode = 0;

	_weightcf = 0.0;
	_weightint = 1.0;
	_pcf_x = 0;
	_oldhoriz = -1;
	_horizont = -1;
}

void yane::MPC::SyncOdeManager::freeMem()
{
	if ( _dgl != 0 ) delete _dgl;
	if ( _ode != 0 ) delete _ode;
	if ( _diffdgl != 0 ) delete _diffdgl;
	if ( _diffode != 0 ) delete _diffode;
	if ( _x != 0 ) delete _x;
	if ( _xdiff != 0 ) delete _xdiff;
	if ( _udiff != 0 ) delete _udiff;
	if ( _tempx != 0 ) delete _tempx;
	if ( _tempr1 != 0 ) delete _tempr1;
	if ( _tempr2 != 0 ) delete _tempr2;
	if ( _pcf_x != 0 ) delete _pcf_x;
	if ( _mass != 0 ) delete _mass;
	if ( _diffmass != 0 ) delete _diffmass;
	if ( _cache != 0) delete _cache;

	_dgl = 0;
	_ode = 0;
	_diffdgl = 0;
	_diffode = 0;
	_x = 0;
	_xdiff = 0;
	_udiff = 0;
	_tempx = 0;
	_tempr1 = 0;
	_tempr2 = 0;
	_pcf_x = 0;
	_mass = 0;
	_diffmass = 0;
	_cache = 0;
}

LIB_EXPORT yane::MPC::SyncOdeManager::~ SyncOdeManager()
{
	freeMem();

	delete _data;
}

LIB_EXPORT void yane::MPC::SyncOdeManager::setFunctions ( int horizont_pre, int total_restr,  yane::Model::Model * model_pre, T_DISCRRESTRFUNC restrfunc, int sdatalength_pre, T_SHOOTINGDATA * sdata_pre )
{
	stringstream mess;
	double * tempmass = 0;

	freeMem();

	_model = model_pre;
	_dimension = _model->dimensionState();
	_dimension_u = _model->dimensionControl();
	_horizont = horizont_pre;
	_dim_restr = total_restr;
	_restrfunction = restrfunc;
	_sdata = sdata_pre;
	_sdatalength = sdatalength_pre;

	freeMem();
	try
	{
		_cache = new Cache(_horizont, _model, _sdata, _sdatalength, Cache::SYNCMODE);
		_mass = new double [( _dimension + 1 ) * ( _dimension + 1 )];
		_diffmass = new double [2 * ( _dimension + 1 ) * 2 *( _dimension + 1 )];
		_dgl = new yane::OdeSolve::OdeFunction ( combinedOdeSystem, _dimension + 1 );
		_diffdgl = new yane::OdeSolve::OdeFunction ( diffCombinedOdeSystem, 2 * ( _dimension + 1 ) );
		_ode = _model->odeSolver()->clone();
		_diffode = _model->odeSolver()->clone();
		_x = new double [_dimension + 1];
		_xdiff = new double [ ( _dimension + 1 ) * 2];
		_udiff = new double [ ( _dimension_u * _horizont + _sdatalength ) * 2 ];
		_tempx = new double [ _dimension * _horizont ];
		_pcf_x = new double [ _dimension * ( _horizont + 1 ) ];
		_tempr1 = new double [ _dim_restr ];
		_tempr2 = new double [ _dim_restr ];
		tempmass = new double [_dimension*_dimension];
	}
	catch (std::bad_alloc)
	{
		if (tempmass != 0) delete tempmass;

		freeMem();

		throw yane::Utils::MemoryException( __DEBUGMESS( "failed allocating memory" ));
	}

	try
	{
		_model->massMatrix ( tempmass );

		memset ( _mass, 0, sizeof ( double ) * 2 * ( _dimension + 1 ) * 2 *( _dimension + 1 ) );
		memset ( _diffmass, 0, sizeof ( double ) * ( _dimension + 1 ) * ( _dimension + 1 ) );

		_mass[(_dimension + 1) * (_dimension + 1) - 1] = 1.0;

		_diffmass[2*(_dimension + 1) * _dimension + _dimension] = 1.0;
		_diffmass[2*(_dimension + 1) * 2 * (_dimension + 1) - 1] = 1.0;

		for ( int i = 0; i < _dimension; i++ )
		{
			memcpy(&_mass[i*(_dimension+1)], &tempmass[i*_dimension], sizeof(double)*_dimension);

			memcpy(&_diffmass[i*2*(_dimension+1)], &tempmass[i*_dimension], sizeof(double)*_dimension);
			memcpy(&_diffmass[(i + _dimension+1)*2*(_dimension+1) + _dimension+1], &tempmass[i*_dimension], sizeof(double)*_dimension);
		}
		_dgl->setMassMatrix ( combinedMassMatrix );
		_diffdgl->setMassMatrix ( diffCombinedMassMatrix );
	}
	catch ( yane::Model::UndefinedException ){}

	delete tempmass;

	try
	{
		_ode->reset ( _dgl, _model->odeConfig() );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Reset of the _ode solver failed" ), &e );
	}

	try
	{
		_diffode->reset ( _diffdgl, _model->odeConfig() );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Reset of the _ode solver failed" ), &e );
	}

	_model->getObjectiveWeight ( _weightint, _weightcf );


}

void yane::MPC::SyncOdeManager::combinedOdeSystem ( int * n, double * t, double * y, double * dy, double * rpar, int * ipar )
{
	T_MPCDATA * _data = ( T_MPCDATA* ) rpar;
	SyncOdeManager * baseobject = ( SyncOdeManager* ) _data->odemanager;

	baseobject->_model->odeFunction ( *t, y, _data->u, dy );
	dy[baseobject->_dimension] = baseobject->_model->continuousCostfunction ( *t, y, _data->u );
}

void yane::MPC::SyncOdeManager::combinedMassMatrix ( int * n, double * M, int * lmas, double * rpar, int * ipar )
{
	T_MPCDATA * _data = ( T_MPCDATA* ) rpar;
	SyncOdeManager * baseobject = ( SyncOdeManager* ) _data->odemanager;

	memcpy ( M, baseobject->_mass, sizeof ( double ) * ( baseobject->_dimension + 1 ) * ( baseobject->_dimension + 1 ) );
}

void yane::MPC::SyncOdeManager::diffCombinedOdeSystem ( int * n, double * t, double * y, double * dy, double * rpar, int * ipar )
{
	T_MPCDATA * _data = ( T_MPCDATA* ) rpar;
	SyncOdeManager * baseobject = ( SyncOdeManager* ) _data->odemanager;

	baseobject->_model->odeFunction ( *t, y, _data->u, dy );
	dy[baseobject->_dimension] = baseobject->_model->continuousCostfunction ( *t, y, _data->u );

	baseobject->_model->odeFunction ( *t, &y[baseobject->_dimension + 1], & ( _data->u ) [baseobject->_dimension_u * baseobject->_horizont + baseobject->_sdatalength], &dy[baseobject->_dimension + 1] );
	dy[2 * baseobject->_dimension + 1 ] = baseobject->_model->continuousCostfunction ( *t, &y[baseobject->_dimension + 1], & ( _data->u ) [baseobject->_dimension_u * baseobject->_horizont + baseobject->_sdatalength] );
}

void yane::MPC::SyncOdeManager::diffCombinedMassMatrix ( int * n, double * M, int * lmas, double * rpar, int * ipar )
{
	T_MPCDATA * _data = ( T_MPCDATA* ) rpar;
	SyncOdeManager * baseobject = ( SyncOdeManager* ) _data->odemanager;

	memcpy ( M, baseobject->_diffmass, sizeof ( double ) * 4 * ( baseobject->_dimension + 1 ) * ( baseobject->_dimension + 1 ) );
}

LIB_EXPORT void yane::MPC::SyncOdeManager::setAuxilliaryObjects ( void * discretization, void * configuration )
{
	_discretization = discretization;
	_configuration = configuration;
}

LIB_EXPORT void yane::MPC::SyncOdeManager::calcObjectiveFunction ( double * t, double * x_pre, double * u, double * fx )
{
	_cache->setStamp( t, x_pre, u );

	try
	{
		calcCache ( u );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}
	*fx = _cache->objValue();
}

LIB_EXPORT void yane::MPC::SyncOdeManager::calcObjectiveFunctionGrad ( double * t, double * x_pre, double * u, double * fx )
{
	_cache->setStamp( t, x_pre, u );
	try
	{
		calcCache ( u );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	for ( int index = 0; index < _horizont*_dimension_u + _sdatalength; index++ )
	{
		try
		{
			calcCacheDerived ( u, index );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "CacheDerived could not be computed" ), &e );
		}
		fx[index] = ( _cache->objDisturbedValue(index) - _cache->objValue(index) ) / yane::Utils::OptimalDiff::get();
	}
}

LIB_EXPORT void yane::MPC::SyncOdeManager::calcRestrFunction ( double * t, double * x_pre, double * u, double * fx )
{
	if ( _dim_restr == 0 ) return;

	_cache->setStamp( t, x_pre, u );
	try
	{
		calcCache ( u );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	_restrfunction ( t, _cache->trajectoryValues(), u, fx, _discretization, _configuration );
}

LIB_EXPORT void yane::MPC::SyncOdeManager::calcRestrFunctionGrad ( double * t, double * x_pre, double * u, double * fx, yane::MinProg::T_MEMMODEL memmodel, int * needc )
{
	if ( _dim_restr == 0 ) return;

	_cache->setStamp( t, x_pre, u );

	try
	{
		calcCache ( u );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	memcpy ( _tempx, _cache->trajectoryValues(), _horizont*_dimension*sizeof ( double ) );
	for ( int h = _horizont - 1; h >= 0; h-- )
	{
		for ( int i = 0; i < _dimension_u; i++ )
		{
			int index = h * _dimension_u + i;
			try
			{
				calcCacheDerived ( u, index );
			}
			catch ( yane::OdeSolve::OdeSolEx e )
			{
				throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "CacheDerived could not be computed" ), &e );
			}


			memcpy ( &_tempx[h*_dimension], _cache->trajectoryValues(index), sizeof ( double ) * ( _horizont - h ) *_dimension );
			_restrfunction ( t, _tempx, u, _tempr1, _discretization, _configuration );
			memcpy ( &_tempx[h*_dimension], _cache->trajectoryDisturbedValues(index), sizeof ( double ) * ( _horizont - h ) *_dimension );
			_restrfunction ( t, _tempx, u, _tempr2, _discretization, _configuration );
			for ( int row = 0; row < _dim_restr; row++ )
			{
				if ( needc[row] != 0 )
				{
					if ( memmodel == yane::MinProg::BYLINE )
					{
						fx[row* ( _dimension_u*_horizont + _sdatalength ) + index] = ( _tempr2[row] - _tempr1[row] ) / yane::Utils::OptimalDiff::get();
					}
					else
					{
						fx[row + index*_dim_restr] = ( _tempr2[row] - _tempr1[row] ) / yane::Utils::OptimalDiff::get();
					}
				}
			}
		}
	}

	memcpy ( _tempx, _cache->trajectoryValues(), _horizont*_dimension*sizeof ( double ) );
	for ( int sdataindex = _sdatalength - 1; sdataindex >= 0; sdataindex-- )
	{
		int index = _horizont * _dimension_u + sdataindex;
		int h = _sdata[sdataindex].horizonindex + 1;
		try
		{
			calcCacheDerived ( u, index );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "CacheDerived could not be computed" ), &e );
		}
		memcpy ( &_tempx[h*_dimension], _cache->trajectoryValues(index), sizeof ( double ) * ( _horizont - h ) *_dimension );
		_restrfunction ( t, _tempx, u, _tempr1, _discretization, _configuration );
		memcpy ( &_tempx[h*_dimension], _cache->trajectoryDisturbedValues(index), sizeof ( double ) * ( _horizont - h ) *_dimension );
		_restrfunction ( t, _tempx, u, _tempr2, _discretization, _configuration );
		for ( int row = 0; row < _dim_restr; row++ )
		{
			if ( needc[row] != 0 )
			{
				if ( memmodel == yane::MinProg::BYLINE )
				{
					fx[row* ( _dimension_u*_horizont + _sdatalength ) + index] = ( _tempr2[row] - _tempr1[row] ) / yane::Utils::OptimalDiff::get();
				}
				else
				{
					fx[row + index*_dim_restr] = ( _tempr2[row] - _tempr1[row] ) / yane::Utils::OptimalDiff::get();
				}
			}
		}
	}
}

void yane::MPC::SyncOdeManager::calcCache ( double * u )
{
	if ( !_cache->baseIsCalc() )
	{
		memcpy ( _x, _cache->x(), sizeof ( double ) * _dimension );
		_x[_dimension] = 0.0;

		try
		{
			_ode->refreshConfig();
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Configuration of the differential equation solver could not be refreshed" ), &e );
		}
		try
		{
			_ode->init ( _cache->t()[0], _x );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Differential equation solver could not be initialized" ), &e );
		}

		int sdataindex = 0;
		for ( int i = 0; i < _horizont; i++ )
		{
			_data->u = &u[i * _dimension_u];
			try
			{
				_ode->calc ( _cache->t()[i+1], ( double * ) _data );
			}
			catch ( yane::OdeSolve::OdeSolEx e )
			{
				throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation failed" ), &e );
			}

			memcpy ( &(_cache->trajectoryValues())[i*_dimension], _x, sizeof ( double ) *_dimension );

			_cache->objHorizonValues()[i] = _x[_dimension];

			if ( _sdatalength > 0  && sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
			{
				while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
				{
					_x[_sdata[sdataindex].varindex] = u[_horizont*_dimension_u + sdataindex];
					++sdataindex;
				}
			}

		}

		_cache->objHorizonValues()[_horizont-1] *= _weightint;

		if ( _weightcf != 0.0 )
		{
			memcpy ( _pcf_x, _cache->x(), sizeof ( double ) *_dimension );
			memcpy ( &_pcf_x[_dimension], _cache->trajectoryValues(), sizeof ( double ) *_dimension*_horizont );
			_cache->objHorizonValues()[_horizont-1] += _weightcf * _model->discreteCostfunction ( _horizont, _horizont, _cache->t(), _pcf_x, u );
		}

		_cache->objValue() = _cache->objHorizonValues()[_horizont-1];

		_cache->baseIsCalc() = true;
	}
}

void yane::MPC::SyncOdeManager::calcCacheDerived ( double * u, int index )
{
	if ( !_cache->disturbedIsCalc(index) )
	{
		int sdataindex = 0;
		int uindex;

		memcpy ( _udiff, u, sizeof ( double ) * _horizont * _dimension_u + _sdatalength );
		memcpy ( &_udiff[_horizont * _dimension_u + _sdatalength], u, sizeof ( double ) * _horizont * _dimension_u + _sdatalength );
		_udiff[_horizont * _dimension_u + _sdatalength + index] += yane::Utils::OptimalDiff::get();

		if ( index < _dimension_u * _horizont )
		{
			sdataindex = 0;
			uindex = index / _dimension_u;
			while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex + 1 < uindex )
			{
				sdataindex++;
			}

			if ( uindex == 0 )
			{
				memcpy ( _xdiff, _cache->x(), sizeof ( double ) * _dimension );
				_xdiff[_dimension] = 0.0;
			}
			else
			{
				memcpy ( _xdiff, &(_cache->trajectoryValues())[ ( uindex-1 ) *_dimension ], sizeof ( double ) *_dimension );
				_xdiff[_dimension] = _cache->objHorizonValues()[uindex-1];
			}
		}
		else
		{
			sdataindex = index - _dimension_u * _horizont;
			while ( sdataindex > 0 && _sdata[sdataindex-1].horizonindex == _sdata[sdataindex].horizonindex )
			{
				--sdataindex;
			}
			uindex = _sdata[sdataindex].horizonindex + 1;
			memcpy ( _xdiff, &(_cache->trajectoryValues())[ ( uindex-1 ) *_dimension], sizeof ( double ) *_dimension );
			_xdiff[_dimension] = _cache->objHorizonValues()[uindex-1];
		}
		while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex + 1 == uindex )
		{
			_xdiff[_sdata[sdataindex].varindex] = _udiff[_dimension_u * _horizont + sdataindex];
			sdataindex++;
		}

		memcpy(&_xdiff[_dimension+1], _xdiff, sizeof(double)*(_dimension+1));

		try
		{
			_diffode->refreshConfig();
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Configuration of the doubled differential equation solver could not be refreshed" ), &e );
		}
		try
		{
			_diffode->init ( _cache->t()[uindex], _xdiff );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Differential equation solver could not be initialized" ), &e );
		}
		for ( int i = uindex; i < _horizont; i++ )
		{
			_data->u = &_udiff[i*_dimension_u];
			try
			{
				_diffode->calc ( _cache->t()[i + 1], ( double * ) _data );
			}
			catch ( yane::OdeSolve::OdeSolEx e )
			{
				throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation failed" ), &e );
			}

			memcpy ( &(_cache->trajectoryValues(index))[( i - uindex ) * _dimension], _xdiff, sizeof ( double ) * _dimension );
			memcpy ( &(_cache->trajectoryDisturbedValues(index))[( i - uindex ) * _dimension], &_xdiff[_dimension + 1], sizeof ( double ) * _dimension );

			if ( _sdatalength > 0  && sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
			{
				while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
				{
					_xdiff[_sdata[sdataindex].varindex] = _udiff[_dimension_u * _horizont + sdataindex];
					_xdiff[_dimension + 1 + _sdata[sdataindex].varindex] = _udiff[2 * _horizont * _dimension_u + _sdatalength + sdataindex];
					sdataindex++;
				}
			}
		}

		_cache->objValue(index) = _weightint * _xdiff[_dimension];
		_cache->objDisturbedValue(index) = _weightint * _xdiff[2 * _dimension + 1];
		if ( _weightcf != 0.0 )
		{
			memcpy ( _pcf_x, _cache->x(), sizeof ( double ) * _dimension );
			if ( uindex != 0 )
			{
				memcpy ( &_pcf_x[_dimension], _cache->trajectoryValues(), uindex * _dimension * sizeof ( double ) );
			}
			memcpy ( &_pcf_x[ ( uindex + 1 ) * _dimension], _cache->trajectoryValues(index), sizeof ( double ) * _dimension * ( _horizont - uindex ) );
			_cache->objValue(index) += _weightcf * _model->discreteCostfunction ( _horizont, _horizont, _cache->t(), _pcf_x, _udiff );

			memcpy ( &_pcf_x[ ( uindex + 1 ) * _dimension], _cache->trajectoryDisturbedValues(index), sizeof ( double ) * _dimension * ( _horizont - uindex ) );
			_cache->objDisturbedValue(index) += _weightcf * _model->discreteCostfunction ( _horizont, _horizont, _cache->t(), _pcf_x, &_udiff[_horizont * _dimension_u + _sdatalength] );
		}

		_cache->disturbedIsCalc(index) = true;

	}
}

LIB_EXPORT void yane::MPC::SyncOdeManager::getObjFunValues ( double * t, double * x_pre, double * u, double * fx, double * trajectory )
{
	_cache->setStamp(t, x_pre, u);
	try
	{
		calcCache ( u );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	memcpy ( fx, _cache->objHorizonValues(), sizeof ( double ) * _horizont );
	fx[_horizont] = 0.0;
	for ( int i = 0; i < _horizont + 1; i++ )
	{
		fx[i] *= _weightint;
	}

	memcpy ( trajectory, _x, sizeof ( double ) * _dimension );
	memcpy ( &trajectory[_dimension], _cache->trajectoryValues(), sizeof ( double ) * _horizont * _dimension );

	if ( _weightcf != 0.0 )
	{
		for ( int i = 0; i < _horizont + 1; i++ )
		{
			fx[i] += _weightcf * _model->discreteCostfunction ( i, _horizont, t, trajectory, u );
		}
	}
}

LIB_EXPORT yane::MPC::OdeManager * yane::MPC::SyncOdeManager::clone()
{
	return new SyncOdeManager();
}

LIB_EXPORT void * yane::MPC::SyncOdeManager::configuration()
{
	return _configuration;
}
