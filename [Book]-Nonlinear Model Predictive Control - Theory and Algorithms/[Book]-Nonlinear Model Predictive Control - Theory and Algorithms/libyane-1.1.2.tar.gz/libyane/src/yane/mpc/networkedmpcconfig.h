/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_NETWORKEDMPCCONFIG_H
#define YANE_MPC_NETWORKEDMPCCONFIG_H

#include "mpc.h"

#include <vector>

namespace yane
{

	namespace Utils
	{
		class Uuid;
	}

	namespace MinProg
	{
		class NLP;
	}

	namespace Model
	{
		class Model;
	}

	namespace MPC
	{
		class Discretization;
		class OdeManager;
		class MPC;

		/** @class NetworkedMPCConfig
		This class allows to control a plant using MPC in a network of connected plants.
		@brief Not yet documented
		*/
		class NetworkedMPCConfig
		{
			public:
				NetworkedMPCConfig();

				~NetworkedMPCConfig();

				virtual void resetDiscretization ( Discretization * problem ) = 0;
				void checkForOutdatedNeighbours(); //TODO checkForOutdatedNeighbours

				void setResetDiscretization ( bool resetDiscretization );
				void setMPCPointer ( MPC * mpc );
				void setDisplaywarnings ( bool displaywarnings );

				MPC * mpc();
				yane::Utils::Uuid * configID();

				void addInputNeighbour ( NetworkedMPCConfig * neighbour );
				void addInputNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps );
				void removeInputNeighbour ( NetworkedMPCConfig * neighbour );
				void removeInputNeighbour ( yane::Utils::Uuid * uuid );
				void listOfInputNeighbours();
				int numberOfInputNeighbours();
				void outdateAllInputNeighbours();

				void addOutputNeighbour ( NetworkedMPCConfig * neighbour );
				void addOutputNeighbour ( yane::Utils::Uuid * uuid );
				void removeOutputNeighbour ( NetworkedMPCConfig * neighbour );
				void removeOutputNeighbour ( yane::Utils::Uuid * uuid );
				void listOfOutputNeighbours();
				int numberOfOutputNeighbours();
				void outdateAllOutputNeighbours();

				void addNeighbour ( NetworkedMPCConfig * neighbour );
				void addNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps );
				void removeNeighbour ( NetworkedMPCConfig * neighbour );
				void removeNeighbour ( yane::Utils::Uuid * uuid );
				void outdateAllNeighbours();

			protected:
				typedef struct
				{
					yane::Utils::Uuid * uuid;
					bool outdated;
					int dimensionState;
					int dimensionControl;
					int horizon;
					int precedesteps;
				} T_NETWORKINPUTMPCDATA;

				typedef struct
				{
					yane::Utils::Uuid * uuid;
					bool outdated;
				} T_NETWORKOUTPUTMPCDATA;

				yane::Utils::Uuid * _setting_uuid;
				std::vector <T_NETWORKINPUTMPCDATA> _inputNeighbours;
				std::vector <T_NETWORKOUTPUTMPCDATA> _outputNeighbours;

				std::vector <std::vector <double> > _inputNeighbourTimesteps;
				std::vector <std::vector <double> > _inputNeighbourControl;
				std::vector <std::vector <double> > _inputNeighbourState;

				MPC * _mpc;

				bool _displaywarnings;
				bool _resetDiscretizationRequired;
		};

	}

}

#endif
