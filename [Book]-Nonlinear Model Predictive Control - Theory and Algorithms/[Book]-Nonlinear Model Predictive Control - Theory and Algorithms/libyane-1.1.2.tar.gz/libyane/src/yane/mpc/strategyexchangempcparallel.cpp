/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "strategyexchangempcparallel.h"
#include "discr.h"
#include "exceptions.h"
#include "odemanager.h"
#include "modelshootingdata.h"

#include "../model/model.h"
#include "../utils.h"
#include "../odesolve.h"

#include <cstring>

#include "libexport.h"

LIB_EXPORT yane::MPC::StrategyExchangeMPCParallel::StrategyExchangeMPCParallel() : StrategyExchangeMPC()
{
}

LIB_EXPORT yane::MPC::StrategyExchangeMPCParallel::~StrategyExchangeMPCParallel()
{
}
