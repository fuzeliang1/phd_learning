/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_TYPEDEFS_H
#define YANE_MPC_TYPEDEFS_H

namespace yane
{

	namespace MPC
	{
		/** \typedef T_DISCRRESTRFUNC
		\brief Defines the pointer on the constraints of the optimal control problem
		*/
		typedef void ( *T_DISCRRESTRFUNC ) ( double * t, double *x, double * u, double * fx, void * discretization, void * configuration );

		/** \struct T_MPCDATA
		\param odemanager Pointer of the differential equation manager
		\param u Pointer of the control vector
		\brief Define a structure which is required to solve the dynamic of the optimal control problem
		*/
		typedef struct
		{
			void * odemanager;
			double * u;
		} T_MPCDATA;

		/** \struct T_SHOOTINGDATA
		\param horizonindex Time index of a shooting node
		\param varindex State dimension index of a shooting node
		\brief Defines a structure for the shooting nodes required for the MPC problem
		*/
		typedef struct
		{
			int horizonindex;
			int varindex;
		} T_SHOOTINGDATA;

		/** @typedef T_OPTIMALITYSTATE
		@brief Enumerator for the suboptimality exception status
			- OK: no exceptions thrown
			- SUBOPTIMAL: exception yane::MPC::SuboptimalityException has been catched
			- PRACTICAL: exception yane::MPC::PracticalException has been catched
			- SQPBROKEN: exception yane::MinProg::SolverWarning has been catched
		*/
		typedef enum
		{
			OK = 0,
			SUBOPTIMAL = 1,
			PRACTICAL = 2,
			SQPBROKEN = 3
		} T_OPTIMALITYSTATE;

		/** @typedef T_SHIFTSTATE
		@brief Enumerator for the shift method to be applied
			- STANDARD: The values of the control over the optimization horizon are shifted by \f$ m \f$ sampling steps, the last \f$ m \f$ new control vectors are copies of the last control vector of the unshifted optimization horizontindex
			- ONESTEP: The values of the control over the optimization horizon are shifted by \f$ m \f$ sampling steps, the last \f$ m \f$ new control vectors are determined by evaluating a optimal control problem with horizon length \f$ m \f$ over the corresponding time grid using the initial state vector associated with time instant \f$ N - m \f$.
			- REPEATED: The values of the control over the optimization horizon are repeatedly shifted \f$ m - 1 \f$ times by \f$ 1 \f$ sampling step. After each shift \f$ i \leq m - 2 \f$, a optimal control problem of length \f$ N - m + i \f$ is solved to keep track of the optimal control strategy. After the last shift, the ONESTEP strategy is applied.
		*/
		typedef enum
		{
			STANDARD = 0,
			ONESTEP = 1,
			REPEATED = 2
		} T_SHIFTSTATE;

		/** @typedef T_IMPLEMENTATION
		@brief Enumerator for available MPC adaptation strategies
			- NOADAPTION: No adaptation is applied
			- SIMPLE: Simple shortening and prolongation strategy are applied respectively if the current suboptimality degree \f$ \alpha \f$ is larger or smaller than a predefined suboptimality bound \f$ \overline{\alpha} \f$.
			- FIXEDPOINT: Simple shortening and fixed point prolongation strategy are applied respectively if the current suboptimality degree \f$ \alpha \f$ is larger or smaller than a predefined suboptimality bound \f$ \overline{\alpha} \f$.
			- MONOTONE: Simple shortening and monotone prolongation strategy are applied respectively if the current suboptimality degree \f$ \alpha \f$ is larger or smaller than a predefined suboptimality bound \f$ \overline{\alpha} \f$.
		*/
		typedef enum
		{
			NOADAPTION = 0,
			SIMPLE = 1,
			FIXEDPOINT = 2,
			MONOTONE = 3
		} T_IMPLEMENTATION;

		/** @typedef T_ESTIMATE
		@brief Enumerator for available suboptimality estimates
			- NONE: Degree of suboptimality is not computed
			- APOSTERIORI: Degree of suboptimality is computed according to the a posteriori estimate implemented in yane::MPC::SuboptimalityMPC::mstepAposterioriEstimate
			- APOSTERIORIPRACTICAL: Practical degree of suboptimality is computed according to the a posteriori estimate implemented in yane::MPC::SuboptimalityMPC::mstepAposterioriPracticalEstimate
			- APRIORI: Degree of suboptimality is computed according to the a priori estimate implemented in yane::MPC::SuboptimalityMPC::mstepAprioriEstimate
			- APRIORIPRACTICAL: Practical degree of suboptimality is computed according to the a priori estimate implemented in yane::MPC::SuboptimalityMPC::mstepAprioriPracticalEstimate
		 */
		typedef enum
		{
			NONE = 0,
			APOSTERIORI = 1,
			APOSTERIORIPRACTICAL = 2,
			APRIORI = 3,
			APRIORIPRACTICAL = 4
		} T_ESTIMATE;

		/** @typedef T_SHIFTRETURNDATA
		@brief Enumerator for available return data of the shift routine
			- CURRENT_DATA Current time and control set are returned
			- PREDICTED_DATA Time and control set of the point of implementation are returned
		*/
		typedef enum
		{
			CURRENT_DATA		= 0,
   			PREDICTED_DATA		= 1
		} T_SHIFTRETURNDATA;

		/** @typedef T_M21ALGORITHM
		@brief Enumerator for available implementations of the m21MPC algorithm
			- NOUPDATECOSTFUNCTION Version without updating the cost function
			- UPDATECOSTFUNCTION Version with update of the cost function
		*/
		typedef enum
		{
			NOUPDATECOSTFUNCTION = 0,
			UPDATECOSTFUNCTION = 1
		} T_M21ALGORITHM;

	}

}

#endif
