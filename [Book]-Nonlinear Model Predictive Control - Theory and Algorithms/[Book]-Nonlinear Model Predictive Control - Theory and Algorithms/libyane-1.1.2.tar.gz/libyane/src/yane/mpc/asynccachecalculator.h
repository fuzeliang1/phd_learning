/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_ASYNCCACHECALCULATOR_H
#define YANE_MPC_ASYNCCACHECALCULATOR_H

#include "typedefs.h"

#include "../minprog/typedefs.h"

namespace yane
{

	namespace Model
	{
		class Model;
	}

	namespace OdeSolve
	{
		class OdeFunction;
		class OdeSolveFirst;
	}

	namespace MPC
	{

		class Cache;
		class OdeManager;

		/** @class ASyncCacheCalculator
		not yet documented
		 */
		class ASyncCacheCalculator
		{
			public:
				ASyncCacheCalculator(OdeManager* odeman, Cache * cache, yane::OdeSolve::OdeFunction * odefunc, int total_restr, T_DISCRRESTRFUNC restrfunc);
				~ASyncCacheCalculator();

				double objValue();
				void objGradient(double * grad, int index, int threadid=0);

				void restrValues(double * fx, void * discretization, void * configuration = 0);
				void restrJacobi(double * jac, int index, void * discretization, yane::MinProg::T_MEMMODEL memmodel, int * needc, bool firstcalc=true, void * configuration = 0, int threadid=0);

			protected:

				void freeMem();

				void calcCache ( );
				void calcCacheDisturbed ( int uindex, int threadid );

				yane::OdeSolve::OdeSolveFirst * _ode;
				Cache * _cache;
				yane::Model::Model * _model;

				int _dimx;
				int _dimu;
				int _horizon;
				int _total_restr;
				T_DISCRRESTRFUNC _restrfunc;
				T_SHOOTINGDATA * _sdata;
				int _sdatalength;

				double * _x;
				double * _trajectory;
				double * _trajectory_restr;
				T_MPCDATA * _data;
				double * _tempr1;
				double * _tempr2;

				double _weightcf;
				double _weightint;


		};

	}

}

#endif
