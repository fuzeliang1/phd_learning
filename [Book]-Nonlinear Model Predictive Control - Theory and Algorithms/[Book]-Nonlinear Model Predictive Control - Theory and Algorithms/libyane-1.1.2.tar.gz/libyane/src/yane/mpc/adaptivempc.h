/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_ADAPTIVEMPC_H
#define YANE_MPC_ADAPTIVEMPC_H

#include "suboptimalitympc.h"

namespace yane
{

	namespace MPC
	{
		class Discretization;

		/** \class AdaptiveMPC
		 @brief Implementation of an NMPC Algorithm with adaptation of the horizon length
		*/
		class AdaptiveMPC : public SuboptimalityMPC
		{
			public:
				/**
				@param h_new Discretization width
				@param INFTY Value for infinity
				@brief Constructor
				 */
				AdaptiveMPC ( double h_new, double INFTY = 1E19 );

				/**
				@brief Destructor
				 */
				~AdaptiveMPC();

				/**
				Function to compute the solution of the NMPC problem with automated adaptation of the horizon length
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@param abortSuboptimalityDegree Bound on the degree of suboptimality to stop the optimization
				@throw yane::Utils::NotInitializedException Is thrown if the yane::MPC::MPC object is not yet defined, i.e. if the yane::MPC::MPC::reset function has not been called
				@throw yane::MPC::EstimationException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@brief Function to compute the solution of the NMPC problem with automated adaptation of the horizon length
				 */
				virtual void calc ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0, double abortSuboptimalityDegree = INFINITY );

				/**
				Function to configure the adaptation algorithm
				@param alphabound Suboptimality bound
				@param estimate Decision variable to define the computing method of the suboptimality degree
				- (0) Standardimplementation without adaptation of the horizon length
				- (1) Adaptation of the horizon length using the a posteriori estimate
				- (2) Adaptation of the horizon length using the a posteriori practical estimate (default)
				- (3) Adaptation of the horizon length using the a priori estimate
				- (4) Adaptation of the horizon length using the a priori practical estimate
				@param implementation Decision variable to define the adaptation strategy
				- (0) Standardimplementation without adaptation of the horizon length
				- (1) Simple shortening and prolongation strategy (default)
				- (2) Simple shortening strategy and fixpoint iteration for prolongation
				- (3) Simple shortening strategy and monotone iteration for prolongation
				@param N0 Parameter for the a priori suboptimality estimate, requires \f$ N_0 \geq 2 \f$, default is \f$ N_0 = 2 \f$
				@param sigma Safety factor for the fixpoint and monotone adaptation strategies, default is \f$ \sigma = 5 \f$
				@param optimizeGamma Decision variable if supplied value N0 shall be used to compute \f$ \gamma(N) \f$ for a posteriori estimate
				@brief Function to configure the adaptation algorithm
				*/
				void setConfigAdaptiveMPC ( double alphabound, T_ESTIMATE estimate = APOSTERIORIPRACTICAL, T_IMPLEMENTATION implementation = SIMPLE, int N0 = 2, double epsilon = 1e-6, int sigma = 5, bool shorteningCheckNextStep = true, bool optimizeGamma = true );

				/**
				@brief Function to return the current suboptimality estimate
				@return Suboptimality estimate
				 */
				double alpha ( void );

			private:
				/**
				Implementation of the simple strategy to shorten and prolong the length of the optimization horizon. Can be used with both a priori and a posteriori estimates as well as practical and non practical implementations
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@brief Implementation of the simple strategy to shorten and prolong the length of the optimization horizon
				 */
				void calcSimple ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Implementation of the simple strategy to shorten and the fixpoint strategy to prolong the length of the optimization horizon. Can be used with both a priori and a posteriori estimates as well as practical and non practical implementations. \n
				The fixpoint iteration uses the iteration formula
				\f[ N = \Phi(N) := \left\lceil N_0 + \frac{2 \ln(\gamma(N)) - \ln(1 - \overline{\alpha})}{\ln(\gamma(N) + 1) - \ln(\gamma(N))} \right\rceil \f]
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@brief Implementation of the simple strategy to shorten and the fixpoint strategy to prolong the length of the optimization horizon
				 */
				void calcSimpleFixpoint ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Implementation of the simple strategy to shorten and the monotone strategy to prolong the length of the optimization horizon. Can be used with both a priori and a posteriori estimates as well as practical and non practical implementations. \n
				The monotone strategy uses the iteration formula
				\f[ N = \Psi(N) := \left\lceil N_0 + \left( \frac{ \ln \left( \left( \frac{\gamma(N)}{\gamma(N) + 1}\right)^{N - N_0} - \frac{\delta}{\gamma(N)^2} \right) - 2 \ln (\vartheta) }{ \ln \left( \vartheta \gamma(N) \right) - \ln \left( \vartheta \gamma(N) + 1 \right) } \right) \right\rceil \f]
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@brief Implementation of the simple strategy to shorten and the monotone strategy to prolong the length of the optimization horizon
				 */
				void calcSimpleMonotone ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Function to shorten the optimization horizon using the simple shortening strategy
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@brief Function to shorten the optimization horizon using the simple shortening strategy
				 */
				void simpleShortening ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Function to check whether shortening step should be accepted
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::OdeSolve::OdeSolEx Is thrown if the yane::OdeSolve::OdeSolve object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@throw yane::Utils::MemoryException Is thrown if memory allocation failed
				@brief Function to check whether shortening step can be accepted
				 */
				void simpleShorteningCheckNextStep ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Function to prolong the length of the optimization horizon using the simple strategy \n
				The prolongation is terminated if the maximal horizon length yane::MPC::MPC::_maxhorizon is reached.
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@brief Function to prolong the length of the optimization horizon using the simple strategy
				 */
				void simpleProlongation ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Function to prolongate the optimization horizon using the fixpoint iteration strategy \n
				The iteration procedure is given by
				\f[ N = \Phi(N) := \left\lceil N_0 + \frac{2 \ln(\gamma(N)) - \ln(1 - \overline{\alpha})}{\ln(\gamma(N) + 1) - \ln(\gamma(N))} \right\rceil \f]
				The prolongation is terminated if the maximal horizon length yane::MPC::MPC::_maxhorizon is reached. Moreover the safety factoryane::MPC::AdaptiveMPC::_sigma is used to prevent overshoots.
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@brief Function to prolongate the optimization horizon using the fixpoint iteration strategy
				 */
				void fixpointProlongation ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Function to prolongate the optimization horizon using the monotone iteration strategy \n
				The iteration procedure is given by
				\f[ N = \Psi(N) := \left\lceil N_0 + \left( \frac{ \ln \left( \left( \frac{\gamma(N)}{\gamma(N) + 1}\right)^{N - N_0} - \frac{\delta}{\gamma(N)^2} \right) - 2 \ln (\vartheta) }{ \ln \left( \vartheta \gamma(N) \right) - \ln \left( \vartheta \gamma(N) + 1 \right) } \right) \right\rceil \f]
				The prolongation is terminated if the maximal horizon length yane::MPC::MPC::_maxhorizon is reached. Moreover the safety factoryane::MPC::AdaptiveMPC::_sigma is used to prevent overshoots. \n
				The variable \b theta is computed online using the approximation
				\f[ \theta(N_i) = \max \left\{ \theta(N_{i-1}, \frac{\gamma(N_{i})}{\gamma(N_{i-1})} \right\} \f]
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@brief Function to prolongate the optimization horizon using the monotone iteration strategy
				 */
				void monotoneProlongation ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

//    Discretization * _problem_predicted; /**< @brief Pointer to the used class yane::Discretization::Discretization object */
				double * _x_predicted_check;  /**< @brief Auxilliary predicted state vectorPraedizierter Zustand des Systems zwecks Gegencheck */
				double * _timesteps_current_check; /**< @brief Auxilliary time grid */
				double * _u_current_check;  /**< @brief Auxilliary current state vector */
				T_IMPLEMENTATION _implementation;        /**< @brief Decision variable to define the adaptation strategy
								- NOADAPTION Standardimplementation without adaptation of the horizon length
								- SIMPLE Sinple shortening and prolongation strategy
								- FIXEDPOINT Simple shortening strategy and fixpoint iteration for prolongation
								- MONOTONE Simple shortening strategy and monotone iteration for prolongation */
				bool _adaptive_initialized;  /**< @brief Initialization variable */
				double _alpha_current;   /**< @brief Current suboptimality estimate \f$ \alpha(N) \f$ used for shortening the horizon */
				int _phi;    /**< @brief Computed horizon length from adaptation iteration scheme */
				int _sigma;    /**< @brief Safety factor used within fixpoint or monontone prolongation strategies */
				double _delta;    /**< @brief Difference between current suboptimality estimate and given suboptimality bound */
				double _theta;    /**< @brief Current estimate of the parameter \f$ \theta \f$ of the monotone iteration sequence for prolongation of the optimization horizon */
				bool _optimizegamma;   /**< @brief Decision parameter if given value yane::MPC::AdaptiveMPC::_N0 is used to compute \f$ \gamma(N) \f$ for a posteriori estimates */
				bool _shorteningCheckNextStep; 	/**< @brief Decision parameter if next step should be check for satisfying suboptimality bound before shortening horizon */
		};

	}

}

#endif
