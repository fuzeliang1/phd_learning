/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "cache.h"

#include "../utils.h"
#include "../model.h"

#include <cstring>
#include <iostream>

using namespace std;

yane::MPC::Cache::Cache ( int horizon_par, yane::Model::Model * model_par, T_SHOOTINGDATA * sdata_par, int sdatalength_par, T_SYNCMODETYPE type_par, int countcopy_u_par )
{
	_horizon = horizon_par;
	_model = model_par;
	_dimx = _model->dimensionState();
	_dimu = _model->dimensionControl();
	_sdatalength = sdatalength_par;
	_type = type_par;
	_sdata = sdata_par;
	_countcopy_u = countcopy_u_par;

	int count;

	count = _dimu * _horizon + _sdatalength;
	if ( _type == SYNCMODE )
	{
		count *= 2;
	}
	else
	{
		count += 1;
	}

	_cache = 0;
	_copy_u = 0;
	_iscalced = 0;
	_baseiscalced = false;
	_stamp = 0;
	_cmpstamp = 0;
	_fxcache = 0;
	_fxhorizonvalues = 0;

	try
	{
		_cache = new double*[count];
		for ( int i = 0; i < count; i++ )
			_cache[i] = 0;

		for ( int i = 0; i < _horizon; i++ )
		{
			for ( int j = 0; j < _dimu; j++ )
			{
				_cache[i*_dimu+j] = new double[ ( _horizon - i ) * _dimx];
			}
		}

		for ( int i = 0; i < _sdatalength; i++ )
		{
			_cache[_horizon*_dimu+i] = new double[ ( _horizon - _sdata[i].horizonindex - 1 ) * _dimx];
		}

		for ( int i = _dimu * _horizon + _sdatalength; i < count; i++ )
		{
			_cache[i] = new double[_horizon * _dimx];
		}

		_iscalced = new bool[ _dimu * _horizon + _sdatalength ];
		_stamp = new double[ _dimx + _horizon + 1 + ( _dimu * _horizon ) + _sdatalength];
		memset(_stamp, 0, sizeof(double)*(_dimx + _horizon + 1 + ( _dimu * _horizon ) + _sdatalength));
		_cmpstamp = new double[ _dimx + _horizon + 1 + ( _dimu * _horizon ) + _sdatalength ];
		_fxcache = new double[ count ];
		_fxhorizonvalues = new double[_horizon];

		_copy_u = new double*[_countcopy_u];
		for ( int i = 0; i < _countcopy_u; i++ )
			_copy_u[i] = 0;

		for ( int i = 1; i < _countcopy_u; i++ )
		{
			_copy_u[i] = new double[_horizon * _dimu + _sdatalength];
		}
		_copy_u[0] = &_stamp[_horizon+1+_dimx];
	}
	catch ( std::bad_alloc )
	{
		if ( _cache != 0 )
		{
			for ( int i = 0; i < count; i++ )
			{
				if ( _cache[i] != 0 )
					delete[] _cache[i];
			}
			delete[] _cache;
		}
		if ( _copy_u != 0 )
		{
			for ( int i = 1; i < _countcopy_u; i++ )
			{
				if ( _copy_u[i] != 0 )
					delete[] _copy_u[i];
			}
			delete[] _copy_u;
		}
		if ( _iscalced != 0 )
			delete[] _iscalced;
		if ( _stamp != 0 )
			delete[] _stamp;
		if ( _cmpstamp != 0 )
			delete[] _cmpstamp;
		if ( _fxcache != 0 )
			delete[] _fxcache;
		if ( _fxhorizonvalues != 0 )
			delete[] _fxhorizonvalues;

		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocate memory" ) );
	}

	memset ( _iscalced, false, _dimu * _horizon + _sdatalength );

	_locker = new yane::Utils::Mutex();
}

yane::MPC::Cache::~ Cache()
{
	delete _locker;
	delete[] _iscalced;
	delete[] _stamp;
	delete[] _cmpstamp;
	delete[] _fxhorizonvalues;
	for ( int i = 0; i < _dimu * _horizon + _sdatalength + ( _type == SYNCMODE ? ( _dimu * _horizon + _sdatalength ) : 1 ); i++ )
	{
		delete[] _cache[i];
	}
	delete[] _cache;
	for ( int i = 1; i < _countcopy_u; i++ )
	{
		delete[] _copy_u[i];
	}
	delete[] _copy_u;
	delete[] _fxcache;
}

void yane::MPC::Cache::setStamp ( double * t, double * x, double * u )
{
	int size = 0;

	memcpy ( _cmpstamp, t, sizeof ( double ) * ( _horizon + 1 ) );
	size +=  _horizon + 1;

	memcpy ( &_cmpstamp[size], x, sizeof ( double ) *_dimx );
	size += _dimx;

	memcpy ( &_cmpstamp[size], u, sizeof ( double ) * ( _dimu * _horizon + _sdatalength ) );
	size += _dimu * _horizon + _sdatalength;

	if ( memcmp ( _stamp, _cmpstamp, sizeof ( double ) * size ) != 0 )
	{
		memset ( _iscalced, false, _dimu * _horizon + _sdatalength );
		_baseiscalced = false;
		memcpy ( _stamp, _cmpstamp, sizeof ( double ) * size );

		for ( int i = 1; i < _countcopy_u; i++ )
		{
			memcpy ( _copy_u[i], u, sizeof ( double ) * ( _dimu * _horizon + _sdatalength ) );
		}
	}
}

double * yane::MPC::Cache::t()
{
	return _stamp;
}

double * yane::MPC::Cache::x()
{
	return &_stamp[_horizon+1];
}

double * yane::MPC::Cache::u ( int _countcopy_u )
{
	return _copy_u[_countcopy_u];
}

double & yane::MPC::Cache::objValue ( int uindex )
{
	if ( _type == ASYNCMODE && uindex != 0 )
		throw yane::Utils::ValueException ( __DEBUGMESS ( "definition of uindex not allowed in async-mode" ) );

	return _fxcache[_dimu * _horizon + _sdatalength + uindex];
}

double & yane::MPC::Cache::objDisturbedValue ( int uindex )
{
	return _fxcache[uindex];
}

double * yane::MPC::Cache::objHorizonValues()
{
	return _fxhorizonvalues;
}

double * yane::MPC::Cache::trajectoryValues ( int uindex )
{
	if ( _type == ASYNCMODE && uindex != 0 )
		throw yane::Utils::ValueException ( __DEBUGMESS ( "definition of uindex not allowed in async-mode" ) );

	return _cache[_dimu * _horizon + _sdatalength + uindex];
}

double * yane::MPC::Cache::trajectoryDisturbedValues ( int uindex )
{
	return _cache[uindex];
}

bool & yane::MPC::Cache::baseIsCalc()
{
	return _baseiscalced;
}

bool & yane::MPC::Cache::disturbedIsCalc ( int uindex )
{
	return _iscalced[uindex];
}

int yane::MPC::Cache::horizon()
{
	return _horizon;
}

yane::MPC::T_SHOOTINGDATA * yane::MPC::Cache::startData()
{
	return _sdata;
}

int yane::MPC::Cache::startDataLength()
{
	return _sdatalength;
}

yane::Model::Model * yane::MPC::Cache::model()
{
	return _model;
}

void yane::MPC::Cache::lock()
{
	_locker->lock();
}

void yane::MPC::Cache::unlock()
{
	_locker->unlock();
}

