/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_SIMPLEODEMANAGER_H
#define YANE_MPC_SIMPLEODEMANAGER_H

#include "typedefs.h"
#include "odemanager.h"

using namespace std;

namespace yane
{

	namespace OdeSolve
	{
		class OdeFunction;
		class OdeSolveFirst;
	}

	namespace MPC
	{

		/** @class SimpleOdeManager
		@brief Implementation of a simple manager class for solving the control system and its derivative
		*/
		class SimpleOdeManager : public OdeManager
		{
			public:
				/**
				@brief Constructor
				*/
				SimpleOdeManager();

				/**
				@brief Destructor
				*/
				~SimpleOdeManager();

				virtual void calcObjectiveFunction ( double * t, double* x, double* u, double* fx );
				virtual void calcObjectiveFunctionGrad ( double * t, double* x, double* u, double* fx );
				virtual void calcRestrFunction ( double * t, double * x, double* u, double* fx );
				virtual void calcRestrFunctionGrad ( double * t, double * x, double* u, double* fx, yane::MinProg::T_MEMMODEL memmodel, int * needc=0 );
				virtual void setFunctions ( int horizont, int total_restr, yane::Model::Model * model, T_DISCRRESTRFUNC restrfunc, int sdatalength=0, T_SHOOTINGDATA * sdata=0 );
				virtual void setAuxilliaryObjects ( void * discretization, void * configuration = 0 );
				virtual void getObjFunValues ( double * t, double * x, double * u, double * fx, double * points );
				virtual OdeManager * clone();
				virtual void * configuration();


			private:
				/**
				Function to compute the solution of the differential equation system. Here, this system consists of the dynamic yane::Model::Model::odeFunction and the running costs yane::Model::Model::continuousCostfunction defined within the class Model object under consideration.
				@param n Dimension of the differential equation system
				@param t Time grid
				@param y Initial value of the state
				@param dy Value of the right hand side of the differential equation system
				@param rpar Vector of real valued parameters
				@param ipar Vector of integer valued parameters
				@brief Function to compute the solution of the differential equation system
				*/
				static void combinedOdeSystem ( int * n, double * t, double * y, double * dy, double * rpar, int* ipar );

				/**
				Function to evaluate the mass matrix of the differential equation system. Here, this system consists of the dynamic yane::Model::Model::odeFunction and the running costs yane::Model::Model::continuousCostfunction defined within the class Model object under consideration.
				@param n Dimension of the differential equation system
				@param M Mass matrix
				@param lmas Number of subdiagonals
				@param rpar Vector of real valued parameters
				@param ipar Vector of integer valued parameters
				@brief Function to evaluate the mass matrix of the differential equation system
				 */
				static void combinedMassMatrix ( int * n, double * M, int * lmas, double * rpar, int * ipar );

				/**
				@brief Function to free all internally allocated memory
				 */
				void freeMem();

				yane::OdeSolve::OdeFunction * _dgl;	/**< @brief Pointer of the control system */
				yane::Model::Model * _model;		/**< @brief Pointer of the model object */
				yane::OdeSolve::OdeSolveFirst * _ode;	/**< @brief Pointer of the used odemanager object of class yane::OdeSolve::OdeSolveFirst */

				int _dimension;				/**< @brief Dimension of the state variable */
				int _dimension_u;			/**< @brief Dimension of the control variable */
				int _horizon;				/**< @brief Length of the horizon */
				int _dim_restr;				/**< @brief Total number of restrictions */
				T_DISCRRESTRFUNC _restrfunction;	/**< @brief Pointer of the nonlinear restrictions */

				double * _x;				/**< @brief State vector */
				double * _tempx;			/**< @brief Auxilliary state vector for computation of the gradient of the cost function */
				double * _tempr1;			/**< @brief Auxilliary vector of constraint values for computation of the Jacobian of the constraints */
				double * _tempr2;			/**< @brief Auxilliary vector of constraint values for computation of the Jacobian of the constraints */
				T_MPCDATA * _data;			/**< @brief Structure of MPC data values */
				double * _points;			/**< @brief Auxilliary state vector to evaluate the point cost function */

				void * _discretization;			/**< @brief Pointer of the Class Discretization object */
				void * _configuration;			/**< @brief Pointer of the Class MPCConfig object */
				double * _mass;				/**< @brief Pointer of the mass matrix */

				T_SHOOTINGDATA * _sdata;			/**< @brief Pointer of the shooting data vector */
				int _sdatalength;			/**< @brief Number of shooting nodes */

				double _weightcf;			/**< @brief Weight of the discrete part of the cost function */
				double _weightint;			/**< @brief Weight of the integral part of the cost function */
		};

	}

}


#endif
