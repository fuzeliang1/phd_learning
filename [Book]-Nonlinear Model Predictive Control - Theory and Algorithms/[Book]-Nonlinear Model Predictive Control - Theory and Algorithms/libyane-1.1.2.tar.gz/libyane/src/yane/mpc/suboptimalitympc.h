/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_SUBOPTIMALITYMPC_H
#define YANE_MPC_SUBOPTIMALITYMPC_H

#include "mpc.h"

namespace yane
{

	namespace MPC
	{

		/** \class SuboptimalityMPC
		 Implementation of various suboptimality estimates for model predictive control laws \n
		 Using the classes methods one can compute the degree of suboptimality along the closed loop solution as well as the local degree of suboptimality. In the nonpractical case, the results are based on the relaxed Lyapunov inequality
		 \f[ V_N(x(n + 1)) \leq V_N(x(n)) - \alpha l(x(n), \mu_N(x(n))) \f]
		 while in the practical case results are derived from the practical variant of the relaxed Lyapunov inequality
		 \f[ V_N(x(n + 1)) \leq V_N(x(n)) - \min \{ \alpha ( l(x(n), \mu_N(x(n))) - \varepsilon ), l(x(n), \mu_N(x(n))) - \varepsilon \} \f]
		 \brief Implementation of various suboptimality estimates for model predictive control laws
		*/
		class SuboptimalityMPC : public MPC
		{
			public:
				/**
				@brief Constructor
				@param h_new Discretization width
				@param INFTY Value for \f$ \infty \f$
				 */
				SuboptimalityMPC ( double h_new, double INFTY = 1E19 );

				/**
				@brief Destructor
				 */
				~SuboptimalityMPC();

				/**
				This function computes a suboptimality estimate using the relaxed Lyapunov inequality
				\f[ V_N(x(n + 1)) \leq V_N(x(n)) - \alpha l(x(n), \mu_N(x(n))) \f]
				for the closed loop solution along the closed loop trajectory. Here, the values of the optimal value function of two consecutive optimal control problems \f$ V_N(x(n)) \f$ and \f$ V_N(x(n + 1)) \f$ with identical length of the optimization horizon are related to the running cost \f$ l(x(n), \mu_N(x(n))) \f$ of the older optimal control problem. The suboptimality estimate is given by the maximal value of the parameter \f$ \alpha \f$ which satisfies
				\f[ \alpha \leq \frac{V_N(x(n)) - V_N(x(n + 1))}{l(x(n), \mu_N(x(n)))} \f]
				\b Remark: This function assumes the optimal control for the current optimization horizon is known.
				@param x Current state vector
				@param alpha Suboptimality estimate which contains
				- the value of the estimate in the prior MPC step on entrance
				- either the estimate for the current MPC step or the minimum of the current estimate and the previous estimate according to the choice of yane::MPC::SuboptimalityMPC::single on exit
				@param saveprevious Decision variable to store the running cost and cost function value of the current MPC step
				@param restart Decision variable if the estimate shall be restarted
				@throw yane::MPC::SuboptimalityException Is thrown if \f$ V_N(x(n + 1)) > V_N(x(n)) \f$ or \f$ V_N(x(n + 1)) < V_N(x(n)) - l(x(n), \mu_N(x(n))) \f$ holds \n
				Remark: If this exception occurs due to the second condition then it is likely that a wrong value of \f$ V_N(x(n + 1)) \f$ has been computed. In the following MPC step this can be seen from a value \f$ \alpha > 1 \f$.
				@throw yane::Utils::Exception Is thrown if any other error occured
				@brief Function to evaluate the a posteriori suboptimality estimate
				 */
				void aposterioriEstimate ( double * x, double & alpha, bool saveprevious = true, bool restart = false );

				/**
				This function computes a m-step suboptimality estimate using the relaxed Lyapunov inequality
				\f[ V_N(x(n + m)) \leq V_N(x(n)) - \alpha \sum\limits_{j = n}^{n + m} l(x_u(j, x(n)), u(j, x(n))) \f]
				for the closed loop solution along the closed loop trajectory. Here, we relate two optimal control problems to each other which arise from a shift of \f$ m \f$ time instances, i.e. we not only implement one control vector but a sequence of \f$ m \f$ control vectors before reoptimizing. The values of the optimal value function of two consecutive optimal control problems \f$ V_N(x(n)) \f$ and \f$ V_N(x(n + m)) \f$ with identical length of the optimization horizon are related to the sum of running cost \f$ \sum\limits_{j = n}^{n + m} l(x(n), \mu_N(x(n))) \f$ of the older optimal control problem. The suboptimality estimate is given by the maximal value of the parameter \f$ \alpha \f$ which satisfies
				\f[ \alpha \leq \frac{V_N(x(n)) - V_N(x(n + m))}{\sum\limits_{j = n}^{n + m} l(x_u(j, n), u(j, x(n)))} \f]
				\b Remark: This function assumes the optimal control for the current optimization horizon is known.
				@param x Current state vector
				@param alpha Suboptimality estimate which contains
				- the value of the estimate in the prior MPC step on entrance
				- either the estimate for the current MPC step or the minimum of the current estimate and the previous estimate according to the choice of yane::MPC::SuboptimalityMPC::single on exit
				@param m Number of control vectors which shall be implemented
				@param saveprevious Decision variable to store the running cost and cost function value of the current MPC step
				@param restart Decision variable if the estimate shall be restarted
				@throw yane::MPC::SuboptimalityException Is thrown if \f$ V_N(x_{u}(n + m, x)) > V_N(x_{u}(n, x)) \f$ or \f$ V_N(x(n + m)) < V_N(x(n)) - \sum\limits_{j = n}^{n + m} l(x_u(j, x(n)), u(j, x(n))) \f$ holds \n
				Remark: If this exception occurs due to the second condition then it is likely that a wrong value of \f$ V_N(x(n + m)) \f$ has been computed. In the following MPC step this can be seen from a value \f$ \alpha > 1 \f$.
				@throw yane::OdeSolve::OdeSolEx Is thrown if the yane::OdeSolve::OdeSolve object terminates with an error
				@throw yane::Utils::ValueException Is thrown if a null pointer is submitted or \f$ m \f$ is larger than the optimization horizon
				@throw yane::Utils::Exception Is thrown if any other error occured
				@brief Function to evaluate the m-step a posteriori suboptimality estimate
				 */
				void mstepAposterioriEstimate ( double * x, double & alpha, int m, bool saveprevious = true, bool restart = false );

				/**
				This function computes the a priori suboptimality estimate implicitely based on the relaxed Lyapunov inequality
				\f[ V_N(x(n + 1)) \leq V_N(x(n)) - \alpha l(x(n), \mu_N(x(n))) \f]
				along the closed loop trajectory. Since the value of \f$ V_N(x(n + 1)) \f$ is not readily available at runtime of the algorithm this is replaced by a sufficient condition: \n
				Suppose that for a given \f$ N \geq N_0 \geq 2 \f$ there exists a \f$ \gamma > 0 \f$ such that inequalities
				\f[ \frac{V_{N_0}(x_{u}(N - N_0, x(n)))}{\gamma + 1} \leq \max_{j = 2, \ldots, N_0} l(x_{u}(N - j, x(n)), \mu_{j - 1}(x_{u}(N - j, x(n)))) \f]
				\f[ \frac{V_k(x_{u}(N - k, x(n)))}{\gamma + 1} \leq l(x_{u}(N - k, x(n)), \mu_k(x_{u_N}(N - k, x(n)))) \f]
				hold for all \f$ k \in \{N_0 + 1, \ldots, N \} \f$ and all \f$ n \geq 0 \f$. Here, \f$ x_{u}(j, x(n)) \f$ denotes the \f$ j \f$th open loop state vector of the optimal control problem with initial value \f$ x(n) \f$ and horizon length \f$ N \f$. \n
				Then, we can compute the suboptimality degree \f$ \alpha \f$ according to the following formula
				\f[ \alpha = \frac{(\gamma + 1)^{N - N_0} - \gamma^{N - N_0 + 2}}{(\gamma + 1)^{N - N_0}} \f]
				\b Remark: This function assumes the optimal control for the current optimization horizon is known.
				@param x Current state vector
				@param alpha Suboptimality estimate which contains
				- the value of the estimate in the prior MPC step on entrance
				- either the estimate for the current MPC step or the minimum of the current estimate and the previous estimate according to the choice of yane::MPC::SuboptimalityMPC::single on exit
				@param gamma Variable \f$ \gamma \f$ which contains
				- the value of the characteristic of the prior MPC step on entrance
				- either the characteristic or the minimum of the current and the previous characteristic according to the choice of yane::MPC::SuboptimalityMPC::single on exit
				@param N0 Horizon length of the auxilliary optimal control problem
				@throw yane::MPC::SuboptimalityException Is thrown if one of the optimal control problems is not correctly solved \n
				Remark: If this exception is thrown then either a wrong value of \f$ l(x_{u}(N - j, x(n)), \mu_{j - 1}(x_{u}(N - j, x(n)))) \f$ or \f$ V_{N}(x(n)) \f$ has been computed within the optimization. This becomes obvious if a value \f$ \alpha > 1 \f$ could be obtained.
				@throw yane::MPC::MPCException Is thrown if an MPC internal error occured
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::OdeSolve::OdeSolEx Is thrown if the yane::OdeSolve::OdeSolve object terminates with an error
				@throw yane::Utils::ValueException Is thrown if a null pointer is submitted or \f$ N_0 \f$ is larger than the optimization horizon
				@throw yane::Utils::Exception Is thrown if any other error occured
				@brief Function to evaluate the a priori suboptimality estimate
				 */
				void aprioriEstimate ( double * x, double & alpha, double & gamma, int N0 );

				/**
				This function computes the a posteriori practical suboptimality estimated based upon the relaxed Lyapunov inequality
				\f[ V_N(x(n + 1)) \leq V_N(x(n)) - \min \{ \alpha ( l(x(n), \mu_N(x(n))) - \varepsilon ), l(x(n), \mu_N(x(n))) - \varepsilon \} \f]
				along the closed loop trajectory. Here, the values of the optimal value function of two consecutive optimal control problems \f$ V_N(x(n)) \f$ and \f$ V_N(x(n + 1)) \f$ with identical length of the optimization horizon are related to the running costs of the past optimal control problem \f$ l(x(n), \mu_N(x(n))) \f$. Once a set \f$ \mathcal{L} \f$ is reached which is forward invariant under the control law \f$ u_N \f$, then \f$ n_0  \f$ denotes the minimal index such that for all \f$ 0 \leq n \leq n_0 \f$ the inequality
				\f[ V_N(x(n + 1)) \leq V_N(x(n)) \f]
				holds. Furthermore we define
				\f[ \sigma := \inf \{ V_N(x(n+ 1)) \, | \; 0 \leq n \leq n_0 \} = V_N(x(n_0 + 1)). \f]
				Then the suboptimality estimate
				\f[ \alpha V_\infty(x(n)) \leq \alpha V_\infty^{u_N}(x(n)) \leq V(x(n)) - \sigma, \f]
				hold with parameter \f$ \alpha \f$ which is chosen maximally satisfying the above inequality.\n
				\b Remark: This function assumes the optimal control for the current optimization horizon is known.
				@param x Current state vector
				@param alpha Suboptimality estimate which contains
				- the value of the estimate in the prior MPC step on entrance
				- either the estimate for the current MPC step or the minimum of the current estimate and the previous estimate according to the choice of yane::MPC::SuboptimalityMPC::single on exit
				@param saveprevious Decision variable to store the running cost and cost function value of the current MPC step
				@param restart Decision variable if the estimate shall be restarted
				@throw yane::MPC::SuboptimalityException Is thrown if \f$ V_N(x(n + 1)) > V_N(x(n)) \f$ or \f$ V_N(x(n)) < V_N(x(n + 1)) - l(x(n), \mu_N(x(n))) + \varepsilon \f$ holds \n
				Remark: If this exception occurs due to the second condition then it is likely that a wrong value of \f$ V_N(x(n + 1)) \f$ has been computed. In the following MPC step this can be seen from a value \f$ \alpha > 1 \f$.
				@throw yane::MPC::PracticalException Is thrown if \f$ l(x(n), \mu_N(n)) < \varepsilon \f$
				@throw yane::Utils::Exception Is thrown if any other error occured
				@brief Function to evaluate the a posteriori practical suboptimality estimate
				 */
				void aposterioriPracticalEstimate ( double * x, double & alpha, bool saveprevious = true, bool restart = false );

				/**
				This function computes the a posteriori practical suboptimality estimated based upon the relaxed Lyapunov inequality
				\f[ V_N(x(n + 1)) \leq V_N(x(n)) - \min \{ \alpha ( \sum\limits_{j = n}^{n + m} l(x_u(j, x(n)), u(j, x(n))) - \varepsilon ), \sum\limits_{j = n}^{n + m} l(x_u(j, x(n)), u(j, x(n))) - \varepsilon \} \f]
				along the closed loop trajectory. Here, we relate two optimal control problems to each other which arise from a shift of \f$ m \f$ time instances, i.e. we not only implement one control vector but a sequence of \f$ m \f$ control vectors before reoptimizing. The values of the optimal value function of two consecutive optimal control problems \f$ V_N(x(n)) \f$ and \f$ V_N(x(n + m)) \f$ with identical length of the optimization horizon are related to the sum of running cost \f$ \sum\limits_{j = n}^{n + m} l(x(n), \mu_N(x(n))) \f$ of the older optimal control problem. Once a set \f$ \mathcal{L} \f$ is reached which is forward invariant under the control law \f$ u_N \f$, then \f$ n_0  \f$ denotes the minimal index such that for all \f$ 0 \leq n \leq n_0 \f$ the inequality
				\f[ V_N(x(n + 1)) \leq V_N(x(n)) \f]
				holds. Furthermore we define
				\f[ \sigma := \inf \{ V_N(x(n + m)) \, | \; 0 \leq n \leq n_0 \} = V_N(x(n_0 + 1)). \f]
				Then the suboptimality estimate
				\f[ \alpha V_\infty(x(n)) \leq \alpha V_\infty^{u_N}(x(n)) \leq V(x(n)) - \sigma, \f]
				hold with parameter \f$ \alpha \f$ which is chosen maximally satisfying the above inequality.\n
				\b Remark: This function assumes the optimal control for the current optimization horizon is known.
				@param x Current state vector
				@param alpha Suboptimality estimate which contains
				- the value of the estimate in the prior MPC step on entrance
				- either the estimate for the current MPC step or the minimum of the current estimate and the previous estimate according to the choice of yane::MPC::SuboptimalityMPC::single on exit
				- or 1 if the restart option is used
				@param m Number of control vectors which shall be implemented
				@param saveprevious Decision variable to store the running cost and cost function value of the current MPC step (default true)
				@param restart Decision variable if the estimate shall be restarted (default false)
				@throw yane::MPC::SuboptimalityException Is thrown if \f$ V_N(x(n + m)) > V_N(x(n)) \f$ or \f$ V_N(x(n)) < V_N(x(n + m)) - \sum\limits_{j = i}^{i + m} l(x_u(j, x(n)), u(j, x(n))) + \varepsilon \f$ holds \n
				Remark: If this exception occurs due to the second condition then it is likely that a wrong value of \f$ V_N(x(n + m)) \f$ has been computed. In the following MPC step this can be seen from a value \f$ \alpha > 1 \f$.
				@throw yane::MPC::PracticalException Is thrown if \f$ \sum\limits_{j = i}^{i + m} l(x_u(j, x(n)), u(j, x(n))) < \varepsilon \f$
				@throw yane::MPC::MPCException Is thrown if an MPC internal error occured
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::OdeSolve::OdeSolEx Is thrown if the yane::OdeSolve::OdeSolve object terminates with an error
				@throw yane::Utils::ValueException Is thrown if a null pointer is submitted or \f$ N_0 \f$ is larger than the optimization horizon
				@throw yane::Utils::Exception Is thrown if any other error occured
				@brief Function to evaluate the m-step a posteriori practical suboptimality estimate
				 */
				void mstepAposterioriPracticalEstimate ( double * x, double & alpha, int m, bool saveprevious = true, bool restart = false );

				/**
				This function computes the a priori suboptimality estimate implicitely based on the relaxed Lyapunov inequality
				\f[ V_N(x(n + 1)) \leq V_N(x(n)) - \min \{ \alpha ( l(x(n), \mu_N(x(n))) - \varepsilon ), l(x(n), \mu_N(x(n))) - \varepsilon \} \f]
				along the closed loop trajectory. Since the value of \f$ V_N(x(n + 1)) \f$ is not readily available at runtime of the algorithm this is replaced by a sufficient condition: \n
				Suppose that for a given \f$ N \geq N_0 \geq 2 \f$ there exists a \f$ \gamma > 0 \f$ such that inequalities
				\f[ V_{N_0}(x_{u}(N - N_0, x(n))) \leq \max_{j = 2, \ldots, N_0} \{ (\gamma + 1) l(x_{u}(N - j, x(n)), \mu_{j - 1}(x_{u}(N - j, x(n)))) + (1 - (N_0 - 1) \gamma) \varepsilon, l(x_{u}(N - j, x(n)), \mu_{j - 1}(x_{u}(N - j, x(n)))) + \varepsilon \} \f]
				\f[ V_k(x_{u}(N - k, x(n))) \leq \max \{ (\gamma + 1) l(x_{u}(N - k, x(n)), \mu_k(x_{u}(N - k, x(n)))) + (k - \gamma - 1) \varepsilon, l(x_{u}(N - k, x(n)), \mu_k(x_{u}(N - k, x(n)))) + (k - 1) \varepsilon \} \f]
				hold for all \f$ k \in \{N_0 + 1, \ldots, N \} \f$ and all \f$ n \geq 0 \f$. Here, \f$ x_{u}(j, x(n)) \f$ denotes the \f$ j \f$th open loop state vector of the optimal control problem with initial value \f$ x(n) \f$ and horizon length \f$ N \f$. \n
				Then, we can compute the suboptimality degree \f$ \alpha \f$ according to the following formula
				\f[ \alpha = \frac{(\gamma + 1)^{N - N_0} - \gamma^{N - N_0 + 2}}{(\gamma + 1)^{N - N_0}} \f]
				\b Remark: This function assumes the optimal control for the current optimization horizon is known.
				@param x Current state vector
				@param alpha Suboptimality estimate which contains
				- the value of the estimate in the prior MPC step on entrance
				- either the estimate for the current MPC step or the minimum of the current estimate and the previous estimate according to the choice of yane::MPC::SuboptimalityMPC::single on exit
				@param gamma Variable \f$ \gamma \f$ which contains
				- the value of the characteristic of the prior MPC step on entrance
				- either the characteristic or the minimum of the current and the previous characteristic according to the choice of yane::MPC::SuboptimalityMPC::single on exit
				@param N0 Horizon length of the auxilliary optimal control problem
				@throw yane::MPC::SuboptimalityException Is thrown if  \n
				(1)  \f$ \max\limits_{j=2, \ldots, N_0} l(x_{u}(N - j, x(n)), \mu_{j-1}(x_{u}(N - j, x(n))) \leq ( N_0 - 1 ) \varepsilon \f$ \n
				(2)  \f$ V_{N_0}(x_{u}(N - N_0, x(n))) \leq \max\limits_{j=2, \ldots, N_0} l(x_{u}(N - j, x(n)), \mu_{j - 1}(x_u(N - j, x(n)))) + \varepsilon \f$ \n
				(3)  \f$ V_k(x_{u}(N - k, x(n))) \leq k \varepsilon \f$ for all \f$ k \in \{ N_0 + 1, \ldots, N \} \f$ \n
				(4)  \f$ l(x_{u}(N - k, x(n)), \mu_N(x_{u}(N - k, x(n))) \leq \varepsilon \f$
				@throw yane::MPC::PracticalException Is thrown if \f$ l(x(n), \mu_N(x(n))) < \varepsilon \f$
				@throw yane::MPC::MPCException Is thrown if an MPC internal error occured
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::OdeSolve::OdeSolEx Is thrown if the yane::OdeSolve::OdeSolve object terminates with an error
				@throw yane::Utils::ValueException Is thrown if a null pointer is submitted or \f$ N_0 \f$ is larger than the optimization horizon
				@throw yane::Utils::Exception Is thrown if any other error occured
				@brief Function to evaluate the a priori practical suboptimality estimate
				 */
				void aprioriPracticalEstimate ( double * x, double & alpha, double & gamma, int N0 );
				
                                /**
				 * This functions resets the class yane::MPC::SuboptimalityMPC object with new pointers for underlying classes.
				 * @param odemanager Pointer to used class yane::MPC::OdeManager object
				 * @param minimizer Pointer to used class yane::Minprog2::NLP object
				 * @param model Pointer to used class yane::Model::Model object
				 * @param horizon Maximal length of the optimization horizon
				 * @param precedesteps Number of prediction steps to obtain initial value for optimization
				 * @param shootingdata Pointer to used class yane::MPC::ModelShootingData object
				 * @throw yane::MPC::MPCException Is thrown if an MPC internal error occured
				 * @brief Function to reset the class yane::MPC::SuboptimalityMPC object with new pointers for underlying classes
				 */
				virtual void reset ( OdeManager * odemanager, yane::MinProg::NLP * minimizer, yane::Model::Model * model, int horizon, int precedesteps = 0, ModelShootingData * shootingdata = 0 );

				virtual void resizeHorizon ( int newhorizon, double h_new );

				/**
				This function set the decision variable to distinguish between computing local and closed loop suboptimality estimates.
				@param single Decision variable to distinguish between computing local and closed loop suboptimality estimates
				@brief Function to set the decision variable to distinguish between computing local and closed loop suboptimality estimates
				*/
				void setSingle ( bool single = true );

				/**
				This function sets the radius of the (supposably) practical stability region.
				@param epsilon Radius of the (supposably) practical stability region
				@brief Function to set the radius of the (supposably) practical stability region
				*/
				void setEpsilon ( double epsilon = 1E-6 );

				/**
				@brief Function to set the maximal number of Newton steps to compute \f$ \gamma(N) \f$ from a posteriori estimate of \f$ \alpha(N) \f$
				@param newtonItermax Maximal number of Newton steps
				 */
				void setNewtonItermax ( int newtonItermax );

				/**
				Function to set the sampling width of the new added horizon instances
				@param h_new Sampling width
				@brief Function to set the sampling width of the new added horizon instances

				 */
				void setSamplingLength ( double h_new );

				/**
				@brief Function to return the sampling width
				@return Sampling width
				 */
				double samplingLength();

				/**
				Function to configure the suboptimality algorithm
				@param estimate Decision variable to define the computing method of the suboptimality degree
				- (0) Standardimplementation without adaptation of the horizon length
				- (1) Adaptation of the horizon length using the a posteriori estimate
				- (2) Adaptation of the horizon length using the a posteriori practical estimate
				- (3) Adaptation of the horizon length using the a priori estimate
				- (4) Adaptation of the horizon length using the a priori practical estimate
				@param N0 Parameter for the a priori suboptimality estimate, requires \f$ N_0 \geq 2 \f$, default is \f$ N_0 = 2 \f$
				@brief Function to configure the suboptimality algorithm
				 */
				void setConfigSuboptimalityMPC ( T_ESTIMATE estimate, int N0 = 2 );

				/**
				Function to set decision variable to store predicted value function in case an predicted aposteriori estimate is used
				@param storeValuefunction Decision variable
				@brief Function to set decision variable to store predicted value function in case an predicted aposteriori estimate is used
				*/
				void setStoreValuefunction ( bool storeValuefunction );

				/**
				Function to return the stored degree of suboptimality \f$ \alpha \f$
				@return degree of suboptimality \f$ \alpha \f$
				@brief Function to return the stored degree of suboptimality \f$ \alpha \f$
				 */
				double alpha();

			protected:

				/**
				Function to compute the suboptimality estimate \f$ \alpha(N) \f$ \n
				To this end, the suboptimality estimate of class SuboptimalityMPC chosen by setting \b estimate in method \b setConfigSuboptimalityMPC is used.\n
				\b Remark: This function doesnot assume the optimal control for the current optimization horizon to be known. However, setting _controlAlreadyOptimal to \b true will override an additional start of the minimizer.
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@sa yane::MPC::AdaptiveMPC::setConfigAdaptiveMPC Function to configure the adaptation algorithm
				@sa yane::MPC::AdaptiveMPC::_estimate Decision variable to define the computing method of the suboptimality degree
				- (0) Standardimplementation without adaptation of the horizon length
				- (1) Adaptation of the horizon length using the a posteriori estimate
				- (2) Adaptation of the horizon length using the a posteriori practical estimate
				- (3) Adaptation of the horizon length using the a priori estimate
				- (4) Adaptation of the horizon length using the a priori practical estimate
				@brief Function to compute the suboptimality estimate \f$ \alpha(N) \f$
				 */
				void calcAlpha ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Function to compute \f$ \gamma(N) \f$ for given \f$ \alpha(N) \f$
				@sa _newtonItermax Maximal number of Newton steps
				@param N0 Length of the subproblem
				@brief Function to compute \f$ \gamma(N) \f$ for given \f$ \alpha(N) \f$
				 */
				void aposterioriGamma ( int N0 );

				/**
				Function to compute the suboptimality estimate \f$ \alpha(N) \f$ using the methods yane::MPC::SuboptimalityMPC::aposterioriEstimate or yane::MPC::SuboptimalityMPC::aposterioriPracticalEstimate \n
				To this end the open-loop problem is artificially shifted forward in time and the resulting value of \f$ V_N(\cdot) \f$ is used within the estimate \f$ \alpha(N) \f$. \n
				Remark: If the adaptation algorithm is used with the methods yane::MPC::AdaptiveMPC::fixpointProlongation or yane::MPC::AdaptiveMPC::monotoneProlongation then the method yane::MPC::AdaptiveMPC::aposterioriGamma is called to compute \f$ \gamma(N) \f$.\n
				\b Remark: This function doesnot assume the optimal control for the current optimization horizon to be known. However, setting _controlAlreadyOptimal to \b true will override an additional start of the minimizer.

				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@throw yane::Utils::MemoryException Is thrown if memory allocation failed
				@brief Function to compute the suboptimality estimate \f$ \alpha(N) \f$ using the methods yane::MPC::SuboptimalityMPC::aposterioriEstimate or yane::MPC::SuboptimalityMPC::aposterioriPracticalEstimate
				 */
				void predictedAposterioriEstimate ( double * x, int realtimesteps, double aborttimeoffset );

				/**
				Function to compute the suboptimality estimate \f$ \alpha(N) \f$ using the methods yane::MPC::SuboptimalityMPC::aposterioriEstimate or yane::MPC::SuboptimalityMPC::aposterioriPracticalEstimate for \f$ m \f$ open loop steps \n
				To this end the open-loop problem is artificially shifted forward in time and the resulting value of \f$ V_N(\cdot) \f$ is used within the estimate \f$ \alpha(N) \f$. \n
				Remark: If the adaptation algorithm is used with the methods yane::MPC::AdaptiveMPC::fixpointProlongation or yane::MPC::AdaptiveMPC::monotoneProlongation then the method yane::MPC::AdaptiveMPC::aposterioriGamma is called to compute \f$ \gamma(N) \f$.\n
				\b Remark: This function doesnot assume the optimal control for the current optimization horizon to be known. However, setting _controlAlreadyOptimal to \b true will override an additional start of the minimizer.
				@param x Estimate of the initial value of the state
				@param m Number of open loop steps
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@throw yane::Utils::MemoryException Is thrown if memory allocation failed
				@brief Function to compute the suboptimality estimate \f$ \alpha(N) \f$ using the methods yane::MPC::SuboptimalityMPC::aposterioriEstimate or yane::MPC::SuboptimalityMPC::aposterioriPracticalEstimate
				 */
				void mstepPredictedAposterioriEstimate ( double * x, int m = 1, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Function to compute the suboptimality estimate \f$ \alpha(N) \f$ using the methods yane::MPC::SuboptimalityMPC::aprioriEstimate or yane::MPC::SuboptimalityMPC::aprioriPracticalEstimate \n
				\b Remark: This function doesnot assume the optimal control for the current optimization horizon to be known. However, setting _controlAlreadyOptimal to \b true will override an additional start of the minimizer.
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::MPC::MPCException Is thrown if the underlying yane::MPC::MPC object terminates with an error
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@brief Function to compute the suboptimality estimate \f$ \alpha(N) \f$ using the methods yane::MPC::SuboptimalityMPC::aposterioriEstimate or yane::MPC::SuboptimalityMPC::aposterioriPracticalEstimate
				 */
				void aprioriCalculatedEstimate ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				T_ESTIMATE _estimate;   /**< @brief Decision variable to define the computing method of the suboptimality degree
						- NONE Standardimplementation without adaptation of the horizon length
						- APOSTERIORI Adaptation of the horizon length using the a posteriori estimate
						- APOSTERIORIPRACTICAL Adaptation of the horizon length using the a posteriori practical estimate
						- APRIORI Adaptation of the horizon length using the a priori estimate
						- APRIORIPRACTICAL Adaptation of the horizon length using the a priori practical estimate */
				bool _controlAlreadyOptimal; /**< @brief Decision variable whether optimal control needs to be recalculated for suboptimality estimate */
				int _N0;    /**< @brief Parameter of the auxilliary length of the additional optimal control problem to compute the a priori suboptimality estimate */
				double _alpha;    /**< @brief Suboptimality estimate */
				double _alphabound;   /**< @brief Suboptimality bound */
				double _gamma;    /**< @brief Current value of \f$ \gamma(N) \f$ */
				double _epsilon;    /**< @brief Radius of the (supposably) practical stability region */
				double * _nextcontrols;   /**< @brief Control vector for implementation */
				double * _nexttimesteps;  /**< @brief Time grid for implementation */
				double _h_new;    /**< @brief New added sampling width */
				double * _x_predicted;   /**< @brief Predicted state vector */
				double * _timesteps_current;  /**< @brief Time grid */
				double * _u_current;   /**< @brief Current state vector */
				double * _valuefunction_simulated;  /**< @brief Pointer of the cost function along the open loop solution */
				double * _valuefunction_base;  /**< @brief Pointer of the cost function along the open loop solution for a base initial value using predicted a posteriori estimates */
				double * _valuefunction_predicted;  /**< @brief Pointer of the cost function along the open loop solution for a predicted initial value using predicted a posteriori estimates */
				double * _trajectory_simulated;  /**< @brief Pointer of the open loop solution */

			private:
				inline void allocateValueAndTrajectory();  /**< @brief (Re-)Allocates memory for open loop solution */
				inline void freeValueAndTrajectory();  /**< @brief Frees memory for open loop solution */

				inline void allocateSubproblem ( int N0 ); /**< @brief (Re-)Allocates memory for the optimal control subproblem */
				inline void freeSubproblem();  /**< @brief Frees the memory for the optimal control subproblem */

				bool _single;    /**< @brief Decision variable to distinguish between computing local and closed loop suboptimality estimates */
				bool _storeValuefunction;	/**< @brief Decision variable to store value functions in case an predicted aposteriori estimate is used */
				int _newtonIterMax;   /**< @brief Maximal number of Newton steps */
				double _alpha2;    /**< @brief Auxilliary parameter to compute suboptimality degree \f$ \alpha \f$ */

				double _valuefunction_previous;  /**< @brief Value of the value function at the last NMPC iterate */
				double _runningcost_previous;  /**< @brief Value of the running costs at the last NMPC iterate */

				Discretization * _subproblem;  /**< @brief Pointer of the class yane::MPC::Discretization object of the subproblem */
				double _maxsubproblemcurrentrunningcost; /**< @brief Maximal value of the running costs of the subproblem */
				double * _subproblemcurrentvaluefunction; /**< @brief Pointer of the cost function along the open loop solution of the subproblem */
				double * _subproblemtrajectory;  /**< @brief Pointer of the open loop solutions of the subproblem */
				double * _subproblemcontrol;  /**< @brief Pointer of the open loop control of the subproblem */
		};

	}

}

#endif
