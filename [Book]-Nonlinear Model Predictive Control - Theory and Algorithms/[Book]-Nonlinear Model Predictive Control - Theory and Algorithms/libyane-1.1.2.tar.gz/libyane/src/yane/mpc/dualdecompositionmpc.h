/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_DUALDECOMPOSITIONMPC_H
#define YANE_MPC_DUALDECOMPOSITIONMPC_H

#include "networkedmpcconfig.h"

namespace yane
{

	namespace MinProg
	{
		class GaussNewton;
	}

	namespace MPC
	{

		/** @class DualDecompositionMPC
		This class allows to control a plant using MPC and Dual Decomposition in a network of connected plants.
		@brief Not yet documented
		 */
		class DualDecompositionMPC : public yane::MPC::NetworkedMPCConfig
		{
			public:
				DualDecompositionMPC();

				~DualDecompositionMPC();

				void resetDiscretization ( Discretization * problem );
				void computeNewMultiplier();

				void addInputNeighbour ( NetworkedMPCConfig * neighbour );
				void addInputNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps );
				void removeInputNeighbour ( NetworkedMPCConfig * neighbour );
				void removeInputNeighbour ( yane::Utils::Uuid * uuid );
				void updateInputNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, double * multiplier, int precedesteps );

				void addNeighbour ( NetworkedMPCConfig * neighbour );
				void addNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps );
				void removeNeighbour ( NetworkedMPCConfig * neighbour );
				void removeNeighbour ( yane::Utils::Uuid * uuid );
				void updateOutputNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, double * multiplier, int precedesteps );

				void updateNeighbour ( NetworkedMPCConfig * neighbour, double * timesteps, double * control, double * state, double * multiplier );
				void updateNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, double * multiplier, int precedesteps );


			protected:
				static void networkCostfunction ( const double * x, double * fx, void * params );

				static void objectivFunctionMultiplierNLP ( const double *x, double *fx, void *params );
				static void boxConstraintsMultiplierNLP ( int numberOfMultipliers, double * _lbound_multiplier, double * _ubound_multiplier );

				std::vector <std::vector <double> > _inputNeighbourMultiplier;

				yane::MinProg::GaussNewton * _minimizer;
				bool _resetMultiplierNLP;
				double * _lbound_multiplier;
				double * _ubound_multiplier;
				double * _multiplier;
				int _numberOfMultipliers;

		};

	}

}

#endif
