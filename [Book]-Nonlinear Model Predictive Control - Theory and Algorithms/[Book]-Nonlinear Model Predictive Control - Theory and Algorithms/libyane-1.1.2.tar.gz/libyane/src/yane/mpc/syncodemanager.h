/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_SYNCODEMANAGER_H
#define YANE_MPC_SYNCODEMANAGER_H

#include "typedefs.h"
#include "odemanager.h"

using namespace std;

namespace yane
{
	namespace OdeSolve
	{
		class OdeFunction;
		class OdeSolveFirst;
	}

	namespace MPC
	{

		class Cache;

		/** @class SyncOdeManager
		@brief Implementation of a manager class for solving the control system and its derivative in a synchronized way
		*/
		class SyncOdeManager : public OdeManager
		{
			public:
				/**
				@throw yane::Utils::MemoryException Is thrown if memory allocation failed
				@brief Constructor
				*/
				SyncOdeManager();

				/**
				@brief Destructor
				*/
				~SyncOdeManager();

				virtual void calcObjectiveFunction ( double * t, double* x, double* u, double* fx );
				virtual void calcObjectiveFunctionGrad ( double * t, double* x, double* u, double* fx );
				virtual void calcRestrFunction ( double * t, double * x, double* u, double* fx );
				virtual void calcRestrFunctionGrad ( double * t, double * x, double* u, double* fx, yane::MinProg::T_MEMMODEL memmodel, int * needc=0 );
				virtual void setFunctions ( int horizont, int total_restr, yane::Model::Model * model, T_DISCRRESTRFUNC restrfunc, int sdatalength=0, T_SHOOTINGDATA * sdata=0 );
				virtual void setAuxilliaryObjects ( void * discretization, void * configuration = 0 );
				virtual void getObjFunValues ( double * t, double * x, double * u, double * fx, double * points );
				virtual OdeManager * clone();
				virtual void * configuration();


			private:
				/**
				Function to compute the solution of the differential equation system. Here, this system consists of the dynamic yane::Model::Model::odeFunction and the running costs yane::Model::Model::continuousCostfunction defined within the class Model object under consideration.
				@param n Dimension of the differential equation system
				@param t Time grid
				@param y Initial value of the state
				@param dy Value of the right hand side of the differential equation system
				@param rpar Vector of real valued parameters
				@param ipar Vector of integer valued parameters
				@brief Function to compute the solution of the differential equation system
				 */
				static void combinedOdeSystem ( int * n, double * t, double * y, double * dy, double * rpar, int* ipar );

				/**
				Function to evaluate the combined mass matrix. Here, the mass matrix contains the mass matrix of the dynamic of the system itself as well as the mass matrix of the cost function.
				@param n Dimension of the dynamic
				@param M Mass matrix
				@param lmas Number of of-diagonals
				@param rpar Vector of real valued parameter
				@param ipar Vector of integer valued parameter
				@brief Function to evaluate the combined mass matrix
				 */
				static void combinedMassMatrix ( int * n, double * M, int * lmas, double * rpar, int * ipar );

				/**
				Function to evaluate the mass matrix of the differential equation system. Here, this system consists of the dynamic yane::Model::Model::odeFunction and the running costs yane::Model::Model::continuousCostfunction defined within the class Model object under consideration.
				@param n Dimension of the differential equation system
				@param M Mass matrix
				@param lmas Number of subdiagonals
				@param rpar Vector of real valued parameters
				@param ipar Vector of integer valued parameters
				@brief Function to evaluate the mass matrix of the differential equation system
				 */
				static void diffCombinedOdeSystem ( int * n, double * t, double * y, double * dy, double * rpar, int* ipar );

				/**
				Function to evaluate the combined mass matrix
				@param n Dimension of the dynamic
				@param M Mass matrix
				@param lmas Number of of-diagonals
				@param rpar Vector of real valued parameter
				@param ipar Vector of integer valued parameter
				@brief Function to evaluate the partial derivatives of the combined mass matrix
				 */
				static void diffCombinedMassMatrix ( int * n, double * M, int * lmas, double * rpar, int * ipar );

				/**
				Function to evaluate the combined dynamics using the class yane::MPC::Cache object
				@param u Current control vector
				@throw yane::OdeSolve::OdeSolEx Is thrown if the yane::OdeSolve::OdeSolve object terminates with an error
				@brief Function to evaluate the combined dynamics using the class yane::MPC::Cache object
				 */
				void calcCache ( double * u );

				/**
				Function to evaluate the column of partial derivatives of the combined dynamics using the class yane::MPC::Cache object
				@param u Current control vector
				@param index Column index
				@throw yane::OdeSolve::OdeSolEx Is thrown if the yane::OdeSolve::OdeSolve object terminates with an error
				@brief Function to evaluate the column of partial derivatives of the combined dynamics using the class yane::MPC::Cache object
				 */
				void calcCacheDerived ( double * u, int index );

				/**
				@brief Function to free all internally allocated memory
				 */
				void freeMem();

				yane::OdeSolve::OdeFunction * _dgl;	/**< @brief Pointer of the dynamic of the control system */
				yane::OdeSolve::OdeSolveFirst * _ode;	/**< @brief Pointer of the used odemanager object of class yane::OdeSolve::OdeSolveFirst */
				yane::Model::Model * _model;		/**< @brief Pointer of the underlying model problem of class yane::Model::Model */
				Cache * _cache;				/**< @brief Pointer of the underlying class yane::MPC::Cache object */

				int _dimension;				/**< @brief Dimension of the state vector */
				int _dimension_u;			/**< @brief Dimension of the control vector */
				int _horizont;				/**< @brief Length of the horizon */
				int _oldhoriz;				/**< @brief Previous length of the horizon */
				T_DISCRRESTRFUNC _restrfunction;	/**< @brief Pointer of the nonlinear restrictions */

				int _dim_restr;				/**< @brief Total number of constraints */

				double * _x;				/**< @brief State vector */
				double * _tempx;			/**< @brief Auxilliary state vector for computation of the gradient of the cost function */
				double * _tempr1;			/**< @brief Auxilliary vector of constraint values for computation of the Jacobian of the constraints */
				double * _tempr2;			/**< @brief Auxilliary vector of constraint values for computation of the Jacobian of the constraints */
				T_MPCDATA * _data;			/**< @brief Structure of MPC data values */
				double * _pcf_x;			/**< @brief Auxilliary state vector to evaluate the point cost function */
				double * _mass;				/**< @brief Pointer of the mass matrix */
				double * _diffmass;			/**< @brief Pointer of the derivative of the mass matrix */

				void * _discretization;			/**< @brief Pointer of the Class Discretization object */
				void * _configuration;			/**< @brief Pointer of the Class MPCConfig object */

				T_SHOOTINGDATA * _sdata;			/**< @brief Structure of shooting nodes */
				int _sdatalength;			/**< @brief Number of shooting nodes */
				double _weightcf;			/**< @brief Weight of the discrete part of the cost function */
				double _weightint;			/**< @brief Weight of the integral part of the cost function */

				double * _xdiff;			/**< @brief State vector for parallel differentiation */
				double * _udiff;			/**< @brief Control vector for parallel differentiation */
				yane::OdeSolve::OdeFunction * _diffdgl;	/**< @brief Pointer of the dynamic of the control system for computing the partial derivatives */
				yane::OdeSolve::OdeSolveFirst * _diffode;	/**< @brief Clone of the differential equation solver for solving the control system used for parallel computation of the partial derivatives*/

		};

	}

}


#endif
