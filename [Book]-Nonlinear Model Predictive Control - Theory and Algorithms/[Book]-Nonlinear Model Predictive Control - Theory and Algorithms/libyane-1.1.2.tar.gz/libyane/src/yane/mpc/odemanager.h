/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_ODEMANAGER_H
#define YANE_MPC_ODEMANAGER_H

#include "typedefs.h"

#include "../minprog/nlp.h"
#include "../model.h"

//TODO Shootingknotenindex nach Theorie verschieben

namespace yane
{

	namespace MPC
	{

		/** \class OdeManager
		@brief Implementation of a parenting manager class for solving control systems and computing their derivatives.
		*/
		class OdeManager
		{
			public:
				/**
				@brief Destructor
				 */
				virtual ~OdeManager() {}

				/**
				Function to supply required data for defining and evaluating the restrictions
				@param horizont Length of the horizon
				@param total_restr Number of restrictions
				@param model Pointer of the model
				@param restrfunc Pointer of the restriction function
				@param sdatalength Number of shooting nodes
				@param sdata Structure of the shooting nodes
				@throw yane::Utils::MemoryException is thrown if internal memory allocation failed
				@throw yane::OdeSolve::OdeSolEx is thrown if the reset of the ode solver failed
				@brief Function to supply required data for defining and evaluating the restrictions
				*/
				virtual void setFunctions ( int horizont, int total_restr, yane::Model::Model * model, T_DISCRRESTRFUNC restrfunc, int sdatalength=0, T_SHOOTINGDATA * sdata=0 ) = 0;

				/**
				Function to set required auxilliary objects
				@param discretization Class Discretization objects
				@param configuration Class MPCConfig object
				@brief Function to set required auxilliary objects
				 */
				virtual void setAuxilliaryObjects ( void * discretization, void * configuration = 0 ) = 0;

				/**
				Function to evaluate the objective function using the supplied differential equation manager. This function has to be defined in every derived class.
				@param t Current time grid
				@param x Initial state vector
				@param u Control vector
				@param fx Value of the objective function
				@throw yane::OdeSolve::OdeSolEx is thrown if the ode solver returns with an error message
				@brief Function to evaluate the objective function using the supplied differential equation manager
				 */
				virtual void calcObjectiveFunction ( double * t, double * x, double * u, double * fx ) = 0;

				/**
				Function to evaluate the gradient of the objective function using the supplied differential equation manager. This function has to be defined in every derived class.
				@param t Current time grid
				@param x Initial state vector
				@param u Control vector
				@param fx Gradient of the objective function
				@throw yane::OdeSolve::OdeSolEx is thrown if the ode solver returns with an error message
				@brief Function to evaluate the gradient of the objective function using the supplied differential equation manager
				 */
				virtual void calcObjectiveFunctionGrad ( double * t, double * x, double * u, double * fx ) = 0;

				/**
				Function to evaluate the restrictions using the supplied differential equation manager. This function has to be defined in every derived class.
				@param t Current time grid
				@param x Initial state vector
				@param u Control vector
				@param fx Vector of restriction values
				@throw yane::OdeSolve::OdeSolEx is thrown if the ode solver returns with an error message
				@brief Function to evaluate the restrictions using the supplied differential equation manager
				 */
				virtual void calcRestrFunction ( double * t, double * x, double * u, double * fx ) = 0;

				/**
				Function to evaluate the Jacobian of the restrictions using the supplied differential equation manager. This function has to be defined in every derived class.
				@param t Current time grid
				@param x Initial state vector
				@param u Control vector
				@param fx Jacobian of the restrictions
				@param memmodel Memory model
				@param needc Variable containing a list of the derivatives which need to be updated
				@throw yane::OdeSolve::OdeSolEx is thrown if the ode solver returns with an error message
				@brief Function to evaluate the Jacobian of the restrictions using the supplied differential equation manager
				 */
				virtual void calcRestrFunctionGrad ( double * t, double * x, double * u, double * fx, yane::MinProg::T_MEMMODEL memmodel, int * needc=0 ) = 0;

				/**
				Function to compute the state and objective function values for each point of the current time grid.
				@param t Current time grid
				@param x Initial state vector
				@param u Control vector
				@param fx Objective function values for the current time grid
				@param trajectory State vectors for the current time grid
				@throw yane::OdeSolve::OdeSolEx is thrown if the ode solver returns with an error message
				@brief Function to compute the state and objective function values for each point of the current time grid
				 */
				virtual void getObjFunValues ( double * t, double * x, double * u, double * fx, double * trajectory ) = 0;

				/**
				Function to generate a clone of the current OdeManager object. The object itself is not initialized yet and has to be destructed manually.
				@return Pointer of the cloned class OdeManager objects
				@brief Function to generate a clone of the current OdeManager object
				 */
				virtual OdeManager * clone() = 0;

				/**
				Function to return an internal pointer of the configuration of the discretized object
				@return Pointer of the configuration of the discretized object
				@brief Function to return an internal pointer of the configuration of the discretized object
				 */
				virtual void * configuration() = 0;
		};

	}

}

#endif
