/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_CACHE_H
#define YANE_MPC_CACHE_H

#include "typedefs.h"

#include <pthread.h>

namespace yane
{

	namespace Model
	{
		class Model;
	}

	namespace Utils
	{
		class Mutex;
	}

	namespace MPC
	{

		/** @class Cache
		@brief Class to save, identify and access intermediate results of trajectories computed by the class OdeManager object
		*/
		class Cache
		{
			public:
				typedef enum
				{
					SYNCMODE,
					ASYNCMODE
				} T_SYNCMODETYPE;

				/**
				Constructor
				@param horizon Length of the horizon
				@param model Pointer of the used class yane::Model::Model object
				@param sdata Structure of the shooting nodes
				@param sdatalength Number of shooting nodes
				@param type Type of synchronization
				@param countcopy_u Number of parallel threads
				@throw yane::Utils::MemoryException Is thrown if memory allocation fails
				@brief Constructor
				 */
				Cache ( int horizon, yane::Model::Model * model, T_SHOOTINGDATA * sdata, int sdatalength, T_SYNCMODETYPE type = ASYNCMODE, int countcopy_u = 1 );

				/**
				@brief Destructor
				 */
				~Cache();

				/**
				Function to define comparison criterion to prevent repeated evaluations
				@param t Time grid
				@param x Estimate of the initial value of the state
				@param u Control vector
				@brief Function to define comparison criterion to prevent repeated evaluations
				 */
				void setStamp ( double * t, double * x, double * u );

				/**
				Function to return the pointer of the time grid
				@return Pointer of the time grid
				@brief Function to return the pointer of the time grid
				 */
				double * t();

				/**
				Function to return the initial value of the state
				@return Pointer of the initial state vector
				@brief Function to return the initial value of the state
				 */
				double * x();

				/**
				Function to return the control variable
				@param countcopy_u Number of associated thread
				@return Pointer of the control variable
				@brief Function to return the control variable
				 */
				double * u ( int countcopy_u = 0 );

				/**
				Function to return the value of the cost function
				@param uindex Distinguished time instant of evaluation
				@return Value of the cost function at the distinguished time instant
				@brief Function to return the value of the cost function
				 */
				double & objValue ( int uindex = 0 );

				/**
				Function to return the value of the cost function for disturbed control vector
				@param uindex Distinguished time instant of evaluation
				@return Value of the cost function for disturbed control vector at the distinguished time instant
				@brief Function to return the value of the cost function for disturbed control vector
				 */
				double & objDisturbedValue ( int uindex );

				/**
				Function to return the value of the cost function
				@return Pointer of the cost function values
				@brief Function to return the value of the cost function
				 */
				double * objHorizonValues();

				/**
				Function to return the trajectory values
				@param uindex Distinguished time instant of evaluation
				@return Pointer of the trajectory values at the distinguished time instant
				@brief Function to return the trajectory values
				 */
				double * trajectoryValues ( int uindex = 0 );

				/**
				Function to return the trajectory values for a disturbed control vector
				@param uindex Distinguished time instant of evaluation
				@return Pointer of the trajectory values for a disturbed control vector at the distinguished time instant
				@brief Function to return the trajectory values for a disturbed control vector
				 */
				double * trajectoryDisturbedValues ( int uindex );

				/**
				Function to return information on the computing status
				@return Information on the computing status
				@brief Function to return information on the computing status
				 */
				bool & baseIsCalc();

				/**
				Function to return information on the computing status for a disturbed control vector
				@param uindex Distinguished time instant of evaluation
				@return Information on the computing status for a disturbed control vector
				@brief Function to return information on the computing status
				 */
				bool & disturbedIsCalc ( int uindex );

				/**
				Function to return the length of the horizon
				@return Length of the horizon
				@brief Function to return the length of the horizon
				 */
				int horizon();

				/**
				Function to return the shooting node information
				@return Strukture of the shooting nodes
				@brief Function to return the shooting node information
				 */
				T_SHOOTINGDATA * startData();

				/**
				Function to return the number of shooting nodes
				@return Number of shooting nodes
				@brief Function to return the number of shooting nodes
				 */
				int startDataLength();

				/**
				Function to return the underlying class yane::Model::Model object
				@return Pointer of the underlying class yane::Model::Model object
				@brief Function to return the underlying class yane::Model::Model object
				 */
				yane::Model::Model * model();

				/**
				@brief Function to lock a thread
				 */
				void lock();

				/**
				@brief Function to unlock a thread
				 */
				void unlock();

			protected:

				int _horizon;			/**< @brief  Length of the horizon */
				int _dimx;			/**< @brief  Dimension of the state vector */
				int _dimu;			/**< @brief  Dimension of the control vector */

				T_SHOOTINGDATA * _sdata;		/**< @brief  Strukture of the shooting nodes */
				int _sdatalength;		/**< @brief  Number of shooting nodes */
				yane::Model::Model * _model;	/**< @brief  Pointer of the underlying class yane::Model::Model object */

				double * _fxcache;		/**< @brief  Array of cost function values */
				double * _fxhorizonvalues;	/**< @brief  Array of all cost function values */
				double ** _cache;		/**< @brief  Array to store all computed data such as time grid, state trajectories and control vectors */

				bool * _iscalced;		/**< @brief  Bool array containing information on the computing status */
				bool _baseiscalced;		/**< @brief  Bool variable containing information on the computing status of the base problem */

				double * _stamp;		/**< @brief  Array containing comparison values */
				double * _cmpstamp;		/**< @brief  Array containing comparison values */

				int _countcopy_u;		/**< @brief  Number of threads */
				double ** _copy_u;		/**< @brief  Array of control vectors used for parallel computing */

				T_SYNCMODETYPE _type;		/**< @brief  Synchronisation mode */
				yane::Utils::Mutex * _locker;	/**< @brief  Locking routine for threads */

		};

	}

}

#endif
