/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "simpleodemanager.h"
#include "exceptions.h"

#include "../utils.h"
#include "../odesolve.h"

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iomanip>

#include "libexport.h"

LIB_EXPORT yane::MPC::SimpleOdeManager::SimpleOdeManager()
{
	_dgl = 0;
	_ode = 0;
	_model = 0;

	_x = 0;

	_data = 0;
	try
	{
		_data = new T_MPCDATA;
	}
	catch (std::bad_alloc)
	{
		throw yane::Utils::MemoryException( __DEBUGMESS( "failed allocating memory" ));
	}

	_data->odemanager = this;
	_data->u = 0;

//	diffacc = 1E-5;
	_tempx = 0;
	_tempr1 = 0;
	_tempr2 = 0;
	_points = 0;
	_mass = 0;

	_weightcf = 0.0;
	_weightint = 1.0;
}

void yane::MPC::SimpleOdeManager::freeMem()
{
	if ( _dgl != 0 ) delete _dgl;
	if ( _ode != 0 ) delete _ode;
	if ( _x != 0 ) delete[] _x ;
	if ( _tempx != 0 ) delete[] _tempx;
	if ( _tempr1 != 0 ) delete[] _tempr1;
	if ( _tempr2 != 0 ) delete[] _tempr2;
	if ( _points != 0 ) delete[] _points;
	if ( _mass != 0 ) delete[] _mass;

	_dgl = 0;
	_ode = 0;
	_x = 0;
	_tempx = 0;
	_tempr1 = 0;
	_tempr2 = 0;
	_points = 0;
	_mass = 0;
}

LIB_EXPORT yane::MPC::SimpleOdeManager::~ SimpleOdeManager()
{
	freeMem();

	delete _data;
}

LIB_EXPORT void yane::MPC::SimpleOdeManager::setFunctions ( int horizon, int total_restr, yane::Model::Model * model, T_DISCRRESTRFUNC restrfunc, int sdatalength, T_SHOOTINGDATA * sdata )
{
	freeMem();

	double * tempmass = 0;

	_model = model;
	_dimension = _model->dimensionState();
	_dimension_u = _model->dimensionControl();

	_restrfunction = restrfunc;
	_sdata = sdata;
	_sdatalength = sdatalength;

	_horizon = horizon;
	_dim_restr = total_restr;

	freeMem();

	try
	{
		_ode = _model->odeSolver()->clone();
		_dgl = new yane::OdeSolve::OdeFunction ( combinedOdeSystem, _dimension + 1 );
		tempmass = new double [_dimension*_dimension];
		_x = new double [ _dimension + 1 ];
		_tempx = new double [ _dimension * _horizon ];
		_tempr1 = new double [ _dim_restr ];
		_tempr2 = new double [ _dim_restr ];
		_points = new double [ _dimension * ( _horizon + 1 ) ];
		_mass = new double [ ( _dimension + 1 ) * ( _dimension + 1 ) ];
	}
	catch (std::bad_alloc)
	{
		freeMem();

		if (tempmass != 0) delete[] tempmass;

		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating memory" ) );
	}

	try
	{
		_model->massMatrix ( tempmass );
		memset ( _mass, 0, sizeof ( double ) * ( _dimension + 1 ) * ( _dimension + 1 ) );
		_mass[(_dimension + 1) * (_dimension + 1) - 1] = 1.0;
		for ( int i = 0; i < _dimension; i++ )
		{
			memcpy(&_mass[i*(_dimension+1)], &tempmass[i*_dimension], sizeof(double)*_dimension);
		}
		_dgl->setMassMatrix ( combinedMassMatrix );
	}
	catch ( yane::Model::UndefinedException ) {}

	delete[] tempmass;
	tempmass = 0;

	try
	{
		_ode->reset ( _dgl, _model->odeConfig() );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Reset of the _ode solver failed" ), &e );
	}

	_model->getObjectiveWeight ( _weightint, _weightcf );
}

void yane::MPC::SimpleOdeManager::combinedOdeSystem ( int * n, double * t, double * y, double * dy, double * rpar, int * ipar )
{
	T_MPCDATA * _data = ( T_MPCDATA* ) rpar;
	SimpleOdeManager * baseobject = ( SimpleOdeManager* ) _data->odemanager;

	baseobject->_model->odeFunction ( *t, y, _data->u, dy );
	dy[baseobject->_dimension] = baseobject->_model->continuousCostfunction ( *t, y, _data->u );
}

void yane::MPC::SimpleOdeManager::combinedMassMatrix ( int * n, double * M, int * lmas, double * rpar, int * ipar )
{
	T_MPCDATA * _data = ( T_MPCDATA* ) rpar;
	SimpleOdeManager * baseobject = ( SimpleOdeManager* ) _data->odemanager;

	memcpy(M, baseobject->_mass, sizeof ( double ) * ( baseobject->_dimension + 1 ) * ( baseobject->_dimension + 1 ) );
}

LIB_EXPORT void yane::MPC::SimpleOdeManager::setAuxilliaryObjects ( void * discretization, void * configuration )
{
	_discretization = discretization;
	_configuration = configuration;
}

LIB_EXPORT void yane::MPC::SimpleOdeManager::calcObjectiveFunction ( double * t, double * x, double * u, double * fx )
{
	memcpy ( _x, x, sizeof ( double ) *_dimension );
	_x[_dimension] = 0.0;

	try
	{
		_ode->refreshConfig();
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Configuration of the differential equation solver could not be refreshed" ), &e );
	}
	try
	{
		_ode->init ( t[0], _x );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Differential equation solver could not be initialized" ), &e );
	}

	int sdataindex = 0;

	if ( _weightcf != 0.0 )
	{
		memcpy ( _points, _x, sizeof ( double ) *_dimension );
	}

	for ( int i = 0; i < _horizon; i++ )
	{
		_data->u = &u[i*_dimension_u];
		try
		{
			_ode->calc ( t[i+1], ( double* ) _data );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation failed" ), &e );
		}

		if ( _weightcf != 0.0 )
		{
			memcpy ( &_points[ ( i+1 ) *_dimension], _x, sizeof ( double ) *_dimension );
		}

		if ( _sdatalength > 0  && sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
		{
			while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
			{
				_x[_sdata[sdataindex].varindex] = u[_horizon*_dimension_u + sdataindex];
				++sdataindex;
			}
		}
	}

	if ( _weightcf != 0.0 )
	{
		*fx = _weightint * _x[_dimension] + _weightcf * _model->discreteCostfunction ( _horizon, _horizon, t, _points, u );
	}
	else
	{
		*fx = _weightint * _x[_dimension];
	}
}

LIB_EXPORT void yane::MPC::SimpleOdeManager::calcObjectiveFunctionGrad ( double * t, double * x, double * u, double * fx )
{
	double fx2, fx1;
	double oldu;

	try
	{
		calcObjectiveFunction ( t, x, u, &fx1 );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Setting tolerance vector within the _ode solver failed" ), &e );
	}

	for ( int i = 0; i < _horizon*_dimension_u + _sdatalength; i++ )
	{
		oldu = u[i];
		u[i] += yane::Utils::OptimalDiff::get();
		try
		{
			calcObjectiveFunction ( t, x, u, &fx2 );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Setting tolerance vector within the _ode solver failed" ), &e );
		}
		fx[i] = ( fx2 - fx1 ) / yane::Utils::OptimalDiff::get();

		u[i] = oldu;
	}
}

LIB_EXPORT void yane::MPC::SimpleOdeManager::calcRestrFunction ( double * t, double * x, double * u, double * fx )
{
	if ( _dim_restr == 0 ) return;

	memcpy ( _x, x, sizeof ( double ) *_dimension );
	_x[_dimension] = 0;

	try
	{
		_ode->refreshConfig();
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Configuration of the differential equation solver could not be refreshed" ), &e );
	}
	try
	{
		_ode->init ( t[0], _x );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Differential equation solver could not be initialized" ), &e );
	}

	int sdataindex = 0;
	for ( int i = 0; i < _horizon; i++ )
	{
		_data->u = &u[i*_dimension_u];
		try
		{
			_ode->calc ( t[i+1], ( double* ) _data );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation failed" ), &e );
		}

		memcpy ( &_tempx[i*_dimension], _x, sizeof ( double ) *_dimension );

		if ( _sdatalength > 0  && sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
		{
			while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
			{
				_x[_sdata[sdataindex].varindex] = u[_horizon*_dimension_u + sdataindex];
				++sdataindex;
			}
		}

	}

	_restrfunction ( t, _tempx, u, fx, _discretization, _configuration );
}

LIB_EXPORT void yane::MPC::SimpleOdeManager::calcRestrFunctionGrad ( double * t, double * x, double * u, double * fx, yane::MinProg::T_MEMMODEL memmodel, int * needc )
{
	if ( _dim_restr == 0 ) return;

	double oldu;
	try
	{
		calcRestrFunction ( t, x, u, _tempr1 );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation failed" ), &e );
	}


	for ( int i = 0; i < _horizon*_dimension_u + _sdatalength; i++ )
	{
		oldu = u[i];
		u[i] += yane::Utils::OptimalDiff::get();
		try
		{
			calcRestrFunction ( t, x, u, _tempr2 );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation failed" ), &e );
		}

		for ( int row = 0; row < _dim_restr; row++ )
		{
			if ( needc[row] != 0 )
			{
				if ( memmodel == yane::MinProg::BYLINE )
				{
					fx[row* ( _dimension_u*_horizon + _sdatalength ) + i] = ( _tempr2[row] - _tempr1[row] ) / yane::Utils::OptimalDiff::get();
				}
				else
				{
					fx[row + i*_dim_restr] = ( _tempr2[row] - _tempr1[row] ) / yane::Utils::OptimalDiff::get();
				}
			}
		}
		u[i] = oldu;
	}
}

LIB_EXPORT void yane::MPC::SimpleOdeManager::getObjFunValues ( double * t, double * x, double * u, double * fx, double * trajectory )
{
	memcpy ( _x, x, sizeof ( double ) *_dimension );
	_x[_dimension] = 0.0;

	try
	{
		_ode->refreshConfig();
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Configuration of the differential equation solver could not be refreshed" ), &e );
	}
	try
	{
		_ode->init ( t[0], _x );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ),  __DEBUGMESS ( "Differential equation solver could not be initialized" ), &e );
	}

	int sdataindex = 0;
	fx[0] = 0.0;
	if ( _weightcf != 0.0 )
	{
		fx[0] = _weightcf * _model->discreteCostfunction ( 0, _horizon, t, trajectory, u );
	}
	memcpy ( trajectory, _x, sizeof ( double ) *_dimension );
	for ( int i = 0; i < _horizon; i++ )
	{
		_data->u = &u[i*_dimension_u];
		try
		{
			_ode->calc ( t[i+1], ( double* ) _data );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation failed" ), &e );
		}
		if ( _weightcf != 0.0 )
		{
			fx[i] += _weightint * _x[_dimension];
			fx[i+1] = _weightcf * _model->discreteCostfunction ( i + 1,  _horizon, t, trajectory, u );
		}
		else
		{
			fx[i] = _weightint * _x[_dimension];
		}
		memcpy ( &trajectory[ ( i+1 ) *_dimension], _x, sizeof ( double ) *_dimension );

		if ( _sdatalength > 0  && sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
		{
			while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
			{
				_x[_sdata[sdataindex].varindex] = u[_horizon*_dimension_u + sdataindex];
				++sdataindex;
			}
		}
	}
}

LIB_EXPORT yane::MPC::OdeManager * yane::MPC::SimpleOdeManager::clone()
{
	return new SimpleOdeManager();
}

LIB_EXPORT void * yane::MPC::SimpleOdeManager::configuration()
{
	return _configuration;
}

