/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_MULTITHREADCACHEODEMANAGER_H
#define YANE_MPC_MULTITHREADCACHEODEMANAGER_H

#include "typedefs.h"
#include "odemanager.h"

#include <pthread.h>
#include <vector>

using namespace std;

namespace yane
{
	namespace OdeSolve
	{
		class OdeFunction;
	}

	namespace MPC
	{
		class Cache;
		class ASyncCacheCalculator;

		/** @class MultiThreadCacheOdeManager
		@brief Implementation of a parallelized version of the class yane::MPC::CacheOdeManager
		*/
		class MultiThreadCacheOdeManager : public OdeManager
		{
			public:
				/**
				@brief Constructor
				*/
				MultiThreadCacheOdeManager(int threadcount);

				/**
				@brief Destructor
				*/
				~MultiThreadCacheOdeManager();

				virtual void calcObjectiveFunction ( double * t, double* x, double* u, double* fx );
				virtual void calcObjectiveFunctionGrad ( double * t, double* x, double* u, double* fx );
				virtual void calcRestrFunction ( double * t, double * x, double* u, double* fx );
				virtual void calcRestrFunctionGrad ( double * t, double * x, double* u, double* fx, yane::MinProg::T_MEMMODEL memmodel, int * needc=0 );
				virtual void setFunctions ( int horizon, int total_restr, yane::Model::Model * model, T_DISCRRESTRFUNC restrfunc, int sdatalength=0, T_SHOOTINGDATA * sdata=0 );
				virtual void setAuxilliaryObjects ( void * discretization, void * configuration = 0 );
				virtual void getObjFunValues ( double * t, double * x, double * u, double * fx, double * points );
				virtual OdeManager * clone();
				virtual void * configuration();


			private:
				/** @struct T_THREADDATA
				Structure containing the data of a single thread
				@param threadidx Thread index
				@param base Pointer of the odemanager
				@param cachecalc Pointer of the cache calculator
				@param fx Pointer of the cost function
				@param discretization Pointer of the class Discretization object
				@param configuration Pointer of the class MPCConfig object
				@param memmodel Used memory model
				@param needc Pointer of the required column updates of the Jacobian of the constraints
				@param result Error indicator for the thread
				@brief Structure containing the data of a single thread
				*/
				typedef struct
				{
					int threadidx;
					MultiThreadCacheOdeManager * base;
					ASyncCacheCalculator* cachecalc;
					double * fx;
					void * discretization;
					void * configuration;
					yane::MinProg::T_MEMMODEL memmodel;
					int * needc;
					int result;
				} T_THREADDATA;

				/**
				Function to compute the solution of the differential equation system. Here, this system consists of the dynamic yane::Model::Model::odeFunction and the running costs yane::Model::Model::continuousCostfunction defined within the class Model object under consideration.
				@param n Dimension of the differential equation system
				@param t Time grid
				@param y Initial value of the state
				@param dy Value of the right hand side of the differential equation system
				@param rpar Vector of real valued parameters
				@param ipar Vector of integer valued parameters
				@brief Function to compute the solution of the differential equation system
				 */
				static void combinedOdeSystem ( int * n, double * t, double * y, double * dy, double * rpar, int* ipar );

				/**
				Function to evaluate the mass matrix of the differential equation system. Here, this system consists of the dynamic yane::Model::Model::odeFunction and the running costs yane::Model::Model::continuousCostfunction defined within the class Model object under consideration.
				@param n Dimension of the differential equation system
				@param M Mass matrix
				@param lmas Number of subdiagonals
				@param rpar Vector of real valued parameters
				@param ipar Vector of integer valued parameters
				@brief Function to evaluate the mass matrix of the differential equation system
				 */
				static void combinedMassMatrix ( int * n, double * M, int * lmas, double * rpar, int * ipar );

				/**
				Function to compute the Jacobian of the constraints
				@param arg Data structure of type yane::MPC::T_THREADDATA of the thread
				@brief Function to compute the Jacobian of the constraints
				 */
				static void* jacThreadWorker ( void* arg );

				/**
				Function to compute the gradient of the cost function
				@param arg Data structure of type yane::MPC::T_THREADDATA of the thread
				@brief Function to compute the gradient of the cost function
				 */
				static void* gradThreadWorker ( void* arg );

				/**
				@brief Function to free all internally allocated memory
				 */
				void freeFunctionMem();

				yane::OdeSolve::OdeFunction * _dgl;	/**< @brief Pointer of the control system */
				yane::Model::Model * _model;		/**< @brief Pointer of the model object */

				ASyncCacheCalculator ** _cachecalc;	/**< @brief Pointer of the cache calculator */

				int _dimension;				/**< @brief Dimension of the state variable */
				int _dimension_u;			/**< @brief Dimension of the control variable */
				int _horizon;				/**< @brief Length of the horizon */
				int _dim_restr;				/**< @brief Total number of restrictions */

				void * _discretization;			/**< @brief Pointer of the Class Discretization object */
				void * _configuration;			/**< @brief Pointer of the Class MPCConfig object */
				double * _mass;				/**< @brief Pointer of the mass matrix */

				T_SHOOTINGDATA * _sdata;			/**< @brief Pointer of the shooting data vector */
				int _sdatalength;			/**< @brief Number of shooting nodes */

				double _weightcf;			/**< @brief Weight of the discrete part of the cost function */
				double _weightint;			/**< @brief Weight of the integral part of the cost function */

				Cache * _cache;				/**< @brief Pointer of the cache memory */

				int _threadcount;			/**< @brief Number of threads */

				//TODO Parallele auswertung auf Utils-Klassen umstellen
				pthread_t * _jacthreads;		/**< @brief Pointer of threads for evaluating the Jacobian of the constraints */
				pthread_attr_t * _jacthread_attrs;	/**< @brief Pointer of the thread attributes for evaluating the Jacobian of the constraints */
				pthread_mutex_t * _jacthread_lockers;	/**< @brief Pointer of the thread lockers for evaluating the Jacobian of the constraints */
				pthread_cond_t * _jacthread_conds;	/**< @brief Pointer of the thread conditions for evaluating the Jacobian of the constraints */
				bool * _jacthread_running;		/**< @brief Pointer of decision variables for running threads to evaluate the Jacobian of the constraints */

				pthread_t * _gradthreads;		/**< @brief Pointer of threads for evaluating the gradient of the cost function */
				pthread_attr_t * _gradthread_attrs;	/**< @brief Pointer of the thread attributes for evaluating the gradient of the cost function */
				pthread_mutex_t * _gradthread_lockers;	/**< @brief Pointer of the thread lockers for evaluating the gradient of the cost function */
				pthread_cond_t * _gradthread_conds;	/**< @brief Pointer of the thread conditions for evaluating the gradient of the cost function */
				bool * _gradthread_running;		/**< @brief Pointer of decision variables for running threads to evalute the gradient of the cost function */

				T_THREADDATA * _threaddata;		/**< @brief Data structure of threads */
				vector<int> * _scheduler;		/**< @brief Scheduler vector for parallel threads */

				bool _abort;				/**< @brief Decision variable to abort computation */

		};

	}

}


#endif
