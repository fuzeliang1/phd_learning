/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "cacheodemanager.h"
#include "cache.h"
#include "asynccachecalculator.h"
#include "exceptions.h"

#include "../utils.h"
#include "../odesolve.h"

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iomanip>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::MPC::CacheOdeManager::CacheOdeManager()
{
	_dgl = 0;
	_model = 0;
	_mass = 0;
	_cache = 0;
	_cachecalc = 0;

	_weightcf = 0.0;
	_weightint = 1.0;

	_horizon = -1;
}

void yane::MPC::CacheOdeManager::freeFunctionMem()
{
	if ( _dgl != 0 ) delete _dgl;
	if ( _cache != 0 ) delete _cache;
	if ( _cachecalc != 0 ) delete _cachecalc;
	if ( _mass != 0 ) delete[] _mass;

	_dgl = 0;
	_cache = 0;
	_cachecalc = 0;
	_mass = 0;
}

LIB_EXPORT yane::MPC::CacheOdeManager::~ CacheOdeManager()
{
	freeFunctionMem();
}

LIB_EXPORT void yane::MPC::CacheOdeManager::setFunctions ( int horizon, int total_restr,  yane::Model::Model * model, T_DISCRRESTRFUNC restrfunc, int sdatalength, T_SHOOTINGDATA * sdata )
{
	double * tempmass = 0;

	_model = model;
	_dimension = _model->dimensionState();
	_dimension_u = _model->dimensionControl();

	_horizon = horizon;
	_dim_restr = total_restr;

	_sdata = sdata;
	_sdatalength = sdatalength;

	freeFunctionMem();

	try
	{
		_dgl = new yane::OdeSolve::OdeFunction ( combinedOdeSystem, _dimension + 1 );
		_cache = new Cache ( _horizon, _model, _sdata, _sdatalength );
		_cachecalc = new ASyncCacheCalculator ( this, _cache, _dgl, _dim_restr, restrfunc );
		tempmass = new double[ _dimension * _dimension ];
		try
		{
			_model->massMatrix ( tempmass );

			_mass = new double [ ( _dimension + 1 ) * ( _dimension + 1 ) ];

			memset ( _mass, 0, sizeof ( double ) * ( _dimension + 1 ) * ( _dimension + 1 ) );
			_mass[ ( _dimension + 1 ) * ( _dimension + 1 ) - 1 ] = 1.0;
			for ( int i = 0; i < _dimension; i++ )
			{
				memcpy ( &_mass[ i * ( _dimension + 1 ) ], &tempmass[ i * _dimension ], sizeof ( double ) * _dimension );
			}
			_dgl->setMassMatrix ( combinedMassMatrix );
		}
		catch ( yane::Model::UndefinedException ) { }

		delete[] tempmass;
		tempmass = 0;
	}
	catch ( std::bad_alloc )
	{
		if ( tempmass != 0 )
		{
			delete[] tempmass;
			tempmass = 0;
		}

		freeFunctionMem();
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating memory" ) );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Reset of the ode solver failed" ), &e );
	}

	_model->getObjectiveWeight ( _weightint, _weightcf );
}

void yane::MPC::CacheOdeManager::combinedOdeSystem ( int * n, double * t, double * y, double * dy, double * rpar, int * ipar )
{
	T_MPCDATA * data = ( T_MPCDATA* ) rpar;
	CacheOdeManager * baseobject = ( CacheOdeManager* ) data->odemanager;

	baseobject->_model->odeFunction ( *t, y, data->u, dy );
	dy[baseobject->_dimension] = baseobject->_model->continuousCostfunction ( *t, y, data->u );
}

void yane::MPC::CacheOdeManager::combinedMassMatrix ( int * n, double * M, int * lmas, double * rpar, int * ipar )
{
	T_MPCDATA * data = ( T_MPCDATA* ) rpar;
	CacheOdeManager * baseobject = ( CacheOdeManager* ) data->odemanager;

	memcpy ( M, baseobject->_mass, sizeof ( double ) * ( baseobject->_dimension + 1 ) * ( baseobject->_dimension + 1 ) );
}

LIB_EXPORT void yane::MPC::CacheOdeManager::setAuxilliaryObjects ( void * discretization, void * configuration )
{
	_discretization = discretization;
	_configuration = configuration;
}

LIB_EXPORT void yane::MPC::CacheOdeManager::calcObjectiveFunction ( double * t, double * x, double * u, double * fx )
{
	_cache->setStamp ( t, x, u );

	try
	{
		*fx = _cachecalc->objValue();
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::CacheOdeManager::calcObjectiveFunctionGrad ( double * t, double * x, double * u, double * fx )
{
	_cache->setStamp ( t, x, u );

	try
	{
		for ( int index = 0; index < _horizon*_dimension_u + _sdatalength; index++ )
		{
			_cachecalc->objGradient ( fx, index );
		}
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::CacheOdeManager::calcRestrFunction ( double * t, double * x, double * u, double * fx )
{
	if ( _dim_restr == 0 ) return;

	_cache->setStamp ( t, x, u );

	try
	{
		_cachecalc->restrValues ( fx, _discretization, _configuration );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::CacheOdeManager::calcRestrFunctionGrad ( double * t, double * x, double * u, double * fx, yane::MinProg::T_MEMMODEL memmodel, int * needc )
{
	if ( _dim_restr == 0 ) return;

	_cache->setStamp ( t, x, u );

	try
	{
		bool first = true;

		for ( int h = _horizon - 1; h >= 0; h-- )
		{
			for ( int i = 0; i < _dimension_u; i++ )
			{
				_cachecalc->restrJacobi ( fx, h*_dimension_u + i, _discretization, memmodel, needc, first, _configuration );
				first = false;
			}
		}

		first = true;
		for ( int index = _dimension_u * _horizon + _sdatalength - 1; index >= _dimension_u*_horizon; index-- )
		{
			_cachecalc->restrJacobi ( fx, index, _discretization, memmodel, needc, first, _configuration );
			first = false;
		}

	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}
}

LIB_EXPORT void yane::MPC::CacheOdeManager::getObjFunValues ( double * t, double * x, double * u, double * fx, double * trajectory )
{
	_cache->setStamp ( t, x, u );

	try
	{
		_cachecalc->objValue();
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	memcpy ( fx, _cache->objHorizonValues(), sizeof ( double ) * _horizon );
	fx[_horizon] = 0.0;
	for ( int i = 0; i < _horizon + 1; i++ )
	{
		fx[i] *= _weightint;
	}

	memcpy ( trajectory, x, sizeof ( double ) * _dimension );
	memcpy ( &trajectory[_dimension], _cache->trajectoryValues(), sizeof ( double ) * _horizon * _dimension );

	if ( _weightcf != 0.0 )
	{
		for ( int i = 0; i < _horizon + 1; i++ )
		{
			fx[i] += _weightcf * _model->discreteCostfunction ( i, _horizon, t, trajectory, u );
		}
	}
}

LIB_EXPORT yane::MPC::OdeManager * yane::MPC::CacheOdeManager::clone()
{
	return new CacheOdeManager();
}

LIB_EXPORT void * yane::MPC::CacheOdeManager::configuration()
{
	return _configuration;
}
