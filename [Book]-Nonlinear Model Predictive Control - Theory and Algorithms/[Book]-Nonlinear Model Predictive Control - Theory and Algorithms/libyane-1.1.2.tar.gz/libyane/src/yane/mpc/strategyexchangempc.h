/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_STRATEGYEXCHANGEMPC_H
#define YANE_MPC_STRATEGYEXCHANGEMPC_H

#include "networkedmpcconfig.h"

#include <vector>

namespace yane
{

	namespace OdeSolve
	{
		class OdeConfig;
	}

	namespace MPC
	{
		class Discretization;

		/** @class StrategyExchangeMPC
		This class allows to control a plant using MPC in a network of connected plants by exchanging control strategies.
		@brief Not yet documented
		 */
		class StrategyExchangeMPC : public yane::MPC::NetworkedMPCConfig
		{
			public:
				StrategyExchangeMPC();

				~StrategyExchangeMPC();

				void resetDiscretization ( Discretization * problem );

				void addInputNeighbour ( NetworkedMPCConfig * neighbour );
				void addInputNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps );
				void removeInputNeighbour ( NetworkedMPCConfig * neighbour );
				void removeInputNeighbour ( yane::Utils::Uuid * uuid );
				void updateInputNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, int precedesteps );

				void addNeighbour ( NetworkedMPCConfig * neighbour );
				void addNeighbour ( yane::Utils::Uuid * uuid, int dimensionState, int dimensionControl, int horizon, int precedesteps );
				void removeNeighbour ( NetworkedMPCConfig * neighbour );
				void removeNeighbour ( yane::Utils::Uuid * uuid );
				void updateOutputNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, int precedesteps );

				void updateNeighbour ( NetworkedMPCConfig * neighbour, double * timesteps, double * control, double * state );
				void updateNeighbour ( yane::Utils::Uuid * uuid, int horizon, double * timesteps, double * control, double * state, int precedesteps );

				void setReducedNumberOfConstraints ( bool reducedNumberOfConstraints );

			protected:
				static void extendedFullRestrictionFunction ( double * t, double * x, double * u, double * fx, void * discretization, void * configuration );
				static void extendedReducedRestrictionFunction ( double * t, double * x, double * u, double * fx, void * discretization, void * configuration );
				void resetFullDiscretization ( Discretization * problem, int horizon, int sdatalength, int totalRestrictionNumber );
				void resetReducedDiscretization ( Discretization * problem, int horizon, int sdatalength, int totalRestrictionNumber );

				bool _reducedNumberOfConstraints;
		};

	}

}

#endif
