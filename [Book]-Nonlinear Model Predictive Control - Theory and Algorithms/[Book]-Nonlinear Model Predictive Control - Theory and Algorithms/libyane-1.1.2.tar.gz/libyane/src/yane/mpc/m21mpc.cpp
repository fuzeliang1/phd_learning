/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "m21mpc.h"
#include "odemanager.h"
#include "exceptions.h"


#include "../model.h"
#include "../minprog.h"
#include "../odesolve.h"
#include "../utils.h"

#include <cstring>

#include "libexport.h"

LIB_EXPORT yane::MPC::m21MPC::m21MPC ( double h_new, double _infty ) : yane::MPC::SuboptimalityMPC::SuboptimalityMPC ( h_new, _infty )
{
	_algorithmMode = UPDATECOSTFUNCTION;
	_controlHorizonMax = 1;
	_controlHorizon = 0;
	_implementationCounter = 0;
	_alphabound = 0.0;
	_estimate = APOSTERIORIPRACTICAL;
	_epsilon = 1e-6;

	_controlUpdated = true;

	_valuefunction_base2 = 0;
	_valuefunction_predicted2 = 0;
}

LIB_EXPORT yane::MPC::m21MPC::~m21MPC()
{
	freeValuefunctions();
}

bool yane::MPC::m21MPC::checkConditionsUpdate()
{
	if ( _algorithmMode != NOUPDATECOSTFUNCTION && _algorithmMode != UPDATECOSTFUNCTION )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "Algorithm must be set to be in NOUPDATECOSTFUNCTION or UPDATECOSTFUNCTION mode" ) );
	}
	if ( _algorithmMode == NOUPDATECOSTFUNCTION )
	{
		if ( _valuefunction_predicted[_horizon - 1] - _valuefunction_base2[_horizon - 1] <= - _alphabound * ( _valuefunction_base2[_implementationCounter - 1] + _valuefunction_predicted[_controlHorizon - 1] ) )
		{
			cout << "update" << endl;
			return true;
		}
	}
	else
	{
		if ( _valuefunction_predicted[_horizon - 1] - _valuefunction_predicted2[_horizon - 1] <= _alphabound * ( _valuefunction_base2[_implementationCounter + _controlHorizon - 1] - _valuefunction_base2[_implementationCounter - 1] - _valuefunction_base[_controlHorizon - 1] ) )
		{
			cout << "update" << endl;
			return true;
		}
	}
	return false;
}

LIB_EXPORT void yane::MPC::m21MPC::setAlgorithmMode ( T_M21ALGORITHM algorithmMode )
{
	_algorithmMode = algorithmMode;

}

LIB_EXPORT void yane::MPC::m21MPC::setConfigM21MPC ( int controlHorizonMax, double alphabound, T_ESTIMATE estimate, double epsilon, T_M21ALGORITHM algorithmMode )
{
	_controlHorizonMax = controlHorizonMax;
	_alphabound = alphabound;
	_estimate = estimate;
	if ( _estimate != APOSTERIORI && _estimate != APOSTERIORIPRACTICAL )
	{
		throw yane::Utils::ValueException ( __DEBUGMESS ( "_estimate must be set to either APOSTERIORI or APOSTERIORIPRACTICAL" ) );
	}
	try
	{
		setEpsilon ( epsilon );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ), __DEBUGMESS ( "Setting of practical region parameter epsilon failed" ), &e );
	}
	setAlgorithmMode ( algorithmMode );
}

LIB_EXPORT void yane::MPC::m21MPC::calcControlHorizon ( double * x, int realtimesteps, double aborttimeoffset )
{
	try
	{
		_alpha = -_infty;
		_controlHorizon = 0;
		setStoreValuefunction ( true );
		while ( _alpha < _alphabound && _controlHorizon < _controlHorizonMax )
		{
			_controlHorizon++;
			mstepPredictedAposterioriEstimate ( x, _controlHorizon, realtimesteps, aborttimeoffset );
		}
		if ( _alpha < _alphabound )
		{
			_controlHorizon = 1;
			throw SuboptimalityException ( __DEBUGMESS ( "Suboptimality estimate doesnot satisfy predefined bound" ) );
		}
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
	}
}

LIB_EXPORT void yane::MPC::m21MPC::calc ( double * x, int realtimesteps, double aborttimeoffset )
{
	try
	{
		if ( _controlHorizon == 0 )
		{
			_implementationCounter = 0;
			calcControlHorizon ( x, realtimesteps, aborttimeoffset );
			memcpy ( _valuefunction_base2, _valuefunction_base, sizeof ( double ) * ( _horizon + 1 ) );
			memcpy ( _valuefunction_predicted2, _valuefunction_predicted, sizeof ( double ) * ( _horizon + 1 ) );
			_controlUpdated = true;
		}
		else
		{
			memcpy ( _u_current, _u_preceded, sizeof ( double ) * model()->dimensionControl() * ( _horizon + _precedesteps ) );
			setStoreValuefunction ( true );
			double alpha_save = _alpha;
			mstepPredictedAposterioriEstimate ( x, _controlHorizon, realtimesteps, aborttimeoffset );
			if ( checkConditionsUpdate() )
			{
				memcpy ( _u_preceded, _u_current, sizeof ( double ) * model()->dimensionControl() * ( _horizon + _precedesteps ) );
				_controlUpdated = true;
				if ( _algorithmMode == UPDATECOSTFUNCTION )
				{
					memcpy ( _valuefunction_base2, _valuefunction_base, sizeof ( double ) * ( _horizon + 1 ) );
					memcpy ( _valuefunction_predicted2, _valuefunction_predicted, sizeof ( double ) * ( _horizon + 1 ) );
					_implementationCounter = 0;
				}
			}
			else
			{
				_alpha = alpha_save;
				_controlUpdated = false;
			}
		}
	}
	catch ( SuboptimalityException e )
	{
		if ( _showSuboptimalityError )
		{
			throw SuboptimalityException ( __DEBUGMESS ( "Suboptimality estimate doesnot satisfy predefined bound" ), &e );
		}
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
	}
}

LIB_EXPORT void yane::MPC::m21MPC::shiftHorizon ( double * nextControls, double * nextTimesteps, int m, double * x, double h_new )
{
	try
	{
		yane::MPC::MPC::shiftHorizon ( nextControls, nextTimesteps, m, x, h_new );
		_controlHorizon--;
		_implementationCounter++;
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ), __DEBUGMESS ( "Calculation was aborted" ), &e );
	}
}

LIB_EXPORT int yane::MPC::m21MPC::controlHorizon()
{
	return _controlHorizon;
}

LIB_EXPORT void yane::MPC::m21MPC::setShowSuboptimalityError ( bool showSuboptimalityError )
{
	_showSuboptimalityError = showSuboptimalityError;
}

LIB_EXPORT void yane::MPC::m21MPC::reset ( OdeManager * odemanager, yane::MinProg::NLP * minimizer, yane::Model::Model * model, int horizon, int precedesteps, ModelShootingData * shootingdata )
{
	try
	{
		yane::MPC::SuboptimalityMPC::reset ( odemanager, minimizer, model, horizon, precedesteps, shootingdata );
	}
	catch ( MPCException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Allocation of discretized problem was not successful" ), &e );;
	}

	try
	{
		allocateValuefunctions();
	}
	catch ( MPCException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "'failed allocating value- and trajectoryarrays" ), &e );
	}
}

LIB_EXPORT void yane::MPC::m21MPC::allocateValuefunctions()
{
	freeValuefunctions();
	try
	{
		_valuefunction_base2 = new double [_horizon+1];
		_valuefunction_predicted2 = new double [_horizon+1];
	}
	catch ( std::bad_alloc )
	{
		freeValuefunctions();
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating value function array" ) );
	}
}

LIB_EXPORT void yane::MPC::m21MPC::freeValuefunctions()
{
	if ( _valuefunction_base2 != 0 )
	{
		delete[] _valuefunction_base2;
		_valuefunction_base2 = 0;
	}
	if ( _valuefunction_predicted2 != 0 )
	{
		delete[] _valuefunction_predicted2;
		_valuefunction_predicted2 = 0;
	}
}

LIB_EXPORT void yane::MPC::m21MPC::resizeHorizon ( int newhorizon, double h_new )
{
	try
	{
		yane::MPC::SuboptimalityMPC::resizeHorizon ( newhorizon, h_new );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Allocation Error" ), __DEBUGMESS ( "Resizing the _horizon failed" ), &e );
	}

	try
	{
		allocateValuefunctions();
	}
	catch ( MPCException e )
	{
		throw MPCException ( __EXCEPTIONMESS ( MPCException::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "'failed allocating value- and trajectoryarrays" ), &e );
	}
}

LIB_EXPORT int yane::MPC::m21MPC::controlUpdated()
{
	return _controlUpdated;
}
