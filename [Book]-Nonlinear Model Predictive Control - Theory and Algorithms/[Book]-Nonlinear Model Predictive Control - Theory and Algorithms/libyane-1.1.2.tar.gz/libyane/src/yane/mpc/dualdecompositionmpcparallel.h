/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_DUALDECOMPOSITIONMPCPARALLEL_H
#define YANE_MPC_DUALDECOMPOSITIONMPCPARALLEL_H

#include "dualdecompositionmpc.h"

namespace yane
{

	namespace MPC
	{

		class DualDecompositionMPCParallel : public DualDecompositionMPC
		{
			public:
				DualDecompositionMPCParallel();

				~DualDecompositionMPCParallel();

		};

	}

}

#endif
