/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_EXCEPTIONS_H
#define YANE_MPC_EXCEPTIONS_H

#include "../utils/exception.h"

#include <string>

namespace yane
{

	namespace MPC
	{

		/**
		\brief Exception within the MPC algorithm
		*/
		class MPCException : public yane::Utils::Exception
		{
			public:
				MPCException ( std::string message="unknown exception", std::string debugmess="<no debuginfo>", yane::Utils::Exception * innerex=0 );
				static const std::string TYPE;

		};

		/**
		\brief Violation of the relaxed Lyapunov inequality
		 */
		class SuboptimalityException : public MPCException
		{
			public:
				SuboptimalityException ( std::string debugmessage="<no debuginfo>", yane::Utils::Exception * innerex=0 );
				static const std::string TYPE;
		};

		/**
		\brief Practical region of the suboptimality estimate reached
		 */
		class PracticalException : public MPCException
		{
			public:
				PracticalException ( std::string debugmessage="<no debuginfo>", yane::Utils::Exception * innerex=0 );
				static const std::string TYPE;
		};

		/**
		\brief Error in suboptimality estimate detected
		 */
		class EstimationException : public MPCException
		{
			public:
				EstimationException ( std::string debugmessage="<no debuginfo>", yane::Utils::Exception * innerex=0 );
				static const std::string TYPE;
		};

		/**
		\brief Error in neighbourhood configuration of MPC object detected
		*/
		class NetworkedMPCConfigException : public MPCException
		{
			public:
				NetworkedMPCConfigException ( std::string debugmessage="<no debuginfo>", yane::Utils::Exception * innerex=0 );
				static const std::string TYPE;
		};

		/**
		\brief Noncritical Error in neighbourhood configuration of MPC object detected
		 */
		class NetworkedMPCConfigWarning : public MPCException
		{
			public:
				NetworkedMPCConfigWarning ( std::string debugmessage="<no debuginfo>", yane::Utils::Exception * innerex=0 );
				static const std::string TYPE;
		};

	}
}

#endif

