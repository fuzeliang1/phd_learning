/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "exceptions.h"

#include <string>

#include "libexport.h"

LIB_EXPORT const std::string yane::MPC::MPCException::TYPE = std::string ( "yane::MPC::MPCException" );

LIB_EXPORT yane::MPC::MPCException::MPCException ( std::string message, std::string debugmess, yane::Utils::Exception * innerex )
		: yane::Utils::Exception ( message, debugmess, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::MPC::SuboptimalityException::TYPE = std::string ( "yane::MPC::SuboptimalityException" );

LIB_EXPORT yane::MPC::SuboptimalityException::SuboptimalityException ( std::string debugmessage, yane::Utils::Exception * innerex )
	: yane::MPC::MPCException ( "violated relaxed Lyapunov inequality", debugmessage, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::MPC::PracticalException::TYPE = std::string ( "yane::MPC::PracticalException" );

LIB_EXPORT yane::MPC::PracticalException::PracticalException ( std::string debugmessage, yane::Utils::Exception * innerex )
	: yane::MPC::MPCException ( "practical region is reached", debugmessage, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::MPC::EstimationException::TYPE = std::string ( "yane::MPC::EstimationException" );

LIB_EXPORT yane::MPC::EstimationException::EstimationException ( std::string debugmessage, yane::Utils::Exception * innerex )
	: yane::MPC::MPCException ( "internal estimation is based on erroneous data", debugmessage, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::MPC::NetworkedMPCConfigException::TYPE = std::string ( "yane::MPC::NetworkedMPCConfigException" );

LIB_EXPORT yane::MPC::NetworkedMPCConfigException::NetworkedMPCConfigException ( std::string debugmessage, yane::Utils::Exception * innerex )
	: yane::MPC::MPCException ( "network configuration exhibits critical errors", debugmessage, innerex )
{
	addType ( TYPE );
}

LIB_EXPORT const std::string yane::MPC::NetworkedMPCConfigWarning::TYPE = std::string ( "yane::MPC::NetworkedMPCWarning" );

LIB_EXPORT yane::MPC::NetworkedMPCConfigWarning::NetworkedMPCConfigWarning ( std::string debugmessage, yane::Utils::Exception * innerex )
	: yane::MPC::MPCException ( "network configuration possibly corrupted", debugmessage, innerex )
{
	addType ( TYPE );
}
