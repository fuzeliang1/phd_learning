/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_M21MPC_H
#define YANE_MPC_M21MPC_H

#include "suboptimalitympc.h"
#include "typedefs.h"

namespace yane
{

	namespace MPC
	{

		/** @class m21MPC
		@brief Not yet documented
		 */
		class m21MPC : public yane::MPC::SuboptimalityMPC
		{
			public:
				/**
				@brief Constructor
				@param h_new Discretization width
				@param INFTY Value for \f$ \infty \f$
				 */
				m21MPC ( double h_new, double INFTY = 1E19 );

				/**
				@brief Destructor
				 */
				~m21MPC();

				/**
				This function triggers the computation of the m21MPC solution with additional check for stabilizing control horizons
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@throw yane::Utils::NotInitializedException Is thrown if the yane::MPC::MPC object is not yet defined, i.e. if the yane::MPC::MPC::reset function has not been called
				@throw yane::MinProg::SolverWarning Is thrown if the yane::MinProg::NLP object terminates with a warning
				@throw yane::OdeSolve::OdeSolEx Is thrown if the yane::OdeSolve::OdeSolve object terminates with an error
				@throw yane::Utils::ValueException Is thrown if a null pointer is submitted
				@throw yane::Utils::Exception Is thrown if any other error occurs
				@brief Function to start the computation of the m21MPC solution with additional check for stabilizing control horizons
				 */
				virtual void calc ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				This function shifts the time horizon of the optimal control problem with additional check for stabilizing control horizons \n
				The function expects pointers for the control values and the time instances at which these are valid. Moreover, the number of shifts is required. Optionally, the user can supply an estimate of the current state vector as well as a length for the new added sampling interval at the end of the optimization horizon.
				@param nextControls Pointer to the control values which are to be implemented next
				@param nextTimesteps Pointer to the time instances for which the next control values are computed
				@param m Number of sampling instances to be shifted (default 1)
				@param x Estimate of the current state vector
				@param h_new Length of the added sampling interval at the end of the shifted optimization horizon
				@throw yane::Utils::NotInitializedException Is thrown if the yane::MPC::MPC object is not yet defined, i.e. if the yane::MPC::MPC::reset function has not been called
				@throw yane::MinProg::MinProgException Is thrown if the discretized optimization problem or the prediction cannot be initialized
				@throw yane::OdeSolve::OdeSolEx Is thrown if the yane::OdeSolve::OdeSolve object terminates with an error
				@throw yane::Utils::MemoryException Is thrown if memory allocation fails
				@throw yane::Utils::ValueException Is thrown if input is errorneous
				@throw yane::Utils::Exception Is thrown if an other error occurs
				@brief Function to shift the time horizon of the optimal control problem with additional check for stabilizing control horizons
				 */
				virtual void shiftHorizon ( double * nextControls, double * nextTimesteps, int m, double * x, double h_new );
				virtual void reset ( OdeManager * odemanager, yane::MinProg::NLP * minimizer, yane::Model::Model * model, int horizon, int precedesteps = 0, ModelShootingData * shootingdata = 0 );
				virtual void resizeHorizon ( int newhorizon, double h_new );

				/**
				Function to compute the minimal control horizon for which stability can be guaranteed via the predefined suboptimality estimate
				@param x Estimate of the initial value of the state
				@param realtimesteps Number of time steps on the time grid after which the computation shall be terminated (0 = no limit)
				@param aborttimeoffset Time offset after which the computation shall be terminated (negative values shorten the time interval available for optimization)
				@brief Function to compute the minimal control horizon for which stability can be guaranteed via the predefined suboptimality estimate
				 */
				void calcControlHorizon ( double * x, int realtimesteps = 0, double aborttimeoffset = 0.0 );

				/**
				Function to set the decision variable on the type of m21MPC implementation
				@param algorithmMode Decision variable on the type of m21MPC implementation
				@brief Function to set the decision variable on the type of m21MPC implementation
				 */
				void setAlgorithmMode ( T_M21ALGORITHM algorithmMode );

				/**
				Function to configure the m21MPC algorithm
				@param controlHorizonMax Maximal length of the control horizon to be checked
				@param alphabound Lower bound on the degree of suboptimality which shall be guaranteed
				@param estimate Suboptimality estimate
				@param epsilon Practical region for the suboptimality estimate
				@param algorithmMode Decision variable on the type of m21MPC implementation
				@brief Function to configure the m21MPC algorithm
				 */
				void setConfigM21MPC ( int controlHorizonMax, double alphabound, T_ESTIMATE estimate = APOSTERIORIPRACTICAL, double epsilon = 1.0e-6, T_M21ALGORITHM algorithmMode = UPDATECOSTFUNCTION );

				/**
				Function to return the current control horizon
				@return Current control horizon
				@brief Function to return the current control horizon
				 */
				int controlHorizon();

				/**
				Function to return whether control has been updated
				@return Decision variable whether the control has been updated
				@brief Function to return whether control has been updated
				 */
				int controlUpdated();

				/**
				Function to set the decision variable whether suboptimality estimation error shall be displayed
				@param showSuboptimalityError Decision variable whether suboptimality estimation error shall be displayed
				@brief Function to set the decision variable whether suboptimality estimation error shall be displayed
				 */
				void setShowSuboptimalityError ( bool showSuboptimalityError );

				void allocateValuefunctions();		/**< @brief (Re-)Allocates memory for value functions */
				void freeValuefunctions();		/**< @brief Frees memory for value function */

			private:
				bool checkConditionsUpdate();		/**< @brief Function to check whether an update of the control can be performed without loosing stability and still guaranteeing the predefined lower bound of the degree of suboptimality */

				T_M21ALGORITHM _algorithmMode;		/**< @brief Decision variable on the type of m21MPC implementation */
				bool _controlUpdated;			/**< @brief Decision variable whether control has been updated */
				bool _showSuboptimalityError;		/**< @brief Decision variable whether suboptimality estimation error shall be displayed */
				int _controlHorizonMax;			/**< @brief Maximal length of the control horizon to be checked */
				int _controlHorizon;			/**< @brief Current length of the control horizon to be checked */
				int _implementationCounter;		/**< @brief Counter of the time instances for which the system has been in open loop */
				double * _valuefunction_base2;		/**< @brief Auxilliary variable to store the value function */
				double * _valuefunction_predicted2;	/**< @brief Auxilliary variable to store the predicted value function */
		};

	}

}

#endif
