/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "asynccachecalculator.h"
#include "cache.h"

#include "../model.h"
#include "../odesolve.h"
#include "../utils.h"

#include <cstring>
#include <iostream>

using namespace std;

yane::MPC::ASyncCacheCalculator::ASyncCacheCalculator(OdeManager* odeman, Cache * cache_par, yane::OdeSolve::OdeFunction * odefunc, int total_restr_par, T_DISCRRESTRFUNC restrfunc_par)
{
	_cache = cache_par;
	_total_restr = total_restr_par;
	_restrfunc = restrfunc_par;

	_model = _cache->model();
	_dimx = _model->dimensionState();
	_dimu = _model->dimensionControl();
	_horizon = _cache->horizon();
	_sdata = _cache->startData();
	_sdatalength = _cache->startDataLength();

	_x = 0;
	_ode = 0;
	_trajectory = 0;
	_trajectory_restr = 0;
	_data = 0;
	_tempr1 = 0;
	_tempr2 = 0;

	try
	{
		_x = new double[ _dimx + 1 ];
		_ode = _model->odeSolver()->clone();
		_trajectory = new double[ ( _horizon + 1 ) * _dimx ];
		_trajectory_restr = new double[ ( _horizon + 1 ) * _dimx ];
		_data = new T_MPCDATA;
		_tempr1 = new double [ _total_restr ];
		_tempr2 = new double [ _total_restr ];
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException( __DEBUGMESS( "failed allocating memory" ));
	}

	_data->odemanager = odeman;
	_data->u = 0;

	_ode->reset(odefunc, _model->odeConfig());
	_model->getObjectiveWeight ( _weightint, _weightcf );
}

yane::MPC::ASyncCacheCalculator::~ ASyncCacheCalculator()
{
	freeMem();
}

void yane::MPC::ASyncCacheCalculator::freeMem()
{
	if ( _x != 0 ) delete[] _x;
	if ( _ode != 0 ) delete _ode;
	if ( _trajectory != 0 ) delete[] _trajectory;
	if ( _trajectory_restr != 0 ) delete[] _trajectory_restr;
	if ( _data != 0 ) delete _data;
	if ( _tempr1 != 0 ) delete[] _tempr1;
	if ( _tempr2 != 0 ) delete[] _tempr2;

	_x = 0;
	_ode = 0;
	_trajectory = 0;
	_trajectory_restr = 0;
	_data = 0;
	_tempr1 = 0;
	_tempr2 = 0;
}


double yane::MPC::ASyncCacheCalculator::objValue()
{
	try
	{
		calcCache ( );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	return _cache->objValue();
}

void yane::MPC::ASyncCacheCalculator::objGradient(double * grad, int index, int threadid)
{
	double fx2, fx1;

	try
	{
		calcCache ( );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	fx1 = _cache->objValue();

	try
	{
		calcCacheDisturbed ( index, threadid );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "CacheDerived could not be computed" ), &e );
	}
	fx2 = _cache->objDisturbedValue(index);

	grad[index] = ( fx2 - fx1 ) / yane::Utils::OptimalDiff::get();
}

void yane::MPC::ASyncCacheCalculator::restrValues(double * fx, void * discretization, void * configuration)
{
	if ( _total_restr == 0 ) return;

	try
	{
		calcCache ( );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	_restrfunc( _cache->t(), _cache->trajectoryValues(), _cache->u(), fx, discretization, configuration );
}

void yane::MPC::ASyncCacheCalculator::restrJacobi(double * jac, int index, void * discretization, yane::MinProg::T_MEMMODEL memmodel, int * needc, bool firstcalc, void * configuration, int threadid)
{
	if ( _total_restr == 0 ) return;

	try
	{
		calcCache ( );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Cache could not be computed" ), &e );
	}

	double * u = _cache->u(threadid);

	if (firstcalc)
	{
		_restrfunc ( _cache->t(), _cache->trajectoryValues(), u, _tempr1, discretization, configuration );
		memcpy ( _trajectory_restr, _cache->trajectoryValues(), _horizon*_dimx*sizeof ( double ) );
	}

	int h;

	if (index < _horizon*_dimu)
	{
		h = index/_dimu;
	} else
	{
		h = _sdata[index - _horizon*_dimu ].horizonindex + 1;
	}

	try
	{
		calcCacheDisturbed ( index, threadid );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "CacheDerived could not be computed" ), &e );
	}

	memcpy ( &_trajectory_restr[h*_dimx], _cache->trajectoryDisturbedValues(index), sizeof ( double ) * ( _horizon - h ) *_dimx );

	double oldu = u[index];
	u[index] += yane::Utils::OptimalDiff::get();

	_restrfunc ( _cache->t(), _trajectory_restr, u, _tempr2, discretization, configuration );

	u[index] = oldu;

	for ( int row = 0; row < _total_restr; row++ )
	{
		if ( needc[row] != 0 )
		{
			if ( memmodel == yane::MinProg::BYLINE )
			{
				jac[row* ( _dimu*_horizon + _sdatalength ) + index] = ( _tempr2[row] - _tempr1[row] ) / yane::Utils::OptimalDiff::get();
			}
			else
			{
				jac[row + index*_total_restr] = ( _tempr2[row] - _tempr1[row] ) / yane::Utils::OptimalDiff::get();
			}
		}
	}

}


/***************************************************************

	Hilfsroutinen zur Cachebrechnung

****************************************************************/

void yane::MPC::ASyncCacheCalculator::calcCache()
{
	_cache->lock();

	if ( !_cache->baseIsCalc() )
	{
		memcpy ( _x, _cache->x(), sizeof ( double ) *_dimx );
		_x[_dimx] = 0.0;

		try
		{
			_ode->refreshConfig();
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Configuration of the differential equation solver could not be refreshed" ), &e );
		}
		try
		{
			_ode->init ( _cache->t()[0], _x );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Differential equation solver could not be initialized" ), &e );
		}

		int sdataindex = 0;
		for ( int i = 0; i < _horizon; i++ )
		{
			_data->u = &(_cache->u())[i*_dimu];
			try
			{
				_ode->calc ( _cache->t()[i+1], ( double * ) _data );
			}
			catch ( yane::OdeSolve::OdeSolEx e )
			{
				throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation failed" ), &e );
			}

			memcpy ( &(_cache->trajectoryValues())[i*_dimx], _x, sizeof ( double ) *_dimx );
			_cache->objHorizonValues()[i] = _x[_dimx];

			if ( _sdatalength > 0  && sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
			{
				while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
				{
					_x[_sdata[sdataindex].varindex] = _cache->u()[_horizon*_dimu + sdataindex];
					++sdataindex;
				}
			}

		}
		_cache->objHorizonValues()[_horizon-1] *= _weightint;

		if ( _weightcf != 0.0 )
		{
			memcpy ( _trajectory, _cache->x(), sizeof ( double ) *_dimx );
			memcpy ( &_trajectory[_dimx], _cache->trajectoryValues(), sizeof ( double ) *_dimx*_horizon );
			_cache->objHorizonValues()[_horizon-1] += _weightcf * _model->discreteCostfunction ( _horizon, _horizon, _cache->t(), _trajectory, _cache->u() );
		}
		_cache->objValue() = _cache->objHorizonValues()[_horizon-1];

		_cache->baseIsCalc() = true;
	}
	_cache->unlock();
}

void yane::MPC::ASyncCacheCalculator::calcCacheDisturbed(int index, int threadid)
{
	calcCache ( );

	if ( ! _cache->disturbedIsCalc(index) )
	{
		int sdataindex = 0;
		int uindex;
		double * u = _cache->u(threadid);

		double oldu = u[index];
		u[index] += yane::Utils::OptimalDiff::get();

		// Teilabschnitt für gestörte Trajektorie ermitteln
		if ( index < _dimu*_horizon )
		{
			// Normale Steuerung ist zu differenzieren
			sdataindex = 0;
			uindex = index / _dimu;
			while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex + 1 < uindex )
			{
				sdataindex++;
			}

			if ( uindex == 0 )
			{
				memcpy ( _x, _cache->x(), sizeof ( double ) *_dimx );
				_x[_dimx] = 0.0;
			}
			else
			{
				memcpy ( _x, &(_cache->trajectoryValues())[ ( uindex-1 ) *_dimx ], sizeof ( double ) *_dimx );
				_x[_dimx] = _cache->objHorizonValues()[uindex-1];
			}
		}
		else
		{
			//Shootingknoten ist zu differenzieren
			sdataindex = index - _dimu * _horizon;
			while ( sdataindex > 0 && _sdata[sdataindex-1].horizonindex == _sdata[sdataindex].horizonindex )
			{
				--sdataindex;
			}
			uindex = _sdata[sdataindex].horizonindex + 1;
			memcpy ( _x, &(_cache->trajectoryValues())[ ( uindex-1 ) *_dimx], sizeof ( double ) *_dimx );
			_x[_dimx] = _cache->objHorizonValues()[uindex-1];
		}

		// Die restlichen Shootinginformationen für diesen Horizontpunkt ablaufen
		while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex + 1 == uindex )
		{
			this->_x[_sdata[sdataindex].varindex] = u[_dimu*_horizon + sdataindex];
			sdataindex++;
		}

		try
		{
			_ode->refreshConfig();
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Configuration of the differential equation solver could not be refreshed" ), &e );
		}
		try
		{
			_ode->init ( _cache->t()[uindex], _x );
		}
		catch ( yane::OdeSolve::OdeSolEx e )
		{
			throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "Differential equation solver could not be initialized" ), &e );
		}
		for ( int i = uindex; i < _horizon; i++ )
		{
			_data->u = &u[i*_dimu];
			try
			{
				_ode->calc ( _cache->t()[i+1], ( double * ) _data );
			}
			catch ( yane::OdeSolve::OdeSolEx e )
			{
				throw yane::OdeSolve::OdeSolEx ( __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Computation Error" ), __DEBUGMESS ( "Solving the differential equation failed" ), &e );
			}

			memcpy ( &(_cache->trajectoryDisturbedValues(index))[ ( i-uindex ) *_dimx], this->_x, sizeof ( double ) *_dimx );

			if ( _sdatalength > 0  && sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
			{
				while ( sdataindex < _sdatalength && _sdata[sdataindex].horizonindex == i )
				{
					this->_x[_sdata[sdataindex].varindex] = u[_horizon*_dimu + sdataindex];
					++sdataindex;
				}
			}
		}
		_cache->objDisturbedValue(index) = _weightint * _x[_dimx];
		if ( _weightcf != 0.0 )
		{
			// Ersten Punkt der Trajektorie kopieren
			memcpy ( _trajectory, _cache->x(), sizeof ( double ) *_dimx );
			if ( uindex != 0 )
			{
				// Unveränderter erster Teil der Trajektorie kopieren
				memcpy ( &_trajectory[_dimx], _cache->trajectoryValues(), uindex*_dimx*sizeof ( double ) );
			}
			// Gestörter Teil der Trajektorie kopieren
			memcpy ( &_trajectory[ ( uindex+1 ) *_dimx], _cache->trajectoryDisturbedValues(index), sizeof ( double ) *_dimx* ( _horizon - uindex ) );

			_cache->objDisturbedValue(index) += _weightcf * _model->discreteCostfunction ( _horizon, _horizon, _cache->t(), _trajectory, u );
		}

		u[index] = oldu;

		_cache->disturbedIsCalc(index);
	}
}




