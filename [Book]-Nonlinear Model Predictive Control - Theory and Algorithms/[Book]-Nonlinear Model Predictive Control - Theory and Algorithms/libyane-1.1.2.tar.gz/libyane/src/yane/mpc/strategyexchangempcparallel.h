/***************************************************************************
 *                                                                         *
 * Model Predictive Control Library                                        *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MPC_STRATEGYEXCHANGEMPCPARALLEL_H
#define YANE_MPC_STRATEGYEXCHANGEMPCPARALLEL_H

#include "strategyexchangempc.h"

#include <vector>

namespace yane
{

	namespace MPC
	{

		/** @class StrategyExchangeMPCParallel
		This class allows to control a plant using MPC in parallel in a network of connected plants by exchanging control strategies.
		@brief Not yet documented
		 */
		class StrategyExchangeMPCParallel : public yane::MPC::StrategyExchangeMPC
		{
			public:
				StrategyExchangeMPCParallel();

				~StrategyExchangeMPCParallel();

		};

	}

}

#endif
