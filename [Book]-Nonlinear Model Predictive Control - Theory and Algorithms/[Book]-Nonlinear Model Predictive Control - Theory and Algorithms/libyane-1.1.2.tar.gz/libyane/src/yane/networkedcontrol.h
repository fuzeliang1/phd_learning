/***************************************************************************
 *                                                                         *
 * Networked Control Library                                               *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Autoren:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/


/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

/** @namespace yane::NetworkedControl
	\brief Namespace of the Networked Predictive Controller Scheme
 */

#ifndef YANE_NETWORKEDCONTROL_MAIN
#define YANE_NETWORKEDCONTROL_MAIN

#include "networkedcontrol/typedefs.h"

#include "networkedcontrol/cycle.h"
#include "networkedcontrol/iointerface.h"
#include "networkedcontrol/controller.h"

#include "networkedcontrol/actuator.h"
#include "networkedcontrol/controller_mpc.h"
#include "networkedcontrol/iointerfacelocal.h"
#include "networkedcontrol/modelhandlerlocal.h"

#include "networkedcontrol/actuator_realtime.h"
#include "networkedcontrol/controller_realtimempc.h"

#include "networkedcontrol/iointerfacetcp.h"
#include "networkedcontrol/modelhandlertcp.h"

#endif
