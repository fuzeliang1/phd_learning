/***************************************************************************
 *                                                                         *
 * Model Library                                                           *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "model.h"
#include "exceptions.h"

#include "../utils.h"
#include "../odesolve.h"

#include <cstring>
#include <sstream>

#include "libexport.h"

using namespace std;
using namespace yane::Utils;

LIB_EXPORT yane::Model::Model::Model ( yane::OdeSolve::OdeSolveFirst * ode, yane::OdeSolve::OdeConfig * odeconf, int dimension, int ctrl_dimension, int restrsize, int paramsize, int iparamsize, int networkrestrsize )
{
	if ( ode == 0 )
	{
		throw MemoryException ( __DEBUGMESS ( "got NULL-pointer as OdeSolveFirst-object" ) );
	}
	_ode = ode;

	if ( odeconf == 0 )
	{
		throw MemoryException ( __DEBUGMESS ( "got NULL-pointer as OdeConfig-object" ) );
	}
	_odeconfig = odeconf;
	_dimension = dimension;
	_restrsize = restrsize;
	_ctrl_dimension = ctrl_dimension;
	_paramsize = paramsize;
	_iparamsize = iparamsize;
	_network_restrsize = networkrestrsize;

	try
	{
		_control_lb = new double[ctrl_dimension];
		_control_ub = new double[ctrl_dimension];
		_state_lb = new double[dimension];
		_state_ub = new double[dimension];
		_params = new double[paramsize];
		_iparams = new int[iparamsize];
	}
	catch ( std::bad_alloc )
	{
		throw MemoryException ( __DEBUGMESS ( "failed allocating memory" ) );
	}

	for ( int i = 0; i < _dimension; i++ )
	{
		_state_ub[i] = 1E19;
		_state_lb[i] = -1E19;
	}

	for ( int i = 0; i < _ctrl_dimension; i++ )
	{
		_control_ub[i] = 1E19;
		_control_lb[i] = -1E19;
	}
}

yane::Model::Model::Model ( Model & input )
{
}

yane::Model::Model::Model()
{
}

LIB_EXPORT yane::Model::Model::~ Model()
{
	delete[] _params;
	delete[] _iparams;
	delete[] _control_lb;
	delete[] _control_ub;
	delete[] _state_lb;
	delete[] _state_ub;
}

LIB_EXPORT void yane::Model::Model::setDoubleParameter ( int paramid, double value )
{
	if ( _paramsize == 0 )
	{
		throw IndexException ( __DEBUGMESS ( "this model has no double-parameters" ) );
	}
	if ( paramid < 0 || paramid >= _paramsize )
	{
		stringstream out;
		out << "invalid parameter-index specified, got " << paramid << ", must be in 0.." << ( int ) ( _paramsize - 1 );
		throw IndexException ( __DEBUGMESS ( out.str() ) );
	}
	_params[paramid] = value;
}

LIB_EXPORT void yane::Model::Model::setIntParameter ( int paramid, int value )
{
	if ( _iparamsize == 0 )
	{
		throw IndexException ( __DEBUGMESS ( "this model has no int-parameters" ) );
	}
	if ( paramid < 0 || paramid >= _iparamsize )
	{
		stringstream out;
		out << "invalid parameter-index specified, got " << paramid << ", must be in 0.." << ( int ) ( _iparamsize - 1 );
		throw IndexException ( __DEBUGMESS ( out.str() ) );
	}
	_iparams[paramid] = value;
}

LIB_EXPORT double yane::Model::Model::doubleParameter ( int paramid )
{
	if ( _paramsize == 0 )
	{
		throw IndexException ( __DEBUGMESS ( "this model has no double-parameters" ) );
	}
	if ( paramid < 0 || paramid >= _paramsize )
	{
		stringstream out;
		out << "invalid parameter-index specified, got " << paramid << ", must be in 0.." << ( int ) ( _paramsize - 1 );
		throw IndexException ( __DEBUGMESS ( out.str() ) );
	}

	return _params[paramid];
}

LIB_EXPORT int yane::Model::Model::intParameter ( int paramid )
{
	if ( _iparamsize == 0 )
	{
		throw IndexException ( __DEBUGMESS ( "this model has no int-parameters" ) );
	}
	if ( paramid < 0 || paramid >= _iparamsize )
	{
		stringstream out;
		out << "invalid parameter-index specified, got " << paramid << ", must be in 0.." << ( int ) ( _iparamsize - 1 );
		throw IndexException ( __DEBUGMESS ( out.str() ) );
	}

	return _iparams[paramid];
}

LIB_EXPORT void yane::Model::Model::setDimensionState ( int dimension )
{
	if ( dimension < 1 )
	{
		throw ValueException ( __DEBUGMESS ( "dimension must be greater than zero" ) );
	}
	_dimension = dimension;
}

LIB_EXPORT void yane::Model::Model::setDimensionControl ( int ctrl_dimension )
{
	if ( ctrl_dimension < 1 )
	{
		throw ValueException ( __DEBUGMESS ( "ctrl_dimension must be greater than zero" ) );
	}
	_ctrl_dimension = ctrl_dimension;
}

LIB_EXPORT int yane::Model::Model::setRestrictionSize ( int restrsize )
{
	if ( restrsize < 0 )
	{
		throw ValueException ( __DEBUGMESS ( "restrsize must be greater than or equal to zero" ) );
	}
	_restrsize = restrsize;
}

LIB_EXPORT int yane::Model::Model::dimensionState()
{
	return _dimension;
}

LIB_EXPORT int yane::Model::Model::doubleParameterSize()
{
	return _paramsize;
}

LIB_EXPORT int yane::Model::Model::intParameterSize()
{
	return _iparamsize;
}

LIB_EXPORT int yane::Model::Model::dimensionControl()
{
	return _ctrl_dimension;
}

LIB_EXPORT int yane::Model::Model::restrictionSize()
{
	return _restrsize;
}

LIB_EXPORT yane::OdeSolve::OdeSolveFirst * yane::Model::Model::odeSolver()
{
	return _ode;
}

LIB_EXPORT yane::OdeSolve::OdeConfig * yane::Model::Model::odeConfig()
{
	return _odeconfig;
}

LIB_EXPORT void yane::Model::Model::massMatrix ( double * mass )
{
	throw UndefinedException ( __DEBUGMESS ( "Mass matrix is undefined" ) );
}

LIB_EXPORT void yane::Model::Model::jacobiMatrix ( double t, double * x, double * u,  double * dy )
{
	throw UndefinedException ( __DEBUGMESS ( "Jacobi matrix is undefined" ) );
}

LIB_EXPORT void yane::Model::Model::dynamicDerivativeT ( double t, double * x, double * u, double * dft )
{
	throw UndefinedException ( __DEBUGMESS ( "Time derivative of ODE-function is undefined" ) );
}

LIB_EXPORT void yane::Model::Model::costfunctionDerivativeT ( double t, double * x, double * u, double * dot )
{
	throw UndefinedException ( __DEBUGMESS ( "Time derivative of cost function is undefined" ) );
}

LIB_EXPORT void yane::Model::Model::costfunctionGradient ( double t, double * x, double * u, double * dobj )
{
	throw UndefinedException ( __DEBUGMESS ( "Cost function gradient is undefined" ) );
}

LIB_EXPORT void yane::Model::Model::eventBeforeMPC ( int horizont, double * timesteps, double * x, double * sdatavalues )
{
}

LIB_EXPORT void yane::Model::Model::getControlBounds ( double * lb, double * ub )
{
	memcpy ( lb, _control_lb, sizeof ( double ) *_ctrl_dimension );
	memcpy ( ub, _control_ub, sizeof ( double ) *_ctrl_dimension );
}

LIB_EXPORT void yane::Model::Model::getModelBounds ( double * lb, double * ub )
{
	memcpy ( lb, _state_lb, sizeof ( double ) *_dimension );
	memcpy ( ub, _state_ub, sizeof ( double ) *_dimension );
}

LIB_EXPORT void yane::Model::Model::setControlBounds ( double * lb, double * ub )
{
	memcpy ( _control_lb, lb, sizeof ( double ) *_ctrl_dimension );
	memcpy ( _control_ub, ub, sizeof ( double ) *_ctrl_dimension );
}

LIB_EXPORT void yane::Model::Model::setModelBounds ( double * lb, double * ub )
{
	memcpy ( _state_lb, lb, sizeof ( double ) *_dimension );
	memcpy ( _state_ub, ub, sizeof ( double ) *_dimension );
}

LIB_EXPORT void yane::Model::Model::exactDiscreteCostfunctionDerivativeX ( int length, int horizont, double * t, double * x, double * u, double * fx )
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Evaluation Error" ), __DEBUGMESS ( "Function to evaluate the exact derivative is not defined" ) );
}

LIB_EXPORT void yane::Model::Model::exactContinuousCostfunctionDerivativeX ( double t, double * x, double * u, double * fx )
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Evaluation Error" ), __DEBUGMESS ( "Function to evaluate the exact derivative is not defined" ) );
}

LIB_EXPORT void yane::Model::Model::exactContinuousCostfunctionDerivativeU ( double t, double * x, double * u, double * fx )
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Evaluation Error" ), __DEBUGMESS ( "Function to evaluate the exact derivative is not defined" ) );
}

LIB_EXPORT void yane::Model::Model::exactOdeFunctionDerivativeX ( double t, double * x, double * u, double ** fx )
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Evaluation Error" ), __DEBUGMESS ( "Function to evaluate the exact derivative is not defined" ) );
}

LIB_EXPORT void yane::Model::Model::exactOdeFunctionDerivativeU ( double t, double * x, double * u, double ** fx )
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Evaluation Error" ), __DEBUGMESS ( "Function to evaluate the exact derivative is not defined" ) );
}

LIB_EXPORT void yane::Model::Model::exactRestrictionFunctionDerivativeX ( double t, double * x, double * u, double ** fx )
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Evaluation Error" ), __DEBUGMESS ( "Function to evaluate the exact derivative is not defined" ) );
}

LIB_EXPORT void yane::Model::Model::exactRestrictionFunctionDerivativeU ( double t, double * x, double * u, double ** fx )
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Evaluation Error" ), __DEBUGMESS ( "Function to evaluate the exact derivative is not defined" ) );
}

LIB_EXPORT const yane::Utils::Uuid & yane::Model::Model::id()
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "The model id has been requested, but this model class has no id() method implemented." ) );
}

LIB_EXPORT const char * yane::Model::Model::name()
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "The model name has been requested, but this model class has no name() method implemented." ) );
}

LIB_EXPORT const char * yane::Model::Model::description()
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "The model description has been requested, but this model class has no description() method implemented." ) );
}

LIB_EXPORT const char * yane::Model::Model::stateName(int)
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "A model state name has been requested, but this model class has no stateName() method implemented." ) );
}

LIB_EXPORT const char * yane::Model::Model::controlName(int)
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "A model control name has been requested, but this model class has no controlName() method implemented." ) );
}

LIB_EXPORT const char * yane::Model::Model::doubleParameterName(int)
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "A model double parameter name has been requested, but this model class has no doubleParameterName() method implemented." ) );
}

LIB_EXPORT const char * yane::Model::Model::intParameterName(int)
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Initialization Error" ), __DEBUGMESS ( "A model integer parameter name has been requested, but this model class has no intParameterName() method implemented." ) );
}

LIB_EXPORT void yane::Model::Model::networkRestrictionFunction ( double t, double * x, double * u, double * x_neighbour, double * u_neighbour, double * fx )
{
	throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Evaluation Error" ), __DEBUGMESS ( "Function to evaluate the network restrictions is not defined" ) );
}

LIB_EXPORT void yane::Model::Model::setNetworkRestrictionSize ( int networkrestrsize )
{
	_network_restrsize = networkrestrsize;
}

LIB_EXPORT int yane::Model::Model::networkRestrictionSize()
{
	return _network_restrsize;
}

LIB_EXPORT double yane::Model::Model::networkCostfunction(int length, int horizont, double * t, double * x, double * u, double * x_neighbour, double * u_neighbour, double * multiplier)
{
	return 0.0;
}
