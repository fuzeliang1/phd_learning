/***************************************************************************
 *                                                                         *
 * Model Library                                                           *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>             *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
*/

#include "stateestimator.h"
#include "model.h"
#include "simulator.h"

#include "../minprog.h"
#include "../odesolve.h"

#include <cmath>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <sstream>

#include "libexport.h"

using namespace std;
using namespace yane::MinProg;
using namespace yane::OdeSolve;

LIB_EXPORT yane::Model::StateEstimator::StateEstimator ( Model * model, int maxsensorvalues, bool * isParam, int max_iter, double ode_tol, double gn_tol, double prec )
{
	_model = model;
	_is_param = new bool[model->dimensionState()];
	_max_sensors = maxsensorvalues;
	_max_iter = max_iter;

	_amount_sensors = 0;
	_vec_start = 0;
	_vec_end = 0;
	_prec = prec;

	_x0 = new double[_model->dimensionState() ];

	_simulator = new Simulator ( _model );
	_model->odeConfig()->setTolerance(ode_tol, ode_tol);

	_dim_params = 0;
	
	for (int i=0; i<_model->dimensionState(); i++)
	{
		_is_param[i] = isParam[i];
		if (isParam[i]) ++_dim_params;
	}
	
	int dim_x = _model->dimensionState() - _dim_params;

	// Create GaussNewton and data
	_y = new double[_max_sensors];
	for(int i = 0; i < _max_sensors; i++)	_y[i] = 0.0;
		
	_newx = new double[_max_sensors * dim_x];

	_gn = new GaussNewton ( dim_x, _model->dimensionState(), _max_sensors, _newx, _y, modelfunction );
	_gn->setMaxIterations ( _max_iter );
	_gn->setAccuracy ( gn_tol );
}

LIB_EXPORT yane::Model::StateEstimator::~ StateEstimator()
{
	delete[] _x0;
	delete[] _is_param;
	delete _simulator;
	
	delete _gn;
	delete[] _y;
	delete[] _newx;
	
	// delete _vec
	for ( T_STATE * iter = _vec_start; iter != 0; iter = iter->next )
	{
		delete[] iter->value;
		if(iter->hasControl)	delete[] iter->control;
		if(iter->prev != 0)	delete iter->prev;
	}
	delete _vec_end;
	_vec_start = 0;
	_vec_end = 0;
}

LIB_EXPORT void yane::Model::StateEstimator::addSensor ( double t, double * x )
{
	double * sensor = new double[_model->dimensionState() - _dim_params];
	memcpy ( sensor, x, sizeof ( double ) * ( _model->dimensionState() - _dim_params ) );

	insert ( t, true, sensor );
}

LIB_EXPORT void yane::Model::StateEstimator::addControl ( double t, double * u )
{
	double * control = new double[_model->dimensionControl() ];
	memcpy ( control, u, sizeof ( double ) * _model->dimensionControl() );

	insert ( t, false, control );
}

LIB_EXPORT void yane::Model::StateEstimator::modelfunction ( int * i, int * dim_x, int * dim_a, double * a, bool * achanged, double * y, double * fy, double * rpar, int * ipar )
{
	// Get important data
	StateEstimator * base = ( StateEstimator * ) ipar;
	Simulator * simulator = base->_simulator;

	int dim = base->_model->dimensionState();
	int last_step = base->_last_step;
	int step = *i;
	int steps = step - last_step;

	double * x0 = base->_x0;
	double * sensor;
	T_STATE * &u = base->_last_u;
	T_STATE * &x = base->_last_x;

	T_STATE * start = base->_vec_start;

	// If achanged or step - 1 != last step, we need to start at the beginning.
	if ( *achanged || steps < 1 )
	{
		memcpy ( x0, a, sizeof ( double ) * ( *dim_a ) );
		u = start;
		
		if(u->hasControl)
		{
			x = u;
			simulator->initialize ( x->t, x0, u->control );
		}
		else
		{
			x = u->next;
			simulator->initialize ( x->t, x0, u->value );
		}
		
		sensor = x->value;
		
		if(!*achanged)	steps = step - 1;
	}

	// if !achanged, we need to integrate sensor values.
	if ( !*achanged )
	{
		// solve ode until last control
		for ( x = x->next; x != 0 && ! ( x->isSensor && steps == 1 ); x = x->next )
		{
			// Set current control
			if(!u->isSensor)	simulator->setControl ( u->value );
			else if(u->hasControl)	simulator->setControl ( u->control );
			
			// solve ode
			simulator->run ( x->t );

			// Set data for next steps
			if ( x->isSensor )	steps--;
			if ( !x->isSensor || x->hasControl)	u = x;
		}
	
		// solve the last step from last control to last sensor
		if(!u->isSensor)	simulator->setControl ( u->value );
		else if(u->hasControl)
		{
			simulator->setControl ( u->control );
			u = u->next;	
		}

		simulator->run ( x->t );
		
		sensor = x->value;
	}

	// calculate difference between calculated and given sensor
	fy[0] = 0.0;
	int cur_x = 0;
	for ( int j = 0; j < dim; j++ )
	{
		if ( !base->_is_param[j] )
		{
			fy[0] += pow ( x0[j] - sensor[cur_x], 2 );
			cur_x++;
		}
	}
	base->_last_step = step;
}

LIB_EXPORT void yane::Model::StateEstimator::getState ( double &t, double * a )
{
	bool throwwarning = false;
	yane::MinProg::SolverWarning e;
	
	try
	{
		_gn->calcParams ( a, _amount_sensors, 0, ( int* ) this );
	} catch (yane::MinProg::SolverWarning & ex)
	{
		e = ex;
		throwwarning = true;
	}
	//TODO: was ist mit _last_x? taucht nirgends wieder auf, und wird auch nicht initialisiert
	//TODO: gn liefert approximation des STARTWERTS! Es soll aber Zustand des letzten Zeitpunkts wiedergegeben werden
	
//	t = _last_x->t;
	
	//TODO: Behelfsweise wird der passende Zeitpunkt des Startwerts zurückgegeben
	T_STATE * xcur = _vec_start;
	for ( ; xcur != 0 && !xcur->isSensor; xcur = xcur->next );
		
	if(xcur != 0)
	{	
		t = xcur->t;
	}

	if (throwwarning)
	{
		throw yane::MinProg::SolverWarning(__DEBUGMESS("Gauss Newton warning"), &e);
	}
}

LIB_EXPORT void yane::Model::StateEstimator::insert ( double t, bool isSensor, double * value )
{
	T_STATE * state = new T_STATE;
	state->t = t;
	state->isSensor = isSensor;
	state->value = value;
	state->hasControl = false;
	bool added = true;

	T_STATE * iter;

	// Search for position to insert data
	for ( iter = _vec_end; iter != 0 && iter->t > t; iter = iter->prev );
	
	// If two states are to close combine the states
	if((iter != 0 && abs(iter->t - t) < _prec) || (iter != 0 && iter->next != 0 &&  abs(iter->next->t - t) < _prec))
	{
		// Combine with the next state otherwise the default is the previous
		if(iter != 0 && iter->next != 0 &&  abs(iter->next->t - t) < _prec)	iter = iter->next;
		
		// Add control to sensor
		if(iter->isSensor && !isSensor)
		{
			iter->hasControl = true;
			iter->control = value;
		}
		
		// Add sensor to control
		else if(!iter->isSensor && isSensor)
		{
			iter->hasControl = true;
			iter->control = iter->value;
			iter->value = value;
			iter->isSensor = true;
		}
		
		// replace data with newer data
		else
		{
			iter->t = t;
			iter->value = value;
		}
	}

	// Add first state
	else if ( _vec_start == 0 )
	{
		// Add only controls
		if ( !isSensor )
		{
			state->prev = 0;
			state->next = 0;
			_vec_start = state;
			_vec_end = state;
		}
		else	added = false;
	}
	
	// Is second control before first sensor overwrite (if newer) the current control
	else if ( !_vec_start->isSensor && !isSensor && (_vec_start == _vec_end || (_vec_start->next != 0 && t < _vec_start->next->t)))
	{
		if(t > _vec_start->t)
		{
			_vec_start->t = t;
			_vec_start->value = value;
			_vec_start->isSensor = isSensor;
		
			added = false;
		}
	}

	// Add at the end
	else if ( iter == _vec_end )
	{
		_vec_end->next = state;
		state->prev = _vec_end;
		state->next = 0;
		_vec_end = state;
	}

	// Add somewhere in the middle
	else if(iter != 0)
	{
		iter->next->prev = state;
		state->prev = iter;
		state->next = iter->next;
		iter->next = state;
	}

	// If we added a sensor we need to do some things
	if ( isSensor && added )
	{
		_amount_sensors++;
	
		// delete
		if (_amount_sensors > _max_sensors )
		{
			
			// delete first sensor
			_vec_start->next = _vec_start->next->next;
			
			delete[] _vec_start->next->prev->value;
			if(_vec_start->next->prev->hasControl) delete[] _vec_start->next->prev->control;
			delete _vec_start->next->prev;
				
			_vec_start->next->prev = _vec_start;
			_amount_sensors--;
		
			// delete controls
			for(iter = _vec_start->next; iter != 0 && !(iter->isSensor); iter = iter->next)
			{
				delete[] iter->prev->value;
				delete iter->prev;
				iter->prev = 0;
				_vec_start = iter;
			}
			
		}
	}
}

LIB_EXPORT void yane::Model::StateEstimator::print()
{
	for ( T_STATE * iter = _vec_start; iter != 0; iter = iter->next )
	{
		cout << iter->t << " : " << ( iter->value ) [0] << "," << iter->isSensor;
		if(iter->hasControl)	cout << " - control : " << ( iter->control ) [0];
		cout << endl;
	}
	cout << endl;
}

LIB_EXPORT int yane::Model::StateEstimator::countSensors() const
{
	return _amount_sensors;
}

LIB_EXPORT void yane::Model::StateEstimator::getInitialSensorData(int N, double * t, double ** x)
{
	if(N > _amount_sensors)	 throw yane::Utils::ValueException(__DEBUGMESS("estimation object does not contain enough states"));
	
	T_STATE * xcur = _vec_start;
	
	for(int i = 0; i < N; i++)
	{
		for ( ; xcur != 0 && !xcur->isSensor; xcur = xcur->next );
		
		if(xcur != 0)
		{	
			t[i] = xcur->t;
			x[i] = xcur->value;
			xcur = xcur->next;
		}
	}
}


