/***************************************************************************
 *                                                                         *
 * Model Library                                                           *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Michael Schamel <michael.schamel@uni-bayreuth.de>             *
 *                                                                         *
 ***************************************************************************/

/**
	@file
 	@author Michael Schamel <michael.schamel@uni-bayreuth.de>
 */

#ifndef YANE_MODEL_STATEESTIMATOR_H
#define YANE_MODEL_STATEESTIMATOR_H

namespace yane
{
	namespace MinProg
	{
		class GaussNewton;
	}
	
	namespace Model
	{
		class Model;
		class Simulator;

		/**< @Class StateEstimator
		This class estimates initial values of a given model. Therefore sensor data and control data is needed.<br><br>
		
		Adding states (equals sensors and controls) data is restricted by:<br>
		@li the first state has to be a control.
		@li if the second state is a control the first one is replaced.
		@li if a control is added before the first sensor and the control is newer than the first control, the first control is replaced by the new one.
		@li if the time difference between states is smaller than prec, the states are combined.
		
		Usually this class is used as following: <br>
		@li create StateEstimator
		@li add sensor and control data
		@li calculate initial value by getState
		@li delete StateEstimator
		
		@brief This class estimates initial values of a given model.
		*/
				
		class StateEstimator
		{


			public:
				/**
				* @brief Constructor
				* @param model Pointer to a class btmb::Model::Model object of the model under consideration
				* @param maxsensorvalues maximal amount of available sensors.
				* @param isParam Array to specify the state values that has to be handled as parameters (lacking state values). Dimension of the array is the dimension of the model.
				* @param max_iter maximum amount of iterations GaussNewton uses.
				* @param ode_tol Tolerance of the odesolver.
				* @param gn_tol Tolerance of GaussNewton.
				* @param prec if the state time of two states differs less than prec, Stateestimator combines the two states.
				*/
				StateEstimator ( Model * model, int maxsensorvalues, bool * isParam, int max_iter = 20 , double ode_tol = 1E-10, double gn_tol = 1E-5, double prec = 1E-5);

				/**
				 * @brief Destructor
				*/
				~StateEstimator();

				/**
				 * This function adds a sensor to the state-vector.
				 * @param t Time instant
				 * @param x Sensor vector. Dimension of the array is dim_params.
				 * @brief This function adds a sensor to the state-vector.
				*/
				void addSensor ( double t, double * x );
				
				/**
				 * This function adds a control to the state-vector.
				 * @param t Time instant
				 * @param u Control vector
				 * @brief This function adds a control to the state-vector.
				*/
				void addControl ( double t, double * u );
				
				/**
				 * This function adds a sensor to the state-vector.
				 * @param t Time, which is set by Stateestimator to the last sensor time.
				 * @param x Sensor vector with initial values.
				 * @brief This function adds a sensor to the state-vector.
				*/
				void getState ( double &t, double * x );
				
				void print();

				int countSensors() const;
				void getInitialSensorData( int N, double * t, double ** x);
				
			protected:
				static void modelfunction ( int * i, int * dim_x, int * dim_a, double * a, bool * achanged, double * x, double * fx, double * rpar, int * ipar );
				
				void insert(double t, bool isSensor, double * state);
				
				struct T_STATE
				{
					double t;
					bool isSensor;
					double * value;
					bool hasControl;
					double * control;
					T_STATE * next;
					T_STATE * prev;
				};

				int _dim_params;
				bool * _is_param;
				
				int _max_iter;
				double _prec;
				
				int _max_sensors;
				int _amount_sensors;
				T_STATE * _vec_start;
				T_STATE * _vec_end;
				
				double * _x0;
				T_STATE * _last_x;
				T_STATE * _last_u;
				int _last_step;
				
				double * _y;
				double * _newx;
				
				Model * _model;
				Simulator * _simulator;
				MinProg::GaussNewton * _gn;
		};

	}

}

#endif
