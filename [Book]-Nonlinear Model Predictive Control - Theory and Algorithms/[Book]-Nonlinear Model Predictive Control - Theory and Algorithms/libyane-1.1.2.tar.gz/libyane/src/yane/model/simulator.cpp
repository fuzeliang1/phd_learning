/***************************************************************************
 *                                                                         *
 * Model Library                                                           *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
 @file
 @author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
 @author Juergen Pannek <juergen.pannek@googlemail.com>
 */

//TODO exceptions einbauen
#include "model.h"
#include "simulator.h"
#include "exceptions.h"

#include "../utils.h"
#include "../odesolve.h"

#include <cstring>
#include <iostream>

#include "libexport.h"

using namespace std;

LIB_EXPORT yane::Model::Simulator::Simulator ( Model * model, yane::OdeSolve::OdeConfig * odeconf )
{
	double * temp, *tempx, *tempu;
	_model = model;
	_dimensionx = _model->dimensionState ( );
	_dimensionu = _model->dimensionControl ( );

	_x = 0;
	_u = 0;
	_odefunc = 0;

	try
	{
		_odesolver = _model->odeSolver ( )->clone ( );
		_odefunc = new yane::OdeSolve::OdeFunction ( staticodefunc, _dimensionx );
		temp = new double [ _dimensionx * _dimensionx ];
		tempx = new double [ _dimensionx ];
		tempu = new double [ _dimensionu ];
	}
	catch ( std::bad_alloc )
	{
		throw yane::Utils::MemoryException ( __DEBUGMESS ( "failed allocating memory" ) );
	}

	// test ob Mass-matrix definiert
	try
	{
		_model->massMatrix ( temp );
		_odefunc->setMassMatrix ( staticmassfunc );
	}
	catch ( UndefinedException )
	{
	}

	// test ob jacobi-matrix definiert
	try
	{
		_model->jacobiMatrix ( 0.0, tempx, tempu, temp );
		_odefunc->setJacobiMatrix ( staticjacfunc );
	}
	catch ( UndefinedException )
	{
	}

	// test ob timegradient definiert
	try
	{
		_model->dynamicDerivativeT ( 0.0, tempx, tempu, temp );
		_odefunc->setAutonomeMode ( false, staticdftfunc );
	}
	catch ( UndefinedException )
	{
	}

	_odeconfig = ( odeconf == 0 ? _model->odeConfig ( ) : odeconf );

	_odesolver->reset ( _odefunc, _odeconfig );

	delete [ ] temp;
	delete [ ] tempx;
	delete [ ] tempu;
}

LIB_EXPORT yane::Model::Simulator::~Simulator ( )
{
	if ( _odefunc != 0 )
	{
		delete _odefunc;
		_odefunc = 0;
	}
	if ( _odesolver != 0 )
	{
		delete _odesolver;
		_odesolver = 0;
	}
}

LIB_EXPORT void yane::Model::Simulator::staticodefunc ( int *, double * t, double * y, double * dy, double * rpar,
        int * )
{
	Simulator * base = ( Simulator* ) rpar;

	base->_model->odeFunction ( * t, y, base->_u, dy );
}

LIB_EXPORT void yane::Model::Simulator::staticjacfunc ( int *, double * t, double * y, double * dfy, int *,
        double * rpar, int * )
{
	Simulator * base = ( Simulator* ) rpar;

	base->_model->jacobiMatrix ( * t, y, base->_u, dfy );
}

LIB_EXPORT void yane::Model::Simulator::staticmassfunc ( int *, double * mas, int *, double * rpar, int * )
{
	Simulator * base = ( Simulator* ) rpar;

	base->_model->massMatrix ( mas );
}

LIB_EXPORT void yane::Model::Simulator::staticdftfunc ( int *, double * t, double * y, double * dft, double * rpar,
        int * )
{
	Simulator * base = ( Simulator* ) rpar;

	base->_model->dynamicDerivativeT ( * t, y, base->_u, dft );
}

LIB_EXPORT void yane::Model::Simulator::initialize ( double t, double * x, double * u )
{
	_x = x;
	_u = u;

	_odesolver->init ( t, x );
}

LIB_EXPORT void yane::Model::Simulator::run ( double targettime )
{
	_odesolver->calc ( targettime, ( double* ) this );
}

LIB_EXPORT void yane::Model::Simulator::predictSequence ( int seqlength, double * t, double * x, double * u )
{
	_x = x;

	try
	{
		_odesolver->init ( t [ 0 ], x );

		for ( int i = 0; i < seqlength; i++ )
		{
			_u = & u [ _dimensionu * i ];
			_odesolver->calc ( t [ i + 1 ], ( double* ) this );
		}
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx (
		        __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ),
		        __DEBUGMESS ( "Simulator could not compute steps" ) );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ),
		        __DEBUGMESS ( "Calculation was aborted" ), & e );
	}
}

LIB_EXPORT void yane::Model::Simulator::setControl ( double * u )
{
	_u = u;
}

LIB_EXPORT void yane::Model::Simulator::setSolutionOutput ( OdeSolve::T_SOLOUTFUNC func )
{
	try
	{
		_odefunc->setSolutionOutput ( func );
		_odesolver->reset ( _odefunc, _odeconfig );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Error" ),
		        __DEBUGMESS ( "Operation was aborted" ), & e );
	}
}

LIB_EXPORT void yane::Model::Simulator::trajectory ( int seqlength, double * t, double * x, double * u,
        double * trajectory )
{
	_x = x;
	memcpy ( trajectory, _x, sizeof(double) * _dimensionx );

	try
	{
		_odesolver->init ( t [ 0 ], x );

		for ( int i = 0; i < seqlength; i++ )
		{
			_u = & u [ _dimensionu * i ];
			_odesolver->calc ( t [ i + 1 ], ( double* ) this );
			memcpy ( & trajectory [ ( i + 1 ) * _dimensionx ], _x, sizeof(double) * _dimensionx );
		}
		memcpy ( x, trajectory, sizeof(double) * _dimensionx );
	}
	catch ( yane::OdeSolve::OdeSolEx e )
	{
		throw yane::OdeSolve::OdeSolEx (
		        __EXCEPTIONMESS ( yane::OdeSolve::OdeSolEx::TYPE, "Internal Calculation Error" ),
		        __DEBUGMESS ( "Simulator could not compute steps" ) );
	}
	catch ( yane::Utils::Exception e )
	{
		throw yane::Utils::Exception ( __EXCEPTIONMESS ( yane::Utils::Exception::TYPE, "Internal Calculation Error" ),
		        __DEBUGMESS ( "Calculation was aborted" ), & e );
	}
}

