/***************************************************************************
 *                                                                         *
 * Model Library                                                           *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#include "exceptions.h"

#include "libexport.h"

LIB_EXPORT const std::string yane::Model::UndefinedException::TYPE = std::string("yane::Utils::undefinedException");

LIB_EXPORT yane::Model::UndefinedException::UndefinedException(std::string debugmessage, Exception * innerex)
	: yane::Utils::Exception(__EXCEPTIONMESS(TYPE, "method has not been defined"), debugmessage, innerex)
{
	addType(TYPE);
}
