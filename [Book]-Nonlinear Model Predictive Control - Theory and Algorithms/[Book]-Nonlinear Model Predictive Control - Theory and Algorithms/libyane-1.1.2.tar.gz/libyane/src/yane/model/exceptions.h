/***************************************************************************
 *                                                                         *
 * Model Library                                                           *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MODEL_EXCEPTIONS_H
#define YANE_MODEL_EXCEPTIONS_H

#include "../utils/exception.h"
#include <string>

namespace yane
{

	namespace Model
	{

		/**
		 * @brief Undefined exception
		 */
		class UndefinedException : public yane::Utils::Exception
		{
			public:
				UndefinedException(std::string debugmessage="", Exception * innerex = 0);
				static const std::string TYPE;

		};

	}

}

#endif
