/***************************************************************************
 *                                                                         *
 * Model Library                                                           *
 *                                                                         *
 * Description:                                                            *
 *                                                                         *
 * Authors:                                                                *
 *   Thomas Jahn <thomas.jahn@uni-bayreuth.de>                             *
 *   Juergen Pannek <juergen.pannek@googlemail.com>                        *
 *                                                                         *
 ***************************************************************************/

/**
	@file
	@author Thomas Jahn <thomas.jahn@uni-bayreuth.de>
	@author Juergen Pannek <juergen.pannek@googlemail.com>
 */

#ifndef YANE_MODEL_MODEL_H
#define YANE_MODEL_MODEL_H

#if (__GNUC__ > 3 || (__GNUC__ == 3 && __GNUC_MINOR__ >= 1))
#define CPP_DEPRECATED  __attribute__((__deprecated__))
#else
#define CPP_DEPRECATED
#endif

#define _IDX(y,x) ((y)*dimension + (x))

namespace yane
{
	namespace Utils
	{
		class Uuid;
	}
	namespace OdeSolve
	{
		class OdeSolveFirst;
		class OdeConfig;
	}

	namespace Model
	{

		/**
		 * @class Model
		 * This class gives an abstract definition of the model and the optimal control problem which shall be considered. The model itself is defined via its dynamic
		\f[ \dot{x}_{u}(t) = f(x_{u}(t, x_0), u(t, x_0)) \f]
		on the optimization horizon \f$ [t_0, t_N] \f$ with initial value \f$ x_{u}(t_0, x_0) = x_0 \f$. Moreover, the solution of the control system shall satisfy given constraints
		\f{eqnarray*}{
		x_{u}(t, x_0) & \in & X \qquad \forall t \in [t_0, t_N] \\
		u(t, x_0) & \in & U \qquad \forall t \in [t_k, t_k)
		\f}
		Since we suppose at least control law \f$ u(\cdot) \f$ to exist which satisfies all these constraints, i.e. is feasible, an optimization critierion
		\f{eqnarray*}{
		J_N (x_0, u) & = & \sum\limits_{k=0}^{N - 1} \int\limits_{t_k}^{t_{k + 1}} L \left( \tau, x_{u}(\tau, x_0), u(\tau, x_0) \right) d \tau \\
		&& + \sum\limits_{k=0}^{N - 1} l \left( t_k, x_{u}(t_k, x_0), u(t_k, x_0) \right) + F(t_N, x_{u}(t_N, x_0))
		\f}
		is added to measure the quality of feasible solutions.
		 * @brief Abstract class to define the model of the process and the optimal control problem to be solved
		 */
		class Model
		{
			public:
				virtual ~Model();

				/**
				 * This function sets the dimension of the state. \n
				 * Note that after each change of the dimension of the state the yane::MPC::MPC class object must be reset using the method yane::MPC::MPC::reset.
				 * @param dimension New dimension of the state
				 * @throw yane::Utils::ValueException Is thrown if the new dimension is less than 1
				 * @brief Function to set the dimension of the state
				 */
				virtual void setDimensionState ( int dimension );

				/**
				 * This function gives back the dimension of the state.
				 * @return Dimension of the state
				 * @brief Function to obtain the dimension of the state
				 */
				virtual int dimensionState();

				/**
				 * This function sets the dimension of the control. \n
				 * Note that after each change of the dimension of the state the yane::MPC::MPC class object must be reset using the method yane::MPC::MPC::reset.
				 * @param crtl_dimension New dimension of the control
				 * @throw valueException Is thrown if the new dimension is less than 1
				 * @brief Function to set the dimension of the control
				 */
				virtual void setDimensionControl ( int ctrl_dimension );

				/**
				 * This function gives back the dimension of the control.
				 * @return Dimension of the control
				 * @brief Function to obtain the dimension of the control
				 */
				virtual int dimensionControl();

				/**
				 * This function sets the number of the restrictions.
				 * @return Number of restrictions
				 * @brief Function to set the number of restrictions
				 */
				virtual int setRestrictionSize ( int restrsize );

				/**
				 * This function gives back the number of restrictions.
				 * @return Number of restrictions
				 * @brief Function to obtain the number of restrictions
				 */
				virtual int restrictionSize();

				/**
				 * This funciton gives back the number of double parameters.
				 * @return Number of double parameters
				 * @brief Function to obtain the number of double parameters
				 */
				virtual int doubleParameterSize();

				/**
				 * This funciton gives back the number of integer parameters.
				 * @return Number of inteter parameters
				 * @brief Function to obtain the number of integer parameters
				 */
				virtual int intParameterSize();

				/**
				 * This function sets the value of a double parameter.
				 * @param paramid Index of the parameter
				 * @param value Value of the parameter
				 * @throw IndexException Is throw if an invalid index is submitted
				 * @brief Function to set the value of a double parameter
				 */
				virtual void setDoubleParameter ( int paramid, double value );

				/**
				 * This function sets the values of integer parameters.
				 * @param paramid Index of the parameter
				 * @param value Value of the parameter
				 * @throw IndexException Is throw if an invalid index is submitted
				 * @brief Function to set the value of a integer parameter
				 */
				virtual void setIntParameter ( int paramid, int value );

				/**
				 * This function gives back the value of a double parameter.
				 * @param paramid Index of the parameter
				 * @throw IndexException Is throw if an invalid index is submitted
				 * @return Value of the parameter
				 * @brief Function to obtain the value of a double parameter
				 */
				virtual double doubleParameter ( int paramid );

				/**
				 * This function gives back the value of a integer parameter.
				 * @param paramid Index of the parameter
				 * @throw IndexException Is throw if an invalid index is submitted
				 * @return Value of the parameter
				 * @brief Function to obtain the value of a integer parameter
				 */
				virtual int intParameter ( int paramid );

				/**
				 * This function gives back the pointer of the yane::OdeSolve::OdeSolve object which is suitable for the considered class yane::Model::Model object
				 * @return Pointer of the yane::OdeSolve::OdeSolve object
				 * @brief Function to obtain the pointer of the yane::OdeSolve::OdeSolve object which is suitable for the considered class yane::Model::Model object
				 */
				virtual yane::OdeSolve::OdeSolveFirst * odeSolver();

				/**
				 * This function gives back the pointer of the yane::OdeSolve::OdeConfig object which is suitable for the yane::OdeSolve::OdeSolve object defined in the considered class yane::Model::Model object
				 * @return Pointer of the tmb::OdeSolve::OdeConfig object
				 * @brief Function to obtain the pointer of the yane::OdeSolve::OdeConfig object which is suitable for the yane::OdeSolve::OdeSolve object defined in the considered class yane::Model::Model object
				 */
				virtual yane::OdeSolve::OdeConfig * odeConfig();

				/**
				 * This function implements the dynamic of the system
				\f[ \dot{x}_{u}(t) = f(t, x_{u}(t, x_0), u(t, x_0)) \f]
				 Note that the right hand side \f$ f( \cdot, \cdot, \cdot ) \f$ can be stated as a difference equation as well.
				 * @param t Time instant
				 * @param x State vector
				 * @param u Control vector
				 * @param dx Values of the derivatives
				 * @brief Function to implement the dynamic of the system
				\f[ \dot{x}_{u}(t) = f(t, x_{u}(t, x_0), u(t, x_0)) \f]
				 */
				virtual void odeFunction ( double t, double * x, double * u, double * dx ) = 0;

				/**
				 * This function implements the integral function of the cost function
				\f[ L \left( x_{u}(\cdot, x_0), u(\cdot, x_0) \right) \f]
				 * @param t Time instant
				 * @param x State vector
				 * @param u Control vector
				 * @return Value of the integral function
				 * @brief Function to implement the integral part of the cost function
				\f[ L \left( t, x_{u}(t, x_0), u(t, x_0) \right) \f]
				 */
				virtual double continuousCostfunction ( double t, double * x, double * u ) = 0;

				/**
				 * This function implements the nonlinear constraints
				\f{eqnarray*}{
				x_{u}(t, x_0) & \in & X \qquad \forall t \in [t_0, t_N] \\
				u(t, x_0) & \in & U \qquad \forall t \in [t_k, t_k)
				\f}
				of the control system. By definition, these constraints have to be of the form
				\f[ r(t, x(t), u(t)) >= 0 \f]
				 * @param t Time instant
				 * @param x State vector
				 * @param u Control vector
				 * @param fx Values of the constraints
				 * @sa getRestrictionSize
				 * @brief Function to implement the nonlinear constraints
				\f{eqnarray*}{
				x_{u}(t, x_0) & \in & X \qquad \forall t \in [t_0, t_N] \\
				u(t, x_0) & \in & U \qquad \forall t \in [t_k, t_k)
				\f}
				 */
				virtual void restrictionFunction ( double t, double * x, double * u, double * fx ) = 0;

				/**
				 * This function implements the mass matrix of the control system.
				 * @param mass Mass matrix
				 * @throw UndefinedException Is thrown if mass matrix is undefined
				 * @brief Function to implement the mass matrix of the control system
				 */
				virtual void massMatrix ( double * mass );

				/**
				 * This function implements the Jacobian of the constraints of the control system.
				 * @param t Time instant
				 * @param x State vector
				 * @param u Control vector
				 * @param dy Values of the Jacobian
				 * @throw UndefinedException Is thrown if Jacobian of the constraints is undefined
				 * @brief Function to implement the Jacobian of the constraints of the control system
				 */
				virtual void jacobiMatrix ( double t, double * x, double * u, double * dy );

				/**
				 * This function implements the gradient of the cost function of the control system.
				 * @param t Time instant
				 * @param x State vector
				 * @param u Control vector
				 * @param dobj Gradient of the cost function of the control system
				 * @throw UndefinedException Is thrown if gradient of the cost function is undefined
				 * @brief Function to implement the gradient of the cost function of the control system
				 */
				virtual void costfunctionGradient ( double t, double * x, double * u, double * dobj );

				/**
				 * This function implements the derivative with respect to time of the dynamic of the control system.
				 * @param t Time instant
				 * @param x State vector
				 * @param u Control vector
				 * @param dft Time derivative of the dynamic of the control system
				 * @throw UndefinedException Is thrown if time derivative of the dynamic is undefined
				 * @brief Function to implement the derivative with respect to time of the dynamic of the control system
				 */
				virtual void dynamicDerivativeT ( double t, double * x, double * u, double * dft );

				/**
				 * This function implements the derivative with respect to time of the cost function of the control system.
				 * @param t Time instant
				 * @param x State vector
				 * @param u Control vector
				 * @param dot Time derivative of the cost function of the control system
				 * @throw UndefinedException Is thrown if time derivative of the cost function is undefined
				 * @brief Function to implement the derivative with respect to time of the cost function of the control system
				 */
				virtual void costfunctionDerivativeT ( double t, double * x, double * u, double * dot );

				/**
				 * This function implements the discrete running cost as well as the terminal cost term of the cost function of the control system
				\f[ l \left( t_k, x_{u}(t_k, x_0), u(t_k, x_0) \right) \qquad \mbox{and} \qquad F(t_N, x_{u}(t_N, x_0)) \f]
				 * @param length Length of the sum
				 * @param horizont Length of the optimization horizon
				 * @param t Time grid
				 * @param x Open loop state trajectory on the time grid
				 * @param u Open loop control trajectory on the time grid
				 * @return Value of the discrete running cost
				 * @brief Function to implement the discrete running cost as well as the terminal cost term of the cost function of the control system
				\f[ l \left( t_k, x_{u}(t_k, x_0), u(t_k, x_0) \right) \qquad \mbox{and} \qquad F(t_N, x_{u}(t_N, x_0)) \f]
				 */
				virtual double discreteCostfunction ( int length, int horizont, double * t, double *x, double * u ) = 0;


				/**
				 * This function allows the user to put different weights on the integral and discrete time parts of the cost functional.
				 * @param obj_weight Weighting factor of the integral part of the cost function
				 * @param pointcost_weight Weighting factor of the discrete time part of the cost function
				 * @brief Function to put different weights on the integral and discrete time parts of the cost functional
				 */
				virtual void getObjectiveWeight ( double & obj_weight, double & pointcost_weight ) = 0;

				/**
				 * This function gives back the box constraints of the control.
				 * @param lb Pointer on lower bounds of the control
				 * @param ub Pointer on upper bounds of the control
				 * @sa getDimensionControl
				 * @brief Function to obtain the box constraints of the control
				 */
				virtual void getControlBounds ( double * lb, double * ub );

				/**
				 * This function sets the box constraints of the control.
				 * @param lb Pointer on lower bounds of the control
				 * @param ub Pointer on upper bounds of the control
				 * @brief Function to set the box constraints of the control
				 */
				virtual void setControlBounds ( double * lb, double * ub );

				/**
				 * This function gives back the box constraints of the state
				 * @param lb Pointer on lower bounds of the state
				 * @param ub Pointer on upper bounds of the state
				 * @sa getDimension
				 * @brief Function to get the box constraints of the state
				 */
				virtual void getModelBounds ( double * lb, double * ub );

				/**
				 * This function sets the box constraints of the state.
				 * @param lb Pointer on lower bounds of the state
				 * @param ub Pointer on upper bounds of the state
				 * @brief Function to set the box constraints of the state
				 */
				virtual void setModelBounds ( double * lb, double * ub );

				/**
				 * This function gives back the default values of the state defined for the control system under consideration.
				 * @param x Pointer for the default state
				 * @brief Function to get the default values defined for the control system under consideration
				 */
				virtual void getDefaultState ( double * x ) = 0;

				/**
				 * This function gives back the default values of the control defined for the control system under consideration.
				 * @param u Pointer for the default control
				 * @brief Function to get the default values of the control defined for the control system under consideration
				 */
				virtual void getDefaultControl ( double * u ) = 0;

				/**
				 * This function implements the internal resets for the yane::MPC::MPC class object at each iterate of the MPC process. This function allows, e.g., to switch between cost functions, right hand sides of the dynamic, restrictions and allows to set values for shooting nodes.
				 * @param horizon Optimization horizon
				 * @param timesteps Time grid
				 * @param x State vector
				 * @param sdatavalues Shooting node values
				 * @brief Function to implement the internal resets for the yane::MPC::MPC class object at each iterate of the MPC process
				 */
				virtual void eventBeforeMPC ( int horizon, double * timesteps, double * x, double * sdatavalues );

				virtual void exactDiscreteCostfunctionDerivativeX ( int length, int horizont, double * t, double * x, double * u, double * fx );
				virtual void exactContinuousCostfunctionDerivativeX ( double t, double * x, double * u, double * fx );
				virtual void exactContinuousCostfunctionDerivativeU ( double t, double * x, double * u, double * fx );
				virtual void exactOdeFunctionDerivativeX ( double t, double * x, double * u, double ** fx );
				virtual void exactOdeFunctionDerivativeU ( double t, double * x, double * u, double ** fx );
				virtual void exactRestrictionFunctionDerivativeX ( double t, double * x, double * u, double ** fx );
				virtual void exactRestrictionFunctionDerivativeU ( double t, double * x, double * u, double ** fx );

				virtual const yane::Utils::Uuid & id();
				virtual const char * name();
				virtual const char * description();
				virtual const char * stateName(int dimindex);
				virtual const char * controlName(int dimindex);
				virtual const char * doubleParameterName(int parindex);
				virtual const char * intParameterName(int parindex);
				
				/**
				 * This function implements the nonlinear constraints of the decentralized control system with are induced by neighbouring systems. By definition, these constraints have to be of the form
				\f[ r(t, x(t), u(t)) >= 0 \f]
				 * @param t Time instant
				 * @param x State vector
				 * @param u Control vector
				 * @param x_neighbour State vector of the neighbouring system
				 * @param u_neighbour Control vector of the neighbouring system
				 * @param fx Values of the constraints
				 * @sa getRestrictionSize
				 * @brief Function to implement the nonlinear constraints of the decentralized control system with are induced by neighbouring systems
				 */
				virtual void networkRestrictionFunction ( double t, double * x, double * u, double * x_neighbour, double * u_neighbour, double * fx );

				/**
				 * This function sets the number of the restrictions due to the network context.
				 * @return Number of restrictions due to the network context
				 * @brief Function to set the number of restrictions due to the network context
				 */
				virtual void setNetworkRestrictionSize ( int networkrestrsize );

				/**
				 * This function gives back the number of restrictions due to the network context.
				 * @return Number of restrictions due to the network context
				 * @brief Function to obtain the number of restrictions due to the network context
				 */
				virtual int networkRestrictionSize();

				/**
				 * This function implements the discrete running cost as well as the terminal cost term of the cost function of the control system in a networked context
				 * @param length Length of the sum
				 * @param horizont Length of the optimization horizon
				 * @param t Time grid
				 * @param x Open loop state trajectory on the time grid
				 * @param u Open loop control trajectory on the time grid
				 * @param x_neighbour State vector of the neighbouring system
				 * @param u_neighbour Control vector of the neighbouring system
				 * @return Value of the discrete running cost
				 * @brief Function to implement the discrete running cost as well as the terminal cost term of the cost function of the control system in a networked context
				 */
				virtual double networkCostfunction ( int length, int horizont, double * t, double * x, double * u, double * x_neighbour, double * u_neighbour, double * multiplier );


			protected:

				/**
				 * Constructor
				 * @param ode Pointer to the used yane::OdeSolve::OdeSolveFirst object
				 * @param odeconf Pointer to the used yane::OdeSolve::OdeConfig object
				 * @param dimension Dimension of the state variable
				 * @param ctrl_dimension Dimension of the control variable
				 * @param restrsize Number of nonlinear constraints
				 * @param paramsize Number of double parameters
				 * @param iparamsize Number of integer parameters
				 * @param networkrestrsize Number of restrictions per model arising from the network context
				 * @throw yane::Utils::MemoryException Is thrown if the memory allocation failed
				 * @brief Constructor
				 */
				Model ( yane::OdeSolve::OdeSolveFirst * ode, yane::OdeSolve::OdeConfig * odeconf, int dimension, int ctrl_dimension, int restrsize, int paramsize = 0, int iparamsize = 0, int networkrestrsize = 0 );

				int _dimension;    /**< @brief Dimension of the state variable */
				int _ctrl_dimension;   /**< @brief Dimension of the control variable */
				int _paramsize;    /**< @brief Number of double parameters */
				int _iparamsize;   /**< @brief Number of integer parameters */
				int _restrsize;    /**< @brief Number of nonlinear constraints */
				int _network_restrsize;    /**< @brief Number of nonlinear constraints due to the network context */
				double * _params;   /**< @brief Array of double parameters */
				int * _iparams;    /**< @brief Array of integer parameters */
				yane::OdeSolve::OdeSolveFirst * _ode; /**< @brief Pointer to the used yane::OdeSolve::OdeSolveFirst object */
				yane::OdeSolve::OdeConfig * _odeconfig; /**< @brief Pointer to the used yane::OdeSolve::OdeConfig object */

				double * _control_lb;   /**< @brief Array of lower bounds on the control */
				double * _control_ub;   /**< @brief Array of upper bounds on the control */
				double * _state_lb;   /**< @brief Array of lower bounds on the state */
				double * _state_ub;   /**< @brief Array of upper bounds on the state */

			private:
				/**
				 * @brief Locked constructor
				*/
				Model();

				/**
				 * @brief Locked constructor
				 */
				Model ( Model & input );
		};

	}

}

#endif
